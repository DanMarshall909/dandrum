import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

root = Path('/home/dan/code/.worktrees/dandrum/feat-juce-free-host-adapters')
out = Path('/home/dan/code/dandrum/.git/codex/landing-20261101')
cmake = '/home/dan/.local/bin/cmake'
ctest = '/home/dan/.local/bin/ctest'
xvfb = '/home/dan/.cache/dandrum-trigger-beta/xvfb/root/usr/bin'
env = dict(os.environ)
env.update(PATH='/usr/bin:/bin:/home/dan/.cargo/bin:/home/dan/.local/bin:' + xvfb + ':' + env['PATH'], CARGO_NET_OFFLINE='true', LIBGL_ALWAYS_SOFTWARE='1', GDK_BACKEND='x11', NO_AT_BRIDGE='1', __EGL_VENDOR_LIBRARY_FILENAMES='/usr/share/glvnd/egl_vendor.d/50_mesa.json')
records = []

def run(name, command, junit=None, heavy=False):
    if heavy:
        admission = subprocess.run(['python3', '/home/dan/.agents/skills/storage-budget/scripts/storage_budget.py', 'check', '--config', str(root / '.ai-rules.json'), '--workload', 'trigger-beta-verification', '--output-parent', str(root / 'build'), '--temp-parent', env.get('TMPDIR', '/tmp')], cwd=root, env=env, capture_output=True, text=True)
        (out / (name + '-storage.json')).write_text(admission.stdout)
        if admission.returncode:
            print(admission.stdout, admission.stderr, flush=True)
            raise SystemExit(admission.returncode)
    print('START ' + name, flush=True)
    start = time.time()
    log = out / (name + '.log')
    with log.open('w') as f:
        result = subprocess.run(command, cwd=root, env=env, stdout=f, stderr=subprocess.STDOUT)
    record = {'name': name, 'command': command, 'cwd': str(root), 'started_unix': start, 'elapsed_seconds': round(time.time() - start, 3), 'exit_status': result.returncode, 'log': log.name}
    if junit and result.returncode == 0:
        cases = list(ET.parse(junit).getroot().iter('testcase'))
        skipped = [c.attrib.get('name') for c in cases if c.find('skipped') is not None or c.attrib.get('status') in ('notrun', 'disabled')]
        record.update(test_count=len(cases), skipped=skipped)
        if skipped or not cases:
            record['acceptance_failure'] = 'Required regression tests were skipped or absent.'
    records.append(record)
    (out / 'combined-regression.json').write_text(json.dumps(records, indent=2) + '\n')
    print('END ' + name + ' ' + json.dumps(record), flush=True)
    if result.returncode or record.get('acceptance_failure'):
        print(log.read_text()[-5000:], flush=True)
        raise SystemExit(result.returncode or 1)

native_xml = str(out / 'native-regression.xml')
run('native-regression', [xvfb + '/xvfb-run', '-a', '-s', '-screen 0 1920x1200x24 -nolisten tcp', ctest, '--test-dir', 'build/native-session', '--output-on-failure', '--output-junit', native_xml, '-R', '^(cxx-rust-engine-(ffi|sample-accurate-midi)-smoke|cxx-plugin-(instrument-session|engine-handoff(-baseline)?|live-handoff|automatic-reload|reload-job-contracts)|native-session-link-graph|native-editor-smoke)$'], junit=native_xml)
run('web-configure', [cmake, '-S', '.', '-B', 'build/web-host'], heavy=True)
run('web-build', [cmake, '--build', 'build/web-host', '--target', 'dandrum-trigger-native-bridge-test', '--parallel', '2'], heavy=True)
web_xml = str(out / 'web-regression.xml')
run('web-regression', [xvfb + '/xvfb-run', '-a', '-s', '-screen 0 1920x1200x24 -nolisten tcp', ctest, '--test-dir', 'build/web-host', '--output-on-failure', '--output-junit', web_xml, '-R', '^(cxx-trigger-native-bridge|trigger-web-runtime)$'], junit=web_xml)
run('engine-only-build', [cmake, '--build', 'build/engine-only', '--parallel', '1'], heavy=True)
engine_xml = str(out / 'engine-regression.xml')
run('engine-regression', [ctest, '--test-dir', 'build/engine-only', '--output-on-failure', '--output-junit', engine_xml, '-LE', 'native-x11'], junit=engine_xml, heavy=True)
