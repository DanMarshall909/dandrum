import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

with tempfile.TemporaryDirectory(prefix='landing-wm-') as directory:
    env = dict(os.environ)
    env['XDG_CONFIG_HOME'] = directory + '/config'
    env['XDG_CACHE_HOME'] = directory + '/cache'
    Path(env['XDG_CONFIG_HOME']).mkdir()
    Path(env['XDG_CACHE_HOME']).mkdir()
    with (Path(directory) / 'wm.log').open('w+') as log:
        manager = subprocess.Popen(['xfwm4', '--sm-client-disable', '--compositor=off'], env=env, stdout=log, stderr=subprocess.STDOUT)
        try:
            for _ in range(100):
                probe = subprocess.run(['xprop', '-root', '_NET_SUPPORTING_WM_CHECK'], env=env, capture_output=True, text=True)
                if 'window id # 0x' in probe.stdout and 'window id # 0x0' not in probe.stdout:
                    print('PRIVATE_WINDOW_MANAGER_READY ' + probe.stdout.strip(), flush=True)
                    break
                if manager.poll() is not None:
                    raise RuntimeError('Private window manager exited before readiness')
                time.sleep(0.05)
            else:
                raise RuntimeError('Private window manager did not publish readiness')
            result = subprocess.run(sys.argv[1:], env=env)
        finally:
            manager.terminate()
            try:
                manager.wait(timeout=5)
            except subprocess.TimeoutExpired:
                manager.kill()
                manager.wait()
            log.seek(0)
            print('PRIVATE_WINDOW_MANAGER_STOPPED\n' + log.read(), flush=True)
        raise SystemExit(result.returncode)
