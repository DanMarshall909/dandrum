from pathlib import Path
import json,subprocess,sys,time
out=Path(__file__).parent;root=Path('/tmp/dandrum-lanes/integration');driver=out/'run-check.py';cargo='/home/dan/.cargo/bin/cargo'
checks=[
 ('final-format-engine',[cargo,'fmt','--manifest-path','src/rust-engine/Cargo.toml','--','--check'],0),
 ('final-format-host',[cargo,'fmt','--manifest-path','src/trigger-host/Cargo.toml','--','--check'],0),
 ('final-engine-all-targets',[cargo,'test','--offline','--locked','--manifest-path','src/rust-engine/Cargo.toml'],0),
 ('final-host-tests',[cargo,'test','--offline','--locked','--manifest-path','src/trigger-host/Cargo.toml'],0),
 ('final-host-clippy',[cargo,'clippy','--offline','--locked','--manifest-path','src/trigger-host/Cargo.toml','--all-targets','--no-deps','--','-D','warnings'],0),
 ('final-engine-clippy-strict',[cargo,'clippy','--offline','--locked','--manifest-path','src/rust-engine/Cargo.toml','--lib','--tests','--message-format=json','--','-D','warnings'],101),
 ('final-engine-clippy-diagnostics',[cargo,'clippy','--offline','--locked','--manifest-path','src/rust-engine/Cargo.toml','--lib','--tests','--message-format=json'],0)]
results=[]
for label,cmd,expected in checks:
 started=time.monotonic();p=subprocess.run([sys.executable,str(driver),label,'ordinary',*cmd],cwd=root,capture_output=True,text=True)
 (out/(label+'-launcher.log')).write_text(p.stdout+p.stderr)
 results.append({'phase':label,'exit':p.returncode,'expected':expected,'seconds':time.monotonic()-started,'qualification':'Known strict engine baseline failure retained, NOT PASS' if expected else 'Required passing check'})
 print(json.dumps(results[-1]),flush=True)
 (out/'final-checks-progress.json').write_text(json.dumps(results,indent=2)+'\n')
 if p.returncode!=expected:sys.exit(p.returncode if p.returncode else 1)
for label,cmd in [('selected',['openspec','validate','add-juce-free-trigger-beta-products','--strict']),('canonical',['openspec','validate','--specs','--strict']),('spec-map',['scripts/check-spec-coverage']),('diff',['git','diff','--check']),('cached',['git','diff','--cached','--check'])]:
 started=time.monotonic();p=subprocess.run(cmd,cwd=root,capture_output=True,text=True);(out/('final-'+label+'.log')).write_text(p.stdout+p.stderr);results.append({'phase':label,'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-started});print(json.dumps(results[-1]),flush=True)
 if p.returncode:sys.exit(p.returncode)
(out/'final-checks.json').write_text(json.dumps(results,indent=2)+'\n')
