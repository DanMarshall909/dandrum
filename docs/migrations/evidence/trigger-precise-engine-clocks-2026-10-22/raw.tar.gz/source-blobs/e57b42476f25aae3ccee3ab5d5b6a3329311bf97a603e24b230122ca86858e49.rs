use std::fs;

use crate::core::TimedInputEvent;
use crate::diagnostics::error_codes;
use crate::graph::{PortDirection, SignalType};
use crate::graph_processor::RealtimeGraphProcessor;
use crate::graph_processor::render_kernel_offline_named;
use crate::kernel::{
    ChannelCount, ControlDefault, DefinitionImplementation, GraphDefinition,
    POLY_ALLOCATION_OLDEST_STEAL, POLY_DEFINITION, POLY_NOTE_EVENTS_INPUT, Port, ResourceKind,
    ResourceOrigin, ResourceRef, StaticArg, StaticType, StaticValue,
};
use crate::patch::RenderSettings;
use crate::patch::load_preset_str;
use crate::preparation::{
    PreparationContext, prepare_kernel_patch_with_context, prepare_kernel_patch_with_preset,
    prepare_kernel_patch_with_preset_and_context,
};
use crate::sample::PreparedSamplerAssets;
use crate::script::ScriptEvent;

use super::{load_kernel_definition_str, load_kernel_patch_file, load_kernel_patch_str};

#[test]
fn realtime_clock_admission_retains_exact_supported_rates_and_legacy_settings() {
    use crate::render_settings::{RealtimeRenderSettings, SampleRate};

    for hz in [1.0, 1_234.567_8, 48_000.5, f64::from(u32::MAX)] {
        let rate = SampleRate::new(hz).expect("supported realtime clock");
        assert_eq!(rate.hz(), hz);
    }
    let first = SampleRate::new(48_000.0).unwrap();
    let nearby = SampleRate::new(48_000.000_001).unwrap();
    assert_eq!(first.hz() as f32, nearby.hz() as f32);
    assert_ne!(
        first, nearby,
        "configuration identity must retain the f64 clock"
    );

    let legacy = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 31,
        duration_frames: 1_017,
    };
    let realtime = RealtimeRenderSettings::try_from(&legacy).unwrap();
    assert_eq!(realtime.sample_rate_hz, first);
    assert_eq!(realtime.block_size_frames, 31);
    assert_eq!(realtime.duration_frames, 1_017);
    assert_eq!(
        serde_json::to_value(&legacy).unwrap()["sample_rate_hz"],
        48_000
    );
}

#[test]
fn realtime_clock_admission_rejects_invalid_values_before_preparation() {
    use crate::render_settings::{RealtimeRenderSettings, SampleRate};

    for hz in [
        f64::NAN,
        f64::INFINITY,
        f64::NEG_INFINITY,
        -48_000.0,
        -0.0,
        0.0,
        0.5,
        f64::from(u32::MAX) + 0.5,
    ] {
        let error = SampleRate::new(hz).expect_err("unsupported clock must be rejected");
        assert!(error.to_string().contains("sample rate"));
    }
    let zero = RenderSettings {
        sample_rate_hz: 0,
        block_size_frames: 31,
        duration_frames: 1_017,
    };
    assert!(RealtimeRenderSettings::try_from(&zero).is_err());
}

#[test]
fn kernel_preparation_rejects_zero_clock_before_building_a_runtime() {
    let patch = load_kernel_patch_str(
        r#"
ports:
  - { name: master, direction: output, signal: audio, channels: 1, maps_from: source.out }
modules:
  - { id: source, type: control_to_audio, defaults: { in: -0.5 } }
"#,
    )
    .expect("signed constant patch");
    let valid = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    let valid_prepared = crate::preparation::prepare_kernel_patch(&patch, &valid)
        .expect("the same graph prepares at a supported integer clock");
    let zero = RenderSettings {
        sample_rate_hz: 0,
        block_size_frames: 16,
        duration_frames: 16,
    };
    let error = crate::preparation::prepare_kernel_patch(&patch, &zero)
        .expect_err("a zero clock cannot enter an accepted prepared instrument");
    assert!(error.diagnostics().errors().any(|diagnostic| {
        diagnostic.error_code() == error_codes::VALIDATION_INVALID_VALUE
            && diagnostic.message().contains("sample rate")
    }));
    let compile_error = crate::compiled_patch::compile(valid_prepared.graph(), &zero)
        .expect_err("legacy compilation also requires an admitted clock");
    assert!(
        compile_error
            .to_diagnostic()
            .message()
            .contains("render.sample_rate_hz")
    );
}

#[test]
fn fractional_clocks_keep_signed_cursor_and_duration_for_each_sample_player() {
    use crate::preparation::prepare_kernel_patch_realtime_with_context;
    use crate::render_settings::{RealtimeRenderSettings, SampleRate};

    let directory = tempfile::tempdir().expect("owned sample root");
    // Every negative value has an exact PCM16 representation. The nonconstant
    // ramp exposes truncated low-rate interpolation as well as duration drift.
    let values: Vec<f32> = (0..1_024)
        .map(|frame| -0.75 + frame as f32 / 4_096.0)
        .collect();
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).unwrap(),
        48_000,
        &values,
        &values,
    )
    .unwrap();
    for (kind, construction, event_input) in [
        (
            "sample_player",
            "source: hit, region: body, channels: 1",
            "trigger",
        ),
        (
            "sample_slicer",
            "source: hit, slice_table: hit, channels: 1",
            "trigger",
        ),
        (
            "sample_map_player",
            "sample_map: kit, max_voices: 1, channels: 1",
            "note",
        ),
    ] {
        let yaml = format!(
            r#"
metadata: {{ name: precise_sample_clock }}
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{{ id: body, start_frame: 0, end_frame: 1024 }}]
      slices: [{{ id: whole, start_frame: 0, end_frame: 1024 }}]
  sample_maps:
    - id: kit
      zones: [{{ region: hit.body, key_range: [36, 36], velocity_range: [1, 127] }}]
ports:
  - {{ name: master, direction: output, signal: audio, channels: 1, maps_from: player.audio }}
modules:
  - {{ id: midi, type: midi_input }}
  - {{ id: player, type: {kind}, static: {{ {construction} }} }}
connections:
  - {{ from: midi.events, to: player.{event_input} }}
"#
        );
        let patch = load_kernel_patch_str(&yaml).expect("sample player fixture loads");
        for hz in [48_000.0, 1_234.567_8, 48_000.5, 48_000.000_001] {
            let rate = SampleRate::new(hz).unwrap();
            let settings = RealtimeRenderSettings {
                sample_rate_hz: rate,
                block_size_frames: 64,
                duration_frames: 1_026,
            };
            let context = PreparationContext::new_realtime(directory.path(), rate);
            let prepared = prepare_kernel_patch_realtime_with_context(&patch, &settings, &context)
                .expect("supported precise sample clock prepares");
            assert_eq!(context.sample_rate_hz(), hz);
            assert_eq!(prepared.compiled_patch().render_settings(), &settings);
            assert_eq!(
                prepared.sample_assets().sources()[0]
                    .sample()
                    .sample_rate_hz(),
                48_000
            );
            let rendered = render_kernel_offline_named(
                &prepared,
                vec![TimedInputEvent::new(
                    0,
                    ScriptEvent::NoteOn {
                        note: 36,
                        velocity: 100,
                    },
                )],
                &PreparedSamplerAssets::empty(),
            )
            .expect("precise sample clock renders");
            let audio = &rendered[0].1[0];
            assert_eq!(audio[0], -0.75, "{kind} at {hz}");
            let sounding_frames = (1_024.0 * hz / 48_000.0).ceil() as usize;
            assert_ne!(
                audio[sounding_frames - 1],
                0.0,
                "last sounding frame: {kind} at {hz}"
            );
            if hz >= 48_000.0 {
                assert_eq!(
                    audio[sounding_frames - 1],
                    values[1_023],
                    "held final source frame: {kind} at {hz}"
                );
            }
            assert_eq!(
                audio[sounding_frames], 0.0,
                "first silent frame: {kind} at {hz}"
            );
            for (frame, actual) in audio.iter().copied().enumerate() {
                let position = frame as f64 * 48_000.0 / hz;
                let expected = if position < 1_024.0 {
                    (-0.75 + position.min(1_023.0) / 4_096.0) as f32
                } else {
                    0.0
                };
                assert!(
                    (actual - expected).abs() <= 0.000_000_2,
                    "{kind} at {hz}, frame {frame}: {actual} != {expected}"
                );
            }
        }
    }
}

#[test]
fn sample_slicer_nonfinite_pitch_keeps_signed_default_playback() {
    let directory = tempfile::tempdir().unwrap();
    let values = [-0.5, -0.25, -0.125, -0.0625];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).unwrap(),
        48_000,
        &values,
        &values,
    )
    .unwrap();
    let patch = load_kernel_patch_str(
        r#"
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      slices: [{ id: whole, start_frame: 0, end_frame: 4 }]
ports:
  - { name: master, direction: output, signal: audio, channels: 1, maps_from: slicer.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: slicer, type: sample_slicer, static: { source: hit, slice_table: hit, channels: 1 } }
connections:
  - { from: midi.events, to: slicer.trigger }
"#,
    )
    .unwrap();
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 4,
            duration_frames: 4,
        },
        &PreparationContext::new(directory.path(), 48_000),
    )
    .unwrap();
    for invalid in [f32::NAN, f32::INFINITY, f32::NEG_INFINITY] {
        let mut runtime = RealtimeGraphProcessor::from_compiled_patch(
            prepared.compiled_patch().clone(),
            48_000.0,
            &PreparedSamplerAssets::empty(),
            4,
        );
        let pitch = runtime
            .parameter_slot_index("slicer", "pitch_ratio")
            .unwrap();
        let mut output = vec![vec![vec![0.0; 4]]];
        assert!(runtime.set_parameter_slot(pitch, 2.0));
        runtime.note_on(60, 100);
        assert_eq!(runtime.render_root_outputs(&mut output), 4);
        assert_eq!(
            output[0][0],
            [-0.5, -0.125, 0.0, 0.0],
            "finite pitch control witness"
        );
        runtime.reset();
        assert!(runtime.set_parameter_slot(pitch, 2.0));
        let allocations = crate::test_allocator::count_current_thread_allocations(|| {
            assert!(runtime.set_parameter_slot(pitch, invalid));
            runtime.note_on(60, 100);
            assert_eq!(runtime.render_root_outputs(&mut output), 4);
        });
        assert_eq!(allocations, 0);
        assert_eq!(
            output[0][0], values,
            "nonfinite pitch uses the natural rate"
        );
    }
}

#[test]
fn bundled_advanced_sampling_examples_prepare_and_emit_signed_stereo_hits() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    for (name, note, first_sample) in [
        ("advanced-one-shot.yaml", 36, -0.5),
        ("advanced-drum-kit.yaml", 36, -0.5),
        ("advanced-hats.yaml", 46, -0.0625),
        ("advanced-chromatic.yaml", 60, -0.5),
        ("advanced-break-slicer.yaml", 60, -0.5),
    ] {
        let path = root.join("examples/patches").join(name);
        let patch = load_kernel_patch_file(&path).expect("example loads");
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 4,
            duration_frames: 4,
        };
        let prepared = prepare_kernel_patch_with_context(
            &patch,
            &settings,
            &PreparationContext::new(path.parent().unwrap(), 48_000),
        )
        .expect(name);
        let rendered = render_kernel_offline_named(
            &prepared,
            vec![TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note,
                    velocity: 100,
                },
            )],
            &PreparedSamplerAssets::empty(),
        )
        .expect("example renders");
        assert_eq!(rendered[0].0, "master");
        assert_eq!(rendered[0].1.len(), 2);
        assert_eq!(rendered[0].1[0][0], first_sample, "{name} left");
        assert_eq!(rendered[0].1[1][0], first_sample, "{name} right");
    }
}

#[test]
fn bundled_drum_kit_selects_velocity_layers_alternates_and_hat_choke() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let path = root.join("examples/patches/advanced-drum-kit.yaml");
    let patch = load_kernel_patch_file(&path).expect("drum kit loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 4,
        duration_frames: 12,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(path.parent().unwrap(), 48_000),
    )
    .expect("drum kit prepares");
    let render = |events| {
        render_kernel_offline_named(&prepared, events, &PreparedSamplerAssets::empty())
            .expect("drum kit renders")[0]
            .1[0]
            .clone()
    };
    let hit =
        |frame, note, velocity| TimedInputEvent::new(frame, ScriptEvent::NoteOn { note, velocity });

    let soft = render(vec![hit(0, 38, 40)]);
    let hard = render(vec![hit(0, 38, 100)]);
    assert_eq!(soft[0], -0.25);
    assert_eq!(hard[0], -0.375);
    let two_hard = render(vec![hit(0, 38, 100), hit(4, 38, 100)]);
    assert_eq!(two_hard[4] - hard[4], -0.4375);

    let hats = render(vec![hit(0, 46, 100), hit(4, 42, 100)]);
    assert_eq!(hats[0], -0.0625);
    assert_eq!(hats[4], -0.125);
    let with_kick = render(vec![hit(0, 46, 100), hit(0, 36, 100), hit(4, 42, 100)]);
    let kick = render(vec![hit(0, 36, 100)]);
    assert_eq!(with_kick[4], kick[4] - 0.125);
}

#[test]
fn bundled_sampler_presets_use_public_names_and_change_rendered_audio() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let cases = [
        (
            "advanced-drum-kit.yaml",
            "advanced-drum-kit-quiet-left.yaml",
            36,
            -0.25,
            0.0,
        ),
        (
            "advanced-break-slicer.yaml",
            "advanced-break-fill.yaml",
            60,
            0.5,
            0.5,
        ),
    ];
    for (patch_name, preset_name, note, left, right) in cases {
        let path = root.join("examples/patches").join(patch_name);
        let patch = load_kernel_patch_file(&path).expect("sample patch loads");
        let preset_yaml = fs::read_to_string(root.join("examples/presets").join(preset_name))
            .expect("preset file");
        let preset = load_preset_str(&preset_yaml).expect("preset parses");
        let applied = patch.apply_preset(&preset).expect("public preset applies");
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 4,
            duration_frames: 4,
        };
        let prepared = prepare_kernel_patch_with_context(
            &applied,
            &settings,
            &PreparationContext::new(path.parent().unwrap(), 48_000),
        )
        .expect("preset patch prepares");
        let rendered = render_kernel_offline_named(
            &prepared,
            vec![TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note,
                    velocity: 100,
                },
            )],
            &PreparedSamplerAssets::empty(),
        )
        .expect("preset patch renders");
        assert_eq!(rendered[0].1[0][0], left, "{preset_name} left");
        assert_eq!(rendered[0].1[1][0], right, "{preset_name} right");
    }
}

#[test]
fn drum_public_pitch_start_and_variation_controls_change_selected_hits() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let path = root.join("examples/patches/advanced-drum-kit.yaml");
    let patch = load_kernel_patch_file(&path).expect("drum kit loads");
    let source = crate::audio_loading::load_pcm_wav(
        &root.join("examples/patches/assets/advanced-drums.wav"),
        48_000,
    )
    .expect("source loads");
    let render_values = |values: &str, note: u8| {
        let preset = load_preset_str(&format!(
            "name: Modulated Drum\ninstrument: {{ id: dandrum.advanced-drum-kit, preset_schema_version: 1 }}\nvalues:\n{values}\n"
        )).expect("public preset parses");
        let applied = patch.apply_preset(&preset).expect("public preset applies");
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 4,
            duration_frames: 4,
        };
        let prepared = prepare_kernel_patch_with_context(
            &applied,
            &settings,
            &PreparationContext::new(path.parent().unwrap(), 48_000),
        )
        .expect("modulated kit prepares");
        render_kernel_offline_named(
            &prepared,
            vec![TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note,
                    velocity: 100,
                },
            )],
            &PreparedSamplerAssets::empty(),
        )
        .expect("modulated kit renders")[0]
            .1[0]
            .clone()
    };
    let render = |parameter: &str, value: f32, note: u8| {
        render_values(&format!("  drums.{parameter}: {value}"), note)
    };

    let pitched = render("pitch_ratio", 2.0, 36);
    assert_eq!(pitched[0], -0.5);
    assert_eq!(pitched[1], source.frames()[2]);
    let started = render("start_offset", 0.5, 36);
    let expected = (source.frames()[5999] + source.frames()[6000]) * 0.5;
    assert!((started[0] - expected).abs() < 0.00001);
    assert_ne!(started[0], -0.5);
    assert_eq!(render("kick.pitch_ratio", 2.0, 36)[1], source.frames()[2]);
    assert!((render("kick.start_offset", 0.5, 36)[0] - expected).abs() < 0.00001);
    assert_eq!(render("kick.level", 0.5, 36)[0], -0.25);
    assert_eq!(render("kick.pan", 1.0, 36)[0], 0.0);
    assert!(
        (render_values(
            "  drums.start_offset: 0.125\n  drums.kick.start_offset: 0.375",
            36
        )[0] - expected)
            .abs()
            < 0.00001
    );

    assert_eq!(render("variation", 0.0, 38)[0], -0.375);
    assert_eq!(render("variation", 1.0, 38)[0], -0.4375);
    assert_eq!(render("snare.variation", 1.0, 38)[0], -0.4375);
    assert_eq!(
        render_values("  drums.variation: 0.25\n  drums.snare.variation: 0.75", 38)[0],
        -0.4375
    );

    let preset = load_preset_str("name: Alternate Hats\ninstrument: { id: dandrum.advanced-drum-kit, preset_schema_version: 1 }\nvalues: { drums.variation: 1 }\n")
        .expect("variation preset parses");
    let varied = patch.apply_preset(&preset).expect("variation applies");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 4,
        duration_frames: 4,
    };
    let prepared = prepare_kernel_patch_with_context(
        &varied,
        &settings,
        &PreparationContext::new(path.parent().unwrap(), 48_000),
    )
    .expect("varied hats prepare");
    let hats = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 46,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                2,
                ScriptEvent::NoteOn {
                    note: 42,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("varied hats render");
    let alternate_open = -0.0625 * 10.0_f32.powf(-6.0 / 20.0);
    assert!((hats[0].1[0][0] - alternate_open).abs() < 0.000001);
    assert_eq!(hats[0].1[0][2], -0.125);

    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(path.parent().unwrap(), 48_000),
    )
    .expect("unmodulated kit prepares");
    let mut runtime = RealtimeGraphProcessor::polyphonic_with_compiled_patch_and_sampler_assets_and_max_block_size(
        prepared.graph().clone(), prepared.compiled_patch().clone(), 48_000.0,
        &PreparedSamplerAssets::empty(), &crate::patch::VoiceAllocation::default(), 4,
    );
    let variation_slot = runtime
        .parameter_slot_index("player", "variation")
        .expect("live variation slot");
    let mut output = vec![vec![vec![0.0; 4]; 2]];
    runtime.note_on(38, 100);
    assert_eq!(runtime.render_root_outputs(&mut output), 4);
    assert_eq!(output[0][0][0], -0.375);
    runtime.reset();
    assert!(runtime.set_parameter_slot(variation_slot, 1.0));
    let allocations = crate::test_allocator::count_current_thread_allocations(|| {
        runtime.note_on(38, 100);
        assert_eq!(runtime.render_root_outputs(&mut output), 4);
    });
    assert_eq!(allocations, 0);
    assert_eq!(output[0][0][0], -0.4375);
}

#[test]
fn bundled_chromatic_and_hat_examples_follow_root_note_and_choke_group() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    let examples = root.join("examples/patches");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 4,
        duration_frames: 8,
    };
    let render = |name: &str, events| {
        let path = examples.join(name);
        let patch = load_kernel_patch_file(&path).expect("example loads");
        let prepared = prepare_kernel_patch_with_context(
            &patch,
            &settings,
            &PreparationContext::new(path.parent().unwrap(), 48_000),
        )
        .expect("example prepares");
        render_kernel_offline_named(&prepared, events, &PreparedSamplerAssets::empty())
            .expect("example renders")[0]
            .1[0]
            .clone()
    };
    let hit = |frame, note| {
        TimedInputEvent::new(
            frame,
            ScriptEvent::NoteOn {
                note,
                velocity: 100,
            },
        )
    };
    let root_note = render("advanced-chromatic.yaml", vec![hit(0, 60)]);
    let octave = render("advanced-chromatic.yaml", vec![hit(0, 72)]);
    let tone =
        crate::audio_loading::load_pcm_wav(&examples.join("assets/advanced-tone.wav"), 48_000)
            .expect("reference tone");
    assert_eq!(root_note[0], -0.5);
    assert_eq!(octave[0], -0.5);
    assert_eq!(root_note[1], tone.frames()[1]);
    assert_eq!(octave[1], tone.frames()[2]);

    let hats = render("advanced-hats.yaml", vec![hit(0, 46), hit(4, 42)]);
    assert_eq!(hats[0], -0.0625);
    assert_eq!(hats[4], -0.125);
}

#[test]
fn prepared_sampling_examples_keep_source_pitch_at_common_host_rates() {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
    for (patch_name, asset_name, note) in [
        ("advanced-one-shot.yaml", "advanced-drums.wav", 36),
        ("advanced-drum-kit.yaml", "advanced-drums.wav", 36),
        ("advanced-break-slicer.yaml", "advanced-break.wav", 60),
    ] {
        let patch_path = root.join("examples/patches").join(patch_name);
        let patch = load_kernel_patch_file(&patch_path).expect("sample patch loads");
        let source = crate::audio_loading::load_pcm_wav(
            &root.join("examples/patches/assets").join(asset_name),
            48_000,
        )
        .expect("48 kHz source loads");
        for host_rate in [44_100, 96_000] {
            let settings = RenderSettings {
                sample_rate_hz: host_rate,
                block_size_frames: 4,
                duration_frames: 4,
            };
            let prepared = prepare_kernel_patch_with_context(
                &patch,
                &settings,
                &PreparationContext::new(patch_path.parent().unwrap(), host_rate),
            )
            .expect("source prepares at host rate");
            let rendered = render_kernel_offline_named(
                &prepared,
                vec![TimedInputEvent::new(
                    0,
                    ScriptEvent::NoteOn {
                        note,
                        velocity: 100,
                    },
                )],
                &PreparedSamplerAssets::empty(),
            )
            .expect("cross-rate source renders");
            let position = 48_000.0 / f64::from(host_rate);
            let base = position.floor() as usize;
            let fraction = (position - base as f64) as f32;
            let expected = source.frames()[base]
                + fraction * (source.frames()[base + 1] - source.frames()[base]);
            assert_eq!(rendered[0].1[0][0], -0.5, "{patch_name} at {host_rate}");
            assert!(
                (rendered[0].1[0][1] - expected).abs() < 0.00001,
                "{patch_name} at {host_rate}"
            );
        }
    }
}

#[test]
fn drum_map_pitch_extremes_keep_signed_waveform_and_duration_across_host_rates() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let mut values = vec![-0.5; 16];
    values[1] = 0.5;
    values[8] = -0.25;
    values[9] = 0.25;
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    for (host_rate, musical_pitch, duration) in [(96_000, 0.125, 258), (44_100, 8.0, 4)] {
        let yaml = format!(
            r#"
metadata: {{ name: map_cross_rate_pitch }}
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{{ id: body, start_frame: 0, end_frame: 16 }}]
  sample_maps:
    - id: kit
      zones: [{{ region: hit.body, key_range: [36, 36], velocity_range: [1, 127] }}]
ports:
  - {{ name: master, direction: output, signal: audio, channels: 1, maps_from: player.audio }}
modules:
  - {{ id: midi, type: midi_input }}
  - {{ id: player, type: sample_map_player, static: {{ sample_map: kit, max_voices: 1, channels: 1 }}, defaults: {{ pitch_ratio: {musical_pitch} }} }}
connections:
  - {{ from: midi.events, to: player.note }}
"#
        );
        let patch = load_kernel_patch_str(&yaml).expect("drum map loads");
        let settings = RenderSettings {
            sample_rate_hz: host_rate,
            block_size_frames: 64,
            duration_frames: duration,
        };
        let prepared = prepare_kernel_patch_with_context(
            &patch,
            &settings,
            &PreparationContext::new(directory.path(), host_rate),
        )
        .expect("drum map prepares");
        let rendered = render_kernel_offline_named(
            &prepared,
            vec![TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            )],
            &PreparedSamplerAssets::empty(),
        )
        .expect("drum map renders");
        let audio = &rendered[0].1[0];
        let cursor_step = musical_pitch as f64 * 48_000.0 / f64::from(host_rate);
        let position = cursor_step;
        let base = position.floor() as usize;
        let fraction = (position - base as f64) as f32;
        let expected_second = values[base] + fraction * (values[base + 1] - values[base]);
        assert!((audio[0] + 0.5).abs() < 0.00001);
        assert!(
            (audio[1] - expected_second).abs() < 0.0001,
            "host rate {host_rate}"
        );
        let sounding_frames = (16.0 / cursor_step).ceil() as usize;
        assert_ne!(audio[sounding_frames - 1], 0.0, "host rate {host_rate}");
        assert_eq!(audio[sounding_frames], 0.0, "host rate {host_rate}");
    }
}

#[test]
fn drum_variation_skips_other_groups_and_velocity_layers_at_partial_amount() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.4375, -0.375, -0.3125, -0.25, -0.1875, -0.125];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    for (variation, expected) in [(0.0, -0.5), (0.5, -0.1875), (1.0, -0.125)] {
        let yaml = format!(
            r#"
metadata: {{ name: compatible_variation }}
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - {{ id: a, start_frame: 0, end_frame: 1 }}
        - {{ id: other_round_robin, start_frame: 1, end_frame: 2 }}
        - {{ id: other_choke, start_frame: 2, end_frame: 3 }}
        - {{ id: other_control, start_frame: 3, end_frame: 4 }}
        - {{ id: other_velocity, start_frame: 4, end_frame: 5 }}
        - {{ id: b, start_frame: 5, end_frame: 6 }}
        - {{ id: c, start_frame: 6, end_frame: 7 }}
  sample_maps:
    - id: kit
      selection_mode: first_match
      zones:
        - {{ region: hits.a, key_range: [36, 36], velocity_range: [71, 127], round_robin_group: main, choke_group: hats, control_group: 1 }}
        - {{ region: hits.other_round_robin, key_range: [36, 36], velocity_range: [71, 127], round_robin_group: other, choke_group: hats, control_group: 1 }}
        - {{ region: hits.other_choke, key_range: [36, 36], velocity_range: [71, 127], round_robin_group: main, choke_group: other, control_group: 1 }}
        - {{ region: hits.other_control, key_range: [36, 36], velocity_range: [71, 127], round_robin_group: main, choke_group: hats, control_group: 2 }}
        - {{ region: hits.other_velocity, key_range: [36, 36], velocity_range: [1, 70], round_robin_group: main, choke_group: hats, control_group: 1 }}
        - {{ region: hits.b, key_range: [36, 36], velocity_range: [71, 127], round_robin_group: main, choke_group: hats, control_group: 1 }}
        - {{ region: hits.c, key_range: [36, 36], velocity_range: [71, 127], round_robin_group: main, choke_group: hats, control_group: 1 }}
ports:
  - {{ name: master, direction: output, signal: audio, channels: 1, maps_from: player.audio }}
modules:
  - {{ id: midi, type: midi_input }}
  - {{ id: player, type: sample_map_player, static: {{ sample_map: kit, max_voices: 1, channels: 1 }}, defaults: {{ variation: {variation} }} }}
connections:
  - {{ from: midi.events, to: player.note }}
"#
        );
        let patch = load_kernel_patch_str(&yaml).expect("variation map loads");
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 2,
            duration_frames: 2,
        };
        let prepared = prepare_kernel_patch_with_context(
            &patch,
            &settings,
            &PreparationContext::new(directory.path(), 48_000),
        )
        .expect("variation map prepares");
        let rendered = render_kernel_offline_named(
            &prepared,
            vec![TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            )],
            &PreparedSamplerAssets::empty(),
        )
        .expect("variation map renders");
        assert_eq!(rendered[0].1[0], [expected, 0.0], "variation {variation}");
    }
}

#[test]
fn drum_round_robin_skips_other_groups_in_prepared_key_candidates() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.375, -0.25];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let patch = load_kernel_patch_str(r#"
metadata: { name: keyed_round_robin }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: a, start_frame: 0, end_frame: 1 }
        - { id: other, start_frame: 1, end_frame: 2 }
        - { id: b, start_frame: 2, end_frame: 3 }
  sample_maps:
    - id: kit
      selection_mode: round_robin
      zones:
        - { region: hits.a, key_range: [36, 36], velocity_range: [1, 127], round_robin_group: main }
        - { region: hits.other, key_range: [36, 36], velocity_range: [1, 127], round_robin_group: other }
        - { region: hits.b, key_range: [36, 36], velocity_range: [1, 127], round_robin_group: main }
ports:
  - { name: master, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 1, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#).expect("round-robin map loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 8,
        duration_frames: 8,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("round-robin map prepares");
    let events = [0, 2, 4, 6]
        .into_iter()
        .map(|frame| {
            TimedInputEvent::new(
                frame,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            )
        })
        .collect();
    let rendered = render_kernel_offline_named(&prepared, events, &PreparedSamplerAssets::empty())
        .expect("round-robin map renders");
    assert_eq!(
        rendered[0].1[0],
        [-0.5, 0.0, -0.25, 0.0, -0.5, 0.0, -0.25, 0.0]
    );
}

#[test]
fn host_rate_changes_sample_duration_without_changing_source_frame_bounds() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25, 0.25, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let patch = load_kernel_patch_str(
        r#"
metadata: { name: rate_scaled_region }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 0, end_frame: 4 }]
ports:
  - { name: master, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: hit, region: body, channels: 1 } }
connections:
  - { from: midi.events, to: player.trigger }
"#,
    )
    .expect("sample patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 96_000,
        block_size_frames: 3,
        duration_frames: 9,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 96_000),
    )
    .expect("48 kHz source prepares for 96 kHz host");
    assert_eq!(
        prepared.sample_assets().sources()[0]
            .sample()
            .sample_rate_hz(),
        48_000
    );
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![TimedInputEvent::new(
            0,
            ScriptEvent::NoteOn {
                note: 60,
                velocity: 100,
            },
        )],
        &PreparedSamplerAssets::empty(),
    )
    .expect("sample renders at host rate");
    assert_eq!(
        rendered[0].1[0],
        vec![
            -0.5,
            -0.375,
            -0.25,
            -0.000015258789,
            8191.0 / 32768.0,
            0.37496948,
            16383.0 / 32768.0,
            16383.0 / 32768.0,
            0.0
        ]
    );
}

#[test]
fn break_slicer_plays_the_requested_numeric_slice_and_retriggers_it() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25, 0.25, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("break.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: break_slicer }
assets:
  sample_sources:
    - id: break
      path: break.wav
      slices:
        - { id: tail, start_frame: 2, end_frame: 4 }
        - { id: head, start_frame: 0, end_frame: 2 }
ports:
  - { name: master, direction: output, signal: audio, channels: 1, maps_from: slicer.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: slicer, type: sample_slicer, static: { source: break, slice_table: break, channels: 1 }, defaults: { slice_index: 1 } }
connections:
  - { from: midi.events, to: slicer.trigger }
"#;
    let patch = load_kernel_patch_str(yaml).expect("break patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 2,
        duration_frames: 6,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("break slicer prepares");
    let mut runtime = RealtimeGraphProcessor::polyphonic_with_compiled_patch_and_sampler_assets_and_max_block_size(
        prepared.graph().clone(), prepared.compiled_patch().clone(), 48_000.0,
        &PreparedSamplerAssets::empty(), &crate::patch::VoiceAllocation::default(), 2,
    );
    let index_slot = runtime
        .parameter_slot_index("slicer", "slice_index")
        .expect("live index slot");
    let mut output = vec![vec![vec![0.0; 2]]];
    runtime.note_on(60, 100);
    assert_eq!(runtime.render_root_outputs(&mut output), 2);
    assert_eq!(output[0][0], [-0.5, -0.25]);
    assert_eq!(runtime.render_root_outputs(&mut output), 2);
    assert_eq!(output[0][0], [0.0, 0.0]);
    assert!(runtime.set_parameter_slot(index_slot, 0.0));
    runtime.note_on(60, 100);
    assert_eq!(runtime.render_root_outputs(&mut output), 2);
    assert_eq!(output[0][0], [8191.0 / 32768.0, 16383.0 / 32768.0]);
    assert!(runtime.set_parameter_slot(index_slot, 2.0));
    runtime.note_on(60, 100);
    assert_eq!(runtime.render_root_outputs(&mut output), 2);
    assert_eq!(output[0][0], [0.0, 0.0]);

    for (invalid, message) in [
        (yaml.replace("slice_table: break", "slice_table: absent"), "slice table"),
        (yaml.replace("source: break", "source: absent"), "source"),
        (yaml.replace("slices:\n        - { id: tail, start_frame: 2, end_frame: 4 }\n        - { id: head, start_frame: 0, end_frame: 2 }", "slices: []"), "empty table"),
    ] {
        let invalid_patch = load_kernel_patch_str(&invalid).expect("invalid player patch still parses");
        let failure = prepare_kernel_patch_with_context(
            &invalid_patch,
            &settings,
            &PreparationContext::new(directory.path(), 48_000),
        )
        .expect_err(message);
        assert_eq!(failure.diagnostics().errors().next().unwrap().error_code(), error_codes::KERNEL_SAMPLE_INVALID_SLICE);
    }
}

const COMPLETE_PATCH: &str = r#"
metadata:
  name: reusable_voice
  version: "1.2"
  author: Test Author
static_params:
  - name: channels
    type: int
    default: 2
  - name: mode
    type: enum
    default: clean
    allowed_values: [clean, driven]
  - name: source
    type: string
    default: "fn process(ctx) {}"
  - name: impulse
    type: resource
    resource_kind: impulse_response
    default: { kind: impulse_response, path: room_ir.wav }
ports:
  - name: level
    direction: input
    signal: control
    channels: 1
    default: 0.75
    min: 0
    max: 1
    unit: linear
    maps_to: [amp.gain]
  - name: master
    direction: output
    signal: audio
    channels: $channels
    maps_from: [amp.audio_out]
module_definitions:
  - type: amplifier
    static_params:
      - name: channels
        type: int
        default: 1
      - name: mode
        type: enum
        allowed_values: [clean, driven]
      - name: label
        type: string
      - name: impulse
        type: resource
        resource_kind: impulse_response
    ports:
      - name: gain
        direction: input
        signal: control
        channels: 1
        default: 1
        min: 0
        max: 2
        unit: linear
        maps_to: [inner.gain]
      - name: audio_out
        direction: output
        signal: audio
        channels: $channels
        maps_from: [inner.audio_out]
    modules:
      - id: inner
        type: gain
    connections: []
modules:
  - id: amp
    type: amplifier
    static:
      channels: $channels
      mode: driven
      label: main
      impulse: { kind: impulse_response, path: room_ir.wav }
    defaults:
      gain: 0.5
connections:
  - from: amp.audio_out
    to: amp.audio_in
"#;

const SAMPLE_ASSET_PATCH: &str = r#"
metadata: { name: sample_asset_patch }
assets:
  sample_sources:
    - id: break
      path: samples/break.wav
      regions:
        - id: full
          start_frame: 0
          end_frame: 96000
          root_note: 60
          gain_db: -3
          pan: 0.25
          reverse: false
          fade_in_ms: 2
          fade_out_ms: 3
          loop: { mode: forward, start_frame: 24000, end_frame: 48000, crossfade_ms: 5 }
      slices:
        - { id: beat_1, start_frame: 0, end_frame: 24000 }
        - { id: beat_2, start_frame: 24000, end_frame: 48000 }
      cues:
        - { id: downbeat, frame: 0 }
      analysis:
        tempo_bpm: 120
        confidence: 0.95
        beat_grid: { unit: frames, beats: [0, 24000, 48000], downbeats: [0, 48000] }
  sample_maps:
    - id: kit
      selection_seed: 7
      selection_mode: round_robin
      zones:
        - { id: soft, region: break.full, key_range: [36, 36], velocity_range: [1, 70], round_robin_group: kick, choke_group: hats, weight: 2 }
        - { id: loud, region: break.full, key_range: [36, 36], velocity_range: [71, 127], round_robin_group: kick, choke_group: hats, weight: 3 }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: osc.audio }
modules:
  - { id: osc, type: oscillator }
"#;

#[test]
fn kernel_patch_accepts_sample_sources_regions_slices_maps_and_choke_metadata() {
    let patch = load_kernel_patch_str(SAMPLE_ASSET_PATCH).expect("sample assets should load");
    assert_eq!(patch.root().name(), "sample_asset_patch");
    let assets = patch.sample_assets();
    assert_eq!(assets.sample_sources.len(), 1);
    let source = &assets.sample_sources[0];
    assert_eq!(source.id, "break");
    assert_eq!(source.resource.kind(), ResourceKind::Sample);
    assert_eq!(source.resource.path().to_str(), Some("samples/break.wav"));
    assert_eq!(source.resource.origin(), &ResourceOrigin::Document);
    assert_eq!(source.regions.len(), 1);
    let region = &source.regions[0];
    assert_eq!(region.id, "full");
    assert_eq!((region.start_frame, region.end_frame), (0, 96_000));
    assert_eq!(region.root_note, Some(60));
    assert_eq!(region.gain_db, Some(-3.0));
    assert_eq!(region.pan, Some(0.25));
    assert!(!region.reverse);
    assert_eq!(
        (region.fade_in_ms, region.fade_out_ms),
        (Some(2.0), Some(3.0))
    );
    let loop_settings = region.loop_settings.as_ref().expect("loop settings");
    assert_eq!(loop_settings.mode, "forward");
    assert_eq!(
        (loop_settings.start_frame, loop_settings.end_frame),
        (24_000, 48_000)
    );
    assert_eq!(loop_settings.crossfade_ms, Some(5.0));
    assert_eq!(
        source
            .slices
            .iter()
            .map(|slice| slice.id.as_str())
            .collect::<Vec<_>>(),
        vec!["beat_1", "beat_2"]
    );
    assert_eq!(
        (source.slices[1].start_frame, source.slices[1].end_frame),
        (24_000, 48_000)
    );
    assert_eq!(
        (source.cues[0].id.as_str(), source.cues[0].frame),
        ("downbeat", 0)
    );
    let analysis = source.analysis.as_ref().expect("analysis metadata");
    assert_eq!(
        (analysis.tempo_bpm, analysis.confidence),
        (Some(120.0), Some(0.95))
    );
    let grid = analysis.beat_grid.as_ref().expect("explicit beat grid");
    assert_eq!(grid.unit.as_deref(), Some("frames"));
    assert_eq!(grid.beats, vec![0, 24_000, 48_000]);
    assert_eq!(grid.downbeats, vec![0, 48_000]);

    assert_eq!(assets.sample_maps.len(), 1);
    let map = &assets.sample_maps[0];
    assert_eq!(map.id, "kit");
    assert_eq!(map.selection_seed, 7);
    assert_eq!(map.selection_mode.as_deref(), Some("round_robin"));
    assert_eq!(map.zones.len(), 2);
    assert_eq!(map.zones[0].id.as_deref(), Some("soft"));
    assert_eq!(map.zones[0].region, "break.full");
    assert_eq!(map.zones[0].key_range, [36, 36]);
    assert_eq!(map.zones[0].velocity_range, [1, 70]);
    assert_eq!(map.zones[0].round_robin_group.as_deref(), Some("kick"));
    assert_eq!(map.zones[0].choke_group.as_deref(), Some("hats"));
    assert_eq!(map.zones[0].weight, Some(2));
    assert_eq!(map.zones[1].velocity_range, [71, 127]);
}

#[test]
fn packaged_sample_source_retains_its_package_version_root() {
    let package_root = std::path::PathBuf::from("/library/1.2.3");
    let patch = load_kernel_definition_str(
        SAMPLE_ASSET_PATCH,
        "packaged_sample",
        ResourceOrigin::Package(package_root.clone()),
    )
    .expect("packaged sample declaration should load");

    assert_eq!(
        patch.sample_assets().sample_sources[0].resource.origin(),
        &ResourceOrigin::Package(package_root)
    );
}

#[test]
fn packaged_sample_source_prepares_from_its_version_root() {
    let package = tempfile::tempdir().expect("package root");
    let document = tempfile::tempdir().expect("separate document root");
    fs::create_dir(package.path().join("samples")).expect("package sample directory");
    let frames = vec![0.375; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(package.path().join("samples/break.wav")).expect("package sample"),
        48_000,
        &frames,
        &frames,
    )
    .expect("write package sample");
    let patch = load_kernel_definition_str(
        SAMPLE_ASSET_PATCH,
        "packaged_sample",
        ResourceOrigin::Package(package.path().to_path_buf()),
    )
    .expect("packaged declaration loads");
    let context = PreparationContext::new(document.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };

    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("sample resolves under package root");
    let source = &prepared.sample_assets().sources()[0];
    assert_eq!(source.id(), "break");
    assert!((source.sample().frames()[0] - 0.375).abs() < 0.0001);
}

#[test]
fn unknown_sampling_asset_fields_fail_schema_validation() {
    for (target, replacement) in [
        (
            "path: samples/break.wav",
            "path: samples/break.wav\n      unknown_sampling_field: 1",
        ),
        (
            "root_note: 60",
            "root_note: 60\n          unknown_sampling_field: 1",
        ),
        (
            "{ id: beat_1, start_frame: 0, end_frame: 24000 }",
            "{ id: beat_1, start_frame: 0, end_frame: 24000, unknown_sampling_field: 1 }",
        ),
        (
            "selection_mode: round_robin",
            "selection_mode: round_robin\n      unknown_sampling_field: 1",
        ),
        (
            "id: soft, region: break.full",
            "id: soft, unknown_sampling_field: 1, region: break.full",
        ),
    ] {
        let invalid = SAMPLE_ASSET_PATCH.replacen(target, replacement, 1);
        assert_ne!(
            invalid, SAMPLE_ASSET_PATCH,
            "test fixture substitution must apply"
        );
        let error = load_kernel_patch_str(&invalid).expect_err("unknown asset key must fail");
        let diagnostic = error.errors().next().expect("schema diagnostic");
        assert_eq!(
            diagnostic.error_code(),
            error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
        );
        assert!(diagnostic.message().contains("unknown_sampling_field"));
    }
}

#[test]
fn streaming_granular_and_workstation_sample_declarations_are_deferred() {
    for (target, replacement) in [
        (
            "path: samples/break.wav",
            "path: samples/break.wav\n      streaming: true",
        ),
        (
            "path: samples/break.wav",
            "path: samples/break.wav\n      grain_size_ms: 25",
        ),
        (
            "path: samples/break.wav",
            "path: samples/break.wav\n      time_stretch: beat_sync",
        ),
        (
            "path: samples/break.wav",
            "path: samples/break.wav\n      auto_detect_slices: transient",
        ),
        (
            "id: soft, region: break.full",
            "id: soft, keyswitch: 24, region: break.full",
        ),
        (
            "id: soft, region: break.full",
            "id: soft, release_trigger: true, region: break.full",
        ),
    ] {
        let invalid = SAMPLE_ASSET_PATCH.replacen(target, replacement, 1);
        let result = load_kernel_patch_str(&invalid);
        let error = match result {
            Ok(_) => panic!("out-of-scope sampling field must fail schema validation"),
            Err(error) => error,
        };
        assert_eq!(
            error.errors().next().unwrap().error_code(),
            error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
        );
    }
}

#[test]
fn sample_asset_preparation_reports_invalid_region_loop_and_drum_zone_ranges() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    for (target, replacement, code) in [
        (
            "end_frame: 96000",
            "end_frame: 0",
            error_codes::KERNEL_SAMPLE_INVALID_REGION,
        ),
        (
            "end_frame: 48000, crossfade_ms: 5",
            "end_frame: 24000, crossfade_ms: 5",
            error_codes::KERNEL_SAMPLE_INVALID_LOOP,
        ),
        (
            "key_range: [36, 36]",
            "key_range: [37, 36]",
            error_codes::KERNEL_SAMPLE_INVALID_ZONE,
        ),
        (
            "velocity_range: [1, 70]",
            "velocity_range: [70, 1]",
            error_codes::KERNEL_SAMPLE_INVALID_ZONE,
        ),
    ] {
        let invalid = SAMPLE_ASSET_PATCH.replacen(target, replacement, 1);
        let patch = load_kernel_patch_str(&invalid).expect("shape is valid");
        let error = prepare_kernel_patch_with_context(&patch, &settings, &context)
            .expect_err("invalid sample declaration must fail preparation");
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            code
        );
    }
}

#[test]
fn sample_asset_preparation_reports_missing_file_with_source_identity() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let context = PreparationContext::new(directory.path(), 48_000);
    let patch = load_kernel_patch_str(SAMPLE_ASSET_PATCH).expect("sample declaration loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };

    let error = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect_err("missing sample must fail preparation");
    let diagnostic = error.diagnostics().errors().next().unwrap();
    assert_eq!(
        diagnostic.error_code(),
        error_codes::KERNEL_SAMPLE_MISSING_FILE
    );
    assert!(diagnostic.message().contains("break"));
    assert!(diagnostic.message().contains("samples/break.wav"));
}

#[test]
fn prepared_drum_source_keeps_decoded_frames_regions_and_map_metadata() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let left = vec![0.5; 96_000];
    let right = vec![0.0; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("samples/break.wav")).expect("sample file"),
        48_000,
        &left,
        &right,
    )
    .expect("write sample");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    let patch = load_kernel_patch_str(SAMPLE_ASSET_PATCH).expect("sample declaration loads");

    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("valid drum assets prepare");
    drop(patch);
    fs::remove_file(directory.path().join("samples/break.wav"))
        .expect("prepared sample no longer needs its source file");
    let source = &prepared.sample_assets().sources()[0];
    assert_eq!(source.id(), "break");
    assert_eq!(source.sample().sample_rate_hz(), 48_000);
    assert_eq!(source.sample().source_channel_count(), 2);
    assert_eq!(source.sample().frame_count(), 96_000);
    assert_eq!(source.sample().frames().len(), 96_000);
    assert!((source.sample().frames()[0] - 0.25).abs() < 0.0001);
    assert!((source.sample().source_sample(0, 0).unwrap() - 0.5).abs() < 0.0001);
    assert_eq!(source.sample().source_sample(1, 0), Some(0.0));
    assert_eq!(source.declaration().regions[0].id, "full");
    assert_eq!(source.declaration().regions[0].start_frame, 0);
    assert_eq!(source.declaration().regions[0].end_frame, 96_000);
    let loop_settings = source.declaration().regions[0]
        .loop_settings
        .as_ref()
        .expect("prepared loop");
    assert_eq!(loop_settings.mode, "forward");
    assert_eq!(
        (loop_settings.start_frame, loop_settings.end_frame),
        (24_000, 48_000)
    );
    assert_eq!(
        source.slice(0).map(|slice| slice.id.as_str()),
        Some("beat_1")
    );
    assert_eq!(
        source
            .slice(1)
            .map(|slice| (slice.start_frame, slice.end_frame)),
        Some((24_000, 48_000))
    );
    assert_eq!(prepared.sample_assets().maps()[0].zones.len(), 2);
    let map = prepared
        .sample_assets()
        .map_by_id("kit")
        .expect("prepared map");
    assert_eq!(map.selection_seed(), 7);
    assert_eq!(map.selection_mode(), Some("round_robin"));
    assert_eq!(map.zones()[0].declaration().region, "break.full");
    assert_eq!(map.zones()[0].declaration().key_range, [36, 36]);
    assert_eq!(map.zones()[0].declaration().velocity_range, [1, 70]);
    assert_eq!(map.zones()[0].source_index(), 0);
    assert_eq!(map.zones()[0].region_index(), 0);
}

#[test]
fn prepared_source_revision_and_channels_survive_same_path_replacement() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let path = directory.path().join("samples/break.wav");
    let write_source = |left: f32, right: f32| {
        crate::wav::write_wav_stereo_i16(
            fs::File::create(&path).expect("sample file"),
            48_000,
            &vec![left; 96_000],
            &vec![right; 96_000],
        )
        .expect("write sample");
    };
    let patch = load_kernel_patch_str(SAMPLE_ASSET_PATCH).expect("sample declaration loads");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };

    write_source(-0.75, 0.5);
    let old = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("first source prepares");
    write_source(0.25, -0.25);
    let replacement = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("replacement source prepares");
    fs::remove_file(&path).expect("prepared data owns its PCM");

    let old_sample = old.sample_assets().sources()[0].sample();
    let new_sample = replacement.sample_assets().sources()[0].sample();
    assert_ne!(old_sample.content_revision(), new_sample.content_revision());
    assert!((old_sample.source_sample(0, 0).unwrap() + 0.75).abs() < 0.0001);
    assert!((old_sample.source_sample(1, 0).unwrap() - 0.5).abs() < 0.0001);
    assert!((new_sample.source_sample(0, 0).unwrap() - 0.25).abs() < 0.0001);
    assert!((new_sample.source_sample(1, 0).unwrap() + 0.25).abs() < 0.0001);
}

#[test]
fn prepared_drum_map_resolves_zone_regions_in_authored_order() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let frames = vec![0.25; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("samples/break.wav")).unwrap(),
        48_000,
        &frames,
        &frames,
    )
    .expect("write sample");
    let patch = load_kernel_patch_str(SAMPLE_ASSET_PATCH).expect("sample declaration loads");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };

    let prepared =
        prepare_kernel_patch_with_context(&patch, &settings, &context).expect("drum map prepares");
    let map = prepared
        .sample_assets()
        .map_by_id("kit")
        .expect("prepared map");
    assert_eq!(map.selection_seed(), 7);
    assert_eq!(map.selection_mode(), Some("round_robin"));
    assert_eq!(map.zones().len(), 2);
    assert_eq!(map.zones()[0].source_index(), 0);
    assert_eq!(map.zones()[0].region_index(), 0);
    assert_eq!(map.zones()[0].declaration().id.as_deref(), Some("soft"));
    assert_eq!(map.zones()[1].declaration().id.as_deref(), Some("loud"));
    assert!(prepared.sample_assets().map_by_id("missing").is_none());
}

#[test]
fn prepared_drum_map_indexes_key_candidates_in_authored_order() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let frames = vec![0.25; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("samples/break.wav")).expect("sample file"),
        48_000,
        &frames,
        &frames,
    )
    .expect("write sample");
    let yaml = SAMPLE_ASSET_PATCH.replace(
        "key_range: [36, 36], velocity_range: [71, 127]",
        "key_range: [36, 38], velocity_range: [71, 127]",
    );
    let patch = load_kernel_patch_str(&yaml).expect("sample map loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("map prepares");
    let map = prepared
        .sample_assets()
        .map_by_id("kit")
        .expect("prepared map");
    assert!(map.candidate_zone_indices(35).is_empty());
    assert_eq!(map.candidate_zone_indices(36), &[0, 1]);
    assert_eq!(map.candidate_zone_indices(37), &[1]);
    assert_eq!(map.candidate_zone_indices(38), &[1]);
    assert!(map.candidate_zone_indices(39).is_empty());
}

#[test]
fn out_of_range_rust_notes_leave_direct_and_poly_drum_maps_safe() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    for max_voices in [1, 2] {
        let yaml = format!(
            r#"
metadata: {{ name: out_of_range_note }}
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{{ id: body, start_frame: 0, end_frame: 2 }}]
  sample_maps:
    - id: kit
      zones: [{{ region: hit.body, key_range: [36, 36], velocity_range: [1, 127] }}]
ports:
  - {{ name: master, direction: output, signal: audio, channels: 1, maps_from: player.audio }}
modules:
  - {{ id: midi, type: midi_input }}
  - {{ id: player, type: sample_map_player, static: {{ sample_map: kit, max_voices: {max_voices}, channels: 1 }} }}
connections:
  - {{ from: midi.events, to: player.note }}
"#
        );
        let patch = load_kernel_patch_str(&yaml).expect("drum map loads");
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 5,
            duration_frames: 5,
        };
        let prepared = prepare_kernel_patch_with_context(
            &patch,
            &settings,
            &PreparationContext::new(directory.path(), 48_000),
        )
        .expect("drum map prepares");
        let map = prepared
            .sample_assets()
            .map_by_id("kit")
            .expect("prepared map");
        assert!(map.candidate_zone_indices(128).is_empty());
        assert!(map.candidate_zone_indices(255).is_empty());
        let mut runtime = RealtimeGraphProcessor::polyphonic_with_compiled_patch_and_sampler_assets_and_max_block_size(
            prepared.graph().clone(),
            prepared.compiled_patch().clone(),
            48_000.0,
            &PreparedSamplerAssets::empty(),
            &crate::patch::VoiceAllocation::default(),
            5,
        );
        assert!(!runtime.try_note_on_at(200, 100, 0));
        assert!(!runtime.try_note_off_at(200, 0));
        assert!(runtime.try_note_on_at(127, 100, 0));
        let rendered = render_kernel_offline_named(
            &prepared,
            vec![
                TimedInputEvent::new(
                    0,
                    ScriptEvent::NoteOn {
                        note: 200,
                        velocity: 100,
                    },
                ),
                TimedInputEvent::new(
                    2,
                    ScriptEvent::NoteOn {
                        note: 36,
                        velocity: 100,
                    },
                ),
                TimedInputEvent::new(
                    3,
                    ScriptEvent::NoteOn {
                        note: 255,
                        velocity: 100,
                    },
                ),
            ],
            &PreparedSamplerAssets::empty(),
        )
        .expect("out-of-range note cannot panic during rendering");
        assert_eq!(
            rendered[0].1[0],
            [0.0, 0.0, -0.5, -0.25, 0.0],
            "{max_voices} voices"
        );
    }
}

#[test]
fn prepared_break_slices_keep_explicit_numeric_order() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let frames = vec![0.25; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("samples/break.wav")).unwrap(),
        48_000,
        &frames,
        &frames,
    )
    .expect("write sample");
    let patch = load_kernel_patch_str(SAMPLE_ASSET_PATCH).expect("break declaration loads");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };

    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("explicit slices prepare");
    let source = &prepared.sample_assets().sources()[0];
    assert_eq!(source.slice(0).unwrap().id, "beat_1");
    assert_eq!(
        (
            source.slice(0).unwrap().start_frame,
            source.slice(0).unwrap().end_frame
        ),
        (0, 24_000)
    );
    assert_eq!(source.slice(1).unwrap().id, "beat_2");
    assert_eq!(
        (
            source.slice(1).unwrap().start_frame,
            source.slice(1).unwrap().end_frame
        ),
        (24_000, 48_000)
    );
    assert!(source.slice(2).is_none());
}

#[test]
fn prepared_sample_player_renders_one_shot_region_and_then_stops() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &[0.25, -0.5, 0.75, -0.25],
        &[0.25, -0.5, 0.75, -0.25],
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: one_shot_region }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 1, end_frame: 3 }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: hit, region: body, channels: 1 } }
connections:
  - { from: midi.events, to: player.trigger }
"#;
    let patch = load_kernel_patch_str(yaml).expect("one-shot patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 6,
        duration_frames: 6,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("sample player prepares");

    let rendered = render_kernel_offline_named(
        &prepared,
        vec![TimedInputEvent::new(
            0,
            ScriptEvent::NoteOn {
                note: 60,
                velocity: 100,
            },
        )],
        &PreparedSamplerAssets::empty(),
    )
    .expect("one-shot renders");
    assert_eq!(rendered[0].0, "audio_out");
    assert_eq!(
        rendered[0].1[0],
        vec![-0.5, 24575.0 / 32768.0, 0.0, 0.0, 0.0, 0.0]
    );

    let delayed = render_kernel_offline_named(
        &prepared,
        vec![TimedInputEvent::new(
            2,
            ScriptEvent::NoteOn {
                note: 60,
                velocity: 100,
            },
        )],
        &PreparedSamplerAssets::empty(),
    )
    .expect("offset trigger renders");
    assert_eq!(
        delayed[0].1[0],
        vec![0.0, 0.0, -0.5, 24575.0 / 32768.0, 0.0, 0.0]
    );

    let retriggered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 60,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                3,
                ScriptEvent::NoteOn {
                    note: 60,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("retrigger renders");
    assert_eq!(
        retriggered[0].1[0],
        vec![-0.5, 24575.0 / 32768.0, 0.0, -0.5, 24575.0 / 32768.0, 0.0]
    );

    let silent = render_kernel_offline_named(&prepared, vec![], &PreparedSamplerAssets::empty())
        .expect("untriggered player renders silence");
    assert_eq!(silent[0].1[0], vec![0.0; 6]);

    for invalid_static in [
        "source: absent, region: body",
        "source: hit, region: absent",
    ] {
        let invalid = yaml.replace("source: hit, region: body", invalid_static);
        let patch = load_kernel_patch_str(&invalid).expect("invalid reference shape loads");
        let result = prepare_kernel_patch_with_context(&patch, &settings, &context);
        let error = match result {
            Ok(_) => panic!("unknown sample binding must fail preparation"),
            Err(error) => error,
        };
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            error_codes::KERNEL_SAMPLE_INVALID_REGION
        );
    }
}

#[test]
fn sample_player_uses_region_gain_pan_and_live_start_level_pan() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25, 0.25, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let patch = load_kernel_patch_str(
        r#"
metadata: { name: live_sample_region_mix }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 0, end_frame: 4, gain_db: -6, pan: -0.25 }]
ports:
  - { name: start_offset, direction: input, signal: control, channels: 1, default: 0, min: 0, max: 1, maps_to: player.start_offset }
  - { name: level, direction: input, signal: control, channels: 1, default: 1, min: 0, max: 4, maps_to: player.level }
  - { name: pan, direction: input, signal: control, channels: 1, default: 0, min: -1, max: 1, maps_to: player.pan }
  - { name: audio_out, direction: output, signal: audio, channels: 2, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: hit, region: body, channels: 2 } }
connections:
  - { from: midi.events, to: player.trigger }
"#,
    )
    .expect("sample region patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 2,
        duration_frames: 2,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("sample region patch prepares");
    let mut runtime = RealtimeGraphProcessor::polyphonic_with_compiled_patch_and_sampler_assets_and_max_block_size(
        prepared.graph().clone(), prepared.compiled_patch().clone(), 48_000.0,
        &PreparedSamplerAssets::empty(), &crate::patch::VoiceAllocation::default(), 2,
    );
    let gain = 10.0_f32.powf(-6.0 / 20.0);
    let mut output = vec![vec![vec![0.0; 2]; 2]];
    runtime.note_on(60, 100);
    assert_eq!(runtime.render_root_outputs(&mut output), 2);
    assert!((output[0][0][0] - -0.5 * gain).abs() < 0.00001);
    assert!((output[0][1][0] - -0.5 * gain * 0.75).abs() < 0.00001);

    let level_slot = runtime.parameter_slot_index("player", "level").unwrap();
    let pan_slot = runtime.parameter_slot_index("player", "pan").unwrap();
    assert!(runtime.set_parameter_slot(level_slot, 0.5));
    assert!(runtime.set_parameter_slot(pan_slot, 0.75));
    assert_eq!(runtime.render_root_outputs(&mut output), 2);
    let third = 8191.0 / 32768.0;
    assert!((output[0][0][0] - third * gain * 0.5 * 0.5).abs() < 0.00001);
    assert!((output[0][1][0] - third * gain * 0.5).abs() < 0.00001);

    let start_slot = runtime
        .parameter_slot_index("player", "start_offset")
        .unwrap();
    assert!(runtime.set_parameter_slot(start_slot, 1.0));
    runtime.note_on(60, 100);
    assert_eq!(runtime.render_root_outputs(&mut output), 2);
    let last = 16383.0 / 32768.0;
    assert!((output[0][0][0] - last * gain * 0.5 * 0.5).abs() < 0.00001);
    assert!((output[0][1][0] - last * gain * 0.5).abs() < 0.00001);
    assert_eq!(output[0][0][1], 0.0);
}

#[test]
fn sample_player_start_offset_stays_inside_nonzero_region_in_both_directions() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25, 0.25, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: offset_inside_region }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 1, end_frame: 4, reverse: false }]
ports:
  - { name: start_offset, direction: input, signal: control, channels: 1, default: 0.5, min: 0, max: 1, maps_to: player.start_offset }
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: hit, region: body, channels: 1 } }
connections:
  - { from: midi.events, to: player.trigger }
"#;
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 4,
        duration_frames: 4,
    };
    let render = |document: &str| {
        let patch = load_kernel_patch_str(document).expect("offset patch loads");
        let prepared = prepare_kernel_patch_with_context(
            &patch,
            &settings,
            &PreparationContext::new(directory.path(), 48_000),
        )
        .expect("offset patch prepares");
        render_kernel_offline_named(
            &prepared,
            vec![TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            )],
            &PreparedSamplerAssets::empty(),
        )
        .expect("offset patch renders")[0]
            .1[0]
            .clone()
    };
    assert_eq!(
        render(yaml),
        vec![8191.0 / 32768.0, 16383.0 / 32768.0, 0.0, 0.0]
    );
    assert_eq!(
        render(&yaml.replace("reverse: false", "reverse: true")),
        vec![8191.0 / 32768.0, -0.25, 0.0, 0.0]
    );
}

#[test]
fn drum_map_player_applies_prepared_region_fades() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = vec![-0.5; 96];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hat.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let patch = load_kernel_patch_str(
        r#"
metadata: { name: faded_drum_region }
assets:
  sample_sources:
    - id: hats
      path: hat.wav
      regions: [{ id: open, start_frame: 0, end_frame: 96, fade_in_ms: 1, fade_out_ms: 1 }]
  sample_maps:
    - id: kit
      zones: [{ id: open, region: hats.open, key_range: [46, 46], velocity_range: [1, 127] }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, channels: 1, max_voices: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#,
    )
    .expect("faded drum patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 96,
        duration_frames: 96,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("faded drum patch prepares");
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![TimedInputEvent::new(
            0,
            ScriptEvent::NoteOn {
                note: 46,
                velocity: 100,
            },
        )],
        &PreparedSamplerAssets::empty(),
    )
    .expect("faded drum renders");
    let audio = &rendered[0].1[0];
    assert_eq!(audio[0], 0.0);
    assert!((audio[24] - -0.5 * 24.0 / 47.0).abs() < 0.00001);
    assert_eq!(audio[48], -0.5);
    assert_eq!(audio[95], 0.0);
}

#[test]
fn drum_control_groups_modulate_simultaneous_pads_independently() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.5, 0.25, 0.25];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let patch = load_kernel_patch_str(
        r#"
metadata: { name: independent_drum_controls }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: kick, start_frame: 0, end_frame: 2 }
        - { id: snare, start_frame: 2, end_frame: 4 }
  sample_maps:
    - id: kit
      zones:
        - { region: hits.kick, key_range: [36, 36], velocity_range: [1, 127], control_group: 1 }
        - { region: hits.snare, key_range: [38, 38], velocity_range: [1, 127], control_group: 2 }
ports:
  - { name: kick_level, direction: input, signal: control, channels: 1, default: 0.5, min: 0, max: 4, maps_to: player.group_1_level }
  - { name: snare_pan, direction: input, signal: control, channels: 1, default: 1, min: -1, max: 1, maps_to: player.group_2_pan }
  - { name: audio_out, direction: output, signal: audio, channels: 2, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 2, channels: 2 } }
connections:
  - { from: midi.events, to: player.note }
"#,
    )
    .expect("drum control group patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 2,
        duration_frames: 2,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("drum control group patch prepares");
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 38,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("independent pads render");
    assert_eq!(rendered[0].1[0][0], -0.25);
    assert_eq!(rendered[0].1[1][0], -0.25 + 8191.0 / 32768.0);
}

#[test]
fn drum_control_group_outside_prepared_port_range_is_rejected() {
    for group in [0, 9] {
        let yaml = format!(
            "metadata: {{ name: invalid_drum_group }}\nassets:\n  sample_maps:\n    - id: kit\n      zones: [{{ region: hits.kick, key_range: [36, 36], velocity_range: [1, 127], control_group: {group} }}]\n"
        );
        let error = load_kernel_patch_str(&yaml).expect_err("control group needs a render port");
        assert_eq!(
            error.errors().next().unwrap().error_code(),
            error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
        );
    }
}

#[test]
fn gated_sample_player_stops_on_note_off_at_its_frame_and_can_retrigger() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &[0.25, -0.5, 0.75, -0.25],
        &[0.25, -0.5, 0.75, -0.25],
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: gated_region }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 0, end_frame: 4 }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: hit, region: body, channels: 1, mode: gated } }
connections:
  - { from: midi.events, to: player.trigger }
  - { from: midi.events, to: player.gate }
"#;
    let patch = load_kernel_patch_str(yaml).expect("gated patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 6,
        duration_frames: 6,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("gated sample player prepares");
    let events = vec![
        TimedInputEvent::new(
            0,
            ScriptEvent::NoteOn {
                note: 60,
                velocity: 100,
            },
        ),
        TimedInputEvent::new(2, ScriptEvent::NoteOff { note: 60 }),
        TimedInputEvent::new(
            4,
            ScriptEvent::NoteOn {
                note: 60,
                velocity: 100,
            },
        ),
        TimedInputEvent::new(5, ScriptEvent::NoteOff { note: 60 }),
    ];
    let rendered =
        render_kernel_offline_named(&prepared, events.clone(), &PreparedSamplerAssets::empty())
            .expect("gated region renders");
    assert_eq!(
        rendered[0].1[0],
        vec![8191.0 / 32768.0, -0.5, 0.0, 0.0, 8191.0 / 32768.0, 0.0]
    );

    let one_shot = load_kernel_patch_str(&yaml.replace("mode: gated", "mode: one_shot"))
        .expect("one-shot patch loads");
    let prepared = prepare_kernel_patch_with_context(&one_shot, &settings, &context)
        .expect("one-shot sample player prepares");
    let rendered = render_kernel_offline_named(&prepared, events, &PreparedSamplerAssets::empty())
        .expect("one-shot region renders");
    assert_eq!(
        rendered[0].1[0],
        vec![
            8191.0 / 32768.0,
            -0.5,
            24575.0 / 32768.0,
            -0.25,
            8191.0 / 32768.0,
            -0.5
        ]
    );
}

#[test]
fn looped_sample_player_wraps_and_crossfades_until_gate_release() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [0.0, 0.25, 0.5, 0.75, -0.25, -0.5, -0.75, 0.875];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("loop.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: looped_region }
assets:
  sample_sources:
    - id: loop_sample
      path: loop.wav
      regions:
        - id: body
          start_frame: 0
          end_frame: 8
          loop: { mode: forward, start_frame: 2, end_frame: 8 }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: loop_sample, region: body, mode: looped, channels: 1 } }
connections:
  - { from: midi.events, to: player.trigger }
  - { from: midi.events, to: player.gate }
"#;
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 12,
        duration_frames: 12,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let render = |document: &str| {
        let patch = load_kernel_patch_str(document).expect("loop patch loads");
        let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
            .expect("loop patch prepares");
        render_kernel_offline_named(
            &prepared,
            vec![
                TimedInputEvent::new(
                    0,
                    ScriptEvent::NoteOn {
                        note: 60,
                        velocity: 100,
                    },
                ),
                TimedInputEvent::new(10, ScriptEvent::NoteOff { note: 60 }),
            ],
            &PreparedSamplerAssets::empty(),
        )
        .expect("loop patch renders")[0]
            .1[0]
            .clone()
    };
    let pcm = |value: f32| -> f32 {
        let scale = if value < 0.0 { 32768.0 } else { 32767.0 };
        (value * scale) as i16 as f32 / 32768.0
    };
    assert_eq!(
        render(yaml),
        vec![
            0.0,
            pcm(0.25),
            pcm(0.5),
            pcm(0.75),
            pcm(-0.25),
            pcm(-0.5),
            pcm(-0.75),
            pcm(0.875),
            pcm(0.5),
            pcm(0.75),
            0.0,
            0.0,
        ]
    );

    let crossfaded = yaml.replace("end_frame: 8 }", "end_frame: 8, crossfade_ms: 0.04 }");
    assert_eq!(
        render(&crossfaded),
        vec![
            0.0,
            pcm(0.25),
            pcm(0.5),
            pcm(0.75),
            pcm(-0.25),
            pcm(-0.5),
            (pcm(-0.75) + pcm(0.5)) * 0.5,
            pcm(0.75),
            pcm(-0.25),
            pcm(-0.5),
            0.0,
            0.0,
        ]
    );

    let reversed = yaml.replace(
        "          end_frame: 8\n",
        "          end_frame: 8\n          reverse: true\n",
    );
    assert_eq!(
        render(&reversed),
        vec![
            pcm(0.875),
            pcm(-0.75),
            pcm(-0.5),
            pcm(-0.25),
            pcm(0.75),
            pcm(0.5),
            pcm(0.875),
            pcm(-0.75),
            pcm(-0.5),
            pcm(-0.25),
            0.0,
            0.0,
        ]
    );
    let reversed_crossfaded = crossfaded.replace(
        "          end_frame: 8\n",
        "          end_frame: 8\n          reverse: true\n",
    );
    assert_eq!(
        render(&reversed_crossfaded),
        vec![
            pcm(0.875),
            pcm(-0.75),
            pcm(-0.5),
            pcm(-0.25),
            (pcm(0.75) + pcm(0.875)) * 0.5,
            pcm(-0.75),
            pcm(-0.5),
            pcm(-0.25),
            (pcm(0.75) + pcm(0.875)) * 0.5,
            pcm(-0.75),
            0.0,
            0.0,
        ]
    );

    let no_loop = yaml.replace(
        "          loop: { mode: forward, start_frame: 2, end_frame: 8 }\n",
        "",
    );
    let patch = load_kernel_patch_str(&no_loop).expect("missing loop shape loads");
    let error = match prepare_kernel_patch_with_context(&patch, &settings, &context) {
        Ok(_) => panic!("looped mode requires prepared loop points"),
        Err(error) => error,
    };
    assert_eq!(
        error.diagnostics().errors().next().unwrap().error_code(),
        error_codes::KERNEL_SAMPLE_INVALID_LOOP
    );
}

#[test]
fn pitched_sample_player_uses_declared_interpolation_at_fractional_positions() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [0.0, 1.0, 0.0, -1.0];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("wave.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: pitched_region }
assets:
  sample_sources:
    - id: wave
      path: wave.wav
      regions: [{ id: body, start_frame: 0, end_frame: 4 }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: wave, region: body, channels: 1, interpolation: linear }, defaults: { pitch_ratio: 0.5 } }
connections:
  - { from: midi.events, to: player.trigger }
"#;
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 7,
        duration_frames: 7,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let render = |document: &str| {
        let patch = load_kernel_patch_str(document).expect("pitched patch loads");
        let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
            .expect("pitched patch prepares");
        render_kernel_offline_named(
            &prepared,
            vec![TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 60,
                    velocity: 100,
                },
            )],
            &PreparedSamplerAssets::empty(),
        )
        .expect("pitched patch renders")[0]
            .1[0]
            .clone()
    };
    let top = 32767.0 / 32768.0;
    assert_eq!(
        render(yaml),
        vec![0.0, top * 0.5, top, top * 0.5, 0.0, -0.5, -1.0]
    );
    let nearest = yaml.replace("interpolation: linear", "interpolation: nearest");
    assert_eq!(render(&nearest), vec![0.0, top, top, 0.0, 0.0, -1.0, -1.0]);
    let cubic = yaml.replace("interpolation: linear", "interpolation: cubic");
    let cubic_audio = render(&cubic);
    assert_eq!(cubic_audio[0], 0.0);
    assert_eq!(cubic_audio[1], top * 0.5625);
    assert_eq!(cubic_audio[2], top);
    assert!(cubic_audio[1] > top * 0.5);
}

#[test]
fn reversed_sample_region_starts_at_its_last_frame_and_stops_at_its_first() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [0.125, -0.25, 0.5, -0.75, 0.875];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: reverse_region }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 1, end_frame: 4, reverse: true }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: hit, region: body, channels: 1 } }
connections:
  - { from: midi.events, to: player.trigger }
"#;
    let patch = load_kernel_patch_str(yaml).expect("reverse patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 6,
        duration_frames: 6,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("reverse patch prepares");
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![TimedInputEvent::new(
            0,
            ScriptEvent::NoteOn {
                note: 36,
                velocity: 100,
            },
        )],
        &PreparedSamplerAssets::empty(),
    )
    .expect("reverse region renders");
    assert_eq!(
        rendered[0].1[0],
        vec![-0.75, 16383.0 / 32768.0, -0.25, 0.0, 0.0, 0.0]
    );
}

#[test]
fn sample_region_fades_scale_the_signed_boundary_frames() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [0.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.0];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: faded_region }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 1, end_frame: 7, fade_in_ms: 0.06, fade_out_ms: 0.06 }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: hit, region: body, channels: 1 } }
connections:
  - { from: midi.events, to: player.trigger }
"#;
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 8,
        duration_frames: 8,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let render = |document: &str| {
        let patch = load_kernel_patch_str(document).expect("fade patch loads");
        let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
            .expect("fade patch prepares");
        render_kernel_offline_named(
            &prepared,
            vec![TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            )],
            &PreparedSamplerAssets::empty(),
        )
        .expect("fade patch renders")[0]
            .1[0]
            .clone()
    };
    let half = 16383.0 / 32768.0;
    assert_eq!(
        render(yaml),
        vec![0.0, half * 0.5, half, half, half * 0.5, 0.0, 0.0, 0.0]
    );
    let one_frame_fade = yaml.replace("fade_in_ms: 0.06", "fade_in_ms: 0.020833333333333332");
    assert_eq!(
        render(&one_frame_fade),
        vec![0.0, half, half, half, half * 0.5, 0.0, 0.0, 0.0]
    );
    let reverse = yaml.replace("fade_in_ms: 0.06", "reverse: true, fade_in_ms: 0.06");
    assert_eq!(
        render(&reverse),
        vec![0.0, half * 0.5, half, half, half * 0.5, 0.0, 0.0, 0.0]
    );
    let plain = yaml.replace(", fade_in_ms: 0.06, fade_out_ms: 0.06", "");
    assert_eq!(
        render(&plain),
        vec![half, half, half, half, half, half, 0.0, 0.0]
    );
}

#[test]
fn sample_player_oversized_root_render_matches_prepared_small_blocks() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, 0.25, 0.5, -0.25, 0.75, -0.75, 0.125, -0.125];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: split_sample_render }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 0, end_frame: 8 }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: hit, region: body, channels: 1, mode: gated } }
connections:
  - { from: midi.events, to: player.trigger }
  - { from: midi.events, to: player.gate }
"#;
    let patch = load_kernel_patch_str(yaml).expect("sample patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 3,
        duration_frames: 10,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("sample patch prepares");
    let runtime = || {
        RealtimeGraphProcessor::polyphonic_with_compiled_patch_and_sampler_assets_and_max_block_size(
            prepared.graph().clone(),
            prepared.compiled_patch().clone(),
            48_000.0,
            &PreparedSamplerAssets::empty(),
            &crate::patch::VoiceAllocation::default(),
            3,
        )
    };
    let mut oversized = runtime();
    oversized.note_on_at(36, 100, 2);
    oversized.note_off_at(36, 7);
    let mut large_output = vec![vec![vec![0.0; 10]]];
    assert_eq!(oversized.render_root_outputs(&mut large_output), 10);

    let mut small = runtime();
    small.note_on_at(36, 100, 2);
    let mut small_samples = Vec::new();
    for chunk in [3, 3, 3, 1] {
        if small_samples.len() == 6 {
            small.note_off_at(36, 1);
        }
        let mut output = vec![vec![vec![0.0; chunk]]];
        assert_eq!(small.render_root_outputs(&mut output), chunk);
        small_samples.extend(output.remove(0).remove(0));
    }
    assert_eq!(large_output[0][0], small_samples);
    assert_eq!(
        large_output[0][0],
        vec![
            0.0,
            0.0,
            -0.5,
            8191.0 / 32768.0,
            16383.0 / 32768.0,
            -0.25,
            24575.0 / 32768.0,
            0.0,
            0.0,
            0.0
        ]
    );
}

#[test]
fn drum_sample_map_selects_key_and_velocity_regions_from_note_events() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25, 0.25, 0.5, -0.75, -0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: drum_map_selection }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: soft_kick, start_frame: 0, end_frame: 2 }
        - { id: hard_kick, start_frame: 2, end_frame: 4 }
        - { id: snare, start_frame: 4, end_frame: 6 }
  sample_maps:
    - id: kit
      selection_mode: first_match
      zones:
        - { id: soft, region: hits.soft_kick, key_range: [36, 36], velocity_range: [1, 63] }
        - { id: hard, region: hits.hard_kick, key_range: [36, 36], velocity_range: [64, 127] }
        - { id: snare, region: hits.snare, key_range: [38, 40], velocity_range: [1, 127] }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 1, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("drum map patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 9,
        duration_frames: 9,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("drum map patch prepares");
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 40,
                },
            ),
            TimedInputEvent::new(
                3,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                6,
                ScriptEvent::NoteOn {
                    note: 39,
                    velocity: 90,
                },
            ),
            TimedInputEvent::new(
                7,
                ScriptEvent::NoteOn {
                    note: 41,
                    velocity: 90,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("drum map renders");
    assert_eq!(
        rendered[0].1[0],
        vec![
            -0.5,
            -0.25,
            0.0,
            8191.0 / 32768.0,
            16383.0 / 32768.0,
            0.0,
            -0.75,
            -0.5,
            0.0
        ]
    );
}

#[test]
fn poly_drum_map_unmatched_key_or_velocity_keeps_sounding_voices() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.25; 8];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: unmatched_drum_map_note }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 0, end_frame: 8 }]
  sample_maps:
    - id: kit
      zones: [{ region: hit.body, key_range: [36, 36], velocity_range: [64, 127] }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 2, channels: 1, voice_steal: oldest } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("drum map patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 8,
        duration_frames: 8,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("drum map patch prepares");
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                2,
                ScriptEvent::NoteOn {
                    note: 41,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                4,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 40,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("drum map renders");
    assert_eq!(rendered[0].1[0], vec![-0.5; 8]);
}

#[test]
fn poly_drum_map_player_renders_two_selected_hits_and_retires_released_voices() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25, 0.25, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: poly_drum_map }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: kick, start_frame: 0, end_frame: 2 }
        - { id: snare, start_frame: 2, end_frame: 4 }
  sample_maps:
    - id: kit
      selection_mode: first_match
      zones:
        - { region: hits.kick, key_range: [36, 36], velocity_range: [1, 127] }
        - { region: hits.snare, key_range: [38, 38], velocity_range: [1, 127] }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: voices.audio }
module_definitions:
  - type: sample_voice
    ports:
      - { name: audio, direction: output, signal: audio, channels: 1, maps_from: player.audio }
    modules:
      - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 2, channels: 1 } }
    connections:
      - { from: voice.gate, to: player.note }
modules:
  - { id: midi, type: midi_input }
  - { id: voices, type: poly, static: { definition: sample_voice, max_voices: 2, allocation: reject-new } }
connections:
  - { from: midi.events, to: voices.notes }
"#;
    let patch = load_kernel_patch_str(yaml).expect("poly kit patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 8,
        duration_frames: 8,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("poly kit patch prepares");
    assert_eq!(
        prepared.compiled_patch().poly_regions()[0]
            .child_patch()
            .poly_regions()[0]
            .max_voices(),
        2
    );
    let mut runtime = RealtimeGraphProcessor::polyphonic_with_compiled_patch_and_sampler_assets_and_max_block_size(
        prepared.graph().clone(), prepared.compiled_patch().clone(), 48_000.0,
        &PreparedSamplerAssets::empty(), &crate::patch::VoiceAllocation::default(), 8,
    );
    runtime.note_on_at(36, 100, 0);
    runtime.note_on_at(38, 100, 0);
    runtime.note_off_at(36, 2);
    runtime.note_off_at(38, 2);
    let mut output = vec![vec![vec![0.0; 8]]];
    assert_eq!(runtime.render_root_outputs(&mut output), 8);
    assert_eq!(
        output[0][0],
        vec![
            -0.5 + 8191.0 / 32768.0,
            -0.25 + 16383.0 / 32768.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ]
    );
    assert!(
        runtime.prepared_poly_runtime_regions()[0]
            .voice_gate_events(0)
            .iter()
            .any(|event| matches!(event.event, ScriptEvent::NoteOff { .. }))
    );
    let mut quiet = vec![vec![vec![0.0; 512]]];
    assert_eq!(runtime.render_root_outputs(&mut quiet), 512);
    assert!(quiet[0][0].iter().all(|sample| *sample == 0.0));
    assert_eq!(
        runtime.prepared_poly_runtime_regions()[0].active_voice_count(),
        0
    );
}

#[test]
fn drum_map_max_voices_overlaps_hits_through_a_bounded_poly_region() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25, 0.25, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: bounded_drum_map }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: kick, start_frame: 0, end_frame: 2 }
        - { id: snare, start_frame: 2, end_frame: 4 }
  sample_maps:
    - id: kit
      zones:
        - { region: hits.kick, key_range: [36, 36], velocity_range: [1, 127] }
        - { region: hits.snare, key_range: [38, 38], velocity_range: [1, 127] }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 2, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("bounded drum map loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 4,
        duration_frames: 4,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("bounded drum map prepares");
    assert_eq!(prepared.compiled_patch().poly_regions().len(), 1);
    assert_eq!(prepared.compiled_patch().poly_regions()[0].max_voices(), 2);
    let default_patch = load_kernel_patch_str(&yaml.replace("max_voices: 2, ", ""))
        .expect("default voice count patch loads");
    let default_prepared = prepare_kernel_patch_with_context(
        &default_patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("default voice count prepares");
    assert_eq!(
        default_prepared.compiled_patch().poly_regions()[0].max_voices(),
        16
    );
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 38,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("overlapping hits render");
    assert_eq!(
        rendered[0].1[0],
        vec![-0.5 + 8191.0 / 32768.0, -0.25 + 16383.0 / 32768.0, 0.0, 0.0,]
    );

    let reject_patch = load_kernel_patch_str(&yaml.replace(
        "max_voices: 2, channels: 1",
        "max_voices: 2, voice_steal: reject_new, channels: 1",
    ))
    .expect("reject-new kit loads");
    let recycle_settings = RenderSettings {
        block_size_frames: 2,
        duration_frames: 6,
        ..settings
    };
    let recycle_prepared = prepare_kernel_patch_with_context(
        &reject_patch,
        &recycle_settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("reject-new kit prepares");
    let recycled = render_kernel_offline_named(
        &recycle_prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 38,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                4,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("finished one-shots recycle their voices");
    assert_eq!(
        recycled[0].1[0],
        vec![
            -0.5 + 8191.0 / 32768.0,
            -0.25 + 16383.0 / 32768.0,
            0.0,
            0.0,
            -0.5,
            -0.25,
        ]
    );
}

#[test]
fn overlapping_drum_voices_share_round_robin_order() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25, 0.25, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: shared_drum_round_robin }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: a, start_frame: 0, end_frame: 2 }
        - { id: b, start_frame: 2, end_frame: 4 }
  sample_maps:
    - id: kit
      selection_mode: round_robin
      zones:
        - { region: hits.a, key_range: [36, 36], velocity_range: [1, 127], round_robin_group: kick }
        - { region: hits.b, key_range: [36, 36], velocity_range: [1, 127], round_robin_group: kick }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 2, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("drum map loads");
    let events = vec![
        TimedInputEvent::new(
            0,
            ScriptEvent::NoteOn {
                note: 36,
                velocity: 100,
            },
        ),
        TimedInputEvent::new(
            0,
            ScriptEvent::NoteOn {
                note: 36,
                velocity: 100,
            },
        ),
    ];
    for block_size_frames in [1, 2, 4] {
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames,
            duration_frames: 4,
        };
        let prepared = prepare_kernel_patch_with_context(
            &patch,
            &settings,
            &PreparationContext::new(directory.path(), 48_000),
        )
        .expect("drum map prepares");
        let rendered =
            render_kernel_offline_named(&prepared, events.clone(), &PreparedSamplerAssets::empty())
                .expect("overlapping round robin hits render");
        assert_eq!(
            rendered[0].1[0],
            vec![-0.5 + 8191.0 / 32768.0, -0.25 + 16383.0 / 32768.0, 0.0, 0.0]
        );
    }
}

#[test]
fn drum_map_voice_steal_uses_oldest_quietest_or_reject_new_policy() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let mut values = vec![0.5; 8];
    values.extend(vec![0.125; 8]);
    values.extend(vec![-0.5; 8]);
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: drum_voice_stealing }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: loud, start_frame: 0, end_frame: 8 }
        - { id: quiet, start_frame: 8, end_frame: 16 }
        - { id: new, start_frame: 16, end_frame: 24 }
  sample_maps:
    - id: kit
      zones:
        - { region: hits.loud, key_range: [36, 36], velocity_range: [1, 127] }
        - { region: hits.quiet, key_range: [38, 38], velocity_range: [1, 127] }
        - { region: hits.new, key_range: [40, 40], velocity_range: [1, 127] }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 2, voice_steal: POLICY, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 2,
        duration_frames: 4,
    };
    let loud = 16383.0 / 32768.0;
    let quiet = 4095.0 / 32768.0;
    for (policy, third_hit) in [
        ("oldest", quiet - 0.5),
        ("quietest", loud - 0.5),
        ("reject_new", loud + quiet),
    ] {
        let patch =
            load_kernel_patch_str(&yaml.replace("POLICY", policy)).expect("voice policy kit loads");
        let prepared = prepare_kernel_patch_with_context(
            &patch,
            &settings,
            &PreparationContext::new(directory.path(), 48_000),
        )
        .expect("voice policy kit prepares");
        let rendered = render_kernel_offline_named(
            &prepared,
            vec![
                TimedInputEvent::new(
                    0,
                    ScriptEvent::NoteOn {
                        note: 36,
                        velocity: 100,
                    },
                ),
                TimedInputEvent::new(
                    0,
                    ScriptEvent::NoteOn {
                        note: 38,
                        velocity: 100,
                    },
                ),
                TimedInputEvent::new(
                    2,
                    ScriptEvent::NoteOn {
                        note: 40,
                        velocity: 100,
                    },
                ),
            ],
            &PreparedSamplerAssets::empty(),
        )
        .expect("voice policy kit renders");
        assert_eq!(
            rendered[0].1[0],
            vec![loud + quiet, loud + quiet, third_hit, third_hit]
        );
    }
    let quietest_patch =
        load_kernel_patch_str(&yaml.replace("POLICY", "quietest")).expect("quietest kit loads");
    let quietest_prepared = prepare_kernel_patch_with_context(
        &quietest_patch,
        &RenderSettings {
            block_size_frames: 4,
            ..settings
        },
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("quietest kit prepares");
    let tied = render_kernel_offline_named(
        &quietest_prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 38,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 40,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("equal peak voices render");
    assert_eq!(tied[0].1[0], vec![quiet - 0.5; 4]);

    let mono_patch = load_kernel_patch_str(
        &yaml
            .replace("max_voices: 2", "max_voices: 1")
            .replace("POLICY", "reject_new"),
    )
    .expect("single-voice reject-new kit loads");
    let mono_prepared = prepare_kernel_patch_with_context(
        &mono_patch,
        &RenderSettings {
            duration_frames: 10,
            ..settings
        },
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("single-voice reject-new kit prepares");
    let mono_rendered = render_kernel_offline_named(
        &mono_prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                2,
                ScriptEvent::NoteOn {
                    note: 40,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                8,
                ScriptEvent::NoteOn {
                    note: 40,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("single-voice reject-new kit renders");
    assert_eq!(
        mono_rendered[0].1[0],
        [vec![loud; 8], vec![-0.5; 2]].concat()
    );
}

#[test]
fn closed_hat_cuts_open_hat_at_its_event_frame_without_choking_kick() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let mut values = vec![0.5; 8];
    values.extend(vec![-0.25; 2]);
    values.extend(vec![0.125; 8]);
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("kit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: choked_hats }
assets:
  sample_sources:
    - id: kit
      path: kit.wav
      regions:
        - { id: open, start_frame: 0, end_frame: 8 }
        - { id: closed, start_frame: 8, end_frame: 10 }
        - { id: kick, start_frame: 10, end_frame: 18 }
  sample_maps:
    - id: drums
      zones:
        - { region: kit.open, key_range: [46, 46], velocity_range: [1, 127], choke_group: hats }
        - { region: kit.closed, key_range: [42, 42], velocity_range: [1, 127], choke_group: hats }
        - { region: kit.kick, key_range: [36, 36], velocity_range: [1, 127] }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: drums, max_voices: 3, choke_mode: cut, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("hat kit loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 8,
        duration_frames: 8,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("hat kit prepares");
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 46,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                3,
                ScriptEvent::NoteOn {
                    note: 42,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("hat kit renders");
    let open = 16383.0 / 32768.0;
    let kick = 4095.0 / 32768.0;
    assert_eq!(
        rendered[0].1[0],
        vec![
            open + kick,
            open + kick,
            open + kick,
            -0.25 + kick,
            -0.25 + kick,
            kick,
            kick,
            kick,
        ]
    );
    let split_prepared = prepare_kernel_patch_with_context(
        &patch,
        &RenderSettings {
            block_size_frames: 2,
            ..settings
        },
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("split hat kit prepares");
    let split = render_kernel_offline_named(
        &split_prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 46,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                3,
                ScriptEvent::NoteOn {
                    note: 42,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("split hat kit renders");
    assert_eq!(split[0].1[0], rendered[0].1[0]);

    let release_patch =
        load_kernel_patch_str(&yaml.replace("choke_mode: cut", "choke_mode: release"))
            .expect("release-mode hat kit loads");
    let release_prepared = prepare_kernel_patch_with_context(
        &release_patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("release-mode hat kit prepares");
    let released = render_kernel_offline_named(
        &release_prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 46,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                3,
                ScriptEvent::NoteOn {
                    note: 42,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("release-mode hat kit renders");
    assert_eq!(
        released[0].1[0],
        vec![
            open + kick,
            open + kick,
            open + kick,
            open - 0.25 + kick,
            open - 0.25 + kick,
            open + kick,
            open + kick,
            open + kick,
        ]
    );
    let mut runtime = RealtimeGraphProcessor::polyphonic_with_compiled_patch_and_sampler_assets_and_max_block_size(
        release_prepared.graph().clone(), release_prepared.compiled_patch().clone(), 48_000.0,
        &PreparedSamplerAssets::empty(), &crate::patch::VoiceAllocation::default(), 8,
    );
    runtime.note_on_at(46, 100, 0);
    runtime.note_on_at(36, 100, 0);
    runtime.note_on_at(42, 100, 3);
    let mut output = vec![vec![vec![0.0; 8]]];
    assert_eq!(runtime.render_root_outputs(&mut output), 8);
    assert_eq!(output[0][0], released[0].1[0]);
    assert!(
        runtime.prepared_poly_runtime_regions()[0]
            .voice_gate_events(0)
            .iter()
            .any(|event| event.event == ScriptEvent::NoteOff { note: 46 })
    );
    let repeated_patch = load_kernel_patch_str(
        &yaml
            .replace("choke_mode: cut", "choke_mode: release")
            .replace("max_voices: 3", "max_voices: 4"),
    )
    .expect("repeated release kit loads");
    let repeated_prepared = prepare_kernel_patch_with_context(
        &repeated_patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("repeated release kit prepares");
    let repeated = render_kernel_offline_named(
        &repeated_prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 46,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                3,
                ScriptEvent::NoteOn {
                    note: 42,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                4,
                ScriptEvent::NoteOn {
                    note: 42,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("repeated release kit renders");
    assert_eq!(repeated[0].1[0][4], open + kick - 0.5);
    assert_eq!(repeated[0].1[0][5], open + kick - 0.25);
    assert_eq!(repeated[0].1[0][7], open + kick);

    let short_prepared = prepare_kernel_patch_with_context(
        &patch,
        &RenderSettings {
            block_size_frames: 1,
            duration_frames: 1,
            ..settings
        },
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("one-frame drum kit prepares");
    let mut short_runtime = RealtimeGraphProcessor::polyphonic_with_compiled_patch_and_sampler_assets_and_max_block_size(
        short_prepared.graph().clone(), short_prepared.compiled_patch().clone(), 48_000.0,
        &PreparedSamplerAssets::empty(), &crate::patch::VoiceAllocation::default(), 1,
    );
    let mut short_output = vec![vec![vec![0.0; 1]]];
    for _ in 0..3 {
        short_runtime.reset();
        let allocations = crate::test_allocator::count_current_thread_allocations(|| {
            short_runtime.note_on_at(46, 100, 0);
            short_runtime.note_on_at(36, 100, 0);
            short_runtime.note_on_at(42, 100, 0);
            assert_eq!(short_runtime.render_root_outputs(&mut short_output), 1);
        });
        assert_eq!(allocations, 0);
        assert_eq!(short_output[0][0][0], -0.25 + kick);
    }
}

#[test]
fn hat_choke_fade_spans_blocks_and_retires_at_its_end() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let mut values = vec![0.5; 96];
    values.extend(vec![-0.25; 2]);
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hats.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: fading_hats }
assets:
  sample_sources:
    - id: hats
      path: hats.wav
      regions:
        - { id: open, start_frame: 0, end_frame: 96 }
        - { id: closed, start_frame: 96, end_frame: 98 }
  sample_maps:
    - id: kit
      zones:
        - { region: hats.open, key_range: [46, 46], velocity_range: [1, 127], choke_group: hats }
        - { region: hats.closed, key_range: [42, 42], velocity_range: [1, 127], choke_group: hats }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 2, choke_mode: fade, choke_fade_ms: 1, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("fade kit loads");
    let open = 16383.0_f32 / 32768.0;
    for block_size_frames in [64, 16] {
        let prepared = prepare_kernel_patch_with_context(
            &patch,
            &RenderSettings {
                sample_rate_hz: 48_000,
                block_size_frames,
                duration_frames: 64,
            },
            &PreparationContext::new(directory.path(), 48_000),
        )
        .expect("fade kit prepares");
        let rendered = render_kernel_offline_named(
            &prepared,
            vec![
                TimedInputEvent::new(
                    0,
                    ScriptEvent::NoteOn {
                        note: 46,
                        velocity: 100,
                    },
                ),
                TimedInputEvent::new(
                    8,
                    ScriptEvent::NoteOn {
                        note: 42,
                        velocity: 100,
                    },
                ),
            ],
            &PreparedSamplerAssets::empty(),
        )
        .expect("fade kit renders");
        let samples = &rendered[0].1[0];
        assert_eq!(samples[7], open);
        assert_eq!(samples[8], open - 0.25);
        assert_eq!(samples[9], open * (1.0 - 1.0 / 48.0) - 0.25);
        assert_eq!(samples[32], open * 0.5);
        assert_eq!(samples[55], open * (1.0 - 47.0 / 48.0));
        assert_eq!(samples[56], 0.0);
        assert_eq!(samples[63], 0.0);
    }
    for invalid_yaml in [
        yaml.replace("choke_fade_ms: 1", "choke_fade_ms: 0"),
        yaml.replace("choke_fade_ms: 1", "choke_fade_ms: 1001"),
        yaml.replace("max_voices: 2", "max_voices: 1"),
        yaml.replace("max_voices: 2", "max_voices: 1")
            .replace("choke_mode: fade", "choke_mode: release"),
    ] {
        let invalid = load_kernel_patch_str(&invalid_yaml).expect("invalid choke graph loads");
        let error = match prepare_kernel_patch_with_context(
            &invalid,
            &RenderSettings {
                sample_rate_hz: 48_000,
                block_size_frames: 64,
                duration_frames: 64,
            },
            &PreparationContext::new(directory.path(), 48_000),
        ) {
            Ok(_) => panic!("invalid choke options must fail preparation"),
            Err(error) => error,
        };
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            error_codes::KERNEL_SAMPLE_UNSUPPORTED_MODE
        );
    }
}

#[test]
fn drum_map_round_robin_counters_are_repeatable_and_independent_per_group() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, 0.25, -0.75, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: round_robin_drums }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: kick_a, start_frame: 0, end_frame: 1 }
        - { id: kick_b, start_frame: 1, end_frame: 2 }
        - { id: snare_a, start_frame: 2, end_frame: 3 }
        - { id: snare_b, start_frame: 3, end_frame: 4 }
  sample_maps:
    - id: kit
      selection_mode: round_robin
      zones:
        - { region: hits.kick_a, key_range: [36, 36], velocity_range: [1, 127], round_robin_group: kick }
        - { region: hits.kick_b, key_range: [36, 36], velocity_range: [1, 127], round_robin_group: kick }
        - { region: hits.snare_a, key_range: [38, 38], velocity_range: [1, 127], round_robin_group: snare }
        - { region: hits.snare_b, key_range: [38, 38], velocity_range: [1, 127], round_robin_group: snare }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 1, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("round-robin kit loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 5,
        duration_frames: 5,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("round-robin kit prepares");
    let events = vec![
        TimedInputEvent::new(
            0,
            ScriptEvent::NoteOn {
                note: 36,
                velocity: 100,
            },
        ),
        TimedInputEvent::new(
            1,
            ScriptEvent::NoteOn {
                note: 38,
                velocity: 100,
            },
        ),
        TimedInputEvent::new(
            2,
            ScriptEvent::NoteOn {
                note: 36,
                velocity: 100,
            },
        ),
        TimedInputEvent::new(
            3,
            ScriptEvent::NoteOn {
                note: 38,
                velocity: 100,
            },
        ),
        TimedInputEvent::new(
            4,
            ScriptEvent::NoteOn {
                note: 36,
                velocity: 100,
            },
        ),
    ];
    let first =
        render_kernel_offline_named(&prepared, events.clone(), &PreparedSamplerAssets::empty())
            .expect("first round-robin render");
    let second = render_kernel_offline_named(&prepared, events, &PreparedSamplerAssets::empty())
        .expect("second round-robin render");
    assert_eq!(first, second);
    assert_eq!(
        first[0].1[0],
        vec![-0.5, -0.75, 8191.0 / 32768.0, 16383.0 / 32768.0, -0.5]
    );
}

#[test]
fn seeded_weighted_drum_map_repeats_its_signed_hit_sequence() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: weighted_drums }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: rare, start_frame: 0, end_frame: 1 }
        - { id: common, start_frame: 1, end_frame: 2 }
  sample_maps:
    - id: kit
      selection_mode: random_weighted
      selection_seed: 123
      zones:
        - { region: hits.rare, key_range: [36, 36], velocity_range: [1, 127], weight: 1 }
        - { region: hits.common, key_range: [36, 36], velocity_range: [1, 127], weight: 3 }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 1, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("weighted kit loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 8,
        duration_frames: 8,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("weighted kit prepares");
    let events = (0..8)
        .map(|frame| {
            TimedInputEvent::new(
                frame,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            )
        })
        .collect::<Vec<_>>();
    let first =
        render_kernel_offline_named(&prepared, events.clone(), &PreparedSamplerAssets::empty())
            .expect("first weighted render");
    let second =
        render_kernel_offline_named(&prepared, events.clone(), &PreparedSamplerAssets::empty())
            .expect("second weighted render");
    assert_eq!(first, second);
    let common = 16383.0 / 32768.0;
    assert_eq!(
        first[0].1[0],
        vec![common, -0.5, -0.5, common, common, -0.5, common, common]
    );
    let poly_patch = load_kernel_patch_str(&yaml.replace("max_voices: 1", "max_voices: 2"))
        .expect("poly weighted kit loads");
    for block_size_frames in [8, 3, 1] {
        let poly_settings = RenderSettings {
            block_size_frames,
            ..settings.clone()
        };
        let poly_prepared =
            prepare_kernel_patch_with_context(&poly_patch, &poly_settings, &context)
                .expect("poly weighted kit prepares");
        let poly_rendered = render_kernel_offline_named(
            &poly_prepared,
            events.clone(),
            &PreparedSamplerAssets::empty(),
        )
        .expect("poly weighted kit renders");
        assert_eq!(poly_rendered[0].1[0], first[0].1[0]);
    }

    let error = match load_kernel_patch_str(&yaml.replace("weight: 3", "weight: 0")) {
        Ok(_) => panic!("zero-weight zone must fail schema validation"),
        Err(error) => error,
    };
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
    );
}

#[test]
fn drum_zone_region_gain_pan_and_pitch_offset_shape_stereo_hits() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [0.5, 0.25, -0.5, 0.75];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hits.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: zone_performance }
assets:
  sample_sources:
    - id: hits
      path: hits.wav
      regions:
        - { id: kick, start_frame: 0, end_frame: 2, gain_db: -6.020599913279624, pan: -0.5 }
        - { id: snare, start_frame: 2, end_frame: 4 }
  sample_maps:
    - id: kit
      zones:
        - { region: hits.kick, key_range: [36, 36], velocity_range: [1, 127], gain_db: -6.020599913279624, pan: -0.5, pitch_semitones: 12 }
        - { region: hits.snare, key_range: [38, 38], velocity_range: [1, 127], pan: 1 }
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 2, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 1, channels: 2 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("zone performance patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 5,
        duration_frames: 5,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("zone performance patch prepares");
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                2,
                ScriptEvent::NoteOn {
                    note: 38,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("zone performance patch renders");
    let left = &rendered[0].1[0];
    let right = &rendered[0].1[1];
    assert!((left[0] - 16383.0 / 32768.0 * 0.25).abs() < 1.0e-6);
    assert_eq!(left[1..], [0.0, 0.0, 0.0, 0.0]);
    assert_eq!(right, &vec![0.0, 0.0, -0.5, 24575.0 / 32768.0, 0.0]);

    for invalid in [
        yaml.replace("pitch_semitones: 12", "pitch_semitones: 49"),
        yaml.replace("pan: 1 }", "pan: 2 }"),
        yaml.replace(
            "velocity_range: [1, 127], gain_db: -6.020599913279624, pan: -0.5",
            "velocity_range: [1, 127], gain_db: 25, pan: -0.5",
        ),
    ] {
        let patch = load_kernel_patch_str(&invalid).expect("invalid zone numeric shape loads");
        let error = match prepare_kernel_patch_with_context(&patch, &settings, &context) {
            Ok(_) => panic!("out-of-range zone control must fail preparation"),
            Err(error) => error,
        };
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            error_codes::KERNEL_SAMPLE_INVALID_ZONE
        );
    }
}

#[test]
fn drum_zone_region_window_overrides_only_that_zones_playback() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, -0.25, 0.25, 0.5];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: zone_window }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 0, end_frame: 4 }]
  sample_maps:
    - id: kit
      zones:
        - { region: hit.body, region_override: { start_frame: 1, end_frame: 3 }, key_range: [36, 36], velocity_range: [1, 127] }
        - { region: hit.body, key_range: [38, 38], velocity_range: [1, 127] }
ports:
  - { name: master, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_map_player, static: { sample_map: kit, max_voices: 1, channels: 1 } }
connections:
  - { from: midi.events, to: player.note }
"#;
    let patch = load_kernel_patch_str(yaml).expect("zone window loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 5,
        duration_frames: 5,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("zone window prepares");
    assert_eq!(
        prepared.sample_assets().sources()[0].declaration().regions[0].start_frame,
        0
    );
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                3,
                ScriptEvent::NoteOn {
                    note: 38,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("zone window renders");
    assert_eq!(
        rendered[0].1[0],
        [-0.25, 8191.0 / 32768.0, 0.0, -0.5, -0.25]
    );

    for (replacement, code) in [
        (
            "start_frame: 3, end_frame: 3",
            error_codes::KERNEL_SAMPLE_INVALID_ZONE,
        ),
        (
            "start_frame: 1, end_frame: 5",
            error_codes::KERNEL_SAMPLE_INVALID_ZONE,
        ),
    ] {
        let invalid = yaml.replace("start_frame: 1, end_frame: 3", replacement);
        let patch = load_kernel_patch_str(&invalid).expect("invalid window shape loads");
        let error = prepare_kernel_patch_with_context(&patch, &settings, &context)
            .expect_err("invalid window must fail preparation");
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            code
        );
    }
    let looped = yaml.replace(
        "regions: [{ id: body, start_frame: 0, end_frame: 4 }]",
        "regions: [{ id: body, start_frame: 0, end_frame: 4, loop: { mode: forward, start_frame: 0, end_frame: 4 } }]",
    );
    let patch = load_kernel_patch_str(&looped).expect("looped window shape loads");
    let error = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect_err("window excluding inherited loop must fail");
    assert_eq!(
        error.diagnostics().errors().next().unwrap().error_code(),
        error_codes::KERNEL_SAMPLE_INVALID_ZONE
    );
}

#[test]
fn weighted_drum_selection_ignores_block_and_source_declaration_order() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    for (file, value) in [("rare.wav", -0.5), ("common.wav", 0.5)] {
        crate::wav::write_wav_stereo_i16(
            fs::File::create(directory.path().join(file)).expect("sample file"),
            48_000,
            &[value],
            &[value],
        )
        .expect("write sample");
    }
    let source_a = "    - id: rare\n      path: rare.wav\n      regions: [{ id: hit, start_frame: 0, end_frame: 1 }]\n";
    let source_b = "    - id: common\n      path: common.wav\n      regions: [{ id: hit, start_frame: 0, end_frame: 1 }]\n";
    let yaml = format!(
        r#"
metadata: {{ name: stable_weighted_kit }}
assets:
  sample_sources:
{source_a}{source_b}  sample_maps:
    - id: kit
      selection_mode: random_weighted
      selection_seed: 123
      zones:
        - {{ region: rare.hit, key_range: [36, 36], velocity_range: [1, 127], weight: 1 }}
        - {{ region: common.hit, key_range: [36, 36], velocity_range: [1, 127], weight: 3 }}
ports:
  - {{ name: audio_out, direction: output, signal: audio, channels: 1, maps_from: player.audio }}
modules:
  - {{ id: midi, type: midi_input }}
  - {{ id: player, type: sample_map_player, static: {{ sample_map: kit, max_voices: 1, channels: 1 }} }}
connections:
  - {{ from: midi.events, to: player.note }}
"#
    );
    let reordered = yaml.replace(
        &format!("{source_a}{source_b}"),
        &format!("{source_b}{source_a}"),
    );
    let events = (0..8)
        .map(|frame| {
            TimedInputEvent::new(
                frame,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            )
        })
        .collect::<Vec<_>>();
    let context = PreparationContext::new(directory.path(), 48_000);
    let mut results = Vec::new();
    for (document, block_size) in [(&yaml, 8), (&yaml, 3), (&reordered, 1)] {
        let patch = load_kernel_patch_str(document).expect("stable kit loads");
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: block_size,
            duration_frames: 8,
        };
        let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
            .expect("stable kit prepares");
        let rendered =
            render_kernel_offline_named(&prepared, events.clone(), &PreparedSamplerAssets::empty())
                .expect("stable kit renders");
        results.push(rendered[0].1[0].clone());
    }
    assert_eq!(results[0], results[1]);
    assert_eq!(results[0], results[2]);
    let common = 16383.0 / 32768.0;
    assert_eq!(
        results[0],
        vec![common, -0.5, -0.5, common, common, -0.5, common, common]
    );
}

#[test]
fn poly_region_renders_sample_player_child_with_independent_voices() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("hit.wav")).expect("sample file"),
        48_000,
        &[-0.5, 0.25, 0.0, 0.0],
        &[-0.5, 0.25, 0.0, 0.0],
    )
    .expect("write sample");
    let yaml = r#"
metadata: { name: poly_sample_region }
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{ id: body, start_frame: 0, end_frame: 2 }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: voices.audio }
module_definitions:
  - type: sample_voice
    ports:
      - { name: audio, direction: output, signal: audio, channels: 1, maps_from: player.audio }
    modules:
      - { id: player, type: sample_player, static: { source: hit, region: body, channels: 1 } }
    connections:
      - { from: voice.gate, to: player.trigger }
modules:
  - { id: midi, type: midi_input }
  - { id: voices, type: poly, static: { definition: sample_voice, max_voices: 2, allocation: reject-new } }
connections:
  - { from: midi.events, to: voices.notes }
"#;
    let patch = load_kernel_patch_str(yaml).expect("poly sample patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 5,
        duration_frames: 5,
    };
    let context = PreparationContext::new(directory.path(), 48_000);
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("poly sample voice prepares");
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 38,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("poly sample voices render");
    assert_eq!(
        rendered[0].1[0],
        vec![-1.0, 16382.0 / 32768.0, 0.0, 0.0, 0.0]
    );
}

#[test]
fn poly_region_renders_sample_slicer_child_and_recycles_finished_voices() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let values = [-0.5, 0.25];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("break.wav")).expect("sample file"),
        48_000,
        &values,
        &values,
    )
    .expect("write sample");
    let patch = load_kernel_patch_str(
        r#"
metadata: { name: poly_break_slice }
assets:
  sample_sources:
    - id: break
      path: break.wav
      slices: [{ id: hit, start_frame: 0, end_frame: 2 }]
ports:
  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: voices.audio }
module_definitions:
  - type: slice_voice
    ports:
      - { name: audio, direction: output, signal: audio, channels: 1, maps_from: slicer.audio }
    modules:
      - { id: slicer, type: sample_slicer, static: { source: break, slice_table: break, channels: 1 } }
    connections:
      - { from: voice.gate, to: slicer.trigger }
modules:
  - { id: midi, type: midi_input }
  - { id: voices, type: poly, static: { definition: slice_voice, max_voices: 2, allocation: reject-new } }
connections:
  - { from: midi.events, to: voices.notes }
"#,
    )
    .expect("poly break patch loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 2,
        duration_frames: 6,
    };
    let prepared = prepare_kernel_patch_with_context(
        &patch,
        &settings,
        &PreparationContext::new(directory.path(), 48_000),
    )
    .expect("poly slicer prepares");
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                0,
                ScriptEvent::NoteOn {
                    note: 38,
                    velocity: 100,
                },
            ),
            TimedInputEvent::new(
                4,
                ScriptEvent::NoteOn {
                    note: 36,
                    velocity: 100,
                },
            ),
        ],
        &PreparedSamplerAssets::empty(),
    )
    .expect("poly slice voices render");
    assert_eq!(
        rendered[0].1[0],
        vec![-1.0, 16382.0 / 32768.0, 0.0, 0.0, -0.5, 8191.0 / 32768.0]
    );
}

#[test]
fn invalid_explicit_slice_cue_and_beat_markers_fail_preparation() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let frames = vec![0.25; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("samples/break.wav")).unwrap(),
        48_000,
        &frames,
        &frames,
    )
    .expect("write sample");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    for (target, replacement, code) in [
        (
            "id: beat_1, start_frame: 0, end_frame: 24000",
            "id: beat_1, start_frame: 0, end_frame: 96001",
            error_codes::KERNEL_SAMPLE_INVALID_SLICE,
        ),
        (
            "id: beat_1, start_frame: 0, end_frame: 24000",
            "id: beat_1, start_frame: 24000, end_frame: 24000",
            error_codes::KERNEL_SAMPLE_INVALID_SLICE,
        ),
        (
            "id: beat_2, start_frame: 24000",
            "id: beat_1, start_frame: 24000",
            error_codes::KERNEL_SAMPLE_INVALID_SLICE,
        ),
        (
            "id: downbeat, frame: 0",
            "id: downbeat, frame: 96000",
            error_codes::KERNEL_SAMPLE_INVALID_TIMING,
        ),
        (
            "beats: [0, 24000, 48000]",
            "beats: [0, 96000]",
            error_codes::KERNEL_SAMPLE_INVALID_TIMING,
        ),
        (
            "beats: [0, 24000, 48000]",
            "beats: [24000, 0]",
            error_codes::KERNEL_SAMPLE_INVALID_TIMING,
        ),
        (
            "downbeats: [0, 48000]",
            "downbeats: [0, 48001]",
            error_codes::KERNEL_SAMPLE_INVALID_TIMING,
        ),
        (
            "tempo_bpm: 120",
            "tempo_bpm: 0",
            error_codes::KERNEL_SAMPLE_INVALID_TIMING,
        ),
        (
            "confidence: 0.95",
            "confidence: 1.5",
            error_codes::KERNEL_SAMPLE_INVALID_TIMING,
        ),
        (
            "- { id: downbeat, frame: 0 }",
            "- { id: downbeat, frame: 0 }\n        - { id: downbeat, frame: 1 }",
            error_codes::KERNEL_SAMPLE_INVALID_TIMING,
        ),
    ] {
        let invalid = SAMPLE_ASSET_PATCH.replacen(target, replacement, 1);
        let patch = load_kernel_patch_str(&invalid).expect("marker shape loads");
        let result = prepare_kernel_patch_with_context(&patch, &settings, &context);
        let error = match result {
            Ok(_) => panic!("invalid explicit marker {replacement} must fail"),
            Err(error) => error,
        };
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            code
        );
    }
}

#[test]
fn sample_map_rejects_missing_region_ambiguous_overlap_and_unknown_selection_mode() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let frames = vec![0.25; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("samples/break.wav")).unwrap(),
        48_000,
        &frames,
        &frames,
    )
    .expect("write sample");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    for (yaml, code) in [
        (
            SAMPLE_ASSET_PATCH.replacen("region: break.full", "region: break.missing", 1),
            error_codes::KERNEL_SAMPLE_INVALID_ZONE,
        ),
        (
            SAMPLE_ASSET_PATCH
                .replace("      selection_mode: round_robin\n", "")
                .replace("velocity_range: [71, 127]", "velocity_range: [1, 70]"),
            error_codes::KERNEL_SAMPLE_INVALID_ZONE,
        ),
        (
            SAMPLE_ASSET_PATCH.replace("selection_mode: round_robin", "selection_mode: shuffle"),
            error_codes::KERNEL_SAMPLE_UNSUPPORTED_MODE,
        ),
    ] {
        let patch = load_kernel_patch_str(&yaml).expect("map shape loads");
        let result = prepare_kernel_patch_with_context(&patch, &settings, &context);
        let error = match result {
            Ok(_) => panic!("invalid map must fail preparation"),
            Err(error) => error,
        };
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            code
        );
    }
}

#[test]
fn prepared_map_accepts_explicit_first_match_overlap_and_rejects_duplicate_ids() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let frames = vec![0.25; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("samples/break.wav")).unwrap(),
        48_000,
        &frames,
        &frames,
    )
    .expect("write sample");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    let first_match = SAMPLE_ASSET_PATCH
        .replace("selection_mode: round_robin", "selection_mode: first_match")
        .replace("velocity_range: [71, 127]", "velocity_range: [1, 70]");
    let patch = load_kernel_patch_str(&first_match).expect("explicit overlap loads");
    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("first_match resolves overlapping zones in authored order");
    let map = prepared.sample_assets().map_by_id("kit").unwrap();
    assert_eq!(map.zones()[0].declaration().id.as_deref(), Some("soft"));
    assert_eq!(map.zones()[1].declaration().id.as_deref(), Some("loud"));

    for (yaml, code) in [
        (
            SAMPLE_ASSET_PATCH.replace(
                "      slices:\n",
                "        - { id: full, start_frame: 0, end_frame: 100 }\n      slices:\n",
            ),
            error_codes::KERNEL_SAMPLE_INVALID_REGION,
        ),
        (
            SAMPLE_ASSET_PATCH.replace(
                "ports:\n",
                "    - id: kit\n      zones: [{ region: break.full, key_range: [36, 36], velocity_range: [1, 127] }]\nports:\n",
            ),
            error_codes::KERNEL_SAMPLE_INVALID_ZONE,
        ),
    ] {
        let patch = load_kernel_patch_str(&yaml).expect("duplicate identifier shape loads");
        let result = prepare_kernel_patch_with_context(&patch, &settings, &context);
        let error = match result {
            Ok(_) => panic!("duplicate sample identifier must fail"),
            Err(error) => error,
        };
        assert_eq!(error.diagnostics().errors().next().unwrap().error_code(), code);
        assert!(error.diagnostics().errors().next().unwrap().message().contains("duplicate"));
    }
}

#[test]
fn sample_map_requires_at_least_one_zone() {
    let yaml = "metadata: { name: empty_map }\nassets: { sample_maps: [{ id: kit, zones: [] }] }\nports:\n  - { name: audio_out, direction: output, signal: audio, channels: 1, maps_from: osc.audio }\nmodules:\n  - { id: osc, type: oscillator }\n";
    let result = load_kernel_patch_str(yaml);
    let error = match result {
        Ok(_) => panic!("empty sample map must fail schema validation"),
        Err(error) => error,
    };
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
    );
}

#[test]
fn sample_source_rejects_unsupported_decode_format_and_out_of_bounds_region() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let path = directory.path().join("samples/break.wav");
    fs::write(&path, b"not a WAV file").expect("write invalid sample");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    let patch = load_kernel_patch_str(SAMPLE_ASSET_PATCH).expect("sample declaration loads");

    let error = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect_err("unsupported sample must fail preparation");
    assert_eq!(
        error.diagnostics().errors().next().unwrap().error_code(),
        error_codes::KERNEL_SAMPLE_UNSUPPORTED_FORMAT
    );

    let frames = vec![0.25; 95_999];
    crate::wav::write_wav_stereo_i16(fs::File::create(&path).unwrap(), 48_000, &frames, &frames)
        .expect("write valid short sample");
    let error = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect_err("region beyond sample must fail preparation");
    assert_eq!(
        error.diagnostics().errors().next().unwrap().error_code(),
        error_codes::KERNEL_SAMPLE_INVALID_REGION
    );
}

#[test]
fn sample_source_retains_its_rate_when_host_rate_differs() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let path = directory.path().join("samples/break.wav");
    crate::wav::write_wav_stereo_i16(fs::File::create(&path).unwrap(), 44_100, &[0.5], &[0.5])
        .expect("write sample at another rate");
    let patch = load_kernel_patch_str(
        r#"
metadata: { name: source_rate }
assets:
  sample_sources:
    - id: break
      path: samples/break.wav
      regions: [{ id: hit, start_frame: 0, end_frame: 1 }]
ports:
  - { name: master, direction: output, signal: audio, channels: 1, maps_from: player.audio }
modules:
  - { id: midi, type: midi_input }
  - { id: player, type: sample_player, static: { source: break, region: hit, channels: 1 } }
connections:
  - { from: midi.events, to: player.trigger }
"#,
    )
    .expect("sample declaration loads");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };

    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("different source rate prepares");
    assert_eq!(
        prepared.sample_assets().sources()[0]
            .sample()
            .sample_rate_hz(),
        44_100
    );
    let rendered = render_kernel_offline_named(
        &prepared,
        vec![TimedInputEvent::new(
            0,
            ScriptEvent::NoteOn {
                note: 60,
                velocity: 100,
            },
        )],
        &PreparedSamplerAssets::empty(),
    )
    .expect("source renders at host rate");
    assert_eq!(rendered[0].1[0][0], 16383.0 / 32768.0);
    assert_eq!(rendered[0].1[0][1], 16383.0 / 32768.0);
    assert_eq!(rendered[0].1[0][2], 0.0);
}

#[test]
fn sample_assets_require_a_resource_context_and_reject_path_escape() {
    let patch = load_kernel_patch_str(SAMPLE_ASSET_PATCH).expect("sample declaration loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    let error = crate::preparation::prepare_kernel_patch(&patch, &settings)
        .expect_err("sample declarations need a document root");
    assert_eq!(
        error.diagnostics().errors().next().unwrap().error_code(),
        error_codes::KERNEL_SAMPLE_CONTEXT_REQUIRED
    );

    let escaped = SAMPLE_ASSET_PATCH.replace("samples/break.wav", "../outside.wav");
    let patch = load_kernel_patch_str(&escaped).expect("path shape loads");
    let directory = tempfile::tempdir().expect("temporary resource root");
    let context = PreparationContext::new(directory.path(), 48_000);
    let error = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect_err("escaping path must fail preparation");
    assert_eq!(
        error.diagnostics().errors().next().unwrap().error_code(),
        error_codes::KERNEL_RESOURCE_PATH_ESCAPE
    );
}

#[test]
fn sample_asset_preparation_rejects_unsupported_loop_and_invalid_region_values() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    for (target, replacement, code) in [
        (
            "mode: forward",
            "mode: ping_pong",
            error_codes::KERNEL_SAMPLE_UNSUPPORTED_MODE,
        ),
        (
            "pan: 0.25",
            "pan: 2",
            error_codes::KERNEL_SAMPLE_INVALID_REGION,
        ),
        (
            "fade_in_ms: 2",
            "fade_in_ms: -1",
            error_codes::KERNEL_SAMPLE_INVALID_REGION,
        ),
        (
            "crossfade_ms: 5",
            "crossfade_ms: -5",
            error_codes::KERNEL_SAMPLE_INVALID_LOOP,
        ),
    ] {
        let invalid = SAMPLE_ASSET_PATCH.replacen(target, replacement, 1);
        let patch = load_kernel_patch_str(&invalid).expect("shape is valid");
        let result = prepare_kernel_patch_with_context(&patch, &settings, &context);
        let error = match result {
            Ok(_) => panic!("invalid {target} must fail preparation"),
            Err(error) => error,
        };
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            code
        );
    }
}

#[test]
fn sample_region_rejects_fades_crossfades_and_gain_outside_prepared_bounds() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let frames = vec![0.25; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("samples/break.wav")).unwrap(),
        48_000,
        &frames,
        &frames,
    )
    .expect("write sample");
    let context = PreparationContext::new(directory.path(), 48_000);
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    for (target, replacement, code) in [
        (
            "fade_in_ms: 2",
            "fade_in_ms: 3000",
            error_codes::KERNEL_SAMPLE_INVALID_REGION,
        ),
        (
            "fade_out_ms: 3",
            "fade_out_ms: 3000",
            error_codes::KERNEL_SAMPLE_INVALID_REGION,
        ),
        (
            "fade_in_ms: 2",
            "fade_in_ms: 1000",
            error_codes::KERNEL_SAMPLE_INVALID_REGION,
        ),
        (
            "crossfade_ms: 5",
            "crossfade_ms: 300",
            error_codes::KERNEL_SAMPLE_INVALID_LOOP,
        ),
        (
            "gain_db: -3",
            "gain_db: 100",
            error_codes::KERNEL_SAMPLE_INVALID_REGION,
        ),
    ] {
        let invalid = if target == "fade_in_ms: 2" && replacement == "fade_in_ms: 1000" {
            SAMPLE_ASSET_PATCH
                .replace(target, replacement)
                .replace("fade_out_ms: 3", "fade_out_ms: 1500")
        } else {
            SAMPLE_ASSET_PATCH.replacen(target, replacement, 1)
        };
        let patch = load_kernel_patch_str(&invalid).expect("region declaration loads");
        let result = prepare_kernel_patch_with_context(&patch, &settings, &context);
        let error = match result {
            Ok(_) => panic!("invalid region metadata {replacement} must fail"),
            Err(error) => error,
        };
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            code
        );
    }
}

#[test]
fn sample_region_rejects_invalid_root_note_and_reverse_shape() {
    for (target, replacement) in [
        ("root_note: 60", "root_note: 128"),
        ("reverse: false", "reverse: sometimes"),
    ] {
        let invalid = SAMPLE_ASSET_PATCH.replacen(target, replacement, 1);
        let result = load_kernel_patch_str(&invalid);
        let error = match result {
            Ok(_) => panic!("invalid {target} must fail"),
            Err(error) => error,
        };
        assert_eq!(
            error.errors().next().unwrap().error_code(),
            error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
        );
    }
}

#[test]
fn sample_region_accepts_fades_that_fit_exactly_and_half_loop_crossfade() {
    let directory = tempfile::tempdir().expect("temporary sample root");
    fs::create_dir(directory.path().join("samples")).expect("sample directory");
    let frames = vec![0.25; 96_000];
    crate::wav::write_wav_stereo_i16(
        fs::File::create(directory.path().join("samples/break.wav")).unwrap(),
        48_000,
        &frames,
        &frames,
    )
    .expect("write sample");
    let yaml = SAMPLE_ASSET_PATCH
        .replace("fade_in_ms: 2", "fade_in_ms: 1000")
        .replace("fade_out_ms: 3", "fade_out_ms: 1000")
        .replace("crossfade_ms: 5", "crossfade_ms: 250");
    let patch = load_kernel_patch_str(&yaml).expect("boundary region loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    let context = PreparationContext::new(directory.path(), 48_000);

    let prepared = prepare_kernel_patch_with_context(&patch, &settings, &context)
        .expect("fades exactly within windows should prepare");
    let region = &prepared.sample_assets().sources()[0].declaration().regions[0];
    assert_eq!(region.fade_in_ms, Some(1000.0));
    assert_eq!(region.fade_out_ms, Some(1000.0));
    assert_eq!(
        region.loop_settings.as_ref().unwrap().crossfade_ms,
        Some(250.0)
    );
}

#[test]
fn drum_map_player_rejects_unbounded_or_zero_voice_limits() {
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    for limit in [0, 4096] {
        let yaml = format!(
            "metadata: {{ name: drum_map }}\nports:\n  - {{ name: audio_out, direction: output, signal: audio, channels: 2, maps_from: player.audio }}\nmodules:\n  - {{ id: player, type: sample_map_player, static: {{ sample_map: kit, max_voices: {limit} }} }}\n"
        );
        let patch = load_kernel_patch_str(&yaml).expect("sampler graph loads");
        let result = crate::preparation::prepare_kernel_patch(&patch, &settings);
        let error = match result {
            Ok(_) => panic!("invalid voice limit {limit} must fail"),
            Err(error) => error,
        };
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            error_codes::KERNEL_SAMPLE_INVALID_VOICE_LIMIT
        );
    }
}

#[test]
fn sample_modules_reject_unsupported_interpolation_and_choke_modes() {
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    for (kind, static_args) in [
        (
            "sample_player",
            "source: break, region: full, interpolation: sinc",
        ),
        ("sample_map_player", "sample_map: kit, choke_mode: teleport"),
    ] {
        let yaml = format!(
            "metadata: {{ name: invalid_sample_mode }}\nports:\n  - {{ name: audio_out, direction: output, signal: audio, channels: 2, maps_from: player.audio }}\nmodules:\n  - {{ id: player, type: {kind}, static: {{ {static_args} }} }}\n"
        );
        let patch = load_kernel_patch_str(&yaml).expect("sampler graph shape loads");
        let result = crate::preparation::prepare_kernel_patch(&patch, &settings);
        let error = match result {
            Ok(_) => panic!("unsupported {kind} mode must fail"),
            Err(error) => error,
        };
        assert_eq!(
            error.diagnostics().errors().next().unwrap().error_code(),
            error_codes::KERNEL_STATIC_ARGUMENT_INVALID_ENUM_VALUE
        );
    }
}

#[test]
fn kernel_cli_overrides_resolve_against_declared_static_and_control_types() {
    let mut patch = load_kernel_patch_str(COMPLETE_PATCH).expect("patch loads");
    for (name, value) in [
        ("channels", "1"),
        ("mode", "clean"),
        ("label", "123"),
        ("impulse", "other.wav"),
        ("gain", "0.8"),
    ] {
        patch
            .apply_cli_override("amp", name, value, None)
            .expect("declared CLI value applies");
    }
    let amp = patch
        .root()
        .nodes()
        .iter()
        .find(|node| node.id().as_str() == "amp")
        .expect("amp node");
    assert_eq!(
        amp.static_args().get("channels"),
        Some(&StaticArg::Literal(StaticValue::Int(1)))
    );
    assert_eq!(
        amp.static_args().get("mode"),
        Some(&StaticArg::Literal(StaticValue::Enum("clean".to_string())))
    );
    assert_eq!(
        amp.static_args().get("label"),
        Some(&StaticArg::Literal(StaticValue::String("123".to_string())))
    );
    assert_eq!(
        amp.static_args().get("impulse"),
        Some(&StaticArg::Literal(StaticValue::Resource(
            ResourceRef::new(
                ResourceKind::ImpulseResponse,
                "other.wav",
                ResourceOrigin::Document,
            )
        )))
    );
    assert_eq!(amp.port_default_overrides().get("gain"), Some(&0.8));
    assert_eq!(
        patch.root().ports()[0].control_default().unwrap().default(),
        0.8
    );
}

#[test]
fn kernel_cli_overrides_reject_unknown_targets_types_and_ranges() {
    let patch = load_kernel_patch_str(COMPLETE_PATCH).expect("patch loads");
    for (module, name, value) in [
        ("missing", "gain", "1"),
        ("amp", "missing", "1"),
        ("amp", "channels", "1.5"),
        ("amp", "channels", "inf"),
        ("amp", "channels", "9223372036854775808"),
        ("amp", "mode", "invalid"),
        ("amp", "mode", "true"),
        ("amp", "gain", "true"),
        ("amp", "gain", "3"),
        ("amp", "gain", "1.5"),
        ("amp", "audio_out", "1"),
    ] {
        let mut candidate = patch.clone();
        let diagnostics = candidate
            .apply_cli_override(module, name, value, None)
            .expect_err("invalid CLI override must fail");
        assert_eq!(diagnostics.errors().count(), 1, "{module}.{name}");
        assert!(
            diagnostics
                .to_string()
                .contains(&format!("{module}.{name}")),
            "{module}.{name}: {diagnostics}"
        );
        assert_eq!(
            candidate.root(),
            patch.root(),
            "failure cannot mutate patch"
        );
    }
}

#[test]
fn kernel_cli_override_rejects_module_without_resolved_definition() {
    let mut patch = load_kernel_patch_str(
        "ports:\n  - { name: out, direction: output, signal: audio, channels: 1 }\nmodules:\n  - { id: future, type: future_module }\nconnections: []\n",
    )
    .expect("unresolved definition is preserved by loading");
    let diagnostics = patch
        .apply_cli_override("future", "count", "2", None)
        .expect_err("override needs a resolved declaration");
    assert!(diagnostics.to_string().contains("future_module"));
    assert!(diagnostics.to_string().contains("future.count"));
}

#[test]
fn kernel_cli_override_uses_only_the_matching_external_definition() {
    let reference = "$USER_LIB/demo/demo.yaml";
    let patch = load_kernel_patch_str(
        "ports:\n  - { name: master, direction: output, signal: audio, channels: 1, maps_from: voice.audio }\nmodules:\n  - { id: voice, type: $USER_LIB/demo/demo.yaml }\nconnections: []\n",
    )
    .expect("external reference loads");
    let level = Port::input("level", SignalType::Control, 1u32)
        .with_control_default(ControlDefault::new(0.5).with_min(0.0).with_max(1.0));
    let matching = GraphDefinition::new(reference).with_port(level.clone());
    let unrelated = GraphDefinition::new("$USER_LIB/other/other.yaml").with_port(level);

    let mut rejected = patch.clone();
    let diagnostics = rejected
        .apply_cli_override("voice", "level", "0.4", Some(&unrelated))
        .expect_err("a declaration from another package is not authoritative");
    assert!(diagnostics.to_string().contains(reference));
    assert_eq!(rejected.root(), patch.root());

    let mut applied = patch;
    applied
        .apply_cli_override("voice", "level", "0.4", Some(&matching))
        .expect("matching package declaration accepts the override");
    assert_eq!(
        applied.root().nodes()[0]
            .port_default_overrides()
            .get("level"),
        Some(&0.4)
    );
}

#[test]
fn kernel_cli_override_validates_integer_choices_and_control_port_kind() {
    let mut reverb = load_kernel_patch_str(
        "ports:\n  - { name: master, direction: output, signal: audio, channels: 2, maps_from: effect.audio_out }\nmodules:\n  - { id: effect, type: reverb }\nconnections: []\n",
    )
    .expect("reverb patch loads");
    reverb
        .apply_cli_override("effect", "channels", "1", None)
        .expect("mono is a declared channel choice");
    assert_eq!(
        reverb.root().nodes()[0].static_args().get("channels"),
        Some(&StaticArg::Literal(StaticValue::Int(1)))
    );
    let before = reverb.root().clone();
    assert!(
        reverb
            .apply_cli_override("effect", "channels", "3", None)
            .is_err()
    );
    assert!(
        reverb
            .apply_cli_override("effect", "audio_in", "1", None)
            .is_err()
    );
    assert_eq!(reverb.root(), &before);
}

#[test]
fn kernel_cli_override_validates_builtin_control_range_boundaries() {
    let patch = load_kernel_patch_str(
        "ports:\n  - { name: master, direction: output, signal: audio, channels: 1, maps_from: amp.audio_out }\nmodules:\n  - { id: amp, type: gain }\nconnections: []\n",
    )
    .expect("gain patch loads");
    for value in ["0", "4"] {
        let mut candidate = patch.clone();
        candidate
            .apply_cli_override("amp", "gain", value, None)
            .expect("inclusive boundary is valid");
        assert_eq!(
            candidate.root().nodes()[0]
                .port_default_overrides()
                .get("gain"),
            Some(&value.parse::<f64>().unwrap())
        );
    }
    for value in ["-0.1", "4.1", "NaN"] {
        let mut candidate = patch.clone();
        assert!(
            candidate
                .apply_cli_override("amp", "gain", value, None)
                .is_err()
        );
        assert_eq!(candidate.root(), patch.root());
    }
}

#[test]
fn kernel_cli_override_validates_mapped_root_control_range_boundaries() {
    let patch = load_kernel_patch_str(
        "ports:\n  - { name: level, direction: input, signal: control, channels: 1, default: 0.75, min: 0.5, max: 1, maps_to: amp.gain }\n  - { name: master, direction: output, signal: audio, channels: 1, maps_from: amp.audio_out }\nmodules:\n  - { id: amp, type: gain }\nconnections: []\n",
    )
    .expect("mapped root control loads");
    for (raw, expected) in [("0.5", 0.5), ("1", 1.0)] {
        let mut candidate = patch.clone();
        candidate
            .apply_cli_override("amp", "gain", raw, None)
            .expect("root boundary is inclusive");
        assert_eq!(
            candidate.root().ports()[0]
                .control_default()
                .unwrap()
                .default(),
            expected
        );
    }
    for raw in ["0.25", "1.25"] {
        let mut candidate = patch.clone();
        assert!(
            candidate
                .apply_cli_override("amp", "gain", raw, None)
                .is_err()
        );
        assert_eq!(candidate.root(), patch.root());
    }
}

#[test]
fn kernel_cli_override_changes_only_the_targeted_root_control_default() {
    let mut patch = load_kernel_patch_str(
        "ports:\n  - { name: left_level, direction: input, signal: control, channels: 1, default: 0.75, min: 0, max: 1, maps_to: left.gain }\n  - { name: right_level, direction: input, signal: control, channels: 1, default: 0.6, min: 0.5, max: 1, maps_to: right.gain }\n  - { name: master, direction: output, signal: audio, channels: 1, maps_from: left.audio_out }\nmodules:\n  - { id: left, type: gain }\n  - { id: right, type: gain }\nconnections: []\n",
    )
    .expect("two independent root controls load");
    patch
        .apply_cli_override("left", "gain", "0.2", None)
        .expect("one destination is unambiguous");
    let defaults = patch
        .root()
        .ports()
        .iter()
        .filter_map(|port| {
            port.control_default()
                .map(|default| (port.name(), default.default()))
        })
        .collect::<Vec<_>>();
    assert_eq!(defaults, [("left_level", 0.2), ("right_level", 0.6)]);
}

#[test]
fn kernel_cli_override_rejects_shared_root_control_without_mutating_patch() {
    let mut patch = load_kernel_patch_str(
        "ports:\n  - { name: level, direction: input, signal: control, channels: 1, default: 0.75, min: 0, max: 1, maps_to: [left.gain, right.gain] }\n  - { name: master, direction: output, signal: audio, channels: 1, maps_from: left.audio_out }\nmodules:\n  - { id: left, type: gain }\n  - { id: right, type: gain }\nconnections: []\n",
    )
    .expect("shared root control loads");
    let before = patch.root().clone();
    let diagnostics = patch
        .apply_cli_override("left", "gain", "0.2", None)
        .expect_err("target-specific override cannot change both destinations");
    assert!(diagnostics.to_string().contains("maps to multiple inputs"));
    assert_eq!(patch.root(), &before);
}

const PRESET_PATCH: &str = r#"
metadata: { name: preset_test }
instrument: { id: test.instrument, preset_schema_version: 2 }
static_params:
  - name: sample
    type: resource
    resource_kind: sample
    default: { kind: sample, path: original.wav }
ports:
  - { name: volume, direction: input, signal: control, channels: 1, default: 0.75, min: 0, max: 1, maps_to: amp.gain }
  - { name: out, direction: output, signal: audio, channels: 1, maps_from: amp.audio_out }
preset_surface:
  parameters:
    - { name: loudness, maps_to: volume }
  assets:
    - { name: hit, maps_to: sample }
modules:
  - { id: osc, type: oscillator }
  - { id: amp, type: gain }
connections:
  - { from: osc.audio, to: amp.audio_in }
"#;

#[test]
fn kernel_preset_surface_preserves_aliased_root_metadata() {
    let patch = load_kernel_patch_str(PRESET_PATCH).expect("preset patch loads");

    let identity = patch.instrument().expect("instrument identity");
    assert_eq!(identity.id, "test.instrument");
    assert_eq!(identity.preset_schema_version, 2);
    let value = &patch.preset_surface().parameters()[0];
    assert_eq!(value.name(), "loudness");
    assert_eq!(value.port_name(), "volume");
    assert_eq!(value.control_default().default(), 0.75);
    assert_eq!(value.control_default().min(), Some(0.0));
    assert_eq!(value.control_default().max(), Some(1.0));
    let asset = &patch.preset_surface().assets()[0];
    assert_eq!(asset.name(), "hit");
    assert_eq!(asset.static_param_name(), "sample");
    assert_eq!(asset.kind(), ResourceKind::Sample);
    assert_eq!(
        asset.default().unwrap().path().to_str(),
        Some("original.wav")
    );
}

#[test]
fn kernel_preset_application_changes_root_defaults_before_flattening() {
    let patch = load_kernel_patch_str(PRESET_PATCH).expect("preset patch loads");
    let preset = load_preset_str(
        "name: loud\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nvalues: { loudness: 0.4 }\nassets: { hit: alternate.wav }\n",
    )
    .expect("preset loads");

    let applied = patch.apply_preset(&preset).expect("preset applies");
    let flat = applied
        .root()
        .flatten(applied.registry())
        .expect("flattens");

    assert_eq!(
        applied.root().ports()[0]
            .control_default()
            .unwrap()
            .default(),
        0.4
    );
    assert_eq!(
        flat.node(&crate::kernel::NodeId::new("amp"))
            .unwrap()
            .port_defaults()["gain"],
        0.4
    );
    assert_eq!(
        applied.root().static_params()[0].default(),
        Some(&StaticValue::Resource(ResourceRef::new(
            ResourceKind::Sample,
            "alternate.wav",
            ResourceOrigin::Document,
        )))
    );
    assert_eq!(
        patch.root().ports()[0].control_default().unwrap().default(),
        0.75
    );
}

#[test]
fn kernel_preset_surface_rejects_duplicate_or_unresolved_aliases() {
    let duplicate = PRESET_PATCH.replace(
        "  assets:\n    - { name: hit, maps_to: sample }",
        "  assets:\n    - { name: loudness, maps_to: sample }",
    );
    let error = load_kernel_patch_str(&duplicate).expect_err("duplicate alias fails");
    assert!(
        error
            .to_string()
            .contains("duplicate preset target loudness")
    );

    let missing = PRESET_PATCH.replace("maps_to: volume }", "maps_to: missing }");
    let error = load_kernel_patch_str(&missing).expect_err("missing destination fails");
    assert!(
        error
            .to_string()
            .contains("unresolved control input missing")
    );

    let unnamed = PRESET_PATCH.replace(
        "name: loudness, maps_to: volume",
        "name: '', maps_to: volume",
    );
    let error = load_kernel_patch_str(&unnamed).expect_err("unnamed alias fails");
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED,
    );
    assert!(
        error
            .to_string()
            .contains("/preset_surface/parameters/0/name")
    );

    let no_default =
        PRESET_PATCH.replace("    default: { kind: sample, path: original.wav }\n", "");
    let error = load_kernel_patch_str(&no_default).expect_err("asset alias needs default");
    assert!(
        error
            .to_string()
            .contains("requires a declared resource default")
    );
}

#[test]
fn kernel_preset_rejects_identity_unknown_targets_and_incompatible_values() {
    let patch = load_kernel_patch_str(PRESET_PATCH).expect("preset patch loads");
    for (yaml, expected) in [
        (
            "name: wrong\ninstrument: { id: other, preset_schema_version: 2 }\n",
            "does not match patch instrument",
        ),
        (
            "name: wrong-version\ninstrument: { id: test.instrument, preset_schema_version: 3 }\n",
            "does not match patch instrument",
        ),
        (
            "name: unknown\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nvalues: { other: 0.5 }\n",
            "unknown preset target other",
        ),
        (
            "name: internal\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nvalues: { 'amp.gain': 0.5 }\n",
            "unknown preset target amp.gain",
        ),
        (
            "name: type\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nvalues: { loudness: loud }\n",
            "incompatible type or range",
        ),
        (
            "name: range\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nvalues: { loudness: 2.0 }\n",
            "incompatible type or range",
        ),
        (
            "name: structural\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nmodules: []\n",
            "preset cannot declare structural field modules",
        ),
        (
            "name: connection\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nconnections: []\n",
            "preset cannot declare structural field connections",
        ),
        (
            "name: unknown-asset\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nassets: { extra: other.wav }\n",
            "unknown preset target extra",
        ),
    ] {
        let preset = load_preset_str(yaml).expect("preset YAML loads");
        let error = patch
            .apply_preset(&preset)
            .expect_err("incompatible preset fails");
        assert!(error.to_string().contains(expected), "{error}");
    }
}

#[test]
fn preset_application_requires_instrument_identity_and_known_asset_target() {
    let preset = load_preset_str(
        "name: missing\ninstrument: { id: test.instrument, preset_schema_version: 2 }\n",
    )
    .expect("preset loads");
    let patch = load_kernel_patch_str(&PRESET_PATCH.replace(
        "instrument: { id: test.instrument, preset_schema_version: 2 }\n",
        "",
    ))
    .expect("patch without preset identity loads");
    let error = patch
        .apply_preset(&preset)
        .expect_err("identity is required");
    assert!(
        error
            .to_string()
            .contains("does not declare instrument preset identity")
    );

    let patch = load_kernel_patch_str(PRESET_PATCH).expect("preset patch loads");
    let unknown_asset = load_preset_str(
        "name: unknown\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nassets: { other: alternate.wav }\n",
    )
    .expect("preset loads");
    let error = patch
        .apply_preset(&unknown_asset)
        .expect_err("unknown asset target fails");
    assert!(error.to_string().contains("unknown preset target other"));
}

#[test]
fn preset_surface_rejects_unknown_asset_destination_and_duplicate_parameter_name() {
    let missing_asset = PRESET_PATCH.replace("maps_to: sample }", "maps_to: missing }");
    let error = load_kernel_patch_str(&missing_asset)
        .expect_err("asset target must name a resource static parameter");
    assert!(
        error
            .to_string()
            .contains("unresolved resource static parameter missing")
    );

    let duplicate_parameter = PRESET_PATCH.replace(
        "    - { name: loudness, maps_to: volume }",
        "    - { name: loudness, maps_to: volume }\n    - { name: loudness, maps_to: out }",
    );
    let error = load_kernel_patch_str(&duplicate_parameter)
        .expect_err("duplicate parameter target must fail");
    assert!(
        error
            .to_string()
            .contains("duplicate preset target loudness")
    );
}

#[test]
fn malformed_yaml_shapes_fail_schema_without_panicking() {
    for yaml in [
        "42",
        "module_definitions: [42]\nports: []\nmodules: []\nconnections: []\n",
        "ports: []\nmodules: [42]\nconnections: []\n",
    ] {
        let error = load_kernel_patch_str(yaml).expect_err("malformed document fails");
        assert_eq!(
            error.errors().next().unwrap().error_code(),
            error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
        );
    }
}

#[test]
fn non_string_yaml_mapping_keys_fail_before_graph_construction() {
    let yaml = "? [one, two]\n: 1\n";
    let error = load_kernel_patch_str(yaml).expect_err("non-JSON mapping key fails");
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
    );
    assert!(error.to_string().contains("cannot be represented as JSON"));
}

#[test]
fn unresolved_node_static_literals_keep_inferred_types() {
    let patch = load_kernel_patch_str(
        "ports:\n  - { name: out, direction: output, signal: audio, channels: 1 }\nmodules:\n  - { id: future, type: future_module, static: { count: 3, label: bright, sample: { kind: sample, path: hit.wav } } }\nconnections: []\n",
    )
    .expect("unknown node type can retain its authored static values for later resolution");
    let args = patch.root().nodes()[0].static_args();
    assert_eq!(args["count"], StaticArg::Literal(StaticValue::Int(3)));
    assert_eq!(
        args["label"],
        StaticArg::Literal(StaticValue::String("bright".into()))
    );
    assert_eq!(
        args["sample"],
        StaticArg::Literal(StaticValue::Resource(ResourceRef::new(
            ResourceKind::Sample,
            "hit.wav",
            ResourceOrigin::Document,
        )))
    );
}

#[test]
fn node_static_literal_must_match_the_declared_type() {
    let yaml = "ports:\n  - { name: out, direction: output, signal: audio, channels: 1 }\nmodules:\n  - { id: source, type: control_to_audio, static: { channels: wide } }\nconnections: []\n";
    let error = load_kernel_patch_str(yaml).expect_err("noninteger channel count fails");
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_PARSE_FAILED
    );
    assert!(
        error
            .to_string()
            .contains("does not match declared type Int")
    );
}

#[test]
fn yaml_control_default_must_parse_as_a_number() {
    let yaml = "ports:\n  - { name: out, direction: output, signal: audio, channels: 1, maps_from: amp.audio_out }\nmodules:\n  - { id: amp, type: gain, defaults: { gain: loud } }\nconnections: []\n";
    let error = load_kernel_patch_str(yaml).expect_err("nonnumeric control default fails");
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
    );
    assert!(error.to_string().contains("gain"));
}

#[test]
fn yaml_static_expression_is_retained_for_explicit_rejection() {
    let yaml = "ports:\n  - { name: out, direction: output, signal: audio, channels: 1 }\nmodules:\n  - { id: source, type: control_to_audio, static: { channels: '$channels + 1' } }\nconnections: []\n";
    let patch = load_kernel_patch_str(yaml).expect("expression is parsed before graph validation");
    assert_eq!(
        patch.root().nodes()[0].static_args()["channels"],
        StaticArg::Expression("$channels + 1".into())
    );
    let error = patch
        .root()
        .flatten(patch.registry())
        .expect_err("arithmetic is unsupported");
    assert!(error.to_string().contains("expression"));
}

#[test]
fn malformed_port_reference_has_structured_parse_diagnostic() {
    let yaml = "ports:\n  - { name: out, direction: output, signal: audio, channels: 1, maps_from: source }\nmodules:\n  - { id: source, type: control_to_audio }\nconnections: []\n";
    let error = load_kernel_patch_str(yaml).expect_err("port reference must have module and port");
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_PARSE_FAILED
    );
    assert!(error.to_string().contains("module.port"));
}

#[test]
fn tagged_legacy_binding_is_rejected_before_schema_validation() {
    let yaml = "ports:\n  - { name: out, direction: output, signal: audio, channels: 1 }\nmodules:\n  - id: source\n    type: control_to_audio\n    static: { channels: !tag '${channels}' }\nconnections: []\n";
    let error = load_kernel_patch_str(yaml).expect_err("tagged legacy binding fails");
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_LEGACY_BINDING
    );
}

#[test]
fn missing_kernel_patch_file_has_read_diagnostic() {
    let directory = tempfile::tempdir().expect("temporary directory");
    let path = directory.path().join("absent.yaml");
    let error = load_kernel_patch_file(&path).expect_err("missing patch fails");
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_READ_FAILED
    );
    assert!(error.to_string().contains("absent.yaml"));
}

#[test]
fn kernel_preset_compatibility_diagnostics_identify_expected_and_actual_identity() {
    let patch = load_kernel_patch_str(PRESET_PATCH).expect("preset patch loads");
    for (yaml, expected, actual) in [
        (
            "name: wrong-id\ninstrument: { id: other, preset_schema_version: 2 }\n",
            "test.instrument",
            "other",
        ),
        (
            "name: wrong-version\ninstrument: { id: test.instrument, preset_schema_version: 3 }\n",
            "2",
            "3",
        ),
    ] {
        let preset = load_preset_str(yaml).expect("preset loads");
        let error = patch
            .apply_preset(&preset)
            .expect_err("incompatible preset fails");
        let diagnostic = error.errors().next().expect("compatibility diagnostic");
        assert_eq!(diagnostic.expected(), Some(expected));
        assert_eq!(diagnostic.actual(), Some(actual));
    }
}

#[test]
fn omitted_kernel_preset_targets_keep_root_defaults() {
    let patch = load_kernel_patch_str(PRESET_PATCH).expect("preset patch loads");
    let preset = load_preset_str(
        "name: plain\ninstrument: { id: test.instrument, preset_schema_version: 2 }\n",
    )
    .expect("preset loads");

    let applied = patch.apply_preset(&preset).expect("preset applies");
    assert_eq!(
        applied.root().ports()[0]
            .control_default()
            .unwrap()
            .default(),
        0.75
    );
    assert_eq!(
        applied.root().static_params()[0].default(),
        patch.root().static_params()[0].default()
    );
}

#[test]
fn kernel_preset_asset_passes_through_root_static_parameter_to_node() {
    let yaml = PRESET_PATCH.replace(
        "  - { id: amp, type: gain }",
        "  - { id: amp, type: gain }\n  - { id: hit, type: sampler, static: { sample: $sample } }",
    );
    let patch = load_kernel_patch_str(&yaml).expect("resource patch loads");
    let preset = load_preset_str(
        "name: alternate\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nassets: { hit: alternate.wav }\n",
    )
    .expect("preset loads");

    let applied = patch.apply_preset(&preset).expect("preset applies");
    let flat = applied
        .root()
        .flatten(applied.registry())
        .expect("flattens");
    assert_eq!(
        flat.node(&crate::kernel::NodeId::new("hit"))
            .unwrap()
            .static_args()["sample"],
        StaticValue::Resource(ResourceRef::new(
            ResourceKind::Sample,
            "alternate.wav",
            ResourceOrigin::Document,
        ))
    );
}

#[test]
fn kernel_preset_asset_is_resolved_during_context_preparation() {
    let directory = tempfile::tempdir().expect("temporary resource root");
    for (name, sample) in [("original.wav", 0.25), ("alternate.wav", 0.75)] {
        crate::wav::write_wav_stereo_i16(
            fs::File::create(directory.path().join(name)).expect("create sample"),
            48_000,
            &[sample],
            &[sample],
        )
        .expect("write sample");
    }
    let yaml = PRESET_PATCH.replace(
        "  - { id: amp, type: gain }",
        "  - { id: amp, type: gain }\n  - { id: hit, type: sampler, static: { sample: $sample } }",
    );
    let patch = load_kernel_patch_str(&yaml).expect("resource patch loads");
    let preset = load_preset_str(
        "name: alternate\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nassets: { hit: alternate.wav }\n",
    )
    .expect("preset loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 16,
        duration_frames: 16,
    };
    let context = PreparationContext::new(directory.path(), 48_000);

    let prepared =
        prepare_kernel_patch_with_preset_and_context(&patch, &preset, &settings, &context)
            .expect("preset resource prepares");
    let sample = prepared
        .compiled_patch()
        .nodes()
        .iter()
        .find(|node| node.id.as_str() == "hit")
        .and_then(|node| node.resources.sample.as_ref())
        .expect("sampler has resolved sample");
    assert!((sample.frames()[0] - 0.75).abs() < 0.0001);
}

#[test]
fn incoming_control_connection_takes_precedence_over_preset_default() {
    let yaml = PRESET_PATCH
        .replace(
            "  - { id: amp, type: gain }",
            "  - { id: amp, type: gain }\n  - { id: follower, type: envelope_follower }",
        )
        .replace(
            "  - { from: osc.audio, to: amp.audio_in }",
            "  - { from: osc.audio, to: amp.audio_in }\n  - { from: osc.audio, to: follower.audio_in }\n  - { from: follower.value, to: amp.gain }",
        );
    let patch = load_kernel_patch_str(&yaml).expect("patch loads");
    let preset = load_preset_str(
        "name: quiet\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nvalues: { loudness: 0.4 }\n",
    )
    .expect("preset loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 128,
        duration_frames: 512,
    };

    let preset_prepared = prepare_kernel_patch_with_preset(&patch, &preset, &settings)
        .expect("preset patch prepares");
    let default_prepared = crate::preparation::prepare_kernel_patch(&patch, &settings)
        .expect("default patch prepares");
    let render = |prepared: &_| {
        render_kernel_offline_named(prepared, Vec::new(), &PreparedSamplerAssets::empty())
            .expect("named render succeeds")
    };
    let preset_render = render(&preset_prepared);
    assert!(
        preset_render[0].1[0]
            .iter()
            .any(|sample| sample.abs() > 0.001)
    );
    assert_eq!(preset_render, render(&default_prepared));
}

#[test]
fn kernel_preset_render_is_deterministic_and_uses_aliased_default() {
    let patch = load_kernel_patch_str(PRESET_PATCH).expect("preset patch loads");
    let preset = load_preset_str(
        "name: quiet\ninstrument: { id: test.instrument, preset_schema_version: 2 }\nvalues: { loudness: 0.4 }\n",
    )
    .expect("preset loads");
    let settings = RenderSettings {
        sample_rate_hz: 48_000,
        block_size_frames: 128,
        duration_frames: 512,
    };

    let prepared = prepare_kernel_patch_with_preset(&patch, &preset, &settings)
        .expect("preset patch prepares");
    let render = || {
        render_kernel_offline_named(&prepared, Vec::new(), &PreparedSamplerAssets::empty())
            .expect("named render succeeds")
    };
    let first = render();
    let second = render();
    assert_eq!(first, second);
    assert!(first[0].1[0].iter().any(|sample| sample.abs() > 0.01));

    let default = crate::preparation::prepare_kernel_patch(&patch, &settings)
        .expect("default patch prepares");
    let default_render =
        render_kernel_offline_named(&default, Vec::new(), &PreparedSamplerAssets::empty())
            .expect("default named render succeeds");
    assert_ne!(first[0].1[0], default_render[0].1[0]);
}

#[test]
fn complete_kernel_document_produces_root_and_inline_graph_definitions() {
    let patch = load_kernel_patch_str(COMPLETE_PATCH).expect("kernel patch should load");

    assert_eq!(patch.metadata().name(), Some("reusable_voice"));
    assert_eq!(patch.metadata().version(), Some("1.2"));
    assert_eq!(patch.metadata().author(), Some("Test Author"));

    let root = patch.root();
    assert_eq!(root.name(), "reusable_voice");
    assert_eq!(root.static_params().len(), 4);
    assert_eq!(root.static_params()[0].static_type(), StaticType::Int);
    assert_eq!(
        root.static_params()[0].default(),
        Some(&StaticValue::Int(2))
    );
    assert_eq!(
        root.static_params()[1].allowed_values(),
        ["clean", "driven"]
    );
    assert_eq!(
        root.static_params()[2].default(),
        Some(&StaticValue::String("fn process(ctx) {}".into()))
    );
    assert_eq!(
        root.static_params()[3].static_type(),
        StaticType::Resource(ResourceKind::ImpulseResponse)
    );
    assert_eq!(
        root.static_params()[3].default(),
        Some(&StaticValue::Resource(ResourceRef::new(
            ResourceKind::ImpulseResponse,
            "room_ir.wav",
            ResourceOrigin::Document,
        )))
    );

    let level = &root.ports()[0];
    assert_eq!(level.direction(), PortDirection::Input);
    assert_eq!(level.signal_type(), SignalType::Control);
    assert_eq!(level.channels(), &ChannelCount::Literal(1));
    let default = level.control_default().expect("control default");
    assert_eq!(default.default(), 0.75);
    assert_eq!(default.min(), Some(0.0));
    assert_eq!(default.max(), Some(1.0));
    assert_eq!(default.unit(), Some("linear"));
    assert_eq!(level.internal_targets()[0].node().as_str(), "amp");
    assert_eq!(level.internal_targets()[0].port(), "gain");

    let master = &root.ports()[1];
    assert_eq!(master.channels(), &ChannelCount::Param("channels".into()));
    assert_eq!(master.internal_sources()[0].node().as_str(), "amp");
    assert_eq!(
        root.nodes()[0].static_args()["channels"],
        StaticArg::ParamRef("channels".into())
    );
    assert_eq!(
        root.nodes()[0].static_args()["mode"],
        StaticArg::Literal(StaticValue::Enum("driven".into()))
    );
    assert_eq!(
        root.nodes()[0].static_args()["label"],
        StaticArg::Literal(StaticValue::String("main".into()))
    );
    assert_eq!(
        root.nodes()[0].static_args()["impulse"],
        StaticArg::Literal(StaticValue::Resource(ResourceRef::new(
            ResourceKind::ImpulseResponse,
            "room_ir.wav",
            ResourceOrigin::Document,
        )))
    );
    assert_eq!(root.nodes()[0].port_default_overrides()["gain"], 0.5);
    assert_eq!(root.connections().len(), 1);

    let defined_module = patch
        .registry()
        .get("amplifier")
        .expect("inline defined module");
    assert_eq!(defined_module.static_params().len(), 4);
    assert_eq!(defined_module.ports().len(), 2);
    assert_eq!(defined_module.nodes().len(), 1);
}

#[test]
fn resource_static_parameter_requires_a_resource_kind() {
    let error = load_kernel_patch_str(
        "metadata: { name: missing-kind }\nstatic_params:\n  - { name: sample, type: resource }\nports:\n  - { name: out, direction: output, signal: audio, channels: 1 }\nmodules: []\nconnections: []\n",
    )
    .expect_err("resource declarations without a kind must fail");

    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_PARSE_FAILED
    );
}

#[test]
fn graph_declaration_has_patch_and_defined_module_symmetry() {
    let patch = load_kernel_patch_str(COMPLETE_PATCH).expect("kernel patch should load");
    let defined_module = patch
        .registry()
        .get("amplifier")
        .expect("inline defined module");

    assert_eq!(
        patch.root().static_params()[0].name(),
        defined_module.static_params()[0].name()
    );
    assert_eq!(
        patch.root().static_params()[0].static_type(),
        defined_module.static_params()[0].static_type()
    );
    assert!(patch.root().ports()[0].control_default().is_some());
    assert!(defined_module.ports()[0].control_default().is_some());
    assert_eq!(defined_module.nodes()[0].definition_ref(), "gain");
}

#[test]
fn parsed_root_defined_module_script_and_primitive_use_the_same_discovery_schema() {
    let patch = load_kernel_patch_str(COMPLETE_PATCH).expect("kernel patch loads");
    let root = patch.root().metadata();
    let defined_module = patch.registry().discover("amplifier").unwrap();
    let primitive = patch.registry().discover("gain").unwrap();
    let scripted = load_kernel_patch_str(SCRIPT_DEFINITION_PATCH).expect("script patch loads");
    let script = scripted.registry().discover("counter").unwrap();

    assert_eq!(root.name(), "reusable_voice");
    assert_eq!(root.ports()[1].channels(), &ChannelCount::param("channels"));
    assert_eq!(
        root.static_params()[3].static_type(),
        StaticType::Resource(ResourceKind::ImpulseResponse)
    );
    assert_eq!(
        defined_module.ports()[0].control_default().unwrap().unit(),
        Some("linear")
    );
    assert_eq!(
        defined_module.static_params()[1].allowed_values(),
        ["clean", "driven"]
    );
    assert_eq!(primitive.ports()[0].name(), "audio_in");
    assert_eq!(script.ports()[0].signal_type(), SignalType::Event);
    assert_eq!(script.static_params()[1].static_type(), StaticType::String);
}

#[test]
fn standalone_defined_module_shape_loads_as_a_root_patch() {
    let yaml = r#"
metadata: { name: amplifier }
static_params:
  - { name: channels, type: int, default: 1 }
ports:
  - { name: gain, direction: input, signal: control, channels: 1, default: 1, maps_to: inner.gain }
  - { name: audio_out, direction: output, signal: audio, channels: $channels, maps_from: inner.audio_out }
modules:
  - { id: inner, type: gain }
connections: []
"#;
    let patch = load_kernel_patch_str(yaml).expect("defined-module-shaped root should load");

    assert_eq!(patch.root().name(), "amplifier");
    assert_eq!(patch.root().static_params().len(), 1);
    assert_eq!(patch.root().ports().len(), 2);
    assert_eq!(patch.root().nodes().len(), 1);
}

#[test]
fn yaml_and_yml_files_load_through_public_file_surface() {
    let directory = std::env::temp_dir();
    for extension in ["yaml", "yml"] {
        let path = directory.join(format!("dandrum-kernel-document.{extension}"));
        fs::write(&path, COMPLETE_PATCH).expect("write test patch");
        let loaded = load_kernel_patch_file(&path).expect("load test patch");
        fs::remove_file(path).expect("remove test patch");
        assert_eq!(loaded.root().name(), "reusable_voice");
    }
}

#[test]
fn unsupported_file_format_has_structured_diagnostic() {
    let diagnostics = load_kernel_patch_file("patch.json").expect_err("JSON should be rejected");
    assert_eq!(
        diagnostics.all()[0].error_code(),
        error_codes::KERNEL_DOCUMENT_UNSUPPORTED_FORMAT
    );
    assert!(diagnostics.all()[0].message().contains(".json"));
}

#[test]
fn malformed_yaml_has_structured_diagnostic() {
    let diagnostics = load_kernel_patch_str("ports: [").expect_err("malformed YAML should fail");
    assert_eq!(
        diagnostics.all()[0].error_code(),
        error_codes::KERNEL_DOCUMENT_PARSE_FAILED
    );
}

#[test]
fn legacy_document_fields_are_rejected_with_specific_diagnostics() {
    for (field, code) in [
        ("render", error_codes::KERNEL_DOCUMENT_LEGACY_RENDER),
        (
            "voice_allocation",
            error_codes::KERNEL_DOCUMENT_LEGACY_VOICE_ALLOCATION,
        ),
    ] {
        let yaml = format!(
            "metadata: {{ name: test }}\nports: []\nmodules: []\nconnections: []\n{field}: {{}}\n"
        );
        let diagnostics = load_kernel_patch_str(&yaml).expect_err("legacy field should fail");
        assert_eq!(diagnostics.all()[0].error_code(), code);
        assert!(diagnostics.all()[0].message().contains(field));
        if field == "render" {
            assert!(diagnostics.all()[0].message().contains("host"));
        }
    }
}

#[test]
fn legacy_instance_parameters_are_rejected_with_module_context() {
    let yaml = "metadata: { name: test }\nports: []\nmodules:\n  - id: amp\n    type: gain\n    parameters: { gain: 0.5 }\nconnections: []\n";
    let diagnostics = load_kernel_patch_str(yaml).expect_err("parameters should fail");
    let diagnostic = &diagnostics.all()[0];
    assert_eq!(
        diagnostic.error_code(),
        error_codes::KERNEL_DOCUMENT_LEGACY_PARAMETERS
    );
    assert_eq!(diagnostic.module_id(), Some("amp"));
}

#[test]
fn external_module_reference_rejects_unsupported_composite_id_field() {
    let yaml = "ports:\n  - { name: audio, direction: output, signal: audio, channels: 1, maps_from: voice.audio }\nmodules:\n  - id: voice\n    type: $LIB/1.0.0/voice/voice.yaml\n    composite_id: voice\nconnections: []\n";
    let diagnostics = load_kernel_patch_str(yaml)
        .expect_err("composite_id must not become an alternative module reference field");
    assert_eq!(
        diagnostics.all()[0].error_code(),
        error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
    );
    assert!(diagnostics.all()[0].message().contains("composite_id"));
}

#[test]
fn legacy_parameter_binding_is_rejected_in_static_arguments() {
    let yaml = "metadata: { name: test }\nports: []\nmodule_definitions:\n  - type: child\n    static_params:\n      - { name: channels, type: int }\n    ports: []\n    modules: []\n    connections: []\nmodules:\n  - id: child\n    type: child\n    static: { channels: '${channels}' }\nconnections: []\n";
    let diagnostics = load_kernel_patch_str(yaml).expect_err("legacy binding should fail");
    assert_eq!(
        diagnostics.all()[0].error_code(),
        error_codes::KERNEL_DOCUMENT_LEGACY_BINDING
    );
    assert_eq!(diagnostics.all()[0].module_id(), Some("child"));
}

#[test]
fn legacy_parameter_binding_is_rejected_in_default_overrides() {
    let yaml = "metadata: { name: test }\nports:\n  - { name: out, direction: output, signal: audio, channels: 1 }\nmodules:\n  - id: amp\n    type: gain\n    defaults: { gain: '${level}' }\nconnections: []\n";
    let diagnostics = load_kernel_patch_str(yaml).expect_err("legacy binding should fail");
    assert_eq!(
        diagnostics.all()[0].error_code(),
        error_codes::KERNEL_DOCUMENT_LEGACY_BINDING
    );
    assert_eq!(diagnostics.all()[0].module_id(), Some("amp"));
}

#[test]
fn legacy_composite_asset_bindings_are_rejected_with_definition_context() {
    let yaml = "metadata: { name: test }\nports: []\nmodule_definitions:\n  - type: child\n    asset_bindings: []\n    ports: []\n    modules: []\n    connections: []\nmodules: []\nconnections: []\n";
    let diagnostics = load_kernel_patch_str(yaml).expect_err("asset bindings should fail");
    assert_eq!(
        diagnostics.all()[0].error_code(),
        error_codes::KERNEL_DOCUMENT_LEGACY_ASSET_BINDINGS
    );
    assert_eq!(diagnostics.all()[0].module_id(), Some("child"));
}

#[test]
fn legacy_composite_parameters_are_rejected_with_definition_context() {
    let yaml = "ports: []\nmodule_definitions:\n  - type: child\n    parameters: []\n    ports: []\n    modules: []\n    connections: []\nmodules: []\nconnections: []\n";
    let diagnostics = load_kernel_patch_str(yaml).expect_err("legacy parameters fail");
    assert_eq!(
        diagnostics.all()[0].error_code(),
        error_codes::KERNEL_DOCUMENT_LEGACY_PARAMETERS
    );
    assert_eq!(diagnostics.all()[0].module_id(), Some("child"));
}

#[test]
fn patch_without_root_output_has_structured_diagnostic() {
    let yaml = "metadata: { name: silent }\nports:\n  - { name: level, direction: input, signal: control, channels: 1, default: 0 }\nmodules: []\nconnections: []\n";
    let diagnostics = load_kernel_patch_str(yaml).expect_err("root output is required");
    assert_eq!(
        diagnostics.all()[0].error_code(),
        error_codes::KERNEL_DOCUMENT_NO_OUTPUT
    );
    assert!(
        diagnostics.all()[0]
            .message()
            .contains("no observable output")
    );
}

#[test]
fn unknown_static_and_default_names_are_reported_by_kernel_validation() {
    let yaml = r#"
metadata: { name: invalid_overrides }
ports:
  - { name: out, direction: output, signal: audio, channels: 1, maps_from: amp.audio_out }
module_definitions:
  - type: amplifier
    static_params:
      - { name: channels, type: int, default: 1 }
    ports:
      - { name: audio_out, direction: output, signal: audio, channels: $channels, maps_from: inner.audio_out }
    modules:
      - { id: inner, type: gain }
    connections: []
modules:
  - id: amp
    type: amplifier
    static: { unknown_shape: 2 }
  - id: amp_default
    type: amplifier
    defaults: { unknown_port: 0.5 }
connections: []
"#;
    let patch = load_kernel_patch_str(yaml).expect("document shape should parse");
    let validation = patch.root().validate(patch.registry());
    let codes = validation
        .diagnostics()
        .all()
        .iter()
        .map(|diagnostic| diagnostic.error_code())
        .collect::<Vec<_>>();

    assert!(codes.contains(&error_codes::KERNEL_UNKNOWN_STATIC_ARGUMENT));
    assert!(codes.contains(&error_codes::KERNEL_OVERRIDE_UNKNOWN_PORT));
}

// --- 3.3 Input multiplicity YAML parsing ----------------------------------

#[test]
fn summing_multiplicity_parses_from_yaml() {
    let yaml = r#"
metadata:
  name: summing_test
ports:
  - { name: master, direction: output, signal: audio, channels: 1 }
module_definitions:
  - type: mixer
    ports:
      - { name: inputs, direction: input, signal: audio, channels: 1, multiplicity: summing }
      - { name: mix, direction: output, signal: audio, channels: 1 }
    modules: []
    connections: []
modules:
  - id: m
    type: mixer
connections: []
"#;
    let patch = load_kernel_patch_str(yaml).expect("document should parse");
    let mixer = patch
        .registry()
        .get("mixer")
        .expect("mixer definition registered");
    let inputs = mixer
        .ports()
        .iter()
        .find(|p| p.name() == "inputs")
        .expect("inputs port exists");
    assert_eq!(
        inputs.multiplicity(),
        crate::kernel::Multiplicity::Summing,
        "YAML multiplicity: summing should parse"
    );
}

#[test]
fn omitted_multiplicity_defaults_to_single_source() {
    let yaml = r#"
metadata:
  name: single_test
ports:
  - { name: master, direction: output, signal: audio, channels: 1 }
module_definitions:
  - type: gain_like
    ports:
      - { name: audio_in, direction: input, signal: audio, channels: 1 }
      - { name: audio_out, direction: output, signal: audio, channels: 1 }
    modules: []
    connections: []
modules:
  - id: g
    type: gain_like
connections: []
"#;
    let patch = load_kernel_patch_str(yaml).expect("document should parse");
    let gain_like = patch
        .registry()
        .get("gain_like")
        .expect("gain_like definition registered");
    let audio_in = gain_like
        .ports()
        .iter()
        .find(|p| p.name() == "audio_in")
        .expect("audio_in port exists");
    assert_eq!(
        audio_in.multiplicity(),
        crate::kernel::Multiplicity::SingleSource,
        "omitted multiplicity should default to single_source"
    );
}

#[test]
fn single_source_multiplicity_parses_explicitly() {
    let yaml = r#"
metadata:
  name: explicit_single
ports:
  - { name: master, direction: output, signal: audio, channels: 1 }
module_definitions:
  - type: single_input
    ports:
      - { name: audio_in, direction: input, signal: audio, channels: 1, multiplicity: single_source }
      - { name: audio_out, direction: output, signal: audio, channels: 1 }
    modules: []
    connections: []
modules:
  - id: s
    type: single_input
connections: []
"#;
    let patch = load_kernel_patch_str(yaml).expect("document should parse");
    let single_input = patch
        .registry()
        .get("single_input")
        .expect("single_input definition registered");
    let audio_in = single_input
        .ports()
        .iter()
        .find(|p| p.name() == "audio_in")
        .expect("audio_in port exists");
    assert_eq!(
        audio_in.multiplicity(),
        crate::kernel::Multiplicity::SingleSource,
        "explicit single_source should parse"
    );
}

const SCRIPT_DEFINITION_PATCH: &str = r#"
metadata: { name: scripted }
ports:
  - { name: out, direction: output, signal: audio, channels: 1 }
module_definitions:
  - type: counter
    implementation: script
    static_params:
      - { name: language, type: enum, default: rhai, allowed_values: [rhai] }
      - { name: source, type: string }
    ports:
      - { name: events, direction: input, signal: event, channels: 1 }
      - { name: increment, direction: input, signal: control, channels: 1, default: 1 }
      - { name: count, direction: output, signal: control, channels: 1 }
modules:
  - id: first
    type: counter
    static: { source: "fn process(ctx) {}" }
    defaults: { increment: 2 }
  - id: second
    type: counter
    static: { source: "fn process(ctx) {}" }
connections: []
"#;

#[test]
fn script_backed_definition_uses_the_ordinary_node_shape() {
    let patch = load_kernel_patch_str(SCRIPT_DEFINITION_PATCH).expect("script definition loads");
    let definition = patch.registry().get("counter").expect("named definition");

    assert_eq!(
        definition.implementation(),
        DefinitionImplementation::Script
    );
    assert_eq!(
        definition.static_params()[0].static_type(),
        StaticType::Enum
    );
    assert_eq!(
        definition.static_params()[1].static_type(),
        StaticType::String
    );
    assert_eq!(definition.ports().len(), 3);
    assert_eq!(patch.root().nodes()[0].definition_ref(), "counter");
    assert_eq!(
        patch.root().nodes()[0].port_default_overrides()["increment"],
        2.0
    );
}

#[test]
fn script_instances_reject_ad_hoc_port_fields() {
    let yaml = SCRIPT_DEFINITION_PATCH.replace(
        "    defaults: { increment: 2 }",
        "    defaults: { increment: 2 }\n    inputs: [{ name: invented, signal: control }]",
    );

    let diagnostics = load_kernel_patch_str(&yaml).expect_err("instance ports are not authorable");

    assert_eq!(
        diagnostics.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED
    );
    assert!(diagnostics.all()[0].message().contains("inputs"));
}

#[test]
fn script_definition_rejects_internal_graph_structure_and_audio_ports() {
    for (replacement, expected_fragment) in [
        (
            "    implementation: script\n    modules: [{ id: inner, type: gain }]",
            "internal modules",
        ),
        (
            "    implementation: script\n    connections: [{ from: a.out, to: b.in }]",
            "internal connections",
        ),
        (
            "      - { name: count, direction: output, signal: audio, channels: 1 }",
            "audio port",
        ),
    ] {
        let yaml = if replacement.starts_with("    implementation") {
            SCRIPT_DEFINITION_PATCH.replace("    implementation: script", replacement)
        } else {
            SCRIPT_DEFINITION_PATCH.replace(
                "      - { name: count, direction: output, signal: control, channels: 1 }",
                replacement,
            )
        };

        let diagnostics =
            load_kernel_patch_str(&yaml).expect_err("malformed script definition must fail");
        let diagnostic = diagnostics.errors().next().unwrap();
        assert_eq!(
            diagnostic.error_code(),
            error_codes::KERNEL_SCRIPT_DEFINITION_INVALID
        );
        assert!(diagnostic.message().contains(expected_fragment));
        assert_eq!(diagnostic.module_id(), Some("counter"));
    }
}

#[test]
fn script_definition_requires_typed_language_and_source_declarations() {
    for (yaml, expected_fragment) in [
        (
            SCRIPT_DEFINITION_PATCH.replace(
                "      - { name: language, type: enum, default: rhai, allowed_values: [rhai] }\n",
                "",
            ),
            "language",
        ),
        (
            SCRIPT_DEFINITION_PATCH.replace("      - { name: source, type: string }\n", ""),
            "source",
        ),
        (
            SCRIPT_DEFINITION_PATCH
                .replace("name: language, type: enum", "name: language, type: string"),
            "language",
        ),
        (
            SCRIPT_DEFINITION_PATCH
                .replace("name: source, type: string", "name: source, type: int"),
            "source",
        ),
    ] {
        let diagnostics =
            load_kernel_patch_str(&yaml).expect_err("script construction declarations are fixed");
        let diagnostic = diagnostics.errors().next().unwrap();
        assert_eq!(
            diagnostic.error_code(),
            error_codes::KERNEL_SCRIPT_DEFINITION_INVALID
        );
        assert!(diagnostic.message().contains(expected_fragment));
        assert_eq!(diagnostic.module_id(), Some("counter"));
    }
}

#[test]
fn unsupported_definition_implementation_has_a_structured_diagnostic() {
    let yaml = SCRIPT_DEFINITION_PATCH.replace("implementation: script", "implementation: wasm");

    let diagnostics = load_kernel_patch_str(&yaml).expect_err("unsupported implementation fails");
    let diagnostic = diagnostics.errors().next().unwrap();

    assert_eq!(
        diagnostic.error_code(),
        error_codes::KERNEL_DEFINITION_IMPLEMENTATION_UNSUPPORTED
    );
    assert_eq!(diagnostic.module_id(), Some("counter"));
    assert_eq!(diagnostic.actual(), Some("wasm"));
}

const POLY_PATCH: &str = r#"
metadata: { name: poly_patch }
ports:
  - { name: master, direction: output, signal: audio, channels: 2, maps_from: voices.audio }
module_definitions:
  - type: voice
    ports:
      - { name: level, direction: input, signal: control, channels: 1, default: 0.5 }
      - { name: audio, direction: output, signal: audio, channels: 2 }
    modules: []
    connections: []
modules:
  - { id: midi, type: midi_input }
  - id: voices
    type: poly
    static: { definition: voice, max_voices: 8, allocation: oldest-steal }
connections:
  - { from: midi.events, to: voices.notes }
"#;

#[test]
fn yaml_poly_node_uses_ordinary_node_shape_and_synthesized_interface() {
    let patch = load_kernel_patch_str(POLY_PATCH).expect("poly YAML loads");
    let poly = &patch.root().nodes()[1];

    assert_eq!(poly.definition_ref(), POLY_DEFINITION);
    assert_eq!(
        poly.static_args()["allocation"],
        StaticArg::Literal(StaticValue::Enum(POLY_ALLOCATION_OLDEST_STEAL.to_string()))
    );
    assert!(
        patch.root().validate(patch.registry()).is_ok(),
        "YAML connections validate through the synthesized interface"
    );
    let ports = patch
        .root()
        .resolved_node_ports(patch.registry(), poly.id())
        .expect("poly ports resolve");
    assert!(
        ports
            .iter()
            .any(|port| port.name() == POLY_NOTE_EVENTS_INPUT)
    );
    assert!(ports.iter().any(|port| port.name() == "level"));
    assert!(ports.iter().any(|port| port.name() == "audio"));
}

#[test]
fn yaml_poly_rejects_invalid_allocation_policy_during_validation() {
    let yaml = POLY_PATCH.replace("oldest-steal", "newest-steal");
    let patch = load_kernel_patch_str(&yaml).expect("document shape still loads");
    let validation = patch.root().validate(patch.registry());

    assert_eq!(
        validation
            .diagnostics()
            .errors()
            .next()
            .unwrap()
            .error_code(),
        error_codes::KERNEL_STATIC_ARGUMENT_INVALID_ENUM_VALUE
    );
}

#[test]
fn kernel_loader_checks_external_schema_before_constructing_a_graph() {
    let yaml = r#"
metadata: { name: schema_check }
instrument: { id: "", preset_schema_version: 0 }
ports:
  - { name: out, direction: output, signal: audio, channels: 1, maps_from: osc.audio }
modules:
  - { id: osc, type: oscillator }
"#;

    let error =
        load_kernel_patch_str(yaml).expect_err("empty preset identity fails schema validation");
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED,
    );
    assert!(error.to_string().contains("instrument"));
}

#[test]
fn external_kernel_schema_and_serde_agree_on_document_shape_fixtures() {
    let fixtures = [
        ("complete", COMPLETE_PATCH, true),
        ("preset", PRESET_PATCH, true),
        ("script", SCRIPT_DEFINITION_PATCH, true),
        ("poly", POLY_PATCH, true),
        (
            "summing",
            "ports:\n  - { name: mix, direction: input, signal: audio, channels: 2, multiplicity: summing }\n",
            true,
        ),
        (
            "unknown-root",
            "ports: []\nmodules: []\nunknown: true\n",
            false,
        ),
        (
            "legacy-render",
            "render: { sample_rate_hz: 48000 }\n",
            false,
        ),
        (
            "legacy-voice-allocation",
            "voice_allocation: { max_voices: 8 }\n",
            false,
        ),
        (
            "unknown-node",
            "modules:\n  - { id: osc, type: oscillator, inputs: [] }\n",
            false,
        ),
        (
            "missing-port-channels",
            "ports:\n  - { name: out, direction: output, signal: audio }\n",
            false,
        ),
        (
            "bad-multiplicity",
            "ports:\n  - { name: out, direction: output, signal: audio, channels: 1, multiplicity: many }\n",
            false,
        ),
        (
            "bad-static-type",
            "static_params:\n  - { name: channels, type: float }\n",
            false,
        ),
        (
            "bad-resource-kind",
            "static_params:\n  - { name: sample, type: resource, resource_kind: script }\n",
            false,
        ),
    ];

    for (name, yaml, expected) in fixtures {
        let value: serde_yaml::Value = serde_yaml::from_str(yaml).expect("fixture YAML parses");
        assert_eq!(
            super::validate_kernel_schema(&value).is_ok(),
            expected,
            "schema: {name}",
        );
        assert_eq!(
            serde_yaml::from_value::<super::PatchDocument>(value).is_ok(),
            expected,
            "Serde: {name}",
        );
    }
}

#[test]
fn external_schema_checks_poly_static_argument_types() {
    let yaml = POLY_PATCH.replace("max_voices: 8", "max_voices: many");
    let error = load_kernel_patch_str(&yaml).expect_err("poly shape should fail schema validation");
    assert_eq!(
        error.errors().next().unwrap().error_code(),
        error_codes::KERNEL_DOCUMENT_SCHEMA_FAILED,
    );
    assert!(error.to_string().contains("/modules/1/static/max_voices"));
}
