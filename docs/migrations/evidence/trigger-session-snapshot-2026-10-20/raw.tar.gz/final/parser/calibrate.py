import pathlib,subprocess,json,hashlib,os,time,shutil
root=pathlib.Path('/tmp/dandrum-lanes/evidence-host-snapshot-final-verification/parser');deps=pathlib.Path('/dev/shm/dandrum-beta-20261020/host-snapshot-cov/debug/deps');libs=list(deps.glob('libdandrum_trigger_host-*.rlib'));assert len(libs)==1,libs
package=root/'copied-product';(package/'instrument/assets').mkdir(parents=True,exist_ok=True)
repo=pathlib.Path('/tmp/dandrum-lanes/protocol')
for a,b in [('examples/patches/advanced-drum-kit.yaml','instrument/advanced-drum-kit.yaml'),('examples/patches/assets/advanced-drums.wav','instrument/assets/advanced-drums.wav')]:shutil.copyfile(repo/a,package/b)
commands=[['/home/dan/.cargo/bin/rustc','--edition=2024','-C','instrument-coverage','-L','dependency='+str(deps),'--extern','dandrum_trigger_host='+str(libs[0]),str(root/'projection.rs'),'-o',str(root/'projection')],[str(root/'projection'),str(package)],['/home/dan/.nvm/versions/node/v22.19.0/bin/node','--experimental-loader',str(root/'yaml-loader.mjs'),str(root/'parse-production.mjs'),str(root/'actual-replies.json')]]
receipts=[]
for n,cmd in enumerate(commands):
 start=time.monotonic();env=os.environ.copy();env['LLVM_PROFILE_FILE']=str(root/'oneoff-%p.profraw');p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(root/f'calibration-{n}.stdout').write_bytes(p.stdout);(root/f'calibration-{n}.stderr').write_bytes(p.stderr)
 receipts.append({'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-start});assert p.returncode==0,p.stderr.decode()
 if n==1:(root/'actual-replies.json').write_bytes(p.stdout)
(root/'calibration.json').write_text(json.dumps(receipts,indent=2)+'\n');print((root/'calibration-2.stdout').read_text())
