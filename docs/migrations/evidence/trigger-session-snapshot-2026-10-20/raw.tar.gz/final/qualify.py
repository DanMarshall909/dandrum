import json,pathlib,subprocess,re,hashlib
r=pathlib.Path('/tmp/dandrum-lanes/evidence-host-snapshot-final-verification');w=pathlib.Path('/tmp/dandrum-lanes/protocol');d=json.loads((r/'final-llvm.json').read_text())['data'][0]
result={}
for file in d['files']:
 name=file['filename']
 if '/trigger-host/src/' not in name:continue
 functions=[];spans={};regions={};raw_regions=0;raw_regions_covered=0
 for f in d['functions']:
  if name not in f['filenames']:continue
  primary=f['regions'][0];primary_file=f['filenames'][primary[5]]
  if primary_file==name:
   functions.append(f);key=tuple(primary[:4]);spans[key]=spans.get(key,False) or f['count']>0
  for region in f['regions']:
   if f['filenames'][region[5]]!=name or region[7]!=0:continue
   raw_regions+=1;raw_regions_covered+=region[4]>0;key=tuple(region[:4]);regions[key]=regions.get(key,False) or region[4]>0
 hits={s[0] for s in file['segments'] if s[2]>0};zeros={s[0] for s in file['segments'] if s[2]==0 and s[3] and s[4]}
 result[pathlib.Path(name).name]={'llvm_file_summary':file['summary'],'raw_emitted_function_records':len(functions),'raw_executed_function_records':sum(f['count']>0 for f in functions),'distinct_primary_source_spans':len(spans),'executed_distinct_primary_source_spans':sum(spans.values()),'raw_emitted_kind0_regions':raw_regions,'raw_executed_kind0_regions':raw_regions_covered,'distinct_kind0_region_source_spans':len(regions),'executed_distinct_kind0_region_source_spans':sum(regions.values()),'zero_hit_annotated_physical_lines':sorted(zeros-hits)}
(r/'coverage-qualification.json').write_text(json.dumps({'definitions':{'emitted':'Raw llvm-cov function/region records across compiled instantiations. Unexecuted duplicate instantiations are retained, not treated as distinct untested source behavior.','distinct_primary':'Unique primary region filename/start/end line+column, covered if any associated emitted function has nonzero execution.','distinct_region':'Unique owning-file start/end line+column for LLVM kind0 code regions, covered if any emitted region at that span has nonzero count. This is a diagnostic source-span union, not branch coverage or a replacement for LLVM file summary.','physical_zero':'Region-entry lines with zero execution and no positive segment starting on that same physical line; inherited/new distinction reviewed separately.'},'files':result},indent=2)+'\n')
for name,x in result.items():print(name,'fn emitted',x['raw_executed_function_records'], '/',x['raw_emitted_function_records'],'distinct',x['executed_distinct_primary_source_spans'],'/',x['distinct_primary_source_spans'],'regiondistinct',x['executed_distinct_kind0_region_source_spans'],'/',x['distinct_kind0_region_source_spans'])
