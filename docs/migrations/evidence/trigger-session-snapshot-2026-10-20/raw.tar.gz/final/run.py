import subprocess,sys,time,json,pathlib,os,signal
root=pathlib.Path('/tmp/dandrum-lanes/evidence-host-snapshot-final-verification');label=sys.argv[1];cmd=sys.argv[2:]
assert not (root/(label+'.json')).exists(),label
cache='/dev/shm/dandrum-beta-20261020/host-snapshot-cov';env=os.environ.copy();env.update(CARGO_TARGET_DIR=cache,CARGO_LLVM_COV_TARGET_DIR=cache,CARGO_LLVM_COV_BUILD_DIR=cache,CARGO_BUILD_JOBS='2')
def sample():
 a=os.statvfs('/tmp');b=os.statvfs('/dev/shm');mem={x.split(':',1)[0]:int(x.split()[1])*1024 for x in pathlib.Path('/proc/meminfo').read_text().splitlines()};return {'disk':a.f_bavail*a.f_frsize,'shm':b.f_bavail*b.f_frsize,'memAvailable':mem['MemAvailable']}
def safe(s):return s['disk']>=256*1024**2 and s['shm']>=1024**3 and s['memAvailable']>=4*1024**3
start=time.monotonic();samples=[sample()];assert safe(samples[0]),samples
with (root/(label+'.log')).open('w') as f:
 p=subprocess.Popen(cmd,cwd='/tmp/dandrum-lanes/protocol',env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 stopped=None
 while p.poll() is None:
  s=sample();samples.append(s)
  if not safe(s):
   stopped={'reason':'resource floor','sample':s};os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.25)
 code=p.wait()
result={'command':cmd,'cwd':'/tmp/dandrum-lanes/protocol','exit':code,'seconds':time.monotonic()-start,'pidAndPgid':p.pid,'environment':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','CARGO_BUILD_JOBS']},'resourceSamples':samples,'stopped':stopped}
(root/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='resourceSamples'}));print((root/(label+'.log')).read_text()[-2500:]);sys.exit(code)
