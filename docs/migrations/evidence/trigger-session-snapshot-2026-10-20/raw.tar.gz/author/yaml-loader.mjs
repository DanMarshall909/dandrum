export function resolve(specifier,context,nextResolve){
 return nextResolve(specifier==='yaml'?'/tmp/dandrum-lanes/frontend/web/trigger/node_modules/yaml/dist/index.js':specifier,context);
}
