use dandrum_trigger_host::{TriggerHostConfiguration,parameters::ParameterController,protocol::Admission,runtime::{ControlEvent,TimedEvent}};
fn main() {
 let root=std::env::args_os().nth(1).unwrap();
 let (mut host,mut audio)=ParameterController::open(root,TriggerHostConfiguration{sample_rate_hz:48000,max_block_frames:16},std::num::NonZeroU64::new(9007199254740993).unwrap(),4,8).unwrap();
 let editor=host.attach_editor().unwrap();
 let Admission::New(read)=host.admit(&format!(r#"{{"version":1,"attachmentId":"{}","requestId":"90","method":"getSamplerSession","args":[]}}"#,editor.attachment_id)).unwrap() else {panic!()};
 let initial=host.sampler_session_reply(&read).unwrap();
 let Admission::New(write)=host.admit(&format!(r#"{{"version":1,"attachmentId":"{}","requestId":"91","method":"setParameter","args":["drums.level",0.5,1]}}"#,editor.attachment_id)).unwrap() else {panic!()};
 host.apply(&write).unwrap();
 let (mut left,mut right)=([0.;16],[0.;16]);
 audio.process_events(&mut left,&mut right,&[TimedEvent{frame_offset:0,event:ControlEvent::NoteOn{note:36,velocity:100}}]).unwrap();
 assert_eq!((left[0],right[0]),(-1.,-1.));
 let applied=host.sampler_session_reply(&read).unwrap();
 println!("{{\"initial\":{initial},\"applied\":{applied},\"left\":{}}}",left[0]);
}
