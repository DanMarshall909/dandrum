import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {patchFromSession} from '/tmp/dandrum-lanes/protocol/web/trigger/engine/native-document.mjs';
import {parseSessionConnection} from '/tmp/dandrum-lanes/protocol/web/trigger/engine/session-connection.mjs';
const data=JSON.parse(readFileSync(process.argv[2],'utf8'));
for(const [name,envelope] of Object.entries({initial:data.initial,applied:data.applied})){
 const session=envelope.result,connection=parseSessionConnection(session.connection),patch=patchFromSession(session);
 assert.equal(connection.instanceId,'9007199254740993');assert.equal(connection.nextRequestId,'1');assert.equal(connection.revision,'0');
 assert.equal(patch.id,'dandrum.advanced-drum-kit');assert.equal(patch.name,'Advanced Drum Kit');assert.equal(patch.voicePolicy.limit,8);assert.equal(patch.voicePolicy.steal,'oldest');
 assert.equal(patch.assets.length,1);assert.equal(patch.assets[0].sampleRate,48000);assert.equal(patch.assets[0].channels,1);assert.equal(patch.assets[0].frameCount,51000);assert.equal(patch.assets[0].duration,1.0625);
 assert.ok(patch.assets[0].uri.endsWith('/instrument/assets/advanced-drums.wav'));
 assert.equal(patch.regions.length,6);assert.equal(patch.rules.length,5);assert.equal(Object.keys(patch.params).length,23);
 assert.equal(patch.selectors['kit.hard_snare'].candidates.length,2);assert.equal(patch.selectors['kit.open_hats'].candidates.length,2);assert.equal(patch.selectors['kit.open_hats'].candidates[1].gain,-6);
 assert.equal(patch.params['drums.pitch_ratio'].default,1/9);assert.equal(patch.params['drums.pan'].default,.5);assert.equal(patch.params['drums.level'].default,.25);assert.equal(patch.params['drums.level'].value,name==='initial'?.25:.5);
}
assert.equal(data.left,-1);
console.log('PASS actual Rust accepted/applied replies consumed by unchanged production patchFromSession and parseSessionConnection; 23 parameters, six regions, five displayed rules, two real two-candidate selectors, exact u64 IDs and literal signed -1.');
