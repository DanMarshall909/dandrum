import {pathToFileURL} from 'node:url';
export function resolve(specifier,context,nextResolve){
 if(specifier==='yaml')return {url:pathToFileURL('/tmp/dandrum-lanes/frontend/web/trigger/node_modules/yaml/dist/index.js').href,shortCircuit:true};
 return nextResolve(specifier,context);
}
