use dandrum_trigger_host::parameters::{ParameterController, ParameterError};
use dandrum_trigger_host::protocol::{Admission, AdmittedRequest, ProtocolError, OUTBOUND_BYTES_LIMIT};
use dandrum_trigger_host::runtime::{ControlEvent, TimedEvent};
use dandrum_trigger_host::{ADVANCED_DRUM_KIT_DOCUMENT, ADVANCED_DRUM_KIT_SAMPLE, TriggerHostConfiguration};
use serde_json::{Value, json};
use std::{num::NonZeroU64, path::PathBuf};

fn package() -> (tempfile::TempDir, PathBuf) {
    let temporary = tempfile::tempdir().unwrap();
    let root = temporary.path().join("Trigger.resources");
    std::fs::create_dir_all(root.join("instrument/assets")).unwrap();
    let repository = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..");
    for (source, destination) in [("examples/patches/advanced-drum-kit.yaml", ADVANCED_DRUM_KIT_DOCUMENT), ("examples/patches/assets/advanced-drums.wav", ADVANCED_DRUM_KIT_SAMPLE)] {
        std::fs::copy(repository.join(source), root.join(destination)).unwrap();
    }
    (temporary, root)
}
fn open(root: &std::path::Path) -> (ParameterController, dandrum_trigger_host::runtime::RuntimeAudio) {
    ParameterController::open(root, TriggerHostConfiguration { sample_rate_hz: 48_000, max_block_frames: 16 }, NonZeroU64::new(9_007_199_254_740_993).unwrap(), 4, 8).unwrap()
}
fn request(controller: &mut ParameterController, attachment: &str, id: u64, method: &str, args: Value) -> AdmittedRequest {
    match controller.admit(&json!({"version":1,"attachmentId":attachment,"requestId":id.to_string(),"method":method,"args":args}).to_string()).unwrap() {
        Admission::New(request) => request,
        Admission::Duplicate { .. } => panic!("expected a fresh transport request"),
    }
}
fn reply(controller: &ParameterController, request: &AdmittedRequest) -> Value {
    let encoded = controller.sampler_session_reply(request).unwrap();
    assert!(encoded.len() <= OUTBOUND_BYTES_LIMIT);
    serde_json::from_str(&encoded).unwrap()
}
#[test]
fn accepted_snapshot_projects_real_kit_geometry_and_applied_values_without_changing_session() {
    let (_package, root) = package();
    let (mut controller, mut audio) = open(&root);
    let editor = controller.attach_editor().unwrap();
    let read = request(&mut controller, &editor.attachment_id, 90, "getSamplerSession", json!([]));
    let envelope = reply(&controller, &read);
    assert_eq!(envelope["status"], "accepted");
    assert_eq!(envelope["requestId"], "90");
    assert_eq!(envelope["instanceId"], "9007199254740993");
    let session = &envelope["result"];
    assert_eq!(session["yaml"], editor.snapshot.yaml);
    assert_eq!(session["sourcePath"], root.join(ADVANCED_DRUM_KIT_DOCUMENT).to_str().unwrap());
    assert_eq!(session["connection"], json!({"version":1,"instanceId":"9007199254740993","attachmentId":"1","revision":"0","nextRequestId":"1","limits":{"attachments":16,"history":100,"outcomes":128,"activeRequests":1},"history":{"undoCount":0,"redoCount":0}}));
    let document = &session["document"];
    assert_eq!(document["generation"], 1);
    assert_eq!(document["instrumentId"], "dandrum.advanced-drum-kit");
    assert_eq!(document["parameters"].as_array().unwrap().len(), 23);
    let params = document["parameters"].as_array().unwrap();
    for (index, param) in params.iter().enumerate() {
        let group = match index { 0..=4 => None, 5..=8 => Some(1), 9..=13 => Some(2), 14..=17 => Some(3), _ => Some(4) };
        assert_eq!(param["scope"], if group.is_some() { "sampleGroup" } else { "instrument" });
        assert_eq!(param.get("controlGroup"), group.as_ref().map(|group| json!(group)).as_ref());
        let id = param["id"].as_str().unwrap();
        let (min, max, default) = if id.ends_with("pitch_ratio") { (0.125, 8.0, 1.0/9.0) } else if id.ends_with("level") { (0.0, 4.0, 0.25) } else if id.ends_with("pan") { (-1.0, 1.0, 0.5) } else { (0.0, 1.0, 0.0) };
        assert_eq!(param["minValue"], min); assert_eq!(param["maxValue"], max);
        assert_eq!(param["normalisedDefaultValue"], default); assert_eq!(param["normalisedValue"], default);
    }
    let source = &document["sources"][0];
    assert_eq!((source["id"].as_str(), source["frameCount"].as_str()), (Some("drums"), Some("51000")));
    assert_eq!(source["sampleRateHz"], 48000); assert_eq!(source["channelCount"], 1);
    let regions = source["regions"].as_array().unwrap();
    assert_eq!(regions.len(), 6);
    for (region, (id, start, end)) in regions.iter().zip([("kick","0","12000"),("snare_soft","12000","20000"),("snare_hard_a","20000","28000"),("snare_hard_b","28000","36000"),("hat_closed","36000","39000"),("hat_open","39000","51000")]) {
        assert_eq!((region["id"].as_str(),region["startFrame"].as_str(),region["endFrame"].as_str()),(Some(id),Some(start),Some(end)));
        assert_eq!(region["reverse"], false); assert!(region.get("loop").is_none());
    }
    let map = &document["maps"][0];
    assert_eq!(map["id"], "kit"); assert_eq!(map["selectionMode"], "round_robin"); assert_eq!(map["selectionSeed"], "2026");
    let zones = map["zones"].as_array().unwrap(); assert_eq!(zones.len(), 7);
    for (zone, (region, key, low, high, group)) in zones.iter().zip([(0,36,1,127,1),(1,38,1,63,2),(2,38,64,127,2),(3,38,64,127,2),(4,42,1,127,3),(5,46,1,127,4),(5,46,1,127,4)]) {
        assert_eq!(zone["sourceIndex"],0); assert_eq!(zone["regionIndex"],region); assert_eq!(zone["keyLow"],key); assert_eq!(zone["keyHigh"],key); assert_eq!(zone["velocityLow"],low); assert_eq!(zone["velocityHigh"],high); assert_eq!(zone["controlGroup"],group);
    }
    assert_eq!(zones[2]["roundRobinGroup"], "hard_snare"); assert_eq!(zones[3]["roundRobinGroup"], "hard_snare"); assert_eq!(zones[5]["roundRobinGroup"], "open_hats"); assert_eq!(zones[6]["gainDb"], -6.0); assert_eq!(zones[4]["chokeGroup"], "hats");
    let write = request(&mut controller, &editor.attachment_id, 91, "setParameter", json!(["drums.level",0.5,1]));
    controller.apply(&write).unwrap();
    let pending = reply(&controller, &read);
    let level = |value: &Value| value["result"]["document"]["parameters"].as_array().unwrap().iter().find(|parameter| parameter["id"] == "drums.level").unwrap()["normalisedValue"].as_f64().unwrap();
    assert_eq!(level(&pending), 0.25);
    let (mut left, mut right) = ([0.0;16], [0.0;16]);
    audio.process_events(&mut left, &mut right, &[TimedEvent { frame_offset: 0, event: ControlEvent::NoteOn { note:36, velocity:100 } }]).unwrap();
    assert_eq!((left[0],right[0]),(-1.0,-1.0));
    let applied = reply(&controller, &read); assert_eq!(level(&applied),0.5);
    assert_eq!(applied["result"]["document"]["parameters"][2]["normalisedDefaultValue"],0.25);
    assert_eq!(controller.parameter_state().parameters[2].value,0.5);
    assert_eq!(controller.session().snapshot(&read.attachment).unwrap(),editor.snapshot);
    assert_eq!(controller.attach_editor().unwrap().attachment_id,"2");
}

#[test]
fn snapshot_reply_rejects_foreign_retired_and_forged_admission_without_leaking_data() {
    let (_package, root) = package();
    let (mut first, _audio) = open(&root);
    let (mut second, _audio2) = open(&root);
    let editor = first.attach_editor().unwrap();
    let other = first.attach_editor().unwrap();
    let other_instance = second.attach_editor().unwrap();
    let mut read = request(&mut first, &editor.attachment_id, 1, "getSamplerSession", json!([]));
    let foreign = request(&mut second, &other_instance.attachment_id, 1, "getSamplerSession", json!([]));
    assert_eq!(first.sampler_session_reply(&foreign), Err(ParameterError::Protocol(ProtocolError::StaleAttachment)));
    read.attachment_id = other.attachment_id.parse().unwrap();
    assert_eq!(first.sampler_session_reply(&read), Err(ParameterError::Protocol(ProtocolError::StaleAttachment)));
    read.attachment_id = 1;
    read.request_id = 2;
    assert_eq!(first.sampler_session_reply(&read), Err(ParameterError::Protocol(ProtocolError::StaleRequest)));
    read.request_id = 1;
    first.detach_editor(&editor.attachment_id).unwrap();
    assert_eq!(first.sampler_session_reply(&read), Err(ParameterError::Protocol(ProtocolError::StaleAttachment)));
    assert_eq!(reply(&second, &foreign)["result"]["connection"]["revision"], "0");
}

#[test]
fn snapshot_reply_does_not_dispatch_other_commands_and_returns_no_oversized_message() {
    let (_package, root) = package();
    let (mut controller, _audio) = open(&root);
    let editor = controller.attach_editor().unwrap();
    let read = request(&mut controller, &editor.attachment_id, 1, "getParameterState", json!([]));
    assert_eq!(controller.sampler_session_reply(&read), Err(ParameterError::UnsupportedCommand));
    let path = root.join(ADVANCED_DRUM_KIT_DOCUMENT);
    let yaml = std::fs::read_to_string(&path).unwrap().replace("name: Advanced Drum Kit", &format!("name: {}", "x".repeat(OUTBOUND_BYTES_LIMIT)));
    std::fs::write(&path,yaml).unwrap();
    let (mut large, _audio2) = open(&root);
    let editor = large.attach_editor().unwrap();
    let read = request(&mut large, &editor.attachment_id, 1, "getSamplerSession", json!([]));
    assert_eq!(large.sampler_session_reply(&read), Err(ParameterError::Protocol(ProtocolError::Oversized)));
    assert_eq!(large.session().snapshot(&read.attachment).unwrap(),editor.snapshot);
}
