import subprocess,sys,time,json,pathlib,hashlib,os
root=pathlib.Path('/tmp/dandrum-lanes/evidence-host-snapshot')
label=sys.argv[1]; cmd=sys.argv[2:]; start=time.monotonic(); env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/dandrum-lanes/cache-runtime';env['CARGO_BUILD_JOBS']='2'
with (root/(label+'.log')).open('w') as f:
 p=subprocess.run(cmd,cwd='/tmp/dandrum-lanes/protocol',env=env,stdout=f,stderr=subprocess.STDOUT)
result={'command':cmd,'cwd':'/tmp/dandrum-lanes/protocol','exit':p.returncode,'seconds':time.monotonic()-start,'environment':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR'],'CARGO_BUILD_JOBS':'2'}}
(root/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((root/(label+'.log')).read_text()[-3500:]);sys.exit(p.returncode)
