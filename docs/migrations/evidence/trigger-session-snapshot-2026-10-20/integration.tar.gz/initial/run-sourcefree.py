"""One-off affected source-free integration using the retained actual fixture."""
from pathlib import Path
import hashlib, json, os, shutil, signal, subprocess, time

root=Path('/tmp/dandrum-lanes/protocol')
out=Path('/tmp/dandrum-lanes/evidence-host-snapshot-integration')
fixture=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source')
build=fixture/'build/trigger-editor'
target=build/'rust-target'
prior=Path('/tmp/dandrum-lanes/evidence-runtime-continuity/sourcefree-disk-retry-inputs.json')
assert not out.exists()
out.mkdir()
assert target.resolve()==Path('/tmp/dandrum-lanes/cache-editor-guard')
assert not any((fixture/name).exists() for name in ('web','ui','third_party'))
old=json.loads(prior.read_text())
changed={}
for name,digest in old.items():
    assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest,name
    current=hashlib.sha256((root/name).read_bytes()).hexdigest()
    if current!=digest:
        changed[name]=dict(prior_sha256=digest,current_sha256=current)
assert set(changed)=={'src/trigger-host/src/parameters.rs','src/trigger-host/src/protocol.rs'},changed
names=list(old)+['src/trigger-host/tests/snapshot.rs']
assert not (fixture/names[-1]).exists()
for name in [*changed,names[-1]]:
    shutil.copy2(root/name,fixture/name)
manifest={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
for name,digest in manifest.items():
    assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest,name
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',TMPDIR='/tmp',CARGO_BUILD_JOBS='2')
commands=[('release-build',['/home/dan/.local/bin/cmake','--build',str(build),'--target','dandrum-trigger-clap-editor','--parallel','2']),('dependencies',['/home/dan/.cargo/bin/cargo','tree','--offline','--locked','--manifest-path',str(fixture/'src/trigger-host/Cargo.toml'),'--edges','normal','--prefix','none']),('runtime-ctests',['/home/dan/.local/bin/ctest','--test-dir',str(build),'--output-on-failure','-V','-R','^(clap-dynamic-host|trigger-host-tests|trigger-editor-tests)$'])]
results=[]
for label,argv in commands:
    start=time.monotonic();samples=[];stop=None
    with (out/(label+'.log')).open('wb') as log:
        p=subprocess.Popen(argv,cwd=fixture,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        while p.poll() is None:
            d=os.statvfs(target);r=os.statvfs('/dev/shm');mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
            sample=dict(elapsed=time.monotonic()-start,disk=d.f_bavail*d.f_frsize,ram=r.f_bavail*r.f_frsize,mem=mem);samples.append(sample)
            if sample['disk']<1024**3 or sample['ram']<256*1024**2 or mem<4*1024**3:
                stop='Owned group interrupted at disk1GiB/RAMfs256MiB/Mem4GiB floor; caches retained';os.killpg(p.pid,signal.SIGINT);break
            time.sleep(.5)
        code=p.wait()
    record=dict(command=argv,cwd=str(fixture),environment={k:env[k] for k in ('PATH','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR','CARGO_BUILD_JOBS')},exit_code=code,elapsed_seconds=time.monotonic()-start,owned_pid=p.pid,owned_pgid=p.pid,stop_reason=stop,resource_samples=samples,log_sha256=hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest())
    (out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    results.append(dict(gate=label,exit_code=code,elapsed_seconds=record['elapsed_seconds']))
    assert code==0,(label,code,stop)
dependencies={line.split()[0].lower() for line in (out/'dependencies.log').read_text().splitlines() if line.strip()}
assert not any(any(word in name for word in ('clack','wry','webkit','gtk','juce')) for name in dependencies)
assert '67 passed' in (out/'runtime-ctests.log').read_text()
for name,digest in manifest.items():
    assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest and hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
receipt=dict(integrationBase=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),results=results,sourceInputs=len(manifest),changedInputs=changed,newInput=names[-1],allCurrentInputsMatch=True,absentTrees=['web','ui','third_party'],compilerTarget=str(target.resolve()),qualification='Affected release rebuild/dependency check/all3runtimeCTests in existing actual source-free fixture; nonincremental disk output. Not a fresh full default-profile guard, actual production React/Wry/CLAP Trigger acceptance or full beta proof.',cachesPreserved=True)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
