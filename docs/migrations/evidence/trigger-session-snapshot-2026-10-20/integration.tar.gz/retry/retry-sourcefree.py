"""One-off source-free retry: invalidate stale fixture dependency timestamps."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time
root=Path('/tmp/dandrum-lanes/protocol');out=Path('/tmp/dandrum-lanes/evidence-host-snapshot-integration-retry');fixture=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source');build=fixture/'build/trigger-editor';target=build/'rust-target'
assert not out.exists();out.mkdir()
prior=Path('/tmp/dandrum-lanes/evidence-host-snapshot-integration/source-manifest.json');manifest=json.loads(prior.read_text());assert len(manifest)==587
for name,digest in manifest.items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest,name
assert not any((fixture/name).exists() for name in ('web','ui','third_party'));assert target.resolve()==Path('/tmp/dandrum-lanes/cache-editor-guard')
changed=json.loads(Path('/tmp/dandrum-lanes/evidence-runtime-continuity/sourcefree-disk-retry-inputs.json').read_text());changed={n:dict(prior_sha256=d,current_sha256=manifest[n]) for n,d in changed.items() if manifest[n]!=d};assert set(changed)=={'src/trigger-host/src/parameters.rs','src/trigger-host/src/protocol.rs'}
names=['src/trigger-host/tests/snapshot.rs']
mtimes=[]
for name in changed:
 p=fixture/name;before=p.stat().st_mtime_ns;os.utime(p,None);mtimes.append(dict(path=name,before=before,after=p.stat().st_mtime_ns,bytesUnchanged=hashlib.sha256(p.read_bytes()).hexdigest()==manifest[name]))
(out/'timestamp-invalidation.json').write_text(json.dumps(dict(reason='Initial CTest newtest compiled against old cached debug library: preserved copy2 source timestamps preceded last compiled artifact. Only copied fixture timestamps advanced; no cache/source bytes deleted.',paths=mtimes),indent=2)+'\n')
(out/'source-manifest.json').write_bytes(prior.read_bytes())
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',TMPDIR='/tmp',CARGO_BUILD_JOBS='2')
commands=[('release-build',['/home/dan/.local/bin/cmake','--build',str(build),'--target','dandrum-trigger-clap-editor','--parallel','2']),('dependencies',['/home/dan/.cargo/bin/cargo','tree','--offline','--locked','--manifest-path',str(fixture/'src/trigger-host/Cargo.toml'),'--edges','normal','--prefix','none']),('runtime-ctests',['/home/dan/.local/bin/ctest','--test-dir',str(build),'--output-on-failure','-V','-R','^(clap-dynamic-host|trigger-host-tests|trigger-editor-tests)$'])]
results=[]
for label,argv in commands:
    start=time.monotonic();samples=[];stop=None
    with (out/(label+'.log')).open('wb') as log:
        p=subprocess.Popen(argv,cwd=fixture,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        while p.poll() is None:
            d=os.statvfs(target);r=os.statvfs('/dev/shm');mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
            sample=dict(elapsed=time.monotonic()-start,disk=d.f_bavail*d.f_frsize,ram=r.f_bavail*r.f_frsize,mem=mem);samples.append(sample)
            if sample['disk']<1024**3 or sample['ram']<256*1024**2 or mem<4*1024**3:
                stop='Owned group interrupted at disk1GiB/RAMfs256MiB/Mem4GiB floor; caches retained';os.killpg(p.pid,signal.SIGINT);break
            time.sleep(.5)
        code=p.wait()
    record=dict(command=argv,cwd=str(fixture),environment={k:env[k] for k in ('PATH','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR','CARGO_BUILD_JOBS')},exit_code=code,elapsed_seconds=time.monotonic()-start,owned_pid=p.pid,owned_pgid=p.pid,stop_reason=stop,resource_samples=samples,log_sha256=hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest())
    (out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    results.append(dict(gate=label,exit_code=code,elapsed_seconds=record['elapsed_seconds']))
    assert code==0,(label,code,stop)
dependencies={line.split()[0].lower() for line in (out/'dependencies.log').read_text().splitlines() if line.strip()}
assert not any(any(word in name for word in ('clack','wry','webkit','gtk','juce')) for name in dependencies)
log=(out/'runtime-ctests.log').read_text(); host_log=log.split('2/3 Test')[0]; assert all(name in host_log for name in ('accepted_snapshot_projects_real_kit_geometry','snapshot_reply_rejects_foreign_retired','unrepresentable_resource_provenance')); import re; counts=[int(n) for n in re.findall(r'^1: test result: ok\. (\d+) passed;',host_log,re.M)]; assert sum(counts)==67,counts
for name,digest in manifest.items():
    assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest and hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
receipt=dict(integrationBase=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),results=results,sourceInputs=len(manifest),changedInputs=changed,newInput=names[-1],allCurrentInputsMatch=True,absentTrees=['web','ui','third_party'],compilerTarget=str(target.resolve()),qualification='Affected release rebuild/dependency check/all3runtimeCTests in existing actual source-free fixture; nonincremental disk output. Not a fresh full default-profile guard, actual production React/Wry/CLAP Trigger acceptance or full beta proof.',cachesPreserved=True)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
