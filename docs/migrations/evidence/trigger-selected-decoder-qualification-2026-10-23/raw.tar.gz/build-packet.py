from pathlib import Path
import subprocess,json,hashlib,tarfile,stat,shutil
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;base='983ce4b3e1bb66bd63fc3b3dda635843b559d17a';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base;sha=lambda b:hashlib.sha256(b).hexdigest();blobs=out/'source-blobs';blobs.mkdir(exist_ok=True);cache={};phases=[]
readiness=Path('/tmp/dandrum-evidence/selected-snapshot-red-readiness');copy=out/'readiness';copy.mkdir(exist_ok=True)
for n in ['report.md','source-bindings.json']:shutil.copy2(readiness/n,copy/n)
for archive in sorted(out.glob('*-source.tar.gz')):
 rows=[]
 with tarfile.open(archive) as t:
  for m in t:
   assert m.isfile();data=t.extractfile(m).read();digest=sha(data);name=m.name
   if name not in cache:
    p=subprocess.run(['git','show',base+':'+name],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL);cache[name]=sha(p.stdout) if p.returncode==0 else None
   row={'path':name,'sha256':digest,'source':'base' if cache[name]==digest else 'blob'}
   if row['source']=='blob':
    p=blobs/digest
    if p.exists():assert p.read_bytes()==data
    else:p.write_bytes(data)
   rows.append(row)
 phases.append({'snapshot':archive.name,'snapshot_sha256':sha(archive.read_bytes()),'files':rows})
(out/'portable-source-replay.json').write_text(json.dumps({'base':base,'phases':phases,'recipe':'Reconstruct each source from the immutable Git base or source-blobs/<SHA256>, verify every hash. Original full Rust snapshots remain external; no build/dependency targets copied.'},indent=2)+'\n')
packet=root/'docs/migrations/evidence/trigger-selected-decoder-qualification-2026-10-23';packet.mkdir(exist_ok=True);members=[]
with tarfile.open(packet/'raw.tar.gz','w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_dir():continue
  assert stat.S_ISREG(p.lstat().st_mode),str(p)
  if p.name.endswith('-source.tar.gz'):continue
  name=str(p.relative_to(out));data=p.read_bytes();members.append({'path':name,'bytes':len(data),'sha256':sha(data)});t.add(p,arcname=name,recursive=False)
with tarfile.open(packet/'raw.tar.gz') as t:
 actual={m.name:m for m in t};assert set(actual)=={r['path'] for r in members}
 for r in members:
  data=t.extractfile(actual[r['path']]).read();assert len(data)==r['bytes'] and sha(data)==r['sha256']
(packet/'raw-index.json').write_text(json.dumps({'archive_sha256':sha((packet/'raw.tar.gz').read_bytes()),'members':members},indent=2)+'\n')
row={'base':base,'scope':'Task5.1 TIDY only: existing decoder resource measurements and one test-only characterization correction. No production behavior/API/catalog/protocol/chooser/selected-sample acceptance or task/scenario closure.','source':'src/rust-engine/src/audio_loading.rs','source_sha256':sha((root/'src/rust-engine/src/audio_loading.rs').read_bytes()),'production_prefix_unchanged':True,'characterization':'Complete valid outer header now reaches existing malformed data-chunk bound check; exact existing error is asserted. Baseline guard line124 hit0, focused current hit1. Existing10decoder tests PASS, formatPASS; GREEN characterization, not claimed behaviorRED.','measurements':'64MiB PCM16 mono33554410frames and stereo16777205frames; signedfirst/last andrate/framecount checksPASS.4process peakRSS264180–264252KiB (about258MiB),debugdecode3.50–4.14seconds. Filemode real public engine ResourceResolver; bytesmode unchanged private decoder source compiled into one-off probe with encodedbytesretained.','memory_limits':'Initial16files/64MiBasset/256MiBaggregate are accepted candidate budgets; decoded-frame/byte/count/in-flight/retirement policies remain to settle. No catalog peak, universal bound or accepted final decoded limit claim.','checks':'FocusedLLVM executes corrected guard and added test assertions. Older aggregate/test-only helper gaps retained. StrictengineClippy FAIL129baseline; exact330all-target diagnostics unchanged, no newidentity or suppression. Normal1090-test/strictcoverage hooks and independent review/publication remain subsequent gates.','resources':'Physical reusable targets/jobs1,8GiB disk/MemAvailable guards. All probe WAVs/workspaces owned scratch removed after verified guardian closure; rawprofiles and source/tool/commands retained. Initial private-API compiler failure and unsupportedreport--lib option are setup failures, notRED or coverage.','readiness':'Read-only report identifies that a meaningful selected-content RED requires a defined trusted-native ingress plus bounded admission/status contract, and real decoded consumer. Existing decoded immutability is alreadyGREEN; preserve packaged-resource re-preparation rejection. No interface chosen/implemented by this packet.','mutation':'Excluded; none run or injected.'};(packet/'binding.json').write_text(json.dumps(row,indent=2)+'\n')
(packet/'README.md').write_text('''# Existing sample decoder qualification

This is preparatory TIDY work for beta task5.1. It implements no selected-resource catalog, wire method, native chooser, patch publication or new production behavior. No task or scenario is completed; the CLAP-only beta remains open and VST3/standalone deferred.

Baseline source-bound engine coverage exposed a weak existing malformed-chunk fixture: its24bytes failed the44byte minimum outer-header check. The fixture now starts from a complete valid PCM WAV, declares100data bytes with only4available, and asserts the existing precise malformed-chunk rejection. The decoder implementation is byte-identical before its test module. This is a GREEN characterization of existing policy, not new behaviorRED. All10decoder owner tests and formatting pass; focusedLLVM changes the intended guard atline124 from0hits to1 and executes the new assertions. Older aggregate/test-only gaps remain explicit.

A disposable resource probe decoded real64MiB mono and stereo PCM16 WAVs with independently exact signed first/last samples,48kHz rate and33554410/16777205frame counts. Four child-process peakRSS measurements are264180–264252KiB (about258MiB), with3.50–4.14second debug decoding. File mode calls the actual public engine ResourceResolver. Byte mode compiles the unchanged private decoder source into the one-off probe while retaining the encoded buffer; it is not an external engine API. These are existing-decoder measurements, not a new catalog limit or native-input/DAW acceptance claim.

The accepted initial16files-per-selection,64MiBencoded-asset and256MiBaggregate budgets still require decoded-frame/byte/count, in-flight reservation and complete lifetime accounting. Encoded+decoded retained arrays can approach3×encoded bytes, with about4×during existing decoding before overhead. A future selected-content outerRED needs a specified trusted native acquisition/admission/status contract and real consumer; the linked readiness report deliberately chooses no wire/interface. Existing packaged missing-file re-preparation rejection and rollback remain intact.

StrictengineClippy stillFAILS with129baseline library diagnostics. A separate warnings-only all-targets reconciliation matches all330diagnostic occurrences exactly by level/code/message/primary source text/labels, ignoring shifted locations; no lint is suppressed or newly introduced. This is not a strict lintPASS. The normal engine tests/strict coverage hooks and independent candidate review/publication remain later exact gates.

Raw commands, memory results, prototype source/manifest/lock, profiles, baseline/current annotation and source replay are portable in raw.tar.gz. The initial one-off private-module compilation error and rejected LLVM report option are setup failures, not behaviorRED. Source snapshots reconstruct from base983ce4b3 plus content-addressed blobs. No build targets or generated WAV payloads are committed. Runs use existing physical targets, one Cargo job and8GiB disk/MemAvailable floors; verified owned scratch is cleaned after worker closure, reusable caches and raw evidence retained. Mutation remains excluded.
''')
print(json.dumps({'packet':str(packet),'members':len(members),'source_phases':len(phases),'bytes':(packet/'raw.tar.gz').stat().st_size}))
