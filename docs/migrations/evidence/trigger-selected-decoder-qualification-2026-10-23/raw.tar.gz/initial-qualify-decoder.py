from pathlib import Path
import subprocess,os,json,time,hashlib,shutil,struct
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;scratch=Path(os.environ['TMPDIR']);project=scratch/'decoder-probe';(project/'src').mkdir(parents=True);shutil.copy2(out/'decoder-probe.rs',project/'src/main.rs');shutil.copy2(out/'decoder-probe.Cargo.toml',project/'Cargo.toml');shutil.copy2(root/'src/rust-engine/Cargo.lock',project/'Cargo.lock');rows=[]
argv=['/home/dan/.cargo/bin/cargo','build','--offline','--jobs','1','--manifest-path',str(project/'Cargo.toml'),'--message-format=json'];start=time.monotonic();p=subprocess.run(argv,cwd=root,stdout=subprocess.PIPE);(out/'compile.stdout').write_bytes(p.stdout);rows.append({'command':argv,'exit':p.returncode,'seconds':time.monotonic()-start});assert p.returncode==0
records=[json.loads(l) for l in p.stdout.decode().splitlines() if l.startswith('{')];bins=[Path(r['executable']) for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='dandrum-selected-decoder-probe' and r.get('executable')];assert len(bins)==1;binary=bins[0]
fixtures=[]
for channels in [1,2]:
 size=64*1024*1024;data_size=(size-44)//(channels*2)*(channels*2);frames=data_size//(channels*2);path=scratch/('near64MiB-'+str(channels)+'.wav');header=struct.pack('<4sI4s4sIHHIIHH4sI',b'RIFF',36+data_size,b'WAVE',b'fmt ',16,1,channels,48000,48000*channels*2,channels*2,16,b'data',data_size);word=struct.pack('<h',-24576) if channels==1 else struct.pack('<hh',-24576,8192);block=word*16384
 with path.open('wb') as f:
  f.write(header);left=data_size
  while left:
   chunk=block[:min(left,len(block))];f.write(chunk);left-=len(chunk)
 fixtures.append({'channels':channels,'encoded_bytes':path.stat().st_size,'frames':frames,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 for mode in ['file','bytes']:
  label=str(channels)+'ch-'+mode;argv=['/usr/bin/time','-f','{"max_rss_kib":%M,"elapsed_s":%e,"user_s":%U,"system_s":%S,"major_faults":%F}','-o',str(out/(label+'-rss.json')),str(binary),mode,str(path),str(frames),str(-.75 if channels==1 else -.25)];start=time.monotonic();p=subprocess.run(argv,cwd=root,env=dict(os.environ,LC_ALL='C'),stdout=subprocess.PIPE,stderr=subprocess.PIPE);(out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);row={'command':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'measurement':json.loads((out/(label+'-rss.json')).read_text())};rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0
(out/'qualification.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256((out/'decoder-probe.rs').read_bytes()).hexdigest(),'fixtures':fixtures,'commands':rows,'scope':'One-off resource characterization of existing PCM16 decoder with real near64MiB mono/stereo files and independently exact signed first/last/frame-count assertions. bytes mode retains encoded bytes while decoder runs. Not new catalog/admission/native/DAW acceptance or TDD RED.'},indent=2)+'\n')
print('Decoder resource qualification PASS',flush=True)
