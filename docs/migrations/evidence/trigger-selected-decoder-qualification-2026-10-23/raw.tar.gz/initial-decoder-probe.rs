use std::{env,fs,hint::black_box};
fn main() {
    let args: Vec<_> = env::args().collect();
    let mode = &args[1];
    let expected_frames: usize = args[3].parse().unwrap();
    let expected_sample: f32 = args[4].parse().unwrap();
    let encoded = if mode == "bytes" { Some(fs::read(&args[2]).unwrap()) } else { None };
    let loaded = if let Some(bytes) = &encoded {
        dandrum_engine::audio_loading::decode_pcm_wav(bytes,48_000).unwrap()
    } else {
        dandrum_engine::audio_loading::load_pcm_wav_any_rate(std::path::Path::new(&args[2])).unwrap()
    };
    assert_eq!(loaded.sample_rate_hz(),48_000);
    assert_eq!(loaded.frames().len(),expected_frames);
    assert_eq!(loaded.frames()[0],expected_sample);
    assert_eq!(loaded.frames()[expected_frames-1],expected_sample);
    black_box(&encoded);
    println!("{{\"mode\":\"{}\",\"frames\":{},\"rate\":{},\"first\":{},\"last\":{}}}",mode,loaded.frames().len(),loaded.sample_rate_hz(),loaded.frames()[0],loaded.frames()[expected_frames-1]);
}
