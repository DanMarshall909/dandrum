use std::{env,fs,hint::black_box};
use dandrum_engine::{preparation::{PreparationContext,ResourceResolver},kernel::{ResourceRef,ResourceKind,ResourceOrigin}};
#[allow(dead_code)]
#[path="/tmp/dandrum-lanes/integration/src/rust-engine/src/audio_loading.rs"]
mod existing_decoder;
fn check(mode:&str,rate:u32,frames:&[f32],expected_frames:usize,expected_sample:f32) {
    assert_eq!(rate,48_000);
    assert_eq!(frames.len(),expected_frames);
    assert_eq!(frames[0],expected_sample);
    assert_eq!(frames[expected_frames-1],expected_sample);
    println!("{{\"mode\":\"{}\",\"frames\":{},\"rate\":{},\"first\":{},\"last\":{}}}",mode,frames.len(),rate,frames[0],frames[expected_frames-1]);
}
fn main() {
    let args: Vec<_> = env::args().collect();
    let mode = &args[1];
    let path=std::path::Path::new(&args[2]);
    let expected_frames: usize = args[3].parse().unwrap();
    let expected_sample: f32 = args[4].parse().unwrap();
    if mode == "bytes" {
        let encoded=fs::read(path).unwrap();
        let loaded=existing_decoder::decode_pcm_wav(&encoded,48_000).unwrap();
        check(mode,loaded.sample_rate_hz(),loaded.frames(),expected_frames,expected_sample);
        black_box(&encoded);
    } else {
        let context=PreparationContext::new(path.parent().unwrap(),48_000);
        let mut resolver=ResourceResolver::new(&context);
        let reference=ResourceRef::new(ResourceKind::Sample,path.file_name().unwrap(),ResourceOrigin::Document);
        let resource=resolver.resolve(&reference).unwrap();
        check(mode,resource.sample().sample_rate_hz(),resource.sample().frames(),expected_frames,expected_sample);
    }
}
