from pathlib import Path
import hashlib,json,tarfile,xml.etree.ElementTree as ET,subprocess
root=Path('/home/dan/code/dandrum');base=Path('/tmp/dandrum-task-8-2');packet=root/'docs/migrations/evidence/trigger-beta-completion-2026-11-03'
reports=['ctest.xml','native-retry.xml','final-daw-replay.xml'];latest={};runs=[]
for name in reports:
 tree=ET.parse(base/name).getroot();cases=[]
 for case in tree.iter('testcase'):
  status='failed' if case.find('failure') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
  row={'name':case.attrib['name'],'status':status,'seconds':float(case.attrib['time']),'report':name};cases.append(row);latest[row['name']]=row
 runs.append({'report':name,'tests':len(cases),'failed':[c['name'] for c in cases if c['status']!='passed']})
assert len(latest)==72,len(latest)
assert all(c['status']=='passed' for c in latest.values()),latest
verification={'result':'PASS','scope':'all 72 configured cases, composite initial run plus environment-corrected failed-case retry and final affected historical replay case','runs':runs,'latest_by_test':list(latest.values()),'production':'unchanged from task8.1; current installed CLAP manifest and historical DAW manifest independently rehashed','mutation':'excluded by user; no mutation jobs','new_replay_tests':5,'initial_failure':'native GTK checks ran without DISPLAY; failed logs retained; no product behavior changed','source_free_builds':'current root CMake inputs, native/plugin build boundaries pass','canonical_proposal':'55/55 strict specs; 657 scenarios,418 mapped,239 unchanged backlog; exact patch applied only after independent PASS','retention':'owned supervisor cleanup receipts retained; no reusable cache/build/dependency deletion','storage_inventory_limitation':'installed Git does not support worktree list --porcelain -z, so skill inventory exits3 with partial attribution; linked native fixture generations also disclosed. Ordinary worktree --porcelain inventory succeeded. Direct du measurement supplements sizing.'}
(packet/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
raw=[]
for name in ['prepare-canonical.py','audit-artifacts.py','run-native-checks.py','finish-packet.py','configure.log','storage-admission.json','storage-inventory.json','rust-target-inventory.json','retention-inventory.json','selected-oracle-red.log','daw-replay.log','current-map.log','proposed-map.log','proposed-specs.json','change-validation.json',*reports,'native-checks.json','native-runtime.json','native-shutdown.json']:
 raw.append((base/name,name))
for directory in ['ctest','native-run','logs']:
 for f in (base/directory).glob('*'):
  if f.is_file():raw.append((f,str(f.relative_to(base))))
expected={name:(path.stat().st_size,hashlib.sha256(path.read_bytes()).hexdigest()) for path,name in raw}
assert len(expected)==len(raw)
archive=packet/'verification-raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for path,name in raw:assert path.is_file(),path;t.add(path,arcname=name,recursive=False)
manifest=[]
with tarfile.open(archive) as t:
 for member in t:
  b=t.extractfile(member).read();assert (len(b),hashlib.sha256(b).hexdigest())==expected[member.name];manifest.append({'path':member.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(packet/'archive-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest,'all_members_read_back':True},indent=2)+'\n')
print(json.dumps({'result':'PASS','cases':len(latest),'runs':runs,'archive_members':len(raw)}))
