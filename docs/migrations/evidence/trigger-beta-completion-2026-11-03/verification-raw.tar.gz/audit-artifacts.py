from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path('/home/dan/code/dandrum');rows=[]
for name,archive in [('trigger-clap-daw-acceptance-2026-11-02','raw-evidence.tar.gz'),('trigger-beta-qualification-2026-11-02','raw-text-and-profiles.tar.gz')]:
 p=root/'docs/migrations/evidence'/name
 d=json.loads((p/'archive-manifest.json').read_text());files=d['files'] if isinstance(d,dict) else d
 with tarfile.open(p/archive) as t:
  actual={m.name:m for m in t if m.isfile()};assert set(actual)=={m['path'] for m in files}
  for f in files:
   b=t.extractfile(f['path']).read();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
 installed=json.loads((p/'installed-manifest.json').read_text());base=Path(installed['root'])
 actual_paths=sorted(str(f.relative_to(base)) for f in base.rglob('*') if f.is_file())
 assert actual_paths==sorted(f['path'] for f in installed['files'])
 for f in installed['files']:
  path=base/f['path'];assert not path.is_symlink();b=path.read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
 rows.append({'packet':name,'archive_sha256':hashlib.sha256((p/archive).read_bytes()).hexdigest(),'verified_archive_members':len(files),'verified_installed_files':len(installed['files']),'installed_clap_sha256':next(f['sha256'] for f in installed['files'] if f['path'].endswith('.clap'))})
paths=['src','schema','examples','web/trigger','cmake','scripts']
diff=subprocess.run(['git','diff','--exit-code','7ea453e2','HEAD','--',*paths],cwd=root,capture_output=True,text=True);assert diff.returncode==0
result={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'qualification_source':'7ea453e2510fdd3c40f40248699356b2440bcf16','unchanged_committed_input_paths':paths,'artifacts':rows,'result':'PASS','limits':'Historical DAW and current qualification binaries are distinct; this audit does not rerun REAPER or physical human input.'}
(root/'docs/migrations/evidence/trigger-beta-completion-2026-11-03/artifact-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
