from pathlib import Path
import difflib,importlib.util,sys,shutil,json
root=Path('/home/dan/code/dandrum')
out=Path('/tmp/dandrum-task-8-2/proposed')
shutil.copytree(root/'openspec/specs',out/'openspec/specs',dirs_exist_ok=True)
shutil.copy2(root/'openspec/config.yaml',out/'openspec/config.yaml')
spec=importlib.util.spec_from_file_location('coverage_map',root/'scripts/check-spec-coverage.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
m.SPECS_DIR=out/'openspec/specs'
M={
'Installed CLAP renders the real Trigger instrument':['optional_product_discovers_stable_trigger_and_retains_fixture_identities','real_sampler_ports_and_offset_midi_parameter_values_render_literal_signed_pcm','state_restores_fresh_mapping_and_physical_values_and_invalid_tail_preserves_running_audio'],
'Fractional host clocks render at the requested rate':['supported_fractional_clocks_activate_and_keep_exact_signed_sample_timing','fractional_reconfiguration_keeps_exact_identity_values_history_and_failure_rollback','fractional_runtime_swaps_reclaim_on_control_and_preserve_reset_and_another_instance'],
'Failed configuration preserves accepted playback':['persistent_endpoints_survive_failed_and_equal_reactivation_then_reconfigure_independently','missing_or_corrupt_resources_leave_the_loaded_runtime_and_configuration_accepted'],
'Native editing survives complete editor replacement':['installed_native_edits_overlap_server_audio_and_midi','copied_native_destroy_releases_held_activity_once_and_reconnects','copied_react_recovers_selected_import_after_lost_reply_and_recreation'],
'Failed native creation leaves the instrument usable':['copied_trigger_editor_exposes_the_actual_clap_gui_extension','copied_editor_failed_native_parent_attempt_retains_only_code_and_preserves_audio','copied_native_ipc_registration_failure_cleans_up_and_retries_preserving_state'],
'Native callbacks retain bounded ownership during replacement':['installed_native_edits_overlap_server_audio_and_midi','copied_native_continuous_audio_callbacks_allocate_and_deallocate_nothing','copied_native_two_instances_keep_edits_audio_and_editors_independent'],
'Two DAW instances retain automation and selected samples':['py:tests/python/test_trigger_clap_daw_evidence.py','installed_native_edits_overlap_server_audio_and_midi','copied_react_import_maps_selected_pcm_once_through_native_history'],
'Source-hidden offline installation remains usable':['fresh_clap_restores_selected_payload_without_a_package_file','copied_native_editor_lifecycle_initializes_the_real_react_session_and_preserves_audio','py:tests/python/test_trigger_clap_install.py','py:tests/python/test_engine_only_build.py'],
'A distinct selected sample is mapped and played natively':['installed_native_edits_overlap_server_audio_and_midi','copied_native_selection_retains_real_metadata_across_source_and_editor_loss','copied_react_import_maps_selected_pcm_once_through_native_history'],
'Cancelled or invalid selection preserves the instrument':['copied_native_selection_retains_real_metadata_across_source_and_editor_loss','rejected_file_count_and_decode_preserve_state_and_allow_later_selection','file_count_encoded_decoded_and_resource_limits_reject_atomically','untrusted_file_shapes_names_and_read_errors_never_publish_resources','rejected_native_acquisition_is_bounded_and_a_later_selection_remains_possible'],
'Original-file changes do not alter admitted playback':['selected_runtime_pins_bytes_until_control_reclamation_without_callback_destruction','copied_react_import_maps_selected_pcm_once_through_native_history','installed_native_edits_overlap_server_audio_and_midi'],
'Import preserves nondefault controls and native history':['whole_patch_publication_survives_view_loss_and_native_undo_preserves_physical_values','copied_react_import_maps_selected_pcm_once_through_native_history'],
'Empty patch and ordinary import form a usable transition':['copied_react_empty_retains_controls_and_imports_after_recreation','silent_empty_document_keeps_product_parameter_scopes_values_and_callback_ownership'],
'Failed patch candidates retain the accepted instrument':['whole_patch_rejects_unsupported_profile_before_owning_a_job','transport_retries_never_repeat_admission_conflicting_or_retired_ids_are_rejected','failed_preparation_reports_only_its_real_error_and_preserves_accepted_state','failed_patch_retry_recovers_after_its_selected_content_is_released'],
'Lost editor recovers one admitted sample edit':['copied_react_recovers_selected_import_after_lost_reply_and_recreation','admitted_selection_survives_view_loss_and_releases_only_its_outcome'],
'Fresh instance restores selected content after source removal':['fresh_clap_restores_selected_payload_without_a_package_file','copied_react_import_maps_selected_pcm_once_through_native_history','py:tests/python/test_trigger_clap_daw_evidence.py'],
'Corrupt portable state preserves the live instrument':['portable_selected_state_restores_owned_pcm_and_values_after_the_source_instance_is_gone','invalid_portable_metadata_is_refused_before_any_foreign_payload_read','invalid_states_and_failing_streams_preserve_every_accepted_field_and_pending_feedback_and_commands','rejected_native_state_preserves_nonempty_real_history_and_successful_external_restore_resets_it','maximum_portable_payload_restores_signed_tail_geometry_and_reclaims_every_owner'],
'Packaged-kit state remains readable':['portable_state_larger_than_legacy_limit_restores_fresh_pcm_and_values_with_reentrant_short_reads','invalid_states_and_failing_streams_preserve_every_accepted_field_and_pending_feedback_and_commands'],
}
purposes={'juce-free-trigger-products':'Qualify the private Linux CLAP Trigger beta, including precise clocks, native ownership, named-host acceptance and installed offline execution.','trigger-sample-resources':'Own native selected samples, atomic patch history and portable patch/sample/physical-parameter state independently of disposable editors.'}
newpaths=[]
for cap,purpose in purposes.items():
 delta=root/'openspec/changes/add-juce-free-trigger-beta-products/specs'/cap/'spec.md'
 path=out/'openspec/specs'/cap/'spec.md';path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text('# '+cap+' Specification\n\n## Purpose\n\n'+purpose+'\n\n'+delta.read_text().replace('## ADDED Requirements','## Requirements',1))
 newpaths.append(Path('openspec/specs')/cap/'spec.md')
acs=m.parse_specs();blocks=m.parse_map(root/'spec-tests.map')
added=[]
for key,fp in acs.items():
 if key.capability in purposes:
  tests=[x if ':' in x else 'rust:'+x for x in M[key.scenario]]
  blocks[key]=m.AcBlock(key,fp,tests)
  added.append({'capability':key.capability,'requirement':key.requirement,'scenario':key.scenario,'fingerprint':fp,'tests':tests})
m.MAP_PATH=out/'spec-tests.map'
original=(root/'spec-tests.map').read_text()
append='\n' if not original.endswith('\n\n') else ''
for row in added:
 append+='AC '+row['capability']+' :: '+row['requirement']+' :: '+row['scenario']+'\n  fp '+row['fingerprint']+'\n'
 append+=''.join('  test '+test+'\n' for test in row['tests'])+'\n'
m.MAP_PATH.write_text(original+append)
assert m.verify()==0
packet=root/'docs/migrations/evidence/trigger-beta-completion-2026-11-03';packet.mkdir(parents=True,exist_ok=True)
patch=''
for rel in [*newpaths,Path('spec-tests.map')]:
 before=(root/rel).read_text() if (root/rel).exists() else ''
 after=(out/rel).read_text()
 patch+=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+str(rel) if before else '/dev/null',tofile='b/'+str(rel)))
(packet/'canonical-sync.patch').write_text(patch)
(packet/'scenario-evidence.json').write_text(json.dumps({'scope':'18 reviewed beta scenarios; canonical sync awaits independent PASS','scenarios':added},indent=2)+'\n')
print('reviewed new scenarios',len(added))
