import pathlib,json,collections,subprocess,hashlib,stat,re
root=pathlib.Path('/tmp/dandrum-lanes/runtime');base=pathlib.Path('/tmp/dandrum-lanes/evidence-runtime-quiescent-combined');name='src/trigger-host/src/runtime.rs';path=str(root/name)
d=json.loads((base/'05-json-report/host.json').read_text())['data'][0];summary=next(x['summary'] for x in d['files'] if x['filename']==path)
regions=collections.Counter();funcs=collections.Counter()
for f in d['functions']:
 own=[r for r in f['regions'] if f['filenames'][r[5]]==path and r[7]==0]
 if own:funcs[tuple(own[0][:4])]+=f['count']
 for r in own:regions[tuple(r[:4])]+=r[4]
cut=next(i for i,l in enumerate((root/name).read_text().splitlines(),1) if l=='#[cfg(test)]')
new={k:v for k,v in regions.items() if 403<=k[0]<=427 or 782<=k[0]<=789}
linecounts=collections.Counter()
for r in (base/'05-full-coverage/host.lcov').read_text().split('end_of_record'):
 if 'SF:'+path+'\n' not in r:continue
 for s in r.splitlines():
  if s.startswith('DA:'):
   n,h,*_=s[3:].split(',');linecounts[int(n)]+=int(h)
versions={tool:subprocess.check_output(cmd,text=True).strip() for tool,cmd in {'cargo':['/home/dan/.cargo/bin/cargo','--version'],'rustc':['/home/dan/.cargo/bin/rustc','--version'],'cargo-llvm-cov':['/home/dan/.cargo/bin/cargo','llvm-cov','--version']}.items()}
qualification=dict(tools=versions,full_package_tests=128,doc_tests=2,session_tests=30,llvm_reported_runtime_summary=summary,merged_source_coordinates=dict(lines=dict(total=len(linecounts),hit=sum(v>0 for v in linecounts.values()),unhit=[k for k,v in linecounts.items() if not v]),functions=dict(total=len(funcs),hit=sum(v>0 for v in funcs.values())),normal_code_regions=dict(total=len(regions),hit=sum(v>0 for v in regions.values()))),production=dict(test_module_starts_at=cut,functions=sum(k[0]<cut for k in funcs),functions_hit=sum(k[0]<cut and v>0 for k,v in funcs.items()),regions=sum(k[0]<cut for k in regions),regions_hit=sum(k[0]<cut and v>0 for k,v in regions.items()),unhit_region_coordinates=[k for k,v in regions.items() if k[0]<cut and not v]),new_service_closure_and_extracted_helper=dict(regions=len(new),hit=sum(v>0 for v in new.values()),counts={str(k):v for k,v in new.items()}),limits=['No branch or MC/DC instrumentation; no blanket owner100% claim.','LLVM emitted summary retains unexecuted instantiations and macro/expansion effects; coordinate-merging is explicitly separate.','Existing apply_event error propagation region at runtime.rs932:78-79 is not executed under valid public event budgets; unchanged code, no invented exclusion.','Nonzero UI settlement and restore epoch have no public observer/service route in this runtime-only API. Fields are structurally untouched; behavioral proof belongs to later controller route.','This is format-neutral inactive runtime foundation only: no controller, stopped flush, rate/configuration, CLAP/native/reactivation/install acceptance.','Mutation explicitly excluded by user.','Baseline RAM-target guard stop is setup/resource failure without report, not RED or passing evidence. Disk target replacement retains original disk/memory floors and samples unused RAM separately.'])
(base/'coverage-qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
paths=['src/trigger-host/src/runtime.rs','src/trigger-host/tests/runtime_quiescent.rs'];files=[]
for p in paths:
 data=(root/p).read_bytes();idx=subprocess.check_output(['git','ls-files','--stage','--',p],cwd=root,text=True).strip();status=subprocess.check_output(['git','status','--short','--untracked-files=all','--',p],cwd=root,text=True).rstrip('\n')
 files.append(dict(path=p,status=status,mode='100755' if (root/p).stat().st_mode & 0o111 else '100644',filesystem_mode=oct(stat.S_IMODE((root/p).stat().st_mode)),sha256=hashlib.sha256(data).hexdigest(),index_entry=idx or None))
manifest=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),branch=subprocess.check_output(['git','symbolic-ref','--short','HEAD'],cwd=root,text=True).strip(),files=files,excluded_root_owned_path='openspec/changes/add-juce-free-trigger-clap-editor/design.md',author_scope='Verification-only disjoint integration followup. No source, index, Git, design, dependency or controller change. Root owns the two existing source edits and publication.',review='Fresh preliminary review is root-owned; final review/publication requires combined integration checks after notes publication. No author self-approval.')
serial=json.dumps(manifest,sort_keys=True,indent=2)+'\n';(base/'author-freeze.json').write_text(serial);(base/'author-freeze.sha256').write_text(hashlib.sha256(serial.encode()).hexdigest()+'  author-freeze.json\n')
print(json.dumps({'manifest_sha256':hashlib.sha256(serial.encode()).hexdigest(),'files':files,'new_regions':len(new),'new_regions_hit':sum(v>0 for v in new.values()),'source_lines':len(linecounts),'source_lines_hit':sum(v>0 for v in linecounts.values())},indent=2))
