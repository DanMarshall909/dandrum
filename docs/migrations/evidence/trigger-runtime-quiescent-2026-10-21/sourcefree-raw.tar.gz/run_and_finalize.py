from pathlib import Path
import os, sys, subprocess, signal, time, json, hashlib, shutil, stat, re, shlex, platform
ROOT=Path('/tmp/dandrum-lanes/runtime')
FIX=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source')
E=Path('/tmp/dandrum-lanes/evidence-runtime-quiescent-sourcefree')
TARGET=Path('/tmp/dandrum-lanes/cache-editor-guard')
TMP=E/'tmp'
FLOORS={'disk_free_bytes':1024**3,'memory_available_bytes':4*1024**3}
UPDATED=['src/trigger-host/src/runtime.rs','src/trigger-host/tests/runtime_quiescent.rs']
EXTRA_EXISTING={'src/trigger-host/src/parameters.rs':'37b8e92e6507036084fcb99b9fabe717550d53fe2f36a2f046312e630cc3efea','src/trigger-host/tests/editor_note_controller.rs':'99b99000f9e35406e87d29325d4f6ae07a6354097a40a94544c7cfff68fbb08e'}
EXPECTED={'src/trigger-host/src/runtime.rs':'b7a65c05a715d739b5a5dd4ff40a2f244025088a756f584bdfe99f62f71353b8','src/trigger-host/tests/runtime_quiescent.rs':'c3d23533215e762663c0eb2706ba4ee58ffe83e54a95b79e62ec58f00de3568f',**EXTRA_EXISTING}
HEAD='5d332b81adc07117e59f69a528785d194c8da3ff'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def resources():
 du=shutil.disk_usage('/tmp');su=shutil.disk_usage('/dev/shm')
 mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 return {'disk_free_bytes':du.free,'memory_available_bytes':mem,'unused_build_output_volume':{'path':'/dev/shm','free_bytes':su.free,'used_for_build_output':False}}
def write(name,obj): (E/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def records(base):
 out={}
 for part in ('CMakeLists.txt','src','tests','examples','schema','scripts','spikes'):
  p=base/part
  if not p.exists():continue
  scan=[]
  if p.is_file():scan=[p]
  else:
   for parent,dirs,files in os.walk(p):
    dirs[:]=[d for d in dirs if d not in ('target','build','__pycache__')]
    scan.extend(Path(parent)/n for n in files)
  for q in scan:
   if q.is_symlink():raise RuntimeError(f'symlink input {q}')
   s=q.stat();out[str(q.relative_to(base))]={'sha256':sha(q),'mode':oct(stat.S_IMODE(s.st_mode)),'mtime_ns':s.st_mtime_ns,'bytes':s.st_size}
 return out
def verify_root():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
 for rel,h in EXPECTED.items():assert sha(ROOT/rel)==h,(rel,sha(ROOT/rel),h)
 assert not (FIX/'web').exists() and not (FIX/'ui').exists() and not (FIX/'third_party').exists()
def verify_fixture(rootmap,basefix,updates_done):
 assert records(ROOT)==rootmap,'runtime root source map changed'
 cur=records(FIX)
 assert set(cur)==set(rootmap),'fixture input set differs from runtime source'
 assert all(cur[k]['sha256']==rootmap[k]['sha256'] for k in rootmap),'fixture bytes differ from runtime source'
 assert all(cur[k]['mode']==basefix[k]['mode'] and cur[k]['mtime_ns']==basefix[k]['mtime_ns'] for k in basefix if k not in UPDATED),'unmodified fixture metadata changed'
 if updates_done:
  assert all(cur[k]['mode']==rootmap[k]['mode'] and cur[k]['mtime_ns']==rootmap[k]['mtime_ns'] for k in UPDATED),'updated fixture metadata mismatch'
def run(label,cmd,env,rootmap,basefix):
 verify_fixture(rootmap,basefix,True);r=resources()
 if r['disk_free_bytes']<FLOORS['disk_free_bytes'] or r['memory_available_bytes']<FLOORS['memory_available_bytes']:
  write('resource-stop.json',{'stage':label,'reason':'prelaunch-floor','resources':r,'floors':FLOORS});raise RuntimeError('resource floor before launch')
 logpath=E/(label+'.log');start=time.monotonic();samples=[];stop=None
 with logpath.open('wb') as log:
  p=subprocess.Popen(cmd,cwd=FIX,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  last=0
  while p.poll() is None:
   r=resources();r['elapsed_seconds']=time.monotonic()-start;samples.append(r)
   if r['disk_free_bytes']<FLOORS['disk_free_bytes'] or r['memory_available_bytes']<FLOORS['memory_available_bytes']:stop={'reason':'resource-floor','resources':r}
   if label=='release-tests' and not stop:
    data=logpath.read_bytes()
    matches=[line.decode('utf8','replace').strip() for line in data.splitlines() if re.search(rb'Compiling dandrum_(?:engine|instrument_session)(?: v| )',line)]
    if matches:stop={'reason':'unexpected-full-dependency-compile','lines':matches}
   if stop:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   now=time.monotonic()
   if now-last>=30:print(json.dumps({'stage':label,'elapsed_seconds':round(now-start,1),'resources':r}),flush=True);last=now
   time.sleep(.5)
  code=p.wait()
 rec={'command':cmd,'cwd':str(FIX),'effective_environment':{k:env[k] for k in sorted(env) if k in ['PATH','HOME','CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTC','RUSTDOC','LD_LIBRARY_PATH','LANG','LC_ALL','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR']},'exit':code,'elapsed_seconds':time.monotonic()-start,'pid':p.pid,'pgid':p.pid,'stop':stop,'resource_samples':samples,'minimum_resources':{'disk_free_bytes':min(x['disk_free_bytes'] for x in samples) if samples else r['disk_free_bytes'],'memory_available_bytes':min(x['memory_available_bytes'] for x in samples) if samples else r['memory_available_bytes'],'unused_build_output_volume_min_free_bytes':min(x['unused_build_output_volume']['free_bytes'] for x in samples) if samples else r['unused_build_output_volume']['free_bytes']},'final_resources':resources(),'raw_log_sha256':sha(logpath),'raw_log_bytes':logpath.stat().st_size}
 write(label+'-run.json',rec);print(json.dumps({'stage':label,'exit':code,'elapsed_seconds':round(rec['elapsed_seconds'],3),'pgid':p.pid,'stop':stop,'final_resources':rec['final_resources']}),flush=True)
 verify_fixture(rootmap,basefix,True)
 if code or stop:raise RuntimeError(f'{label} failed or stopped; retained log/receipt')
 return rec

assert not (E/'receipt.json').exists(),'evidence directory already finalized'
assert os.stat('/tmp').st_dev==os.stat(TARGET).st_dev==os.stat(TMP).st_dev
verify_root(); assert FIX.is_dir() and TARGET.is_dir()
initial=resources();assert initial['disk_free_bytes']>=FLOORS['disk_free_bytes'] and initial['memory_available_bytes']>=FLOORS['memory_available_bytes'],initial
rootmap=records(ROOT);basefix=records(FIX)
assert len(basefix)==591 and len(rootmap)==592,(len(basefix),len(rootmap))
assert set(basefix)<set(rootmap) and set(rootmap)-set(basefix)=={'src/trigger-host/tests/runtime_quiescent.rs'}
unchanged=[k for k in basefix if k not in UPDATED]
assert len(unchanged)==590
assert all(basefix[k]['sha256']==rootmap[k]['sha256'] for k in unchanged if k not in {'src/trigger-host/src/runtime.rs'})
# The sole existing input with new bytes is runtime.rs. The second authorized path is the one new test input.
assert basefix['src/trigger-host/src/runtime.rs']['sha256']!=rootmap['src/trigger-host/src/runtime.rs']['sha256']
write('root-before-map.json',rootmap);write('fixture-before-map.json',basefix)
write('fixture-update-preimages.json',{k:basefix.get(k,{'exists':False}) for k in UPDATED})
# Copy only the two frozen runtime inputs, preserving their exact file metadata.
for rel in UPDATED:
 dst=FIX/rel;src=ROOT/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);shutil.copystat(src,dst)
assert len(records(FIX))==592
verify_fixture(rootmap,basefix,True)
write('fixture-prebuild-map.json',records(FIX))
write('fixture-update-receipt.json',{'root_head':HEAD,'paths_updated':UPDATED,'root_hashes':{k:sha(ROOT/k) for k in UPDATED},'root_modes_mtimes':{k:{'mode':oct(stat.S_IMODE((ROOT/k).stat().st_mode)),'mtime_ns':(ROOT/k).stat().st_mtime_ns} for k in UPDATED},'fixture_input_count_before':len(basefix),'fixture_input_count_after':len(records(FIX)),'unchanged_fixture_inputs_byte_mode_mtime_proven':len(unchanged),'resource_after_update':resources()})
# Capture exact cleaned environment and commands, keeping ordinary default release profile.
env=dict(os.environ);removed={}
for k in list(env):
 if k.startswith(('CARGO_PROFILE_','CARGO_LLVM_COV_','__CARGO_LLVM_COV_')) or k in ('RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LLVM_PROFILE_FILE','RUSTC_BOOTSTRAP','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER'):removed[k]=env.pop(k)
env.update({'PATH':'/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin','CARGO_TARGET_DIR':str(TARGET),'CARGO_BUILD_JOBS':'1','CARGO_NET_OFFLINE':'true','CARGO_INCREMENTAL':'0','TMPDIR':str(TMP)})
commands=[('release-tests',['/home/dan/.cargo/bin/cargo','test','--release','--offline','--locked','--jobs','1','--manifest-path',str(FIX/'src/trigger-host/Cargo.toml'),'-vv']),('dependencies',['/home/dan/.cargo/bin/cargo','tree','--offline','--locked','--manifest-path',str(FIX/'src/trigger-host/Cargo.toml'),'--edges','normal','--prefix','none'])]
write('invocation.json',{'root':str(ROOT),'root_head':HEAD,'fixture':str(FIX),'commands':[{'label':a,'argv':b,'cwd':str(FIX)} for a,b in commands],'initial_resources':initial,'floors':FLOORS,'removed_environment_variable_names':sorted(removed),'effective_environment':{k:env[k] for k in sorted(env) if k in ['PATH','HOME','CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTC','RUSTDOC','LD_LIBRARY_PATH','LANG','LC_ALL','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR']},'target_device':os.stat(TARGET).st_dev,'tmp_device':os.stat(TMP).st_dev,'cargo_manifest':(FIX/'src/trigger-host/Cargo.toml').read_text()})
versions={}
for label,cmd in [('cargo',['/home/dan/.cargo/bin/cargo','-Vv']),('rustc',['/home/dan/.cargo/bin/rustc','-Vv']),('rustdoc',['/home/dan/.cargo/bin/rustdoc','-Vv'])]:
 q=subprocess.run(cmd,text=True,capture_output=True);versions[label]={'command':cmd,'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
write('tool-versions.json',versions)
results=[]
for label,cmd in commands:results.append(run(label,cmd,env,rootmap,basefix))
log=(E/'release-tests.log').read_text(errors='replace');deps=(E/'dependencies.log').read_text(errors='replace')
sr=re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s')
sums=[]
for line in log.splitlines():
 m=sr.search(line)
 if m:sums.append({'status':m.group(1),'passed':int(m.group(2)),'failed':int(m.group(3)),'ignored':int(m.group(4)),'measured':int(m.group(5)),'filtered':int(m.group(6)),'elapsed_seconds':float(m.group(7)),'line':line})
assert len(sums)==12,sums
ordinary=sums[:-2];doc=sums[-2:]
assert sum(x['passed'] for x in ordinary)==128 and sum(x['passed'] for x in doc)==2,(ordinary,doc)
assert all(x['status']=='ok' and x['failed']==x['ignored']==x['measured']==x['filtered']==0 for x in sums),sums
executed=[];running={}
for line in log.splitlines():
 m=re.match(r'\s+Running `([^`]+)`\s*$',line)
 if not m:continue
 try:a=shlex.split(m.group(1))
 except ValueError:continue
 exe=next((x for x in a if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*=',x)),None)
 if not exe:continue
 p=Path(exe)
 if p.is_absolute() and p.parent==TARGET/'release/deps' and p.is_file() and os.access(p,os.X_OK) and p not in executed:executed.append(p);running[p]=line
compiler=[]
for line in log.splitlines():
 if 'Running `' not in line or 'rustc --crate-name' not in line:continue
 m=re.search(r'Running `([^`]+)`',line)
 try:a=shlex.split(m.group(1)) if m else []
 except ValueError:continue
 i=next((i for i,x in enumerate(a) if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*=',x)),None)
 if i is None or not a[i].endswith('/rustc') or '--test' not in a:continue
 try:crate=a[a.index('--crate-name')+1]
 except (ValueError,IndexError):continue
 extra=next((a[j+1] for j,x in enumerate(a[:-1]) if x=='-C' and a[j+1].startswith('extra-filename=')),None)
 compiler.append({'crate_name':crate,'extra_filename':extra,'argv':a,'raw_line':line})
bins=[]
for p in executed:
 stem=p.name;crate,ch=stem.rsplit('-',1);extra='extra-filename=-'+ch
 matches=[c for c in compiler if c['crate_name']==crate and c['extra_filename']==extra]
 assert matches,f'no test compiler invocation for {stem}'
 d=p.with_name(stem+'.d');assert d.is_file();db=d.read_bytes()
 fdir=TARGET/'release/.fingerprint'/('dandrum-trigger-host-'+ch);assert fdir.is_dir()
 fps=[{'path':str(f),'name':f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in fdir.iterdir() if f.is_file()]
 bins.append({'path':str(p),'crate_name':crate,'crate_hash':ch,'bytes':p.stat().st_size,'sha256_after_dependency_audit':sha(p),'mtime_ns':p.stat().st_mtime_ns,'direct_cargo_running_line':running[p],'rustc_test_invocation':matches[-1],'dep_info':{'path':str(d),'bytes':len(db),'sha256':sha(d),'mentions_runtime_source':b'src/runtime.rs' in db,'mentions_runtime_test':b'tests/runtime_quiescent.rs' in db},'cargo_fingerprint_files':fps})
assert len(bins)==11,(len(bins),[p.name for p in executed])
assert any(b['crate_name']=='dandrum_trigger_host' and b['dep_info']['mentions_runtime_source'] for b in bins)
assert any(b['crate_name']=='runtime_quiescent' and b['dep_info']['mentions_runtime_test'] for b in bins)
flags=sorted(set(x for x in ('-C opt-level=3','-C linker-plugin-lto','-C codegen-units=1') if x in log));assert flags==['-C codegen-units=1','-C linker-plugin-lto','-C opt-level=3'],flags
normal=[line.split()[0] for line in deps.splitlines() if line.strip()];forbidden=[n for n in normal if any(x in n.lower() for x in ('clack','wry','gtk','webkit','juce'))];assert not forbidden,forbidden
rootafter=records(ROOT);fixafter=records(FIX);assert rootmap==rootafter and len(rootafter)==592 and len(fixafter)==592
assert set(rootafter)==set(fixafter) and all(rootafter[k]['sha256']==fixafter[k]['sha256'] for k in rootafter)
assert all(basefix[k]['sha256']==fixafter[k]['sha256'] and basefix[k]['mode']==fixafter[k]['mode'] and basefix[k]['mtime_ns']==fixafter[k]['mtime_ns'] for k in unchanged)
assert all(rootafter[k]['mode']==fixafter[k]['mode'] and rootafter[k]['mtime_ns']==fixafter[k]['mtime_ns'] for k in UPDATED)
assert not forbidden
write('root-after-map.json',rootafter);write('fixture-after-map.json',fixafter)
write('source-manifest.json',{k:v['sha256'] for k,v in rootafter.items()})
write('executed-artifact-bindings.json',{'actual_direct_test_executable_count':len(bins),'actual_direct_test_executables':bins,'ordinary_target_summaries':ordinary,'compile_fail_doctest_summaries':doc,'ordinary_test_total':sum(x['passed'] for x in ordinary),'doctest_total':sum(x['passed'] for x in doc),'actual_rustc_test_invocations':compiler,'profile_flags_seen_in_actual_rustc_commands':flags,'normal_dependency_names':normal,'forbidden_dependency_matches':forbidden})
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==HEAD
status=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True)
assert subprocess.run(['git','diff','--cached','--quiet'],cwd=ROOT).returncode==0
owned=[x['pgid'] for x in results];ps=subprocess.check_output(['ps','-eo','pid=,pgid=,args='],text=True).splitlines();survivors=[]
for line in ps:
 z=line.strip().split(None,2)
 if len(z)>=2 and z[1].isdigit() and int(z[1]) in owned:survivors.append(line)
assert not survivors,survivors
source={'head':head,'git_status':status,'staged_diff_empty':True,'root_inputs_before_after':len(rootmap),'fixture_inputs_before_after':[len(basefix),len(fixafter)],'root_full_map_before_after_equal':rootmap==rootafter,'root_full_map_sha256_before_after':hashlib.sha256((E/'root-before-map.json').read_bytes()).hexdigest(),'fixture_matches_root_all_bytes':all(rootafter[k]['sha256']==fixafter[k]['sha256'] for k in rootafter),'unchanged_fixture_inputs_byte_mode_mtime_proven':len(unchanged),'updated_fixture_inputs':UPDATED,'absent_fixture_trees':['web','ui','third_party'],'removed_inputs':[]}
write('source-verification.json',source)
receipt={'status':'PASS','scope':'Full unfiltered source-free default-release Rust host Cargo suite plus normal locked dependency-tree audit','head_source_binding':head,'source_manifest_sha256':sha(E/'source-manifest.json'),'root_inputs':len(rootafter),'fixture_inputs_before':len(basefix),'fixture_inputs_after':len(fixafter),'unchanged_fixture_inputs_byte_mode_mtime':len(unchanged),'updated_fixture_inputs':UPDATED,'ordinary_test_total':sum(x['passed'] for x in ordinary),'compile_fail_doctest_total':sum(x['passed'] for x in doc),'ordinary_and_doctest_summaries':sums,'all_failed_ignored_measured_filtered_counts_zero':True,'executed_test_binary_count':len(bins),'binary_inventory':'executed-artifact-bindings.json','cargo_test_command':results[0]['command'],'cargo_test_cwd':results[0]['cwd'],'cargo_test_exit':results[0]['exit'],'cargo_test_elapsed_seconds':results[0]['elapsed_seconds'],'cargo_tree_command':results[1]['command'],'cargo_tree_exit':results[1]['exit'],'cargo_tree_elapsed_seconds':results[1]['elapsed_seconds'],'effective_environment':results[0]['effective_environment'],'removed_profile_instrumentation_variable_names':sorted(removed),'release_profile':'Default release, opt-level 3, LTO enabled, codegen-units 1; incremental disabled; one build job; no instrumentation/profile override','actual_rustc_profile_flags':flags,'cache':'Existing /tmp/dandrum-lanes/cache-editor-guard; preserved without clean/delete/relocation','private_tmpdir':str(TMP),'tmp_target_same_filesystem':True,'resource_floors_bytes':FLOORS,'minimum_resources':results[0]['minimum_resources'],'final_resources':results[0]['final_resources'],'unused_build_output_volume':results[0]['final_resources']['unused_build_output_volume'],'forbidden_normal_dependency_matches':forbidden,'owned_process_groups':owned,'owned_process_survivors':survivors,'fixture_after_run_retained':True,'prior_success_evidence_untouched':True,'qualification':'Source-free Rust host tests and Rust normal-dependency audit only. No full CMake/native/CLAP/browser/beta/task-completion/publication claim.'}
write('receipt.json',receipt)
print(json.dumps({'status':'PASS','ordinary':receipt['ordinary_test_total'],'doctests':receipt['compile_fail_doctest_total'],'executed_binaries':len(bins),'minimum_resources':receipt['minimum_resources'],'forbidden_dependencies':forbidden,'owned_process_survivors':survivors},indent=2),flush=True)
