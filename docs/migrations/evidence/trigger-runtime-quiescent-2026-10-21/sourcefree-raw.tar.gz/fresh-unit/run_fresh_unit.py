from pathlib import Path
import os,sys,subprocess,signal,time,json,hashlib,shutil,stat,re,shlex,datetime
ROOT=Path('/tmp/dandrum-lanes/runtime');FIX=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source');E=Path('/tmp/dandrum-lanes/evidence-runtime-quiescent-sourcefree');OUT=E/'fresh-unit';TARGET=Path('/tmp/dandrum-lanes/cache-editor-guard');TMP=E/'tmp';HEAD='5d332b81adc07117e59f69a528785d194c8da3ff';FLOORS={'disk_free_bytes':1024**3,'memory_available_bytes':4*1024**3};rel='src/trigger-host/src/runtime.rs';expected='b7a65c05a715d739b5a5dd4ff40a2f244025088a756f584bdfe99f62f71353b8'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resources():
 du=shutil.disk_usage('/tmp');su=shutil.disk_usage('/dev/shm');mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 return {'disk_free_bytes':du.free,'memory_available_bytes':mem,'unused_build_output_volume':{'path':'/dev/shm','free_bytes':su.free,'used_for_build_output':False}}
def write(n,o):(OUT/n).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
def records(base):
 out={}
 for part in ('CMakeLists.txt','src','tests','examples','schema','scripts','spikes'):
  p=base/part
  if not p.exists():continue
  scan=[]
  if p.is_file():scan=[p]
  else:
   for par,dirs,files in os.walk(p):
    dirs[:]=[d for d in dirs if d not in ('target','build','__pycache__')]
    scan.extend(Path(par)/n for n in files)
  for q in scan:
   if q.is_symlink():raise RuntimeError(f'symlink source input {q}')
   st=q.stat();out[str(q.relative_to(base))]={'sha256':sha(q),'mode':oct(stat.S_IMODE(st.st_mode)),'mtime_ns':st.st_mtime_ns,'bytes':st.st_size}
 return out
def relevant_target_map():
 result={}
 paths=[]
 paths.extend((TARGET/'release/deps').glob('dandrum_trigger_host-*'))
 paths.extend((TARGET/'release/deps').glob('libdandrum_trigger_host-*'))
 paths.extend((TARGET/'release/.fingerprint').glob('dandrum-trigger-host-*'))
 for p in paths:
  if p.is_file():result[str(p)]={'sha256':sha(p),'mtime_ns':p.stat().st_mtime_ns,'bytes':p.stat().st_size}
  elif p.is_dir():
   for q in p.iterdir():
    if q.is_file():result[str(q)]={'sha256':sha(q),'mtime_ns':q.stat().st_mtime_ns,'bytes':q.stat().st_size}
 return result
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
assert sha(ROOT/rel)==expected and sha(FIX/rel)==expected
assert records(ROOT)==json.loads((E/'root-after-map.json').read_text())
assert records(FIX)==json.loads((E/'fixture-after-map.json').read_text())
assert os.stat('/tmp').st_dev==os.stat(TARGET).st_dev==os.stat(TMP).st_dev
assert not (OUT/'release-tests.log').exists()
# Ensure the borrowed release cache has no other active Cargo/Rust builder.
active=[]
for d in Path('/proc').iterdir():
 if d.name.isdigit():
  try:comm=(d/'comm').read_text().strip()
  except OSError:continue
  if comm in ('cargo','rustc','rustdoc'):active.append({'pid':int(d.name),'comm':comm})
assert not active,active
r=resources();assert r['disk_free_bytes']>=FLOORS['disk_free_bytes'] and r['memory_available_bytes']>=FLOORS['memory_available_bytes'],r
root_before=records(ROOT);fixture_before=records(FIX);target_before=relevant_target_map()
unit=TARGET/'release/deps/dandrum_trigger_host-7f362fce781ef7bf';fp=TARGET/'release/.fingerprint/dandrum-trigger-host-7f362fce781ef7bf';d=unit.with_name(unit.name+'.d')
pre={'status':'STALE_MTIME_RISK','prior_full_run':'../release-tests.log','prior_full_run_receipt':'../release-tests-run.json','previous_unit_binary_sha256':'3ba52a4ac8abacb75a44a7972f7c0f4e03dcc81d939292a2c9825c5c45a5f082','previous_unit_binary_mtime_ns':unit.stat().st_mtime_ns,'previous_unit_depinfo_sha256':sha(d),'previous_unit_depinfo_mtime_ns':d.stat().st_mtime_ns,'previous_fingerprint_files':{q.name:{'sha256':sha(q),'mtime_ns':q.stat().st_mtime_ns} for q in fp.iterdir() if q.is_file()},'fixture_runtime_before':fixture_before[rel],'root_runtime_before':root_before[rel],'root_map_sha256_before':hashlib.sha256(json.dumps(root_before,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'fixture_map_sha256_before':hashlib.sha256(json.dumps(fixture_before,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'resource_before':r}
write('source-freshness-audit-before.json',pre)
# Change only the fixture source mtime; preserve atime, bytes and mode.
st= (FIX/rel).stat();new_ns=time.time_ns();os.utime(FIX/rel,ns=(st.st_atime_ns,new_ns));st2=(FIX/rel).stat()
assert sha(FIX/rel)==expected and stat.S_IMODE(st.st_mode)==stat.S_IMODE(st2.st_mode) and st2.st_mtime_ns==new_ns
assert (ROOT/rel).stat().st_mtime_ns==root_before[rel]['mtime_ns']
write('fixture-runtime-timestamp-correction.json',{'path':rel,'sha256_before_after':expected,'fixture_mtime_before_ns':st.st_mtime_ns,'fixture_mtime_after_ns':st2.st_mtime_ns,'actual_host_utc':datetime.datetime.fromtimestamp(st2.st_mtime_ns/1e9,datetime.timezone.utc).isoformat(),'mode_before_after':oct(stat.S_IMODE(st.st_mode)),'atime_before_ns':st.st_atime_ns,'root_mtime_untouched_ns':(ROOT/rel).stat().st_mtime_ns,'only_fixture_source_stat_changed':True})
# Snapshot immediately before command, after the deliberate timestamp correction.
root_pre=records(ROOT);fixture_pre=records(FIX);target_pre=relevant_target_map();assert root_pre==root_before
assert fixture_pre[rel]['mtime_ns']==st2.st_mtime_ns and fixture_pre[rel]['sha256']==expected
# Use the same default release environment and offline/locked settings as the full gate.
env=dict(os.environ);removed={}
for k in list(env):
 if k.startswith(('CARGO_PROFILE_','CARGO_LLVM_COV_','__CARGO_LLVM_COV_')) or k in ('RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LLVM_PROFILE_FILE','RUSTC_BOOTSTRAP','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER'):removed[k]=env.pop(k)
env.update({'PATH':'/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin','CARGO_TARGET_DIR':str(TARGET),'CARGO_BUILD_JOBS':'1','CARGO_NET_OFFLINE':'true','CARGO_INCREMENTAL':'0','TMPDIR':str(TMP)})
cmd=['/home/dan/.cargo/bin/cargo','test','--release','--offline','--locked','--jobs','1','--manifest-path',str(FIX/'src/trigger-host/Cargo.toml'),'--lib','-vv']
write('invocation.json',{'command':cmd,'cwd':str(FIX),'effective_environment':{k:env[k] for k in sorted(env) if k in ['PATH','HOME','CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTC','RUSTDOC','LD_LIBRARY_PATH','LANG','LC_ALL','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR']},'removed_profile_instrumentation_variable_names':sorted(removed),'initial_resources':resources(),'floors':FLOORS,'target_device':os.stat(TARGET).st_dev,'tmp_device':os.stat(TMP).st_dev})
logp=OUT/'release-tests.log';start=time.monotonic();samples=[];stop=None
with logp.open('wb') as log:
 p=subprocess.Popen(cmd,cwd=FIX,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);last=0
 while p.poll() is None:
  x=resources();x['elapsed_seconds']=time.monotonic()-start;samples.append(x)
  if x['disk_free_bytes']<FLOORS['disk_free_bytes'] or x['memory_available_bytes']<FLOORS['memory_available_bytes']:stop={'reason':'resource-floor','resources':x}
  if stop:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  now=time.monotonic()
  if now-last>=30:print(json.dumps({'elapsed_seconds':round(now-start,1),'resources':x}),flush=True);last=now
  time.sleep(.5)
 code=p.wait()
rec={'command':cmd,'cwd':str(FIX),'effective_environment':{k:env[k] for k in sorted(env) if k in ['PATH','HOME','CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTC','RUSTDOC','LD_LIBRARY_PATH','LANG','LC_ALL','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR']},'exit':code,'elapsed_seconds':time.monotonic()-start,'pid':p.pid,'pgid':p.pid,'stop':stop,'resource_samples':samples,'minimum_resources':{'disk_free_bytes':min(x['disk_free_bytes'] for x in samples) if samples else resources()['disk_free_bytes'],'memory_available_bytes':min(x['memory_available_bytes'] for x in samples) if samples else resources()['memory_available_bytes'],'unused_build_output_volume_min_free_bytes':min(x['unused_build_output_volume']['free_bytes'] for x in samples) if samples else resources()['unused_build_output_volume']['free_bytes']},'final_resources':resources(),'raw_log_sha256':sha(logp),'raw_log_bytes':logp.stat().st_size}
write('release-tests-run.json',rec)
log=logp.read_text(errors='replace');sums=[]
for line in log.splitlines():
 m=re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s',line)
 if m:sums.append({'status':m.group(1),'passed':int(m.group(2)),'failed':int(m.group(3)),'ignored':int(m.group(4)),'measured':int(m.group(5)),'filtered':int(m.group(6)),'elapsed_seconds':float(m.group(7)),'line':line})
# Parse actual test executable and compiler command for this isolated --lib run.
runs=[];rustcs=[]
for line in log.splitlines():
 if 'Running `' not in line:continue
 m=re.search(r'Running `([^`]+)`',line)
 try:a=shlex.split(m.group(1)) if m else []
 except ValueError:continue
 exe=next((v for v in a if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*=',v)),None)
 if exe and exe.startswith(str(TARGET/'release/deps/dandrum_trigger_host-')):runs.append({'argv':a,'raw_line':line})
 if exe and exe.endswith('/rustc') and '--test' in a:rustcs.append({'argv':a,'raw_line':line})
post_unit_hash=sha(unit);post_depsha=sha(d);fps={q.name:{'sha256':sha(q),'mtime_ns':q.stat().st_mtime_ns,'bytes':q.stat().st_size} for q in fp.iterdir() if q.is_file()}
root_after=records(ROOT);fixture_after=records(FIX);target_after=relevant_target_map()
assert root_after==root_before,'root source changed during unit run'
assert set(fixture_after)==set(root_before) and all(fixture_after[k]['sha256']==root_before[k]['sha256'] for k in root_before)
unchanged=[k for k in fixture_before if k!=rel]
assert len(unchanged)==591 # original fixture now had 592 including newly-added runtime test; only runtime.rs mtime was intentionally changed
assert all(fixture_after[k]['sha256']==fixture_before[k]['sha256'] and fixture_after[k]['mode']==fixture_before[k]['mode'] and fixture_after[k]['mtime_ns']==fixture_before[k]['mtime_ns'] for k in unchanged)
assert fixture_after[rel]['sha256']==expected and fixture_after[rel]['mode']==fixture_before[rel]['mode'] and fixture_after[rel]['mtime_ns']==st2.st_mtime_ns
owned=[]
ps=subprocess.check_output(['ps','-eo','pid=,pgid=,args='],text=True).splitlines()
for line in ps:
 z=line.strip().split(None,2)
 if len(z)>1 and z[1].isdigit() and int(z[1])==p.pid:owned.append(line)
write('unit-result.json',{'command_exit':code,'command_stop':stop,'summary_count':len(sums),'summaries':sums,'rustc_test_command_count':len(rustcs),'rustc_test_commands':rustcs,'direct_binary_run_lines':runs,'unit_binary':{'path':str(unit),'old_sha256':pre['previous_unit_binary_sha256'],'new_sha256':post_unit_hash,'sha_changed':post_unit_hash!=pre['previous_unit_binary_sha256'],'mtime_ns':unit.stat().st_mtime_ns,'dep_info_sha256':post_depsha,'dep_info_mtime_ns':d.stat().st_mtime_ns,'dep_info_mentions_runtime_rs':b'src/runtime.rs' in d.read_bytes(),'fingerprint_files':fps},'root_source_map_unchanged':root_after==root_before,'fixture_input_count':len(fixture_after),'fixture_root_bytes_match':all(fixture_after[k]['sha256']==root_after[k]['sha256'] for k in root_after),'unchanged_fixture_inputs_byte_mode_mtime':len(unchanged),'runtime_fixture_mtime_intentionally_differs_from_root':fixture_after[rel]['mtime_ns']!=root_after[rel]['mtime_ns'],'owned_process_survivors':owned,'minimum_resources':rec['minimum_resources'],'final_resources':rec['final_resources'],'target_change_count':len(set(target_pre)|set(target_after)),'target_changes':{k:{'before':target_pre.get(k),'after':target_after.get(k)} for k in set(target_pre)|set(target_after) if target_pre.get(k)!=target_after.get(k)}})
assert code==0 and stop is None and len(sums)==1 and sums[0]['passed']==15 and sums[0]['failed']==sums[0]['ignored']==sums[0]['measured']==sums[0]['filtered']==0,(code,sums)
assert len(rustcs)==1 and post_unit_hash!=pre['previous_unit_binary_sha256'] and b'src/runtime.rs' in d.read_bytes()
assert not owned
print(json.dumps({'exit':code,'unit_tests':sums[0]['passed'],'binary_sha_changed':True,'new_binary_sha256':post_unit_hash,'rustc_test_commands':len(rustcs),'minimum_resources':rec['minimum_resources'],'root_unchanged':True,'fixture_inputs':len(fixture_after),'unchanged_others':len(unchanged)},indent=2),flush=True)
