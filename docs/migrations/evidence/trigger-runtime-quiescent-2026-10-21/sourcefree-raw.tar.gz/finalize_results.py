from pathlib import Path
import os, subprocess, json, hashlib, re, shlex, stat
ROOT=Path('/tmp/dandrum-lanes/runtime')
FIX=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source')
E=Path('/tmp/dandrum-lanes/evidence-runtime-quiescent-sourcefree')
TARGET=Path('/tmp/dandrum-lanes/cache-editor-guard')
TMP=E/'tmp'
HEAD='5d332b81adc07117e59f69a528785d194c8da3ff'
UPDATED=['src/trigger-host/src/runtime.rs','src/trigger-host/tests/runtime_quiescent.rs']
FLOORS={'disk_free_bytes':1024**3,'memory_available_bytes':4*1024**3}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(name,obj):(E/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def records(base):
 out={}
 for part in ('CMakeLists.txt','src','tests','examples','schema','scripts','spikes'):
  p=base/part
  if not p.exists():continue
  scan=[]
  if p.is_file():scan=[p]
  else:
   for parent,dirs,files in os.walk(p):
    dirs[:]=[d for d in dirs if d not in ('target','build','__pycache__')]
    scan.extend(Path(parent)/n for n in files)
  for q in scan:
   if q.is_symlink():raise RuntimeError(f'symlink input {q}')
   st=q.stat();out[str(q.relative_to(base))]={'sha256':sha(q),'mode':oct(stat.S_IMODE(st.st_mode)),'mtime_ns':st.st_mtime_ns,'bytes':st.st_size}
 return out
rootmap=json.loads((E/'root-before-map.json').read_text())
basefix=json.loads((E/'fixture-before-map.json').read_text())
unchanged=[k for k in basefix if k not in UPDATED]
results=[json.loads((E/'release-tests-run.json').read_text()),json.loads((E/'dependencies-run.json').read_text())]
removed=json.loads((E/'invocation.json').read_text())['removed_environment_variable_names']
log=(E/'release-tests.log').read_text(errors='replace');deps=(E/'dependencies.log').read_text(errors='replace')
sr=re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s')
sums=[]
for line in log.splitlines():
 m=sr.search(line)
 if m:sums.append({'status':m.group(1),'passed':int(m.group(2)),'failed':int(m.group(3)),'ignored':int(m.group(4)),'measured':int(m.group(5)),'filtered':int(m.group(6)),'elapsed_seconds':float(m.group(7)),'line':line})
assert len(sums)==12,sums
ordinary=sums[:-1];doc=sums[-1:]
assert sum(x['passed'] for x in ordinary)==128 and sum(x['passed'] for x in doc)==2,(ordinary,doc)
assert all(x['status']=='ok' and x['failed']==x['ignored']==x['measured']==x['filtered']==0 for x in sums),sums
executed=[];running={}
for line in log.splitlines():
 m=re.match(r'\s+Running `([^`]+)`\s*$',line)
 if not m:continue
 try:a=shlex.split(m.group(1))
 except ValueError:continue
 exe=next((x for x in a if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*=',x)),None)
 if not exe:continue
 p=Path(exe)
 if p.is_absolute() and p.parent==TARGET/'release/deps' and p.is_file() and os.access(p,os.X_OK) and p not in executed:executed.append(p);running[p]=line
compiler=[]
for line in log.splitlines():
 if 'Running `' not in line or 'rustc --crate-name' not in line:continue
 m=re.search(r'Running `([^`]+)`',line)
 try:a=shlex.split(m.group(1)) if m else []
 except ValueError:continue
 i=next((i for i,x in enumerate(a) if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*=',x)),None)
 if i is None or not a[i].endswith('/rustc') or '--test' not in a:continue
 try:crate=a[a.index('--crate-name')+1]
 except (ValueError,IndexError):continue
 extra=next((a[j+1] for j,x in enumerate(a[:-1]) if x=='-C' and a[j+1].startswith('extra-filename=')),None)
 compiler.append({'crate_name':crate,'extra_filename':extra,'argv':a,'raw_line':line})
bins=[]
for p in executed:
 stem=p.name;crate,ch=stem.rsplit('-',1);extra='extra-filename=-'+ch
 matches=[c for c in compiler if c['crate_name']==crate and c['extra_filename']==extra]
 compiler_binding=matches[-1] if matches else None
 d=p.with_name(stem+'.d');assert d.is_file();db=d.read_bytes()
 fdir=TARGET/'release/.fingerprint'/('dandrum-trigger-host-'+ch);assert fdir.is_dir()
 fps=[{'path':str(f),'name':f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in fdir.iterdir() if f.is_file()]
 bins.append({'path':str(p),'crate_name':crate,'crate_hash':ch,'bytes':p.stat().st_size,'sha256_after_dependency_audit':sha(p),'mtime_ns':p.stat().st_mtime_ns,'direct_cargo_running_line':running[p],'rustc_test_invocation':compiler_binding,'current_run_compiler_binding':('present' if compiler_binding else 'not emitted; Cargo reused an existing target artifact'),'dep_info':{'path':str(d),'bytes':len(db),'sha256':sha(d),'mentions_runtime_source':b'src/runtime.rs' in db,'mentions_runtime_test':b'tests/runtime_quiescent.rs' in db},'cargo_fingerprint_files':fps})
assert len(bins)==11,(len(bins),[p.name for p in executed])
assert any(b['crate_name']=='dandrum_trigger_host' and b['dep_info']['mentions_runtime_source'] for b in bins)
assert any(b['crate_name']=='runtime_quiescent' and b['dep_info']['mentions_runtime_test'] for b in bins)
flags=sorted(set(x for x in ('-C opt-level=3','-C linker-plugin-lto','-C codegen-units=1') if x in log));assert flags==['-C codegen-units=1','-C linker-plugin-lto','-C opt-level=3'],flags
normal=[line.split()[0] for line in deps.splitlines() if line.strip()];forbidden=[n for n in normal if any(x in n.lower() for x in ('clack','wry','gtk','webkit','juce'))];assert not forbidden,forbidden
rootafter=records(ROOT);fixafter=records(FIX);assert rootmap==rootafter and len(rootafter)==592 and len(fixafter)==592
assert set(rootafter)==set(fixafter) and all(rootafter[k]['sha256']==fixafter[k]['sha256'] for k in rootafter)
assert all(basefix[k]['sha256']==fixafter[k]['sha256'] and basefix[k]['mode']==fixafter[k]['mode'] and basefix[k]['mtime_ns']==fixafter[k]['mtime_ns'] for k in unchanged)
assert all(rootafter[k]['mode']==fixafter[k]['mode'] and rootafter[k]['mtime_ns']==fixafter[k]['mtime_ns'] for k in UPDATED)
assert not forbidden
write('root-after-map.json',rootafter);write('fixture-after-map.json',fixafter)
write('source-manifest.json',{k:v['sha256'] for k,v in rootafter.items()})
write('executed-artifact-bindings.json',{'actual_direct_test_executable_count':len(bins),'actual_direct_test_executables':bins,'ordinary_target_summaries':ordinary,'compile_fail_doctest_summaries':doc,'ordinary_test_total':sum(x['passed'] for x in ordinary),'doctest_total':sum(x['passed'] for x in doc),'actual_rustc_test_invocations':compiler,'executed_test_binary_compiler_binding_gaps':[b['path'] for b in bins if b['current_run_compiler_binding']!='present'],'profile_flags_seen_in_actual_rustc_commands':flags,'normal_dependency_names':normal,'forbidden_dependency_matches':forbidden})
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==HEAD
status=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True)
assert subprocess.run(['git','diff','--cached','--quiet'],cwd=ROOT).returncode==0
owned=[x['pgid'] for x in results];ps=subprocess.check_output(['ps','-eo','pid=,pgid=,args='],text=True).splitlines();survivors=[]
for line in ps:
 z=line.strip().split(None,2)
 if len(z)>=2 and z[1].isdigit() and int(z[1]) in owned:survivors.append(line)
assert not survivors,survivors
source={'head':head,'git_status':status,'staged_diff_empty':True,'root_inputs_before_after':len(rootmap),'fixture_inputs_before_after':[len(basefix),len(fixafter)],'root_full_map_before_after_equal':rootmap==rootafter,'root_full_map_sha256_before_after':hashlib.sha256((E/'root-before-map.json').read_bytes()).hexdigest(),'fixture_matches_root_all_bytes':all(rootafter[k]['sha256']==fixafter[k]['sha256'] for k in rootafter),'unchanged_fixture_inputs_byte_mode_mtime_proven':len(unchanged),'updated_fixture_inputs':UPDATED,'absent_fixture_trees':['web','ui','third_party'],'removed_inputs':[]}
write('source-verification.json',source)
receipt={'status':'PASS','scope':'Full unfiltered source-free default-release Rust host Cargo suite plus normal locked dependency-tree audit','head_source_binding':head,'source_manifest_sha256':sha(E/'source-manifest.json'),'root_inputs':len(rootafter),'fixture_inputs_before':len(basefix),'fixture_inputs_after':len(fixafter),'unchanged_fixture_inputs_byte_mode_mtime':len(unchanged),'updated_fixture_inputs':UPDATED,'ordinary_test_total':sum(x['passed'] for x in ordinary),'compile_fail_doctest_total':sum(x['passed'] for x in doc),'ordinary_and_doctest_summaries':sums,'all_failed_ignored_measured_filtered_counts_zero':True,'executed_test_binary_count':len(bins),'binary_inventory':'executed-artifact-bindings.json','cargo_test_command':results[0]['command'],'cargo_test_cwd':results[0]['cwd'],'cargo_test_exit':results[0]['exit'],'cargo_test_elapsed_seconds':results[0]['elapsed_seconds'],'cargo_tree_command':results[1]['command'],'cargo_tree_exit':results[1]['exit'],'cargo_tree_elapsed_seconds':results[1]['elapsed_seconds'],'effective_environment':results[0]['effective_environment'],'removed_profile_instrumentation_variable_names':sorted(removed),'release_profile':'Default release, opt-level 3, LTO enabled, codegen-units 1; incremental disabled; one build job; no instrumentation/profile override','actual_rustc_profile_flags':flags,'cache':'Existing /tmp/dandrum-lanes/cache-editor-guard; preserved without clean/delete/relocation','private_tmpdir':str(TMP),'tmp_target_same_filesystem':True,'resource_floors_bytes':FLOORS,'minimum_resources':results[0]['minimum_resources'],'final_resources':results[0]['final_resources'],'unused_build_output_volume':results[0]['final_resources']['unused_build_output_volume'],'forbidden_normal_dependency_matches':forbidden,'owned_process_groups':owned,'owned_process_survivors':survivors,'fixture_after_run_retained':True,'prior_success_evidence_untouched':True,'qualification':'Source-free Rust host tests and Rust normal-dependency audit only. No full CMake/native/CLAP/browser/beta/task-completion/publication claim.'}
write('receipt.json',receipt)
print(json.dumps({'status':'PASS','ordinary':receipt['ordinary_test_total'],'doctests':receipt['compile_fail_doctest_total'],'executed_binaries':len(bins),'minimum_resources':receipt['minimum_resources'],'forbidden_dependencies':forbidden,'owned_process_survivors':survivors},indent=2),flush=True)
