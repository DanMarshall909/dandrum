use dandrum_instrument_session::SessionSnapshot;
use dandrum_trigger_host::TriggerHostConfiguration;
use dandrum_trigger_host::runtime::{
    ControlEvent, PreparedRuntime, QuiescentReport, RuntimeAudio, RuntimeControl, RuntimeError,
    TimedEvent, runtime_handoff,
};

#[path = "support/editor_notes.rs"]
mod fixture;
use fixture::*;

fn publish_pan(
    fixture: &mut Fixture,
    control: &mut RuntimeControl,
    from: f32,
    to: f32,
) -> SessionSnapshot {
    let yaml = fixture
        .session
        .owner_snapshot()
        .yaml
        .replace(&format!("pan: {from}"), &format!("pan: {to}"));
    let candidate = fixture
        .session
        .prepare_document_replacement_owned(&yaml)
        .unwrap();
    fixture
        .session
        .commit_document_replacement(candidate, control)
        .unwrap()
}

fn render(audio: &mut RuntimeAudio, note: u8, swapped: bool) -> ([f32; FRAMES], [f32; FRAMES]) {
    let (mut left, mut right) = ([1.0; FRAMES], [1.0; FRAMES]);
    let measured = allocation_counter::measure(|| {
        let report = audio
            .process_events(
                &mut left,
                &mut right,
                &[TimedEvent {
                    frame_offset: 3,
                    event: ControlEvent::NoteOn {
                        note,
                        velocity: 100,
                    },
                }],
            )
            .unwrap();
        assert_eq!(report.swapped, swapped);
    });
    assert_eq!(
        (
            measured.count_total,
            measured.count_current,
            measured.bytes_current
        ),
        (0, 0, 0),
        "real callback neither allocates nor destroys an owner"
    );
    (left, right)
}

// Expected gains are explicit fixture expectations, independent of the DSP.
fn assert_sample(output: &([f32; FRAMES], [f32; FRAMES]), left_gain: f32, right_gain: f32) {
    for (plane, gain) in [(&output.0, left_gain), (&output.1, right_gain)] {
        assert_eq!(&plane[..3], &[0.0; 3]);
        assert_eq!(&plane[3..7], &PREFIX_L.map(|value| value * gain));
        assert_eq!(&plane[7..], &[TAIL.0 * gain; 9]);
    }
}

#[test]
fn quiescent_adoption_destroys_the_predecessor_and_restores_capacity_without_a_render() {
    for second_publication in [false, true] {
        let mut fixture = Fixture::new("gated", 4);
        let (mut control, mut audio) = fixture.runtime(4);
        let accepted = publish_pan(&mut fixture, &mut control, -0.5, 0.5);
        let measured = allocation_counter::measure(|| {
            assert_eq!(
                control.service_quiescent(&mut audio),
                Ok(QuiescentReport {
                    adopted: true,
                    reclaimed_runtimes: 1
                })
            );
        });
        assert_eq!(measured.count_total, 0);
        assert!(
            measured.count_current < 0 && measured.bytes_current < 0,
            "the calling control thread destroys the replaced graph"
        );
        assert_eq!(
            fixture.session.owner_snapshot(),
            accepted,
            "servicing an accepted graph is not a new session publication"
        );
        assert!(
            control.reclaim().is_none(),
            "no artificial retirement awaits audio"
        );
        for _ in 0..3 {
            assert_eq!(
                control.service_quiescent(&mut audio),
                Ok(QuiescentReport::default())
            );
        }
        if second_publication {
            // A second actual publication succeeds without any intervening process.
            let second = publish_pan(&mut fixture, &mut control, 0.5, 0.25);
            assert_eq!(second.revision, accepted.revision + 1);
            assert_eq!(
                control.service_quiescent(&mut audio),
                Ok(QuiescentReport {
                    adopted: true,
                    reclaimed_runtimes: 1
                })
            );
        }
        let output = render(&mut audio, 60, false);
        assert_sample(&output, if second_publication { 0.75 } else { 0.5 }, 1.0);
    }
}

#[test]
fn foreign_quiescent_pair_is_rejected_before_either_nontrivial_instance_changes() {
    let mut a = Fixture::new("gated", 4);
    let mut b = Fixture::new("gated", 4);
    let (mut a_control, mut a_audio) = a.runtime(4);
    let (mut b_control, mut b_audio) = b.runtime(4);
    for output in [
        render(&mut a_audio, 60, false),
        render(&mut b_audio, 61, false),
    ] {
        assert_eq!(&output.0[3..7], &PREFIX_L);
        assert_eq!(&output.1[3..7], &PREFIX_R);
    }
    let a_accepted = publish_pan(&mut a, &mut a_control, -0.5, 0.5);
    let b_accepted = publish_pan(&mut b, &mut b_control, -0.5, -0.75);
    let rejected = allocation_counter::measure(|| {
        assert_eq!(
            a_control.service_quiescent(&mut b_audio),
            Err(RuntimeError::ForeignEndpoints)
        );
        assert_eq!(
            b_control.service_quiescent(&mut a_audio),
            Err(RuntimeError::ForeignEndpoints)
        );
    });
    assert_eq!(
        (
            rejected.count_total,
            rejected.count_current,
            rejected.bytes_current
        ),
        (0, 0, 0),
        "rejection neither allocates nor consumes an endpoint's owners"
    );
    assert_eq!(a.session.owner_snapshot(), a_accepted);
    assert_eq!(b.session.owner_snapshot(), b_accepted);
    assert!(
        a_control.offer(a.prepared()).is_err(),
        "A still has its accepted pending runtime"
    );
    assert!(
        b_control.offer(b.prepared()).is_err(),
        "B still has its accepted pending runtime"
    );
    let a_output = render(&mut a_audio, 62, true);
    assert_sample(&a_output, 0.5, 1.0);
    let b_output = render(&mut b_audio, 63, true);
    assert_sample(&b_output, 1.0, 0.25);
}
