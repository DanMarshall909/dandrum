import pathlib,tarfile,json,hashlib,subprocess,shlex,collections,shutil
root=pathlib.Path('/tmp/dandrum-lanes/runtime');base=pathlib.Path('/tmp/dandrum-lanes/evidence-runtime-quiescent');out=base/'07-profile-proof'
archive=base/'05-full-coverage/result-profiles.tar.gz'; profiles=out/'profiles';profiles.mkdir()
with tarfile.open(archive) as tf:
 for member in tf.getmembers():
  assert pathlib.Path(member.name).name==member.name
  (profiles/member.name).write_bytes(tf.extractfile(member).read())
original=pathlib.Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/trigger-host-profraw-list').read_text();(out/'profile-list-original.txt').write_text(original)
raws=[profiles/pathlib.Path(line).name for line in original.splitlines()];assert all(p.exists() for p in raws)
(out/'profile-list.txt').write_text(''.join(str(p)+'\n' for p in raws))
llvm=pathlib.Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin')
merge=[str(llvm/'llvm-profdata'),'merge','-sparse','-f',str(out/'profile-list.txt'),'-o',str(out/'remerged.profdata')]
subprocess.run(merge,check=True,capture_output=True)
assert (out/'remerged.profdata').read_bytes()==(profiles/'trigger-host.profdata').read_bytes()
log=(base/'05-json-report/output.log').read_text();line=next(x for x in log.splitlines() if 'llvm-cov export' in x)
command=shlex.split(line.split('`')[1]);objects=[pathlib.Path(command[i+1]) for i,x in enumerate(command) if x=='-object']
recorded=json.loads((base/'05-full-coverage/binary-hashes.json').read_text())
assert len(objects)==10 and all(hashlib.sha256(p.read_bytes()).hexdigest()==recorded[str(p)]['sha256'] for p in objects)
command=[('-instr-profile='+str(out/'remerged.profdata')) if x.startswith('-instr-profile=') else x for x in command]
result=subprocess.run(command,check=True,capture_output=True);(out/'direct-export.json').write_bytes(result.stdout);(out/'direct-export.stderr').write_bytes(result.stderr)
actual=json.loads(result.stdout);expected=json.loads((base/'05-json-report/host.json').read_text())
def normalize(x):
 if isinstance(x,dict):return {k:normalize(v) for k,v in x.items() if k not in ('percent','cargo_llvm_cov')}
 if isinstance(x,list):return [normalize(v) for v in x]
 return x
assert normalize(actual)==normalize(expected)
fp=out/'fingerprints'
for d in pathlib.Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/debug/.fingerprint').glob('dandrum-trigger-host-*'):
 for p in d.iterdir():
  if p.is_file():
   dest=fp/d.name/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
proof=dict(archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),raw_count=len(raws),raw_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in raws},merge_command=merge,merged_byte_identical=True,profile_sha256=hashlib.sha256((out/'remerged.profdata').read_bytes()).hexdigest(),objects={str(p):recorded[str(p)] for p in objects},export_command=command,export_semantics='All paths, source segments, function records, regions, counters and integer summaries exact. Percentage presentation and cargo_llvm_cov metadata excluded from semantic comparison.',source_binding=json.loads((base/'05-full-coverage/receipt.json').read_text())['source_hashes'])
(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:proof[k] for k in ('raw_count','merged_byte_identical','profile_sha256','export_semantics')}))
