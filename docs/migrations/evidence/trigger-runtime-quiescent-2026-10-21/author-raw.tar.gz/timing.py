import pathlib,subprocess,time,statistics,hashlib,json,re
root=pathlib.Path('/tmp/dandrum-lanes/runtime');out=pathlib.Path('/tmp/dandrum-lanes/evidence-runtime-quiescent/06-timings')
binary=pathlib.Path('/tmp/dandrum-lanes/cache-runtime/debug/deps/runtime_quiescent-112221cf9b848dc8')
names=re.findall(r'#\[test\]\nfn (\w+)',(root/'src/trigger-host/tests/runtime_quiescent.rs').read_text())
listed=subprocess.run([str(binary),'--list'],capture_output=True,text=True,check=True)
(out/'inventory.log').write_text(listed.stdout)
assert set(names)==set(re.findall(r'^(\w+): test$',listed.stdout,re.M))
records=[]
for repeat in range(3):
 for name in names:
  cmd=[str(binary),'--exact',name,'--nocapture'];start=time.monotonic()
  result=subprocess.run(cmd,cwd=root,capture_output=True,text=True)
  duration=time.monotonic()-start
  (out/f'{repeat}-{name}.log').write_text(result.stdout+result.stderr)
  records.append(dict(repeat=repeat,test=name,command=cmd,exit=result.returncode,duration_seconds=duration))
  if result.returncode:raise SystemExit(result.returncode)
medians={name:statistics.median(r['duration_seconds'] for r in records if r['test']==name) for name in names}
peer=statistics.median(medians.values());candidates={name:duration for name,duration in medians.items() if duration>peer*1.5}
evidence=dict(binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),cwd=str(root),records=records,medians=medians,peer_median=peer,candidates=candidates,disposition='All7 tests remain in existing trigger-host-fast lane; slow selection for this test owner is empty. Candidate review is required, not automatic reassignment; all medians remain substantially under one second.')
(out/'timings.json').write_text(json.dumps(evidence,indent=2)+'\n');print(json.dumps({k:evidence[k] for k in ('medians','peer_median','candidates')}))
