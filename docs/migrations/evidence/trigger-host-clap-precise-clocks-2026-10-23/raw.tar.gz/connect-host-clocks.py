from pathlib import Path
import re
root=Path('/tmp/dandrum-lanes/integration')
p=root/'src/trigger-host/tests/precise_runtime.rs';s=p.read_text().replace('    reset: bool,\n) ->','    reset: bool,\n    frames: usize,\n) ->').replace('callback(&mut audio, left, right, note, swapped);','callback(&mut audio, &mut left[..frames], &mut right[..frames], note, swapped);');s=s.replace('Some(36), false, false);','Some(36), false, false, BLOCK);').replace('Some(72), true, false);','Some(72), true, false, 1);').replace('None, false, true);','None, false, true, BLOCK);').replace('None, false, false);','None, false, false, BLOCK);');p.write_text(s)
# A validated rate cannot express the old zero-valued struct literal. Raw input
# rejection remains in engine admission and actual CLAP configuration tests.
p=root/'src/trigger-host/tests/runtime.rs';s=p.read_text();zero='''        TriggerHostConfiguration {
            sample_rate_hz: 0,
            max_block_frames: 16,
        },
''';assert s.count(zero)==1;s=s.replace(zero,'');p.write_text(s)
p=root/'src/trigger-host/tests/render_reconfiguration.rs';s=p.read_text();assert '        configuration(0, 16),\n' in s;s=s.replace('        configuration(0, 16),\n','');s=s.replace('fn configuration(rate: u32,','fn configuration(rate: f64,');s=re.sub(r'configuration\(([\d_]+),',r'configuration(\1.0,',s);p.write_text(s)
# Migrate known struct literals only; integer engine DTOs remain untouched.
paths=[*list((root/'src/trigger-host').rglob('*.rs')),root/'src/clap-adapter/src/trigger.rs',root/'src/clap-adapter/tests/internal/trigger_gui_dispatch.rs']
for p in paths:
 if p.name=='precise_runtime.rs':continue
 s=p.read_text()
 def literal(m):
  body=m[0]
  def field(f):
   value=f[1].strip()
   if 'SampleRate' in value:return f[0]
   if p.name=='render_reconfiguration.rs' and value=='rate':value='rate'
   elif value=='config.sample_rate as u32':value='config.sample_rate'
   else:value='f64::from('+value+')'
   return 'sample_rate_hz: dandrum_engine::render_settings::SampleRate::new('+value+').unwrap(),'
  return re.sub(r'(?m)(?<=\s)sample_rate_hz:\s*([^,\n]+),',field,body)
 s=re.sub(r'\bTriggerHostConfiguration\s*\{[^{}]*\}',literal,s)
 p.write_text(s)
p=root/'src/trigger-host/src/lib.rs';s=p.read_text();s=s.replace('use dandrum_engine::patch::RenderSettings;','use dandrum_engine::render_settings::RealtimeRenderSettings;\npub use dandrum_engine::render_settings::SampleRate;');s=s.replace('pub sample_rate_hz: u32,','pub sample_rate_hz: SampleRate,');s=s.replace('let settings = RenderSettings {','let settings = RealtimeRenderSettings {').replace('PreparationContext::new(resources.instrument_root(), configuration.sample_rate_hz)','PreparationContext::new_realtime(resources.instrument_root(), configuration.sample_rate_hz)').replace('InstrumentSession::new_for_planar_host(resources.document(), context, settings, buses)?','InstrumentSession::new_realtime_for_planar_host(resources.document(), context, settings, buses)?');p.write_text(s)
p=root/'src/trigger-host/src/runtime.rs';s=p.read_text();s=s.replace('''        if configuration.sample_rate_hz == 0
            || !(1..=MAX_BLOCK_FRAMES).contains(&configuration.max_block_frames)''','''        if !(1..=MAX_BLOCK_FRAMES).contains(&configuration.max_block_frames)''');s=s.replace('''                .sample_rate_hz
                .hz()
                != f64::from(configuration.sample_rate_hz)''','''                .sample_rate_hz
                != configuration.sample_rate_hz''').replace('configuration.sample_rate_hz as f32','configuration.sample_rate_hz.hz() as f32');p.write_text(s)
p=root/'src/trigger-host/src/parameters.rs';s=p.read_text();s=s.replace('''        if configuration.sample_rate_hz == 0
            || !(1..=crate::runtime::MAX_BLOCK_FRAMES).contains(&configuration.max_block_frames)''','''        if !(1..=crate::runtime::MAX_BLOCK_FRAMES).contains(&configuration.max_block_frames)''');s=s.replace('use dandrum_engine::patch::RenderSettings;','use dandrum_engine::render_settings::RealtimeRenderSettings;').replace('let settings = RenderSettings {','let settings = RealtimeRenderSettings {').replace('.prepare_render_configuration_owned(settings, buses)','.prepare_realtime_render_configuration_owned(settings, buses)');p.write_text(s)
p=root/'src/trigger-host/tests/runtime.rs';s=p.read_text();start=s.index('fn planar_session_at(');end=s.index('\n#[test]',start);block=s[start:end].replace('InstrumentSession::new_for_planar_host(','InstrumentSession::new_realtime_for_planar_host(').replace('PreparationContext::new(','PreparationContext::new_realtime(').replace('        RenderSettings {','        dandrum_engine::render_settings::RealtimeRenderSettings {');s=s[:start]+block+s[end:];p.write_text(s)
