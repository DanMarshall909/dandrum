from pathlib import Path
import subprocess,os,json,time,hashlib,shutil,tarfile,sys
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;cache=Path('/tmp/dandrum-lanes/cache-editor-guard');env=dict(os.environ,CARGO_TARGET_DIR=str(cache),CARGO_BUILD_JOBS='1');rows=[];cargo='/home/dan/.cargo/bin/cargo';manifest='src/clap-adapter/Cargo.toml';profiles=out/'adapter-clock-profiles';profiles.mkdir();env['LLVM_PROFILE_FILE']=str(profiles/'clock-%m-%p.profraw')
def run(label,argv,extra=None,capture=False):
 started=time.monotonic();p=subprocess.run(argv,cwd=root,env=dict(env,**(extra or {})),stdout=subprocess.PIPE if capture else None);rows.append({'label':label,'command':argv,'exit':p.returncode,'seconds':time.monotonic()-started});(out/'adapter-clock-phases.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0,label
 if capture:(out/(label+'.stdout')).write_bytes(p.stdout)
 return p.stdout.decode() if capture else ''
text=run('instrumented-native-release',[cargo,'rustc','--offline','--locked','--release','--jobs','1','--manifest-path',manifest,'--features','trigger-editor','--lib','--message-format=json','--','-C','instrument-coverage'],capture=True)
records=[json.loads(l) for l in text.splitlines() if l.startswith('{')];products=[Path(n) for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='dandrum_clap_adapter' for n in r.get('filenames',[]) if n.endswith('.so')];assert len(products)==1
stage=Path(os.environ['TMPDIR'])/'instrumented-native';stage.mkdir()
# Reuse the exact freshly rebuilt production bundle and packaged resources.
with tarfile.open(out/'native-release-product.tar.gz') as t:
 for m in t:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  p=stage/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
product=stage/'DandrumTrigger.clap';shutil.copy2(products[0],product)
# Retain only the instrumented DSO as an external replay object, never in Git.
obj=out/'adapter-clock-instrumented.so';shutil.copy2(product,obj)
run('native-fast-owner',[cargo,'test','--offline','--locked','--release','--jobs','1','--manifest-path',manifest,'--features','trigger-editor','--lib','--','--test-threads=1'])
text=run('compile-release-dynamic',[cargo,'test','--offline','--locked','--release','--jobs','1','--manifest-path',manifest,'--features','trigger','--test','trigger_dynamic','--no-run','--message-format=json'],capture=True)
records=[json.loads(l) for l in text.splitlines() if l.startswith('{')];tests=[Path(r['executable']) for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='trigger_dynamic' and r.get('executable')];assert len(tests)==1
run('native-product-dynamic',[str(tests[0]),'--test-threads=1','--nocapture'],{'DANDRUM_TRIGGER_CLAP_PLUGIN_PATH':str(product)})
sysroot=Path(subprocess.check_output(['/home/dan/.cargo/bin/rustc','--print','sysroot'],text=True).strip());tools=sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/bin';raw=sorted(profiles.glob('*.profraw'));assert raw
run('merge-adapter-clock',[str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in raw],'-o',str(out/'adapter-clock.profdata')])
args=[str(obj),'--instr-profile',str(out/'adapter-clock.profdata'),str(root/'src/clap-adapter/src/trigger.rs')]
run('adapter-clock-export',[str(tools/'llvm-cov'),'export',*args],capture=True);run('adapter-clock-annotation',[str(tools/'llvm-cov'),'show',*args,'--show-line-counts-or-regions'],capture=True)
(out/'adapter-clock-binding.json').write_text(json.dumps({'object':str(obj),'sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'profiles':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in raw},'merged_sha256':hashlib.sha256((out/'adapter-clock.profdata').read_bytes()).hexdigest(),'scope':'Fresh GUI-enabled CLAP release cdylib local-crate instrumentation. Current fast owner and all dynamic cases; dependencies not instrumented here. Not new native input/X11 lifecycle or named-DAW acceptance.'},indent=2)+'\n')
