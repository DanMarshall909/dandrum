from pathlib import Path
import subprocess,json,sys,hashlib,re,time,statistics,os
out=Path(__file__).parent;root=Path('/tmp/dandrum-lanes/integration');checks=[]
os.environ['PATH']='/home/dan/.nvm/versions/node/v22.19.0/bin:'+os.environ['PATH']
for name,args in [('selected',['openspec','validate','add-juce-free-trigger-beta-products','--strict']),('canonical',['openspec','validate','--specs','--strict']),('spec-map',['scripts/check-spec-coverage']),('diff-check',['git','diff','--check']),('staged-check',['git','diff','--cached','--check'])]:
 start=time.monotonic();p=subprocess.run(args,cwd=root,capture_output=True);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);checks.append({'command':args,'exit':p.returncode,'seconds':time.monotonic()-start});(out/'spec-checks.json').write_text(json.dumps(checks,indent=2)+'\n');assert p.returncode==0,name
# Comparable ordinary tests re-drive the same contract in a fresh test process.
paths=[('precise_runtime',out/'green-precise-runtime-corrected-run/stderr.log'),('render_reconfiguration',out/'precise-controller-undo-state-run/stderr.log')];cases={'precise_runtime':['fractional_runtime_swaps_reclaim_on_control_and_preserve_reset_and_another_instance','runtime_rejects_a_different_clock_even_below_f32_precision'],'render_reconfiguration':['fractional_reconfiguration_keeps_exact_identity_values_history_and_failure_rollback']};bindings={};attempts=[]
for target,log in paths:
 matches=re.findall(r'Running tests/[^\n]*\(([^\n]+/deps/'+target+r'-[0-9a-f]+)\)',log.read_text());assert len(matches)==1,(target,matches);binary=Path(matches[0]);bindings[target]={'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
 for repeat in range(3):
  for case in cases[target]:
   args=[str(binary),'--exact',case,'--test-threads=1'];start=time.monotonic();p=subprocess.run(args,cwd=root,capture_output=True);assert p.returncode==0,(case,p.stdout,p.stderr);attempts.append({'target':target,'repeat':repeat,'case':case,'command':args,'seconds':time.monotonic()-start,'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
(out/'new-host-test-timings.json').write_text(json.dumps({'bindings':bindings,'attempts':attempts,'medians':{case:statistics.median(a['seconds'] for a in attempts if a['case']==case) for cases_ in cases.values() for case in cases_},'lanes':'New owner cases remain fast. Full dynamic CLAP is the existing separate boundary lane; no native/input/DAW claim or lane change.'},indent=2)+'\n')
print('Final spec/map/timing checks PASS')
