# Independent completion review: precise persistent session clocks

**Verdict: FAIL.** The frozen source is coherent and current numerical tests pass, but required executable behavioral RED evidence is absent. One correction remains; this is not publication approval.

Manifest SHA-256: `5d29512738574201850918aed795f8b647c3f026c1c123f790ff6a8daea8ae0e`. Base/current/intended upstream/integration base: `35137fa64659eed41fcf4e53c746fb9b09a0c4c0`. Independently reconstructed index tree: `9c4b6beda5187d8ac0ab613b23f769222582a779`. Branch: `lane/trigger-integration-20261020`; intended upstream: `refs/remotes/origin/feat/juce-free-host-adapters`; no configured branch upstream. Review is limited to this eight-path candidate and its proposed envelope.

## Required correction F1 — executable behavioral RED

**Owners:** `src/instrument-session/tests/precise_clocks.rs`, the extended `fractional_clocks_keep_signed_cursor_and_duration_for_each_sample_player` test, and the candidate's retained TDD evidence for tasks 2.1/2.2.

**Requirement:** shared rules require the behavior-first TDD workflow. `/home/dan/.agents/skills/behavior-first-tdd/SKILL.md`, workflow step 2, says: “Run it and confirm RED is the expected missing behaviour, not invalid setup, compilation, spelling, or an unrelated failure.” The completion-review reference requires genuine RED where the workflow requires it. The project also requires a failing behavior test before implementation.

**Evidence:** `red-precise-session-api-corrected-run/stderr.log` is E0599 for an absent constructor; `red-planar-clock-api-run/stderr.log` is E0432 for an absent preparation API; `red-precise-reconfiguration-api-run/stderr.log` is E0599 for an absent method. The initial session run additionally has an incorrect test import. No numerical or state-transition assertion executes in those runs. The zero/BUSY case characterizes behavior already present. README/binding/manifest disclose these facts accurately, but disclosure does not waive the requirement. Root explicitly confirmed no waiver exists.

**Consequence:** strong GREEN and coverage evidence establish current behavior, but do not complete the required workflow for publishing this material boundary. No production defect is asserted by this finding.

**Required outcome:** retain the historical gap without relabeling it. Root has identified the existing CLAP f64 activation boundary, which still rejects the supported fractional clock, as the next authorized observable seam: specify and run executable fractional activation and independently expected signed-timing RED before changing TriggerHost/controller/CLAP; carry this staged foundation into that coherent clock boundary, perform proportionate GREEN/coverage/refactor verification, rebuild the complete candidate/evidence/envelope and obtain a fresh review covering the enlarged scope. This report does not authorize posthoc numeric faults or mutation jobs. Those are explicitly excluded. No publication under this manifest.

## Task → implementation matrix

| Task/scope | Implementation reviewed | Status justified |
|---|---|---|
| 2.1 precise configuration/preparation, partial foundation | New precise planar wrapper delegates to existing validated realtime graph preparation; existing three-owner/four-rate table now covers both APIs | Component implemented and GREEN; task remains unchecked because real fractional runtime/handoff/reclamation proof is outside this slice |
| 2.2 persistent session/reconfiguration, partial foundation | Session, prepared render candidates and owned mapping jobs use the common realtime settings; precise constructor/reconfiguration and integer adapters | Component implemented and GREEN; task remains unchecked; controller/CLAP/official-case acceptance absent |
| Integer/C ABI compatibility | Existing integer constructors and reconfiguration signatures retained; actual TriggerHost/native-FFI callers adapt through them | Retained tests and owner runs support compatibility; no invented historical migration layer |
| First CLAP beta / other products | No completion checkbox or canonical scenario changes | Beta remains open; VST3/standalone deferred; no native, DAW or release acceptance claimed |

## Criterion → test matrix

| Observable criterion | Executable evidence and assertion | Limit |
|---|---|---|
| Planar preparation retains exact fractional clocks and sample timing | `fractional_clocks_keep_signed_cursor_and_duration_for_each_sample_player`: sample_player, sample_slicer, sample_map_player × 48000, 1234.5678, 48000.5, 48000.000001 × two preparation paths; exact configuration/source rate, literal -0.75 start, analytic complete waveform and final sounding/first silent frames | Existing engine owner, not CLAP activation; API-only RED is F1 |
| Detached work/history retain session clock | `detached_mapping_jobs_and_undo_keep_the_exact_session_clock`: worker-thread owned job after detach, recovered accepted snapshot, new editor undo, signed old/new-note playback at three fractional rates | Joined worker proves transferable ownership and domain result, not concurrent callback safety |
| Reconfiguration preserves history, rollback and independence | `precise_reconfiguration_preserves_history_rollback_and_another_session`: rejection leaves snapshot/old signed audio; success retains history and supports undo/redo at the new clock; another 44100 Hz session remains unchanged | Accept/reject stand-ins prove domain success/failure only, not actual runtime publication/reclamation |
| Invalid integer clock and BUSY preserve usability | `invalid_legacy_clock_and_busy_precise_preparation_preserve_the_session`: zero constructor/reconfiguration rejection, BUSY precedence, unchanged signed output, later successful mapping | Characterization, not new-behavior RED |
| Existing preparation failure and integer callers remain protected | Existing render_configuration tests cover pending job rejection, missing sample preparation and commit while busy, with known -0.5 output; complete session/host owner suites retained | No fractional controller/CLAP inference |
| Full delta scenarios: fractional host case, failed configuration, native lifecycle, state/resources, callbacks, DAW, offline installation | This slice supplies only component evidence for the first two and history/ownership supporting behavior | No complete delta scenario is newly closed or synchronized; official CLAP 33 success/10 skip/1 failure remains unwaived |

## Evidence and test effectiveness

Independently verified all eight paths' status/mode/content/staged blobs, current/upstream/base/merge-base, and the complete index tree without index writes. All 369 raw archive members match hashes/sizes/order; all 25 source replay phases reconstruct exactly against base/content-addressed blobs and external archive hashes (3725 file instances). Eight final owner/test/lint/coverage run receipts bind current source bytes, stdout/stderr, 8 GiB resource floors and terminal cleanup. The lint multiset independently reconstructs 323 old versus 330 current occurrences: no new identity, 316 unchanged library/test occurrences, seven unchanged stepseq identities emitted twice by the broader target selection. Strict engine Clippy remains FAIL129, not waived or suppressed.

Retained results: session 36, engine 1090 unit / 1097 total positive cases, host 159 PASS; strict session/host Clippy PASS. All 49 annotated added production lines execute. Session lib has 69/69 functions, 702/706 lines and 856/863 regions; this is not complete line/region/branch/concurrency coverage. No fresh pre-edit session-owner LLVM run is evidenced. Adjacent tests and prior coverage exist; the current owner measurement is accurately limited. No newly extracted production module needs a separate 100% gate.

Reviewer independently ran only the existing ordinary binary SHA-256 `5c5334e7535da94eeff1d9258f800a2bb3d9f2cfa05bad660113dac19f445f17`, through the frozen owned supervisor: **3/3 PASS in 0.10s**, all children reaped and exact scratch removed. No Cargo/build/native/mutation job was started. Receipts are under `independent-binary-run/`.

Tests protect actual signed sample output and distinguish rate truncation even below f32 precision through duration/cutoff. Public API assertions resist internal refactoring. Three cases have distinct ownership, reconfiguration and rejection responsibilities; fixture extraction keeps them readable. Comparable sub-0.1s timings justify the fast lane. Returning a no-op lease does not calibrate real runtime callbacks, but the report correctly claims only domain acceptance/rejection and retains host tests separately.

## Architecture, alternatives and publication

One validated clock representation owns accepted/candidate/job settings. Legacy integer/C ABI adapters have real callers. Context/settings must agree exactly; preparation remains off-audio. Commit validates busy/owner/revision, activates before replacing accepted state, then updates context/settings/buses and publishes. Rejection precedes accepted mutation. No plugin/editor dependency, new DSP primitive, serialization authority, resource authority or security boundary is introduced.

An optional floating clock beside integer settings would introduce competing identities. Replacing integer APIs outright would churn active host/FFI callers. The common settings owner with thin adapters is the simpler in-scope choice; further generic abstraction is unwarranted. The small wrapper duplication preserves the established preparation entrypoint structure.

Publication scripts and tracker template hashes/current tracker preimage match the manifest. Normal hooks are installed (`.githooks`): pre-commit strict coverage and pre-push ordinary Rust tests plus the explicit mutation exclusion. The finite envelope names validations, unchanged-upstream fetch, exact tree commit/non-force push, four existing fast-forwards, tracker compare-and-append and retained final archive. It makes no post-PASS source/test/task transformation. These checks remain required if a future candidate passes; they were not executed as publication here. All four lane preimages match; main is clean at `68dd6553a2f07e71e2fe09ee1d7094d518559937`; all 1766 preserved Runtime cache entries match their baseline. No publication-envelope defect was found, but F1 prevents using it now.

## Lessons and handback

Candidate lesson: at a new typed API boundary, keep compiler-contract failure distinct from behavioral RED and select an existing observable seam before implementation when the workflow excludes compilation RED. Evidence is F1; proposed owner is this project's behavior-first review/planning practice. Existing shared guidance already states the rule, so no duplicate standing-rule change is proposed. Cost: a larger coherent boundary may require more host proof; disposition: apply in the authorized repair, preserve the historical gap.

All repository/Git/tracker/cache read leases and the sole authorized binary job lease are returned. No workers remain; owned scratch cleanup is verified. Source/index/tracker/build caches were not mutated; only review-owned evidence/report files were written. Root may release the freeze after handback and perform the authorized repair. Compact verification details: `independent-integrity.json`, `independent-evidence-checks.json` and `independent-binary-run/`.
