from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,sys
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;cargo='/home/dan/.cargo/bin/cargo';manifest='src/clap-adapter/Cargo.toml';phases=[]
def run(argv,env=None):
 start=time.monotonic();p=subprocess.run(argv,cwd=root,env=env);phases.append({'command':argv,'exit':p.returncode,'seconds':time.monotonic()-start});(out/'green-phases.json').write_text(json.dumps(phases,indent=2)+'\n');return p.returncode
code=run([cargo,'build','--offline','--locked','--jobs','1','--manifest-path',manifest,'--features','trigger','--lib']);assert code==0,'Build/setup failure, not behavioral RED'
source=Path(os.environ['CARGO_TARGET_DIR'])/'debug/libdandrum_clap_adapter.so';stage=Path(os.environ['TMPDIR'])/'clap-product';stage.mkdir();plugin=stage/'DandrumTrigger.clap';shutil.copy2(source,plugin);resources=stage/'DandrumTrigger.resources/instrument';(resources/'assets').mkdir(parents=True)
for source_name,target_name in [('examples/patches/advanced-drum-kit.yaml','advanced-drum-kit.yaml'),('examples/patches/assets/advanced-drums.wav','assets/advanced-drums.wav')]:shutil.copyfile(root/source_name,resources/target_name)
(out/'green-product-binding.json').write_text(json.dumps({'source_library':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'features':'trigger, headless real dynamic CLAP boundary; no GUI/native acceptance claim','files':{str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in stage.rglob('*') if p.is_file()}},indent=2)+'\n')
env=dict(os.environ,DANDRUM_TRIGGER_CLAP_PLUGIN_PATH=str(plugin));code=run([cargo,'test','--offline','--locked','--jobs','1','--manifest-path',manifest,'--features','trigger','--test','trigger_dynamic','supported_fractional_clocks_activate_and_keep_exact_signed_sample_timing','--','--exact','--test-threads=1','--nocapture'],env=env);sys.exit(code)
