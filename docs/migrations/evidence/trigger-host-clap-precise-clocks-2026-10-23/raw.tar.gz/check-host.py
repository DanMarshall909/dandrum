from pathlib import Path
import subprocess,sys,json
out=Path(__file__).parent;root=Path('/tmp/dandrum-lanes/integration');cargo='/home/dan/.cargo/bin/cargo';checks=[]
for label,mode,args in [
 ('host-owner-green','ordinary',[cargo,'test','--offline','--locked','--manifest-path','src/trigger-host/Cargo.toml']),
 ('host-precise-coverage','coverage',[cargo,'llvm-cov','test','--offline','--locked','--manifest-path','src/trigger-host/Cargo.toml','--json','--output-path',str(out/'host-precise-coverage-export.json')]),
 ('host-precise-annotation','coverage',[cargo,'llvm-cov','report','--manifest-path','src/trigger-host/Cargo.toml','--text','--output-path',str(out/'host-precise-annotated.txt')]),
 ('host-precise-clippy','ordinary',[cargo,'clippy','--offline','--locked','--manifest-path','src/trigger-host/Cargo.toml','--all-targets','--no-deps','--','-D','warnings'])]:
 p=subprocess.run([sys.executable,str(out/'run-check.py'),label,mode,*args],cwd=root);checks.append({'phase':label,'exit':p.returncode});(out/'host-checks.json').write_text(json.dumps(checks,indent=2)+'\n');assert p.returncode==0,label
subprocess.run([sys.executable,str(out/'preserve-profiles.py'),'host-precise'],check=True)
