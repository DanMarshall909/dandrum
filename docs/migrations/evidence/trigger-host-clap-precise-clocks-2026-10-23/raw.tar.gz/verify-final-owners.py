from pathlib import Path
import subprocess,sys,json
out=Path(__file__).parent;cargo='/home/dan/.cargo/bin/cargo';rows=[]
phases=[
 ('final-format','ordinary',[cargo,'fmt','--manifest-path','src/clap-adapter/Cargo.toml','--all','--','--check']),
 ('final-host-clippy','ordinary',[cargo,'clippy','--offline','--locked','--manifest-path','src/trigger-host/Cargo.toml','--all-targets','--no-deps','--','-D','warnings']),
 ('final-clap-clippy','ordinary',[cargo,'clippy','--offline','--locked','--manifest-path','src/clap-adapter/Cargo.toml','--features','trigger-editor','--all-targets','--no-deps','--','-D','warnings']),
 ('final-host-owner-coverage','coverage',[cargo,'llvm-cov','test','--offline','--locked','--manifest-path','src/trigger-host/Cargo.toml','--json','--output-path',str(out/'final-host-owner-export.json')]),
 ('final-host-owner-annotation','coverage',[cargo,'llvm-cov','report','--manifest-path','src/trigger-host/Cargo.toml','--text','--output-path',str(out/'final-host-owner-annotated.txt')]),
]
for label,mode,argv in phases:
 code=subprocess.call([sys.executable,str(out/'run-check.py'),label,mode,*argv]);rows.append({'phase':label,'exit':code});(out/'final-owner-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 if code:sys.exit(code)
subprocess.run([sys.executable,str(out/'preserve-profiles.py'),'final-host-owner'],check=True)
