"""One-off source-bound execution of the maintained source-free guard."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

root = Path('/tmp/dandrum-lanes/runtime')
copy = Path('/dev/shm/dandrum-beta-20261020/editor-guard-source')
label = sys.argv[1]
assert label and all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in label)
compact = False
out = Path('/tmp/dandrum-evidence/editor-disposal-review') / ('guard-' + label)
assert not out.exists(), 'Retain each attempt immutably; choose a fresh label'
out.mkdir(parents=True)

def inputs(base):
    result = {'CMakeLists.txt': hashlib.sha256((base / 'CMakeLists.txt').read_bytes()).hexdigest()}
    for top in ('src', 'tests', 'examples', 'schema', 'scripts', 'spikes'):
        for folder, dirs, files in os.walk(base / top):
            dirs[:] = sorted(d for d in dirs if d not in ('target', 'build', '__pycache__'))
            for name in sorted(files):
                path = Path(folder) / name
                result[path.relative_to(base).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result

manifest = inputs(root)
previous = inputs(copy)
assert not (previous.keys() - manifest.keys()), 'Unexpected old source input; inspect, do not delete'
for name, digest in manifest.items():
    target = copy / name
    if previous.get(name) != digest:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / name, target)
assert inputs(root) == manifest, 'Source changed during snapshot'
assert inputs(copy) == manifest, 'Guard inputs do not match source snapshot'
(out / 'source-manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
argv = ['python3', 'tests/python/test_engine_only_build.py',
        'ClapProofBuildTest.test_trigger_editor_scaffold_stages_copied_resources_without_host_sources', '-v']
env = dict(os.environ, PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin', CARGO_NET_OFFLINE='true')
if compact:
    scratch = Path('/run/user/1000/dandrum-beta-20261020/scratch')
    scratch.mkdir(parents=True, exist_ok=True)
    env.update(CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', CARGO_INCREMENTAL='0', TMPDIR=str(scratch))
samples = []
stop_reason = None
start = time.monotonic()
start_wall = time.time()
with (out / 'guard.log').open('wb') as log:
    proc = subprocess.Popen(argv, cwd=copy, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    while proc.poll() is None:
        disk, ram, user_ram = os.statvfs(root), os.statvfs('/dev/shm'), os.statvfs('/run/user/1000')
        mem = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) * 1024
        sample = dict(elapsed_seconds=round(time.monotonic()-start, 3), disk_free_bytes=disk.f_bavail*disk.f_frsize,
                      ram_free_bytes=ram.f_bavail*ram.f_frsize, user_ram_free_bytes=user_ram.f_bavail*user_ram.f_frsize, mem_available_bytes=mem)
        samples.append(sample)
        ram_floor = 256*1024**2 if compact else 1024**3
        if sample['disk_free_bytes'] < 256*1024**2 or sample['ram_free_bytes'] < ram_floor or sample['user_ram_free_bytes'] < 128*1024**2 or mem < 4*1024**3:
            stop_reason = 'Owned guard stopped at resource floor; reusable caches preserved'
            os.killpg(proc.pid, signal.SIGINT)
            break
        time.sleep(1)
    code = proc.wait()
assert inputs(copy) == manifest, 'Guard source inputs drifted'
stage_logs = []
for path in (copy / 'build/engine-only-regression').glob('*.log'):
    if path.stat().st_mtime >= start_wall:
        shutil.copy2(path, out / path.name)
        stage_logs.append(path.name)
keys = ('PATH','CARGO_NET_OFFLINE','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_INCREMENTAL','TMPDIR')
receipt = dict(argv=argv, cwd=str(copy), environment={k:env[k] for k in keys if k in env},
               exit_code=code, elapsed_seconds=round(time.monotonic()-start,6), stop_reason=stop_reason,
               source_unchanged=True, original_source_unchanged=(inputs(root)==manifest), stage_logs=sorted(stage_logs), resource_samples=samples)
(out / 'run.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k != 'resource_samples'}),flush=True)
raise SystemExit(code if code >= 0 else 128-code)
