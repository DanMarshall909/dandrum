import pathlib,subprocess,json,os,time,re,hashlib,sys
p=pathlib.Path('/tmp/dandrum-lanes/evidence-editor-disposal');phase=sys.argv[1];lanes=sys.argv[2:] or ['native','fast'];base='/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/';binary=re.search(r'Running unittests src/lib.rs \(([^)]+)\)',(p/(phase+'-native-coverage.log')).read_text()).group(1);commands=[]
for lane in lanes:
 prefix=phase+'-'+lane;files=[str(f) for f in p.glob(prefix+'-*.profraw')];assert files,prefix;prof=str(p/(prefix+'.profdata'))
 for cmd,out in [([base+'llvm-profdata','merge','-sparse',*files,'-o',prof],p/(prefix+'-merge.log')),([base+'llvm-cov','export',binary,'--instr-profile',prof],p/(prefix+'-coverage.json')),([base+'llvm-cov','show',binary,'--instr-profile',prof,'--show-instantiations=false','src/trigger-editor/src/native_x11.rs'],p/(prefix+'-coverage.txt'))]:
  t=time.monotonic()
  with out.open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.PIPE,text=True)
  commands.append({'command':cmd,'cwd':os.getcwd(),'exit':r.returncode,'stderr':r.stderr,'elapsed_seconds':time.monotonic()-t});assert r.returncode==0,r.stderr
(p/(phase+'-coverage-export-runs.json')).write_text(json.dumps({'binary':binary,'binary_sha256':hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest(),'commands':commands},indent=2)+'\n')
for lane in lanes:
 j=json.loads((p/(phase+'-'+lane+'-coverage.json')).read_text())
 for f in j['data'][0]['files']:
  if '/src/native_x11.rs' in f['filename'] or '/src/assets.rs' in f['filename']:print(lane,f['filename'],f['summary'])
print([line for line in (p/(phase+'-native-coverage.txt')).read_text().splitlines() if 'with_navigation_handler' in line])
