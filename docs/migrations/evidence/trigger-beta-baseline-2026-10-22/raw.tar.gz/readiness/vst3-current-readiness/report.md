# VST3 current readiness — read-only refresh, 2026-10-22

Followup to [the retained loader report](/tmp/dandrum-evidence/vst3-loader-readiness/report.md); source/compiler/license/loader delta only. No builds, tests, network, installs, native execution, Git operations or repository/cache changes. This does not adopt dependencies, select a new increment or assess CLAP/beta completion.

**Result:** the pins/notices and cached loader facts remain intact. CMake is adequate; no maintained installed C++ compiler meeting the pinned SDK's documented Linux contract was identified. The VST3 parameter path is implemented, while its Linux callback/flush service remains view/run-loop dependent by inspected source. Actual VST3 loading, state, parameters and GUI are still unproved.

## Pins, notices and toolchain

Cached official commit/tree receipts bind clap-wrapper **v0.16.0**, commit `1cca996e96f29ab2be7ae9f8cfe532bbc92e1dd6`, tree `60b845a8e1079f026276f42cc71d39a9407f078f` (not truncated). Its [base_sdks.cmake:99–115](https://github.com/free-audio/clap-wrapper/blob/1cca996e96f29ab2be7ae9f8cfe532bbc92e1dd6/cmake/base_sdks.cmake#L99-L115) selects VST3 SDK **v3.8.0_build_66**; cached SDK authored files bind commit `9fad9770f2ae8542ab1a548a68c1ad1ac690abe0`. The separately cached3.8.1 metadata is not this pin. Wrapper [LICENSE](https://github.com/free-audio/clap-wrapper/blob/1cca996e96f29ab2be7ae9f8cfe532bbc92e1dd6/LICENSE) and SDK [LICENSE.txt](https://github.com/steinbergmedia/vst3sdk/blob/9fad9770f2ae8542ab1a548a68c1ad1ac690abe0/LICENSE.txt) contain MIT notices, copyright2022 defiantnerd and2025 Steinberg respectively, requiring retention of copyright/permission notices in copies or substantial portions. This is file-content evidence, not legal clearance/adoption or transitive-license review.

Actual source caches are `native-inventory/` (wrapper metadata and three `sdk380-*` files), `vst3-loader-readiness/root-wrapper-source/` (five loader/proxy files), `pinned-wrapper-qtractor-timer-readiness/` (flattened backend sources), and `standalone-wrapper-readiness/source/`, all beneath `/tmp/dandrum-evidence/`. These bounded copies do not establish a complete build-ready SDK/submodule checkout. The helper requires `base`, `public.sdk`, `pluginterfaces`, `cmake`, including actual `public.sdk/source/main/pluginfactory.cpp`.

Read-only `--version`, `command -v`, installed `dpkg-query` status, `update-alternatives --list c++`, `/etc/os-release` and narrow conventional compiler-path listings show:

| Item | Observed | Pinned documented contract |
|---|---|---|
| Default GCC/G++ |11.4.0; G++10.5 also installed | SDK README: GCC13.3+ |
| Other compiler | GCC12.3 C driver; no G++12 or newer G++ found in checked installed records/paths; no Clang on PATH | No qualifying no-install C++ choice identified |
| CMake | `/home/dan/.local/bin/cmake`3.30.9 | Wrapper>=3.21; SDK root>=3.25: met |
| OS | Pop!_OS22.04 LTS, Ubuntu/jammy derived | SDK supported Linux table: Ubuntu24.04 x86_64 |

The exact SDK table is [README:42](https://github.com/steinbergmedia/vst3sdk/blob/9fad9770f2ae8542ab1a548a68c1ad1ac690abe0/README.md#L42). `/usr/lib/llvm-11` exists but establishes no qualifying substitute. Compiler paths checked include `/usr/bin`, conventional `/usr/lib/llvm-*`, `/usr/local`, `/opt` GCC/LLVM locations and user-local compiler paths; this is not an exhaustive filesystem search. Older GCC might compile the wrapper-selected SDK subset, but no build was attempted and that would not establish the documented combination. Wrapper C++17 default does not replace the SDK contract. Provisioning/compiler disposition remains unresolved.

## Source facts relevant to the next loader proof

- **External VST3:** `wrapasvst3_entry.cpp:75–111,145–185` selects a same-stem external `.clap` from conventional CLAP roots. `fsutil.cpp:216–228,294–301` uses the chosen spelling for own-handle `dlopen`/`dlsym(clap_entry)` and `entry.init`. No canonicalization is shown. Linux `CLAP_PATH` parsing103–124 is under `if(cp.empty())`; a nonempty override is not parsed as written. This remains an unexecuted source finding.
- **Dandrum path contract:** Integration `lib.rs:252–260` retains exact OS path bytes; `trigger.rs:129–148` requires an absolute existing file and resolves sibling `DandrumTrigger.resources`; `trigger/gui.rs:38–89,255` validates the executing Rust object's identity against that path before GTK promotion. External CLAP plus sibling resources is structurally plausible, not runtime proof. Static/self mode remains separate/unproved (`fsutil.cpp:354–392`; self branch uses `_handle` rather than new `lhandle`).
- **resourceDirectory/argv0:** the inspected standalone CMake helper179–182 explicitly warns `RESOURCE_DIRECTORY` is unsupported. Standalone `entry.cpp:14–25` calls `entry->init(argv[0])` after external initialization. These are standalone-specific, not the VST3 factory flow. The VST3 resource-copy helper was not cached among inspected authored files; its packaging behavior is unknown. No generic resource option is proven to supply Dandrum's sibling contract.
- **Parameter/state distinction:** VST3 `wrapasvst3.cpp:270–311` forwards state streams and resynchronizes values after successful load;1091–1127 and1231–1275 populate/rescan real parameters. `param_request_flush:1290` queues work consumed by onIdle1460–1510 when stopped/not-yet-processed. `setComponentState:493–497` instead returns success without consuming its stream. Empty setup/rescan/clear/request_flush methods belong to **StandaloneHost**141–156; calling the VST3 implementation a parameter stub would be wrong.
- **Main-thread/native limit:** `plugview.cpp:220–237` gets Linux IRunLoop from IPlugFrame. Backend501–528,1581–1625 attaches/detaches idle/timer/FD handlers with the view, without checking registration results. Timer registration1385–1423 returns true even without a run loop;1528–1531 explicitly notes Linux onIdle is not called without it. No editor-independent callback/flush service is established. `plugview.cpp:24–42,104–136` ignores CLAP create/set_parent/show results, so VST3 success is not a native-creation oracle. removed137–144 clears attachment state; destructor19–65 invokes CLAP GUI destruction.

**Smallest later proof boundary:** qualify the toolchain/dependency layout, then load the exact maintained GUI CLAP through this pinned external VST3 factory in a temporary installed layout, selecting the intended Trigger class and independently distinguishing the actual sibling resource root from a decoy. Through VST3 interfaces, prove one real parameter change with independently expected signed PCM, save/restore into a fresh instance, and invalid-stream non-mutation. Check stopped/editor-absent callback/flush behavior. For native GUI, a real X11 parent/IPlugFrame/IRunLoop must yield independently observed child/mapping, production React readiness, authenticated parameter feedback and cleanup; wrapper return codes alone do not suffice. Existing direct-CLAP helpers are reusable expected-value owners, not wrapper proof. CLAP_PATH-only discovery needs characterization only if that override is selected. These are candidate proof needs, not new scope or an implementation decision.

## Revalidated source bindings

All seven wrapper/SDK metadata files below matched the retained source manifest. All five loader files matched both retained SHA256 and Git-blob identities. The six selected backend/standalone files matched their retained source manifests. Hashes of the three Integration owners bind the Dandrum cross-references as read, without claiming a new commit identity.

| Local file | SHA256 |
|---|---|
| `/tmp/dandrum-evidence/native-inventory/wrapper-CMakeLists.txt` | `049cc9d8f7e4b1fe092807cd2d8c054d6fbeedbac1053c9a086aab204bc71d70` |
| `/tmp/dandrum-evidence/native-inventory/wrapper-README.md` | `ec50f278708f814d0f2cbefa38dc6395b1b4a218a867612f53357ce0a4a9d4d6` |
| `/tmp/dandrum-evidence/native-inventory/wrapper-LICENSE` | `7b2309a06f07f21150cef4150f025a676212e975af68ed06f98644db5427cc59` |
| `/tmp/dandrum-evidence/native-inventory/wrapper-base-sdks.cmake` | `3e20f67e1dff8170af9897c50b3e06bad4eff22b646d0995e2e28e8854ecae35` |
| `/tmp/dandrum-evidence/native-inventory/sdk380-CMakeLists.txt` | `1f9df4d539b158b7e98bfb5ad585f9d23c56ffe2826ad7c9ecc650c8d4737730` |
| `/tmp/dandrum-evidence/native-inventory/sdk380-README.md` | `46a70b0feaf83dbadf41a6a8fb727294b19ef30afc8f991c388068adb6c7e3a8` |
| `/tmp/dandrum-evidence/native-inventory/sdk380-LICENSE.txt` | `d6115b263faa1cdf8c7372d70889c833dde1cec95252e7ee93e4f7d599ec96ca` |
| `/tmp/dandrum-evidence/vst3-loader-readiness/root-wrapper-source/src/clap_proxy.cpp` | `d97802f1e6a7a726ff374220dceba9ed442971e986fd9c97e82769ff23f161a9` |
| `/tmp/dandrum-evidence/vst3-loader-readiness/root-wrapper-source/src/clap_proxy.h` | `4c771dd4c3a16613bbbfbde9644af9a34205070eb275c9aff6865ff16873833a` |
| `/tmp/dandrum-evidence/vst3-loader-readiness/root-wrapper-source/src/wrapasvst3_entry.cpp` | `f8b5680281e4958389ad56683460fde113dcf8b3d734bc858d8317ed2c1989c7` |
| `/tmp/dandrum-evidence/vst3-loader-readiness/root-wrapper-source/src/detail/clap/fsutil.cpp` | `fc7f31de0c93cc84c81becda9adb667752fff34fa41baecf534e09935610ee3e` |
| `/tmp/dandrum-evidence/vst3-loader-readiness/root-wrapper-source/src/detail/clap/fsutil.h` | `f2a9c15c66f8da58891b7b596dcd715662506af01d7008818d416b05dd17ca66` |
| `/tmp/dandrum-evidence/pinned-wrapper-qtractor-timer-readiness/wrapper--src--wrapasvst3.cpp` | `f1855d9055aa3b7a5d4e6d03b44a32f7da661ada06980ab82f624895eae87bbc` |
| `/tmp/dandrum-evidence/pinned-wrapper-qtractor-timer-readiness/wrapper--src--detail--vst3--plugview.cpp` | `98c9633dcc43ab9347960835ad57fb2ab35ab687c770c457d5f627db796c90bd` |
| `/tmp/dandrum-evidence/pinned-wrapper-qtractor-timer-readiness/wrapper--src--detail--standalone--standalone_host.h` | `5d9e0ca6cce5f122aa5ece4ef994eff10af584dc471382c92a40d42f59510092` |
| `/tmp/dandrum-evidence/pinned-wrapper-qtractor-timer-readiness/wrapper--src--detail--os--linux.cpp` | `af2709681cd5684caffcdd5617bc15b7c20a49b1d323cce55526a9722bc997da` |
| `/tmp/dandrum-evidence/standalone-wrapper-readiness/source/src__detail__standalone__entry.cpp` | `d6476267afa7c638c733fdcb0b4de58f3483927fb34dbca45335d2d0e33667a2` |
| `/tmp/dandrum-evidence/standalone-wrapper-readiness/source/cmake__wrap_standalone.cmake` | `5cb097d898114e37c3ac527078c3297eab3e04a002f14ccf079cec386244e0f7` |
| `/tmp/dandrum-lanes/integration/src/clap-adapter/src/lib.rs` | `26955a02dd99fa07fa7601072b8cd67aac658c90f7c738ca09d552a153d87ed6` |
| `/tmp/dandrum-lanes/integration/src/clap-adapter/src/trigger.rs` | `14ca55d2f68a4a99e4f27ec785af2b43a66ea659382120f1f96fae9fc6ee6bdb` |
| `/tmp/dandrum-lanes/integration/src/clap-adapter/src/trigger/gui.rs` | `eb878a98a1acfee7a5ad86683d96c54a45992dbdd0ba69959a9cad6d83e4e9b5` |

Read-only assignment released; no build/cache/native resource lease retained.
