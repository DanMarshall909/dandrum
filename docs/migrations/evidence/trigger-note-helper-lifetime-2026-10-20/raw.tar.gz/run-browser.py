from pathlib import Path
import os,subprocess,time,json,shutil,signal
p=Path(__file__).parent
env=os.environ.copy()
for key,folder in [('TMPDIR','browser-tmp'),('XDG_CACHE_HOME','browser-cache'),('XDG_CONFIG_HOME','browser-config')]:
 d=p/folder;d.mkdir(exist_ok=True);env[key]=str(d)
env['TMPDIR']='/run/user/1000/fnl'
env['npm_config_cache']=str(p/'npm-cache');env['npm_config_update_notifier']='false'
cmd=['node','node_modules/@playwright/test/cli.js','test','--config',str(p/'playwright.config.mjs'),'native-transport.spec.mjs']
resources=[]
def resource():
 r={'time':time.time(),'ramfsFree':shutil.disk_usage(p).free,'memAvailableKiB':int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))}
 resources.append(r)
 return r['ramfsFree']>=512*1024**2 and r['memAvailableKiB']>=4*1024**2
assert resource(),'Resource floor before browser launch'
start=time.monotonic();stopped=False
with (p/'browser.log').open('w') as log:
 proc=subprocess.Popen(cmd,cwd='web/trigger',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll() is None:
  if not resource():
   stopped=True;os.killpg(proc.pid,signal.SIGTERM);break
  time.sleep(.5)
 try:code=proc.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
resource()
(p/'browser-resources.json').write_text(json.dumps(resources,indent=2)+'\n')
(p/'browser-run.json').write_text(json.dumps({'command':cmd,'cwd':str(Path('web/trigger').resolve()),'pid':proc.pid,'exit':code,'resourceStopped':stopped,'elapsedSeconds':time.monotonic()-start,'envOverrides':{k:env[k] for k in ['TMPDIR','XDG_CACHE_HOME','XDG_CONFIG_HOME','npm_config_cache']}},indent=2)+'\n')
print((p/'browser.log').read_text()[-6000:]);print('exit',code,'resourceStopped',stopped)
