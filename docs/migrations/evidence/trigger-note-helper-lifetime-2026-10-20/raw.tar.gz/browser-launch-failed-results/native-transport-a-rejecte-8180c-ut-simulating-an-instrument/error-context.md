# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-transport.spec.mjs >> a rejected native snapshot displays its capability error without simulating an instrument
- Location: tests/browser/native-transport.spec.mjs:32:1

# Error details

```
Error: browserType.launch: Target page, context or browser has been closed
Browser logs:

<launching> /usr/bin/google-chrome --disable-field-trial-config --disable-background-networking --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-back-forward-cache --disable-breakpad --disable-client-side-phishing-detection --disable-component-extensions-with-background-pages --disable-component-update --no-default-browser-check --disable-default-apps --disable-dev-shm-usage --disable-edgeupdater --disable-extensions --disable-features=AvoidUnnecessaryBeforeUnloadCheckSync,DestroyProfileOnBrowserClose,DialMediaRouteProvider,GlobalMediaControls,HttpsUpgrades,LensOverlay,MediaRouter,PaintHolding,ThirdPartyStoragePartitioning,BlockOriginHeaderModificationOnRedirect,Translate,AutoDeElevate,OptimizationHints,msForceBrowserSignIn,msEdgeUpdateLaunchServicesPreferredVersion --enable-features=CDPScreenshotNewSurface --allow-pre-commit-input --disable-hang-monitor --disable-ipc-flooding-protection --disable-popup-blocking --disable-prompt-on-repost --disable-renderer-backgrounding --disable-updater-scheduler --force-color-profile=srgb --metrics-recording-only --no-first-run --password-store=basic --use-mock-keychain --no-service-autorun --export-tagged-pdf --disable-search-engine-choice-screen --unsafely-disable-devtools-self-xss-warnings --edge-skip-compat-layer-relaunch --disable-infobars --disable-search-engine-choice-screen --disable-sync --enable-unsafe-swiftshader --headless --hide-scrollbars --mute-audio --blink-settings=primaryHoverType=2,availableHoverTypes=2,primaryPointerType=4,availablePointerTypes=4 --no-sandbox --user-data-dir=/run/user/1000/dandrum-beta-20261020/frontend-note-lifetime-evidence/browser-tmp/playwright_chromiumdev_profile-Pr3hXX --remote-debugging-pipe --no-startup-window
<launched> pid=3573449
[pid=3573449][err] [3573449:3573449:1020/234246.667996:FATAL:chrome/browser/process_singleton_posix.cc:313] Socket path too long: /run/user/1000/dandrum-beta-20261020/frontend-note-lifetime-evidence/browser-tmp/com.google.Chrome.tepHVy/SingletonSocket.
[pid=3573449] <process did exit: exitCode=null, signal=SIGABRT>
[pid=3573449] starting temporary directories cleanup
Call log:
  - <launching> /usr/bin/google-chrome --disable-field-trial-config --disable-background-networking --disable-background-timer-throttling --disable-backgrounding-occluded-windows --disable-back-forward-cache --disable-breakpad --disable-client-side-phishing-detection --disable-component-extensions-with-background-pages --disable-component-update --no-default-browser-check --disable-default-apps --disable-dev-shm-usage --disable-edgeupdater --disable-extensions --disable-features=AvoidUnnecessaryBeforeUnloadCheckSync,DestroyProfileOnBrowserClose,DialMediaRouteProvider,GlobalMediaControls,HttpsUpgrades,LensOverlay,MediaRouter,PaintHolding,ThirdPartyStoragePartitioning,BlockOriginHeaderModificationOnRedirect,Translate,AutoDeElevate,OptimizationHints,msForceBrowserSignIn,msEdgeUpdateLaunchServicesPreferredVersion --enable-features=CDPScreenshotNewSurface --allow-pre-commit-input --disable-hang-monitor --disable-ipc-flooding-protection --disable-popup-blocking --disable-prompt-on-repost --disable-renderer-backgrounding --disable-updater-scheduler --force-color-profile=srgb --metrics-recording-only --no-first-run --password-store=basic --use-mock-keychain --no-service-autorun --export-tagged-pdf --disable-search-engine-choice-screen --unsafely-disable-devtools-self-xss-warnings --edge-skip-compat-layer-relaunch --disable-infobars --disable-search-engine-choice-screen --disable-sync --enable-unsafe-swiftshader --headless --hide-scrollbars --mute-audio --blink-settings=primaryHoverType=2,availableHoverTypes=2,primaryPointerType=4,availablePointerTypes=4 --no-sandbox --user-data-dir=/run/user/1000/dandrum-beta-20261020/frontend-note-lifetime-evidence/browser-tmp/playwright_chromiumdev_profile-Pr3hXX --remote-debugging-pipe --no-startup-window
  - <launched> pid=3573449
  - [pid=3573449][err] [3573449:3573449:1020/234246.667996:FATAL:chrome/browser/process_singleton_posix.cc:313] Socket path too long: /run/user/1000/dandrum-beta-20261020/frontend-note-lifetime-evidence/browser-tmp/com.google.Chrome.tepHVy/SingletonSocket.
  - [pid=3573449] <process did exit: exitCode=null, signal=SIGABRT>
  - [pid=3573449] starting temporary directories cleanup
  - [pid=3573449] <gracefully close start>
  - [pid=3573449] <kill>
  - [pid=3573449] <skipped force kill spawnedProcess.killed=false processClosed=true>
  - [pid=3573449] finished temporary directories cleanup
  - [pid=3573449] <gracefully close end>

```