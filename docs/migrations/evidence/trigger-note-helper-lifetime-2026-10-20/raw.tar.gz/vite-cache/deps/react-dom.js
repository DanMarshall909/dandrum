import {
  require_react_dom
} from "./chunk-WTXBUENR.js";
import "./chunk-33SJK45H.js";
import "./chunk-HKJ2B2AA.js";
export default require_react_dom();
