import {
  require_react
} from "./chunk-33SJK45H.js";
import "./chunk-HKJ2B2AA.js";
export default require_react();
