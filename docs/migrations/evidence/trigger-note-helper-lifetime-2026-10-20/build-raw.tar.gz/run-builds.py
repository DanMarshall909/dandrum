from pathlib import Path
import os,subprocess,time,json,shutil,signal,hashlib
p=Path(__file__).parent;root=Path('/tmp/dandrum-lanes/frontend');env=os.environ.copy()
tmp=p/'build-tmp';tmp.mkdir(exist_ok=True);env['TMPDIR']=str(tmp)
expected={'web/trigger/engine/native-live.mjs':'48a9c5c3e410e7e85bdc5bd66efd6d5f4602929a10c490d730f0fbcbb64c3eb9','web/trigger/tests/native-engine.test.mjs':'71fd785bce9da4ee62e98e27d809d97232000171249688f4abb78062d16e0be6'}
assert all(hashlib.sha256((root/f).read_bytes()).hexdigest()==h for f,h in expected.items())
runs=[];samples=[]
def resource():
 r={'time':time.time(),'ramfsFree':shutil.disk_usage(p).free,'memAvailableKiB':int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))}
 samples.append(r)
 return r['ramfsFree']>=512*1024**2 and r['memAvailableKiB']>=4*1024**2
for name in ['preview','native']:
 assert resource(),'Resource floor before '+name
 cmd=['node','node_modules/vite/bin/vite.js','build','--config',str(p/('build-'+name+'.config.mjs')),'--configLoader','native']
 started=time.monotonic();stopped=False
 with (p/('build-'+name+'.log')).open('w') as log:
  proc=subprocess.Popen(cmd,cwd=root/'web/trigger',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   if not resource():stopped=True;os.killpg(proc.pid,signal.SIGTERM);break
   time.sleep(.25)
  try:code=proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
 resource()
 runs.append({'name':name,'command':cmd,'cwd':str(root/'web/trigger'),'pid':proc.pid,'exit':code,'resourceStopped':stopped,'elapsedSeconds':time.monotonic()-started})
 print(name,'exit',code,flush=True);print((p/('build-'+name+'.log')).read_text()[-4500:],flush=True)
 if code:break
assert all(hashlib.sha256((root/f).read_bytes()).hexdigest()==h for f,h in expected.items())
(p/'build-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
(p/'build-resource-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
