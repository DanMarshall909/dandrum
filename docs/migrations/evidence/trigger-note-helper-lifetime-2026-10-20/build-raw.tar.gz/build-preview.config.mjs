import config from "/tmp/dandrum-lanes/frontend/web/trigger/vite.config.mjs";
export default {...config,root:"/tmp/dandrum-lanes/frontend/web/trigger",cacheDir:"/run/user/1000/dandrum-beta-20261020/frontend-note-lifetime-evidence/build-cache-preview",build:{...config.build,outDir:"/run/user/1000/dandrum-beta-20261020/frontend-note-lifetime-evidence/build-preview",emptyOutDir:false}};
