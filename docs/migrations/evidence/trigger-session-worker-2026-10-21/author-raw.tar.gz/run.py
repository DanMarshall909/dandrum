import subprocess,sys,time,json,pathlib,os,signal,hashlib,tarfile
root=pathlib.Path('/tmp/dandrum-lanes/evidence-session-worker');label=sys.argv[1];cmd=sys.argv[2:];phase=root/label;phase.mkdir();work=pathlib.Path('/tmp/dandrum-lanes/protocol')
env=os.environ.copy(); coverage=label.endswith('coverage')
target='/run/user/1000/dandrum-beta-20261020/runtime-notes-r1-target' if coverage else '/tmp/dandrum-lanes/cache-editor-guard'
env.update(CARGO_TARGET_DIR=target,CARGO_LLVM_COV_TARGET_DIR=target,CARGO_LLVM_COV_BUILD_DIR=target,CARGO_BUILD_JOBS='1',TMPDIR='/dev/shm/dandrum-beta-20261020/session-worker-scratch')
pathlib.Path(env['TMPDIR']).mkdir(parents=True,exist_ok=True)
for key in ['CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']:
 if coverage:env[key]='0'
 else:env.pop(key,None)

paths=['src/trigger-host/src/parameters.rs','src/trigger-host/src/protocol.rs','src/trigger-host/src/runtime.rs','src/instrument-session/src/lib.rs','src/trigger-host/tests/session_jobs.rs','src/trigger-host/tests/parameters.rs','src/trigger-host/Cargo.toml','src/trigger-host/Cargo.lock'];paths=sorted(set(paths+[str(p.relative_to(work)) for folder in ['src/trigger-host/src','src/trigger-host/tests'] for p in (work/folder).rglob('*.rs')]));hashes={}
for name in paths:
 p=work/name
 if p.exists():
  b=p.read_bytes();dest=phase/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);hashes[name]=hashlib.sha256(b).hexdigest()
def sample():
 a=os.statvfs('/tmp');b=os.statvfs('/dev/shm');mem={x.split(':',1)[0]:int(x.split()[1])*1024 for x in pathlib.Path('/proc/meminfo').read_text().splitlines()};return {'disk':a.f_bavail*a.f_frsize,'ramfs':b.f_bavail*b.f_frsize,'memory':mem['MemAvailable'],'target_free':os.statvfs(target).f_bavail*os.statvfs(target).f_frsize}
def safe(s):return s['disk']>=1024**3 and s['ramfs']>=256*1024**2 and s['memory']>=4*1024**3 and s['target_free']>=(256*1024**2 if coverage else 1024**3)
start=time.monotonic();samples=[sample()];assert safe(samples[0]),samples
with (phase/'output.log').open('w') as f:
 p=subprocess.Popen(cmd,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);stopped=None
 while p.poll() is None:
  s=sample();samples.append(s)
  if not safe(s):
   stopped={'reason':'resource floor','sample':s};os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.25)
 code=p.wait()
if coverage:
 with tarfile.open(phase/'profiles.tar.gz','w:gz') as archive:
  for pattern in ['*.profraw','*.profdata']:
   for profile in pathlib.Path(target).glob(pattern):archive.add(profile,arcname=profile.name)
result={'command':cmd,'cwd':str(work),'exit':code,'seconds':time.monotonic()-start,'pidAndPgid':p.pid,'environment':{k:env.get(k) for k in ['CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','CARGO_BUILD_JOBS','TMPDIR','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_PROFILE_DEV_OPT_LEVEL','CARGO_PROFILE_TEST_OPT_LEVEL','CARGO_PROFILE_DEV_DEBUG_ASSERTIONS','CARGO_PROFILE_TEST_DEBUG_ASSERTIONS','CARGO_PROFILE_DEV_OVERFLOW_CHECKS','CARGO_PROFILE_TEST_OVERFLOW_CHECKS','RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS']},'source_hashes':hashes,'resource_first':samples[0],'resource_min':{k:min(s[k] for s in samples) for k in samples[0]},'stop':stopped};(phase/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'phase':label,'exit':code,'seconds':result['seconds'],'resource_min':result['resource_min'],'stop':stopped}));print((phase/'output.log').read_text()[-1400:]);sys.exit(code)
