from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time,re
root=Path('/tmp/dandrum-lanes/protocol');out=Path('/dev/shm/dandrum-beta-20261020/session-worker-sourcefree-success');out.mkdir();scratch=out/'scratch';scratch.mkdir();fixture=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source');target=Path('/tmp/dandrum-lanes/cache-editor-guard');priorpath=Path('/run/user/1000/dandrum-beta-20261020/session-jobs-sourcefree/source-manifest.json')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def save(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
def resources():
 d={k:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for k,p in [('disk','/tmp'),('shm','/dev/shm')]};d['memory']=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;return d
floors={'disk':1024**3,'shm':256*1024**2,'memory':4*1024**3}
def safe(r):return all(r[k]>=v for k,v in floors.items())
def inputs(base):
 result={'CMakeLists.txt':sha(base/'CMakeLists.txt')}
 for part in ('src','tests','examples','schema','scripts','spikes'):
  for parent,dirs,files in os.walk(base/part):
   dirs[:]=[d for d in dirs if d not in ('target','build','__pycache__')]
   for name in files:
    p=Path(parent)/name;assert not p.is_symlink();result[str(p.relative_to(base))]=sha(p)
 return result
assert safe(resources()),resources()
stopped=Path('/dev/shm/dandrum-beta-20261020/session-worker-sourcefree')
old=json.loads((stopped/'source-manifest.json').read_text());assert len(old)==590
current=inputs(root);assert current==old and len(current)==590
expected={'src/trigger-host/src/parameters.rs':'c5d6c817940dd1255e74aac3a53094f7162e444c2a003cdd4ab3d0bef5081efb','src/trigger-host/tests/session_jobs.rs':'95d3be564f52fc38156eb5c015d3299d5ce77fd0cef1424cff1faa0272e8eafa'}
assert all(current[n]==d for n,d in expected.items())
priorstats=json.loads((stopped/'prior-fixture-verified.json').read_text());changedtimes={x['path']:x['fresh_mtime_ns'] for x in json.loads((stopped/'fixture-update.json').read_text())['freshened_only_two']}
expectedtimes={n:changedtimes.get(n,st['mtime_ns']) for n,st in priorstats.items()}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='d2ef616377ce34b446cb0dd1f5d0a3a4bd10c1c8'
def verify():
 assert inputs(root)==current,'root inputs changed'
 assert inputs(fixture)==current,'fixture input set/bytes changed'
 for n,d in current.items():
  assert sha(fixture/n)==d,n
  assert (fixture/n).stat().st_mtime_ns==expectedtimes[n],n
 assert not any((fixture/n).exists() for n in ('web','ui','third_party'))
verify();save('source-manifest.json',current);save('root-before-map.json',inputs(root));save('fixture-before-map.json',inputs(fixture));save('fixture-verification.json',{'head':head,'source_inputs':590,'all_590_bytes_and_retained_mtimes_match':True,'fixture_updates_this_run':0,'stopped_evidence':str(stopped),'stopped_manifest_sha256':sha(stopped/'source-manifest.json'),'expected_mtimes':expectedtimes,'source_sha256':expected,'absent_trees':['web','ui','third_party']})
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',TMPDIR=str(scratch));removed={}
for k in list(env):
 if k.startswith(('CARGO_PROFILE_','CARGO_LLVM_COV_')) or k in ['RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LLVM_PROFILE_FILE','__CARGO_LLVM_COV_RUSTC_WRAPPER','__CARGO_LLVM_COV_RUSTC_WRAPPER_RUSTFLAGS','__CARGO_LLVM_COV_RUSTC_WRAPPER_CRATE_NAMES']:removed[k]=env.pop(k)
commands=[('release-tests',['/home/dan/.cargo/bin/cargo','test','--release','--offline','--locked','--jobs','1','--manifest-path',str(fixture/'src/trigger-host/Cargo.toml'),'-vv']),('dependencies',['/home/dan/.cargo/bin/cargo','tree','--offline','--locked','--manifest-path',str(fixture/'src/trigger-host/Cargo.toml'),'--edges','normal','--prefix','none'])];results=[]
for label,cmd in commands:
 assert safe(resources()),resources();verify();start=time.monotonic();samples=[];stop=None
 with (out/(label+'.log')).open('wb') as log:
  process=subprocess.Popen(cmd,cwd=fixture,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while process.poll() is None:
   r=resources();r['elapsed_seconds']=time.monotonic()-start;samples.append(r);text=(out/(label+'.log')).read_text(errors='replace');unexpected=[l for l in text.splitlines() if l.lstrip().startswith(('Compiling dandrum_engine ','Compiling dandrum_instrument_session '))]
   if unexpected:stop={'unexpected_engine_or_session_compile':unexpected}
   elif not safe(r):stop={'resource_floor':r}
   if stop:
    os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
    break
   time.sleep(.25)
  code=process.wait()
 record={'command':cmd,'cwd':str(fixture),'env':{k:env[k] for k in ['PATH','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR']},'removed_profile_instrumentation_environment':removed,'exit':code,'elapsed':time.monotonic()-start,'pid':process.pid,'pgid':process.pid,'stop':stop,'resource_samples':samples,'raw_sha256':sha(out/(label+'.log'))};save(label+'.json',record);results.append(record);print(label,code,record['elapsed'],flush=True);verify()
 if code!=0 or stop:save('partial-receipt.json',{'results':results,'source_590_unchanged':True,'resources':resources(),'cache_preserved':True});raise SystemExit(1)
log=(out/'release-tests.log').read_text();counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',log)];assert counts==[15,17,8,14,7,18,14,5,9,2],counts
assert not re.search(r'; [1-9]\d* (?:failed|ignored|filtered out);',log)
binaries=[]
for line in log.splitlines():
 if 'Running `' in line:
  m=re.search(r'(/tmp/dandrum-lanes/cache-editor-guard/release/deps/[a-z_]+-[a-f0-9]+)(?:`|\s)',line)
  if m:
   p=Path(m.group(1));binaries.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
assert len(binaries)==9,binaries;names={l.split()[0].lower() for l in (out/'dependencies.log').read_text().splitlines() if l.strip()};forbidden=[n for n in names if any(x in n for x in ['clack','wry','gtk','webkit','juce'])];assert not forbidden,forbidden;verify();save('root-after-map.json',inputs(root));save('fixture-after-map.json',inputs(fixture));save('receipt.json',{'exit':0,'head':head,'ordinary_tests':sum(counts[:-1]),'doctests':counts[-1],'per_target_counts':counts,'all_590_root_fixture_bytes_unchanged':True,'no_new_or_removed_source_inputs':True,'binaries':binaries,'forbidden_dependency_matches':forbidden,'resource_floors_bytes':floors,'final_resources':resources(),'profile':'Actual default optimized release opt3/LTO/codegen1; CARGO_INCREMENTAL0; no instrumentation/profileoverrides','results':[{'command':r['command'],'exit':r['exit'],'elapsed':r['elapsed'],'pgid':r['pgid']} for r in results],'limits':'Full unfiltered source-free host Cargo only; not fullCMakeguard/native/browser/CLAP/taskcompletion/beta/publication','cache_preserved':True,'owned_processes_exited':True});print('FULL PASS ordinary',sum(counts[:-1]),'docs',counts[-1],flush=True)
