local function run()
reaper.TrackFX_Show(reaper.GetTrack(0,0),0,2);reaper.TrackFX_Show(reaper.GetTrack(0,1),0,3);return 'native editor shown'
end
return 'fbcf70e7e3a24034bc0fa5af3bd29fba:'..tostring(run())
