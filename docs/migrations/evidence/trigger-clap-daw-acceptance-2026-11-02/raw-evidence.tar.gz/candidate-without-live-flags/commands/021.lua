local function run()
local t=reaper.GetTrack(0,0);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');if not ok then return 'state pending' end;local f=assert(io.open('/tmp/dandrum-task-7-3/final/instance-a-after-b.b64','w'));f:write(s);f:close();return 'state captured'
end
return 'c5ef1085572a4e2b8c22e79c4a4f2675:'..tostring(run())
