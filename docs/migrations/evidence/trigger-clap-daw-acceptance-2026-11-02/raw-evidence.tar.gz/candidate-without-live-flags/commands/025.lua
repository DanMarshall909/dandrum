local function run()
reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,0),'B_MUTE',1);reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,1),'B_MUTE',0);reaper.GetSetProjectInfo_String(0,'RENDER_PATTERN','b-fresh',true);reaper.Main_OnCommand(41824,0);return 'render complete'
end
return '2a8e949bb9df4d038df4ad5ca57084f2:'..tostring(run())
