local function run()
for i=0,1 do reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,i),'B_MUTE',0) end; reaper.Main_SaveProjectEx(0,'/tmp/dandrum-task-7-3/final/fresh-restoration-input.rpp',0);return 'unmuted project saved for fresh process'
end
return 'e1fb65af655841cfa3060ef977f4d8b0:'..tostring(run())
