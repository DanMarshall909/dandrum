local function run()
local t=reaper.GetTrack(0,0);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');assert(ok);local f=assert(io.open('/tmp/dandrum-task-7-3/final/instance-0-selected.b64','w'));f:write(s);f:close();return 'state captured'
end
return '95d6ec03b6fd4b188c36a1a693f4d414:'..tostring(run())
