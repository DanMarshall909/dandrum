local function run()
reaper.TrackFX_Show(reaper.GetTrack(0,1),0,2);reaper.TrackFX_Show(reaper.GetTrack(0,0),0,3);return 'native editor shown'
end
return '09c61b0ace114626842d991478447090:'..tostring(run())
