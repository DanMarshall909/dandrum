# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-transport.spec.mjs >> dragging a rendered native slider keeps one public gesture open until release
- Location: tests/browser/native-transport.spec.mjs:7:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 7
+ Received  + 1

- Array [
-   Array [
-     "beginGesture",
-     "drums.level",
-     7,
-   ],
- ]
+ Array []

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e4]:
  - banner [ref=e5]:
    - generic [ref=e6]:
      - generic [ref=e7]: dandrum
      - generic [ref=e9]: Trigger
    - generic [ref=e11]:
      - button "Nothing to undo" [disabled] [ref=e12]
      - button "Nothing to redo" [disabled] [ref=e16]
    - button "Patch Advanced Drum Kit" [ref=e20] [cursor=pointer]:
      - generic [ref=e21]: Patch
      - generic [ref=e22]: Advanced Drum Kit
    - generic "Ready · 5 zones · 1 samples" [ref=e25]:
      - status [ref=e26]:
        - generic [ref=e30]: Ready
        - generic [ref=e31]: 5 zones · 1 samples
    - generic "Audio engine connected. Key mapping, native undo and public controls are available. Other edits report native capability limits. Meters and waveforms unavailable." [ref=e32]: Connected
    - generic [ref=e33]: Voices — / 8
    - generic [ref=e35]: Size controlled by host
    - button "Log" [ref=e36] [cursor=pointer]
    - generic [ref=e37]: Meters unavailable
  - generic [ref=e38]: Macros
  - navigation [ref=e41]:
    - tablist [ref=e42]:
      - tab "Sample" [selected] [ref=e43] [cursor=pointer]
      - tab "Slices 0" [ref=e47] [cursor=pointer]:
        - text: Slices
        - generic [ref=e50]: "0"
      - tab "Mapping" [ref=e52] [cursor=pointer]
      - tab "Layers" [ref=e57] [cursor=pointer]
      - tab "Voice" [ref=e61] [cursor=pointer]
      - tab "Modulation 0" [ref=e67] [cursor=pointer]:
        - text: Modulation
        - generic [ref=e70]: "0"
      - tab "Routing" [ref=e72] [cursor=pointer]
      - tab "Effects" [ref=e76] [cursor=pointer]
    - button "Browser" [ref=e81] [cursor=pointer]
  - generic [ref=e84]:
    - complementary [ref=e85]:
      - generic [ref=e86]:
        - generic [ref=e87]: Instrument
        - button "Add group" [ref=e88] [cursor=pointer]
      - generic [ref=e91]:
        - option "Advanced Drum Kit 1 groups" [ref=e93] [cursor=pointer]:
          - generic [ref=e98]: Advanced Drum Kit
          - generic [ref=e99]: 1 groups
        - option "kit 5 zones" [ref=e101] [cursor=pointer]:
          - generic [ref=e107]: kit
          - generic [ref=e108]: 5 zones
        - option "kick 36 C2" [ref=e110] [cursor=pointer]:
          - generic [ref=e115]: kick
          - generic [ref=e116]: 36 C2
        - option "snare soft 38 D2" [ref=e118] [cursor=pointer]:
          - generic [ref=e123]: snare soft
          - generic [ref=e124]: 38 D2
        - option "hat closed 42 F♯2" [ref=e126] [cursor=pointer]:
          - generic [ref=e131]: hat closed
          - generic [ref=e132]: 42 F♯2
        - option "hat open 46 A♯2" [ref=e134] [cursor=pointer]:
          - generic [ref=e139]: hat open
          - generic [ref=e140]: 46 A♯2
      - generic [ref=e141]:
        - generic [ref=e142]: Sources
        - button "Add source…" [ref=e143] [cursor=pointer]
      - button "Imported 1" [ref=e147] [cursor=pointer]:
        - generic [ref=e150]: Imported
        - generic [ref=e151]: "1"
      - generic [ref=e152]:
        - generic [ref=e153]: Modulators
        - button "Add modulator" [ref=e154] [cursor=pointer]
      - generic [ref=e157]:
        - button "Envelopes 0 · 0" [ref=e158] [cursor=pointer]:
          - generic [ref=e161]: Envelopes
          - generic "0 sources" [ref=e162]: 0 · 0
        - button "LFOs 0 · 0" [ref=e163] [cursor=pointer]:
          - generic [ref=e166]: LFOs
          - generic "0 sources" [ref=e167]: 0 · 0
        - button "Performance 0 · 0" [ref=e168] [cursor=pointer]:
          - generic [ref=e171]: Performance
          - generic "0 sources" [ref=e172]: 0 · 0
        - button "Macros 0 · 0" [ref=e173] [cursor=pointer]:
          - generic [ref=e176]: Macros
          - generic "0 sources" [ref=e177]: 0 · 0
        - button "Random 0 · 0" [ref=e178] [cursor=pointer]:
          - generic [ref=e181]: Random
          - generic "0 sources" [ref=e182]: 0 · 0
      - generic [ref=e183]: Click to preview a source. Drag sources onto pads or zones, modulators onto controls. Right-click a control for Modulation.
    - main [ref=e184]:
      - generic [ref=e185]:
        - generic [ref=e186]:
          - generic [ref=e187]: Sample
          - button "advanced-drums.wav" [ref=e189] [cursor=pointer]
          - button "Audition (Space)" [ref=e193] [cursor=pointer]
          - radiogroup [ref=e196]:
            - radio "Once" [checked] [ref=e197] [cursor=pointer]
            - radio "Gated" [ref=e198] [cursor=pointer]
            - radio "Loop" [ref=e199] [cursor=pointer]
            - radio "Ping-pong" [ref=e200] [cursor=pointer]
            - radio "Sustain loop" [ref=e201] [cursor=pointer]
          - button "Reverse" [ref=e202] [cursor=pointer]
        - generic [ref=e205]:
          - img "Waveform unavailable" [ref=e207]
          - generic "Click to preview" [ref=e208] [cursor=pointer]:
            - generic [ref=e209]:
              - img "Waveform unavailable" [ref=e211]
              - slider "Region start" [ref=e212]
              - slider "Region end" [ref=e213]
              - slider "Fade in" [ref=e214]
              - slider "Fade out" [ref=e215]
          - generic [ref=e216]:
            - generic [ref=e217]: Format 48 kHz · stereo
            - generic [ref=e218]: Length 1.063 s
            - generic [ref=e219]: Peak Not analysed
            - generic [ref=e220]: Loudness Not analysed
            - generic [ref=e221]: Pitch Not analysed
            - generic [ref=e222]: Source external · cached
      - generic [ref=e223]:
        - generic [ref=e224]:
          - generic [ref=e225]: Region
          - generic [ref=e227]:
            - slider "Start" [ref=e230]
            - slider "End" [ref=e240]
            - slider "Fade in" [ref=e251]
            - slider "Fade out" [ref=e261]
        - generic [ref=e269]:
          - generic [ref=e270]: Native controls
          - generic [ref=e272]:
            - slider "pitch ratio" [ref=e275]
            - slider "start offset" [ref=e286]
            - slider "level" [active] [ref=e296]:
              - dialog "level value" [ref=e305]:
                - generic "Click to type a value" [ref=e307]: "1"
            - slider "pan" [ref=e311]
            - slider "variation" [ref=e320]
            - slider "pitch ratio" [ref=e330]
            - slider "start offset" [ref=e341]
            - slider "level" [ref=e351]
            - slider "pan" [ref=e362]
            - slider "pitch ratio" [ref=e371]
            - slider "start offset" [ref=e382]
            - slider "level" [ref=e392]
            - slider "pan" [ref=e403]
            - slider "variation" [ref=e412]
            - slider "pitch ratio" [ref=e422]
            - slider "start offset" [ref=e433]
            - slider "level" [ref=e443]
            - slider "pan" [ref=e454]
            - slider "pitch ratio" [ref=e463]
            - slider "start offset" [ref=e474]
            - slider "level" [ref=e484]
            - slider "pan" [ref=e495]
            - slider "variation" [ref=e504]
        - generic [ref=e512]:
          - generic [ref=e513]: Root
          - generic [ref=e515]:
            - generic [ref=e516]: Root note
            - spinbutton "Root note" [ref=e517]:
              - generic [ref=e518]: 36 C2
          - generic [ref=e519]: Pitch not analysed
    - complementary [ref=e520]:
      - generic [ref=e521]:
        - generic [ref=e522]:
          - generic [ref=e523]:
            - generic [ref=e524]: Advanced Drum Kit
            - generic [ref=e525]: ›
          - generic [ref=e526]:
            - generic [ref=e527]: kit
            - generic [ref=e528]: ›
          - generic [ref=e529]: kick
        - generic [ref=e531]:
          - generic [ref=e534]: advanced-drums.wav
          - generic [ref=e535]: Sample
      - generic [ref=e536]:
        - generic [ref=e537]:
          - generic [ref=e538]: History
          - generic [ref=e539]: 1 of 1
          - button "Add operation…" [ref=e540] [cursor=pointer]
          - button "Collapse stack to a new sample" [disabled] [ref=e543]
        - generic [ref=e546]:
          - button "Source Source advanced-drums.wav" [ref=e547] [cursor=pointer]:
            - checkbox "Source" [checked] [disabled] [ref=e548]
            - generic [ref=e554]: Source
            - generic [ref=e555]: advanced-drums.wav
          - generic [ref=e556]: Bottom to top. Uncheck to bypass, drag ⋮⋮ to reorder, click to edit.
      - generic [ref=e557]:
        - generic [ref=e558]: Sample
        - generic [ref=e559]:
          - generic [ref=e560]: State
          - generic [ref=e561]: loaded · cached
        - generic [ref=e562]:
          - generic [ref=e563]: Format
          - generic [ref=e564]: 48 kHz · 0-bit
        - generic [ref=e565]:
          - generic [ref=e566]: Channels
          - generic [ref=e567]: Stereo
        - generic [ref=e568]:
          - generic [ref=e569]: Used by
          - generic [ref=e570]: 1 zone(s)
        - generic [ref=e571]: Region
        - generic [ref=e572]:
          - generic [ref=e573]: Start
          - generic [ref=e574]: 0.000 s
        - generic [ref=e575]:
          - generic [ref=e576]: End
          - generic [ref=e577]: 0.250 s
        - generic [ref=e578]:
          - generic [ref=e579]: Loop
          - generic [ref=e580]: "Off"
        - generic [ref=e581]:
          - generic [ref=e582]: Root
          - generic [ref=e583]: 60 C4
        - generic [ref=e584]: Analysis
        - generic [ref=e585]:
          - generic [ref=e586]: Pitch
          - generic [ref=e587]: Not analysed
        - generic [ref=e588]:
          - generic [ref=e589]: Loudness
          - generic [ref=e590]: Not analysed
        - generic [ref=e591]:
          - generic [ref=e592]: Zero crossings
          - generic [ref=e593]: Ready
        - button "Analyse pitch" [ref=e595] [cursor=pointer]
        - button "Analyse loudness" [ref=e601] [cursor=pointer]
        - button "Analyse loops" [ref=e607] [cursor=pointer]
        - button "Replace…" [ref=e613] [cursor=pointer]
  - contentinfo [ref=e616]:
    - generic [ref=e617]: Drag markers to edit · double-click a value to type · Ctrl+wheel zooms · Space auditions
    - generic [ref=e618]: 1200 × 800
```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test';
  2   | import {session,yaml,editorProfile} from '../native-fixture.mjs';
  3   | import {parse,stringify} from 'yaml';
  4   | 
  5   | test.beforeEach(async({page})=>{await page.addInitScript(profile=>{window.__TEST_EDITOR_PROFILE__=profile;},editorProfile());});
  6   | 
  7   | test('dragging a rendered native slider keeps one public gesture open until release',async({page})=>{
  8   |   await page.addInitScript(initial=>{
  9   |     window.nativeCalls=[];
  10  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend:{
  11  |       addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:name=>async(...args)=>{
  12  |         window.nativeCalls.push([name,...args]);
  13  |         if(name==='negotiateEditorProtocol')return window.__TEST_EDITOR_PROFILE__;
  14  |         if(name==='getSamplerSession')return initial;
  15  |         if(name==='getParameterState')return {generation:7,sequence:0,parameters:[]};
  16  |         if(['beginGesture','setParameter','endGesture'].includes(name))return {status:'accepted',generation:7};
  17  |         return true;
  18  |       },
  19  |     }};
  20  |   },session());
  21  |   await page.goto('/');
  22  |   const slider=page.locator('[data-knob="drums.level"] [role="slider"]');
  23  |   await expect(slider).toBeVisible();
  24  |   const box=await slider.boundingBox();
  25  |   await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();
> 26  |   await expect.poll(()=>page.evaluate(()=>window.nativeCalls.filter(call=>call[0]==='beginGesture'))).toEqual([['beginGesture','drums.level',7]]);
      |                                                                                                       ^ Error: expect(received).toEqual(expected) // deep equality
  27  |   await page.mouse.move(box.x+box.width/2,box.y+box.height/2-30,{steps:5});
  28  |   await expect.poll(()=>page.evaluate(()=>window.nativeCalls.filter(call=>call[0]==='setParameter').length)).toBeGreaterThan(0);
  29  |   expect(await page.evaluate(()=>window.nativeCalls.filter(call=>call[0]==='endGesture'))).toEqual([]);
  30  |   await page.mouse.up();
  31  |   await expect.poll(()=>page.evaluate(()=>window.nativeCalls.filter(call=>call[0]==='endGesture'))).toEqual([['endGesture','drums.level',7]]);
  32  |   expect(await page.evaluate(()=>window.nativeCalls.filter(call=>call[0]==='setParameter').every(call=>call[1]==='drums.level'))).toBe(true);
  33  | });
  34  | 
  35  | test('the production entrypoint uses the versioned host instead of the comparison bridge',async({page})=>{
  36  |   await page.addInitScript(initial=>{
  37  |     window.nativeCalls=[];
  38  |     const backend={addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:name=>async(...args)=>{
  39  |       window.nativeCalls.push([name,...args]);
  40  |       if(name==='negotiateEditorProtocol')return window.__TEST_EDITOR_PROFILE__;
  41  |       if(name==='getSamplerSession')return initial;
  42  |       if(name==='subscribeMeter'||name==='setMeterVisible')return true;
  43  |       if(name==='requestSourceWaveform')return {status:'accepted',job_id:'1',generation:initial.document.generation};
  44  |       if(name==='getWaveformJobStatus')return {state:'ready',generation:initial.document.generation,result:{buckets:[]}};
  45  |       return null;
  46  |     }};
  47  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',backend};
  48  |     window.__JUCE__={backend:{getNativeFunction:()=>{throw new Error('Comparison bridge must remain unused');}}};
  49  |   },session());
  50  |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  51  |   await expect(page.getByRole('banner').locator('[data-backend="native"]')).toBeVisible();
  52  |   expect(await page.evaluate(()=>window.nativeCalls.filter(call=>call[0]==='setTriggerWindowTitle'))).toEqual([['setTriggerWindowTitle','Advanced Drum Kit']]);
  53  |   await expect(page.getByRole('alert')).toHaveCount(0);
  54  | });
  55  | 
  56  | test('an incompatible declared native host displays an error and never opens the silent preview',async({page})=>{
  57  |   await page.addInitScript(()=>{window.__DANDRUM__={protocolVersion:2};});
  58  |   await page.goto('/');
  59  |   await expect(page.getByRole('alert')).toHaveText('Native sampler failed: Unsupported native transport protocol version');
  60  |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  61  | });
  62  | 
  63  | test('a rejected native snapshot displays its capability error without simulating an instrument',async({page})=>{
  64  |   await page.addInitScript(()=>{
  65  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',backend:{addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:name=>async()=>{
  66  |       if(name==='negotiateEditorProtocol')return window.__TEST_EDITOR_PROFILE__;
  67  |       throw Object.assign(new Error('Session snapshot capability unavailable'),{code:'capabilityUnavailable',method:'getSamplerSession'});
  68  |     }}};
  69  |   });
  70  |   await page.goto('/');await expect(page.getByRole('alert')).toHaveText('Native sampler failed: Session snapshot capability unavailable');
  71  |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  72  | });
  73  | 
  74  | test('an ordinary browser continues to show an explicitly silent preview',async({page})=>{
  75  |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  76  |   await expect(page.getByRole('banner').locator('[data-backend="mock"]')).toContainText(/silent/i);
  77  |   await expect(page.getByRole('alert')).toHaveCount(0);
  78  | });
  79  | 
  80  | 
  81  | test('explicit absent services render accepted controls with unavailable measurements and host-controlled size',async({page},testInfo)=>{
  82  |   const errors=[];page.on('pageerror',error=>errors.push(error.message));
  83  |   await page.addInitScript(initial=>{
  84  |     window.nativeCalls=[];
  85  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend:{addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:name=>async(...args)=>{
  86  |       window.nativeCalls.push([name,...args]);if(name==='negotiateEditorProtocol')return window.__TEST_EDITOR_PROFILE__;if(name==='getSamplerSession')return initial;
  87  |       throw Object.assign(new Error('Unsupported '+name),{code:'capabilityUnavailable',method:name});
  88  |     }}};
  89  |   },(()=>{const graph=parse(yaml);graph.assets.sample_sources[0].regions[0].loop={mode:'forward',start_frame:0,end_frame:10000,crossfade_ms:0};return session(stringify(graph));})());
  90  |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  91  |   const header=page.getByRole('banner');
  92  |   await expect(header.getByTestId('backend-status')).toHaveText('Connected');
  93  |   await expect(header).toContainText('Voices — / 8');
  94  |   await expect(header.getByText('Meters unavailable',{exact:true})).toBeVisible();
  95  |   await expect(header.getByText('Size controlled by host',{exact:true})).toBeVisible();
  96  |   await expect(header.getByRole('radio')).toHaveCount(0);
  97  |   await expect(header.getByRole('button',{name:'Collapse',exact:true})).toHaveCount(0);
  98  |   await expect(page.getByRole('img',{name:'Waveform unavailable'}).first()).toBeVisible();
  99  |   await expect(page.locator('[data-knob="drums.level"]')).toBeVisible();
  100 |   await expect(page.getByRole('spinbutton',{name:'Loop start',exact:true})).toBeVisible();
  101 |   await expect(page.getByRole('img',{name:'Waveform unavailable'})).toHaveCount(4);
  102 |   await expect(page.getByRole('img',{name:'Waveform unavailable'}).locator('svg')).toHaveCount(0);
  103 |   await page.getByRole('tab',{name:/^Slices/}).click();await expect(page.getByRole('img',{name:'Waveform unavailable'})).toHaveCount(1);
  104 |   await page.getByRole('tab',{name:'Routing',exact:true}).click();await expect(page.getByText('Meters unavailable',{exact:true})).toHaveCount(2);
  105 |   await expect(page.getByRole('alert')).toHaveCount(0);
  106 |   expect(await page.evaluate(()=>window.nativeCalls.map(call=>call[0]))).toEqual(['negotiateEditorProtocol','getSamplerSession']);
  107 |   await page.screenshot({path:testInfo.outputPath('native-optional-unavailable.png'),animations:'disabled'});
  108 |   expect(errors).toEqual([]);
  109 | });
  110 | 
  111 | test('accepted voice-limit refresh updates the rendered header while meters remain unavailable',async({page})=>{
  112 |   await page.addInitScript(initial=>{
  113 |     window.nativeCalls=[];window.nativeSession=initial;window.nativeEvents={};
  114 |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend:{
  115 |       addEventListener:(name,listener)=>{window.nativeEvents[name]=listener;return name;},removeEventListener:name=>{delete window.nativeEvents[name];},
  116 |       getNativeFunction:name=>async(...args)=>{window.nativeCalls.push([name,...args]);if(name==='negotiateEditorProtocol')return window.__TEST_EDITOR_PROFILE__;if(name==='getSamplerSession')return window.nativeSession;throw Error('Unexpected '+name);},
  117 |     }};
  118 |   },session());
  119 |   await page.goto('/');const header=page.getByRole('banner');await expect(header).toContainText('Voices — / 8');
  120 |   await page.evaluate(async next=>{
  121 |     window.nativeSession=next;await window.nativeEvents.parameterStateChanged({generation:next.document.generation,sequence:0,parameters:[]});
  122 |   },session(yaml.replace('max_voices: 8','max_voices: 12'),8));
  123 |   await expect(header).toContainText('Voices — / 12');
  124 |   await expect(header.getByText('Meters unavailable',{exact:true})).toBeVisible();
  125 |   expect(await page.evaluate(()=>window.nativeCalls.map(call=>call[0]))).toEqual(['negotiateEditorProtocol','getSamplerSession','getSamplerSession']);
  126 |   await expect(page.getByRole('alert')).toHaveCount(0);
```