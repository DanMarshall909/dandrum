local function run()
reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,0),'B_MUTE',0);reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,1),'B_MUTE',0);reaper.GetSetProjectInfo_String(0,'RENDER_PATTERN','both-initial',true);reaper.Main_OnCommand(41824,0);return 'render complete'
end
return 'efbe12f944f14a668a55d772cb3276c1:'..tostring(run())
