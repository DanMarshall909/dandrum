local function run()
local t=reaper.GetTrack(0,0);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');if not ok then return 'state pending' end;local f=assert(io.open('/tmp/dandrum-task-7-3/final/instance-0-selected.b64','w'));f:write(s);f:close();return 'state captured'
end
return '75eedb9fd9634617b5c699d07a41a1cf:'..tostring(run())
