local function run()
for i=0,1 do reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,i),'B_MUTE',0) end; return 'renders complete with both tracks unmuted'
end
return '0bc8183766c14fa3bb5ba066261c7ddb:'..tostring(run())
