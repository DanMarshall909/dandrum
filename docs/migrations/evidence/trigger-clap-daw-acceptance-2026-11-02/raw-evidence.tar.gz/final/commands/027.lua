local function run()
reaper.OnStopButton();return 'stopped before sealing original accepted project'
end
return '2ea01e5e56064e539f6459742ddbc5c0:'..tostring(run())
