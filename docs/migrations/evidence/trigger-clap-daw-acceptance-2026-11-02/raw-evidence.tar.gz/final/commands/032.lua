local function run()
local root='/tmp/dandrum-task-7-3/final/'
local a=reaper.GetTrack(0,0);local b=reaper.GetTrack(0,1)
for i=0,1 do
 local t=reaper.GetTrack(0,i);reaper.TrackFX_Show(t,0,2);reaper.SetTrackAutomationMode(t,1)
 reaper.SetMediaItemInfo_Value(reaper.GetTrackMediaItem(t,0),'D_LENGTH',3)
end
reaper.SetEditCurPos(0,false,false);reaper.OnPlayButton()
local out=assert(io.open(root..'live-editor-lifecycle.tsv','w'));out:write('elapsed\tposition\tA\tB\tA_reopened\n')
local start=reaper.time_precise();local initial=0;local later=0;local reopened=false;local done=false
local function finish(ok,why)
 if done then return end;done=true;reaper.OnStopButton();out:close()
 for i=0,1 do reaper.SetMediaItemInfo_Value(reaper.GetTrackMediaItem(reaper.GetTrack(0,i),0),'D_LENGTH',1) end
 local f=assert(io.open(root..'live-editor-lifecycle-result.txt','w'));f:write((ok and 'PASS' or 'FAIL')..'\n'..why..'\n');f:close()
end
local tick
local function body()
 local elapsed=reaper.time_precise()-start;local p=reaper.GetPlayPosition()
 local av=reaper.TrackFX_GetParam(a,0,2);local bv=reaper.TrackFX_GetParam(b,0,2)
 out:write(string.format('%.9f\t%.9f\t%.9g\t%.9g\t%s\n',elapsed,p,av,bv,tostring(reopened)));out:flush()
 if p>0.15 and p<0.4 then assert(av==0.5 and bv==1.5,'initial automation with both editors absent');initial=initial+1 end
 if p>0.6 then assert(av==0.25 and bv==0.75,'later automation while B editor remains absent');later=later+1 end
 if p>0.65 and not reopened then reaper.TrackFX_Show(a,0,3);reopened=true end
 if p>2.2 then finish(initial>=3 and later>=10 and reopened,'timed values with both editors closed, A reopened during playback, B remained closed')
 elseif elapsed>8 then finish(false,'live automation deadline') else reaper.defer(tick) end
end
tick=function()local ok,why=pcall(body);if not ok then finish(false,tostring(why))end end
reaper.defer(tick)
return 'editor-absent and reopen observer started'

end
return 'ca16b9f23e8a4f3093ab56a04a6a8404:'..tostring(run())
