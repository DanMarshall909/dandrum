local function run()
reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,0),'B_MUTE',0);reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,1),'B_MUTE',1);reaper.GetSetProjectInfo_String(0,'RENDER_PATTERN','a-fresh',true);reaper.Main_OnCommand(41824,0);return 'render complete'
end
return '957a8fb2ec194d7abb27fe43c0f4b348:'..tostring(run())
