local function run()
local a=reaper.GetTrack(0,0);local b=reaper.GetTrack(0,1);assert(reaper.TrackFX_GetOpen(a,0));assert(not reaper.TrackFX_GetOpen(b,0));assert(reaper.TrackFX_GetParam(a,0,2)==0.25 and reaper.TrackFX_GetParam(b,0,2)==0.75);return string.format('PASS A open B absent; A=0.25 B=0.75 during playback at %.9f',reaper.GetPlayPosition())
end
return '49829e42a4224d02ae6a329581cf1631:'..tostring(run())
