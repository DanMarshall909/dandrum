local function run()
local a=reaper.GetTrack(0,0);local b=reaper.GetTrack(0,1);assert(reaper.TrackFX_GetOpen(a,0));assert(not reaper.TrackFX_GetOpen(b,0));assert(reaper.TrackFX_GetParam(a,0,2)==0.25 and reaper.TrackFX_GetParam(b,0,2)==0.75);local f=assert(io.open('/tmp/dandrum-task-7-3/final/editor-feedback-receipt.txt','w'));f:write('PASS\nA editor open after playback, B editor absent; A=0.25 B=0.75; both tracks unmuted; I_PERFFLAGS=2\n');f:close();return 'feedback and editor presence confirmed'
end
return 'a6af1a75829a406583fe40466175f86f:'..tostring(run())
