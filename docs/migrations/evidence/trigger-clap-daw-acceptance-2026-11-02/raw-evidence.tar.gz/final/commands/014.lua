local function run()
local t=reaper.GetTrack(0,1);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');if not ok then return 'state pending' end;local f=assert(io.open('/tmp/dandrum-task-7-3/final/instance-1-selected.b64','w'));f:write(s);f:close();return 'state captured'
end
return 'd9038fce6dc040eca9acb4018ed7295f:'..tostring(run())
