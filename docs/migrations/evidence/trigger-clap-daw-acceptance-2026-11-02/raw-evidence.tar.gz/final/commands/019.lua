local function run()
local t=reaper.GetTrack(0,0);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');if not ok then return 'state pending' end;local f=assert(io.open('/tmp/dandrum-task-7-3/final/instance-a-after-b.b64','w'));f:write(s);f:close();return 'state captured'
end
return 'eab36f7cf05842e688452a7a25e008a1:'..tostring(run())
