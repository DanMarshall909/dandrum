local function run()
local t=reaper.GetTrack(0,0);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');if not ok then return 'state pending' end;local f=assert(io.open('/tmp/dandrum-task-7-3/final/instance-0-selected.b64','w'));f:write(s);f:close();return 'state captured'
end
return 'fcd1468ce1f34f06a9c676ad68203649:'..tostring(run())
