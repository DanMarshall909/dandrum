local function run()
reaper.TrackFX_Show(reaper.GetTrack(0,0),0,2);reaper.TrackFX_Show(reaper.GetTrack(0,1),0,3);return 'show B before observing'
end
return 'd496843a01fd45048dc310099da3fcec:'..tostring(run())
