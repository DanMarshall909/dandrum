local function run()
local t=reaper.GetTrack(0,1);local r={};for p=0,reaper.TrackFX_GetNumParams(t,0)-1 do local ok,name=reaper.TrackFX_GetParamName(t,0,p,'');assert(ok);if name:find('drums.',1,true)==1 then r[#r+1]=string.format('{"id":"%s","value":%.17g}',name,reaper.TrackFX_GetParam(t,0,p)) end end;return '['..table.concat(r,',')..']'
end
return '5377e80f3a9244ab9becaacf40ae66f3:'..tostring(run())
