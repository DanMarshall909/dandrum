local function run()
local a=reaper.GetTrack(0,0);local b=reaper.GetTrack(0,1);return string.format('Aopen=%s Bopen=%s A=%.17g B=%.17g muteA=%s muteB=%s flagsA=%s flagsB=%s',tostring(reaper.TrackFX_GetOpen(a,0)),tostring(reaper.TrackFX_GetOpen(b,0)),reaper.TrackFX_GetParam(a,0,2),reaper.TrackFX_GetParam(b,0,2),reaper.GetMediaTrackInfo_Value(a,'B_MUTE'),reaper.GetMediaTrackInfo_Value(b,'B_MUTE'),reaper.GetMediaTrackInfo_Value(a,'I_PERFFLAGS'),reaper.GetMediaTrackInfo_Value(b,'I_PERFFLAGS'))
end
return '6b19b7e159a741f5ae8f6bdd9c70390f:'..tostring(run())
