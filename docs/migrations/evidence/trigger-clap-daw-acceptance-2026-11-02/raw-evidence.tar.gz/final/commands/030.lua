local function run()
local t=reaper.GetTrack(0,1);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');if not ok then return 'state pending' end;local f=assert(io.open('/tmp/dandrum-task-7-3/final/fresh-restored-1.b64','w'));f:write(s);f:close();return 'state captured'
end
return '2d11fb0395b7467ca7b746ae5b856546:'..tostring(run())
