local function run()
reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,0),'B_MUTE',0);reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,1),'B_MUTE',1);reaper.GetSetProjectInfo_String(0,'RENDER_PATTERN','a-fresh',true);reaper.Main_OnCommand(41824,0);return 'render complete'
end
return '95898b0985b345459c800fc707ca8d8d:'..tostring(run())
