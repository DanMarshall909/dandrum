local function run()
reaper.TrackFX_Show(reaper.GetTrack(0,1),0,2);reaper.TrackFX_Show(reaper.GetTrack(0,0),0,3);return 'native editor shown'
end
return '9ae84cdfa31f4dc0b08fe6b9ff0e9086:'..tostring(run())
