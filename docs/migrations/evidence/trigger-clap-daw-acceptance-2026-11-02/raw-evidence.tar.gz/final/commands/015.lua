local function run()
local t=reaper.GetTrack(0,1);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');if not ok then return 'state pending' end;local f=assert(io.open('/tmp/dandrum-task-7-3/final/instance-1-selected.b64','w'));f:write(s);f:close();return 'state captured'
end
return 'b049e55eccc94f5780d5bcfadfbdb9ab:'..tostring(run())
