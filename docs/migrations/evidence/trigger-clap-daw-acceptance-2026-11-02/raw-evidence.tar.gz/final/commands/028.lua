local function run()
local t=reaper.GetTrack(0,0);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');if not ok then return 'state pending' end;local f=assert(io.open('/tmp/dandrum-task-7-3/final/fresh-restored-0.b64','w'));f:write(s);f:close();return 'state captured'
end
return '872844802f1545368299926d292481d6:'..tostring(run())
