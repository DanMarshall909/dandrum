local function run()
reaper.OnStopButton();for i=0,1 do reaper.SetMediaItemInfo_Value(reaper.GetTrackMediaItem(reaper.GetTrack(0,i),0),'D_LENGTH',1) end;return 'stop restores values at edit cursor 0 normally'
end
return 'ddee5717bc8649f8b60bf855035b9186:'..tostring(run())
