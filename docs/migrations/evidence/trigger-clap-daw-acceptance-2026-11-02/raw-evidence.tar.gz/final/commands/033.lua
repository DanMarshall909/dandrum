local function run()
reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,0),'B_MUTE',0);reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,1),'B_MUTE',0);reaper.GetSetProjectInfo_String(0,'RENDER_PATTERN','both-fresh',true);reaper.Main_OnCommand(41824,0);return 'render complete'
end
return '561ef07349d44b4ba6aef7126bc29ac7:'..tostring(run())
