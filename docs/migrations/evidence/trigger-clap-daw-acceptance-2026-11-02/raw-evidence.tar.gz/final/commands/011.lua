local function run()
reaper.TrackFX_Show(reaper.GetTrack(0,0),0,2);reaper.TrackFX_Show(reaper.GetTrack(0,1),0,3);return 'native editor shown'
end
return '29854537645b44cc98a16fa56106ba11:'..tostring(run())
