#!/usr/bin/env python3
"""Audit this recorded DAW run against its declared PCM and timeline inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import wave


def expected_samples(patterns, slots):
    expected = [0.0] * 96000
    for seconds, gains in [(0.25, [0.5, 1.5]), (0.75, [0.25, 0.75])]:
        for frame in range(256):
            # Existing decoder contract: preserve original stereo PCM in state,
            # use the arithmetic mean as the sampler's mono playback signal.
            sample = sum(sum(patterns[slot]['pattern_pcm16'][frame % 4])
                         / 65536 * gains[slot] for slot in slots)
            offset = round(seconds * 48000) * 2 + frame * 2
            expected[offset:offset + 2] = [sample, sample]
    return expected


def compare(actual, expected, name):
    assert len(actual) == len(expected), f'{name}: channel sample count'
    for index, (observed, wanted) in enumerate(zip(actual, expected)):
        assert observed == wanted, (
            f'{name}: signed PCM mismatch at frame {index // 2}, '
            f'channel {index % 2}: {observed} != {wanted}')


def main(root):
    patterns = json.loads((root / 'selected-fixtures.json').read_text())
    results = []
    for name, slots in [('both-initial.wav', [0, 1]), ('both-fresh.wav', [0, 1]),
                        ('a-fresh.wav', [0]), ('b-fresh.wav', [1])]:
        path = root / 'renders' / name
        with wave.open(str(path), 'rb') as wav:
            assert (wav.getframerate(), wav.getnchannels(), wav.getnframes(),
                    wav.getsampwidth()) == (48000, 2, 48000, 3), f'{name}: WAV format'
            raw = wav.readframes(wav.getnframes())
        actual = [int.from_bytes(raw[i:i + 3], 'little', signed=True) / 8388608
                  for i in range(0, len(raw), 3)]
        expected = expected_samples(patterns, slots)
        compare(actual, expected, name)
        results.append({'artifact': name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'checked_channel_samples': len(actual), 'result': 'PASS'})

        # Calibrate the oracle against a named, nonzero signed fault. This is
        # artifact-checker calibration, not a production mutation-test run.
        faulty = actual.copy()
        faulty[24000] = -faulty[24000]
        try:
            compare(faulty, expected, 'controlled-sign-fault')
        except AssertionError as error:
            assert 'signed PCM mismatch at frame 12000, channel 0' in str(error)
        else:
            raise AssertionError(f'{name}: oracle accepted the controlled sign fault')

    report = {'result': 'PASS', 'renders': results,
              'oracle_calibration': 'each render rejects a sign reversal at frame 12000/channel 0',
              'scope': 'recorded actual REAPER render artifacts; no future live-DAW/CI claim'}
    (root / 'render-verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    main(parser.parse_args().root)
