import shutil
assert final_proc.poll()==0,'diagnostic process must be closed before final replay'
old=root/'candidate-live-first-input'
assert not old.exists()
froot.rename(old)
froot.mkdir()
for d in ['commands','renders','originals','cache','tmp']:(froot/d).mkdir()
shutil.copy2(old/'selected-fixtures.json',froot/'selected-fixtures.json')
for name in ['selected-a.wav','selected-b.wav']:shutil.copy2(old/'originals'/name,froot/'originals'/name)
shutil.copy2(old/'gesture-observer.lua',froot/'gesture-observer.lua')
sequence=0
(root/'command.lua').unlink(missing_ok=True)
final_env=dict(final_env,XDG_CACHE_HOME=str(froot/'cache'),TMPDIR=str(froot/'tmp'))
final_log=(froot/'reaper.log').open('w')
final_proc=subprocess.Popen(['pw-jack',str(reaper_bin),'-newinst','-new','-nosplash','-cfgfile',str(root/'reaper-fixed-config/reaper.ini'),str(root/'setup-final.lua'),str(root/'watch-reaper.lua')],env=final_env,stdout=final_log,stderr=final_log,start_new_session=True)
children.append(final_proc)
print('new live-event candidate PID',final_proc.pid,flush=True)
