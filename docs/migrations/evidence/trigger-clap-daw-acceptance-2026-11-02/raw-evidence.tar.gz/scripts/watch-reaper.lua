local root='/tmp/dandrum-task-7-3/'
local function loop()
 local f=io.open(root..'command.lua','r')
 if f then
  local text=f:read('*a'); f:close(); os.remove(root..'command.lua')
  local fn,err=load(text,'task-7.3-command')
  local ok,result=false,err
  if fn then ok,result=pcall(fn) end
  local out=assert(io.open(root..'command-result.txt','w'))
  out:write(tostring(ok)..'\n'..tostring(result)..'\n'); out:close()
 end
 reaper.defer(loop)
end
loop()
