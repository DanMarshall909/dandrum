from pathlib import Path
import hashlib,json,tarfile
r=Path('/tmp/dandrum-task-7-3');out=Path('/home/dan/code/dandrum/docs/migrations/evidence/trigger-clap-daw-acceptance-2026-11-02')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pkg=r/'installed-fixed';files=[{'path':str(p.relative_to(pkg)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(pkg.rglob('*')) if p.is_file()]
assert len(files)==20
(out/'installed-manifest.json').write_text(json.dumps({'root':str(pkg),'files':files},indent=2)+'\n')
selected={}
def add(p,name=None):
 if p.is_file() and not p.is_symlink():selected[name or str(p.relative_to(r))]=p
for p in r.iterdir():
 if p.suffix in {'.log','.json','.txt','.tsv','.lua','.py','.c','.png'}:add(p,'scripts/'+p.name if p.suffix in {'.lua','.py','.c'} else 'exploration/'+p.name)
for base in ['final','candidate-without-live-flags','candidate-live-first-input','adapter-coverage','browser-old-behavior']:
 for p in (r/base).rglob('*'):
  rel=p.relative_to(r/base)
  if any(part in {'cache','tmp','fresh-cache','fresh-tmp','DandrumTrigger.resources','profiles'} for part in rel.parts):continue
  if p.suffix in {'.so','.clap','.rlib','.dmp'}:continue
  add(p)
for name in ['reaper.ini','reaper-clap-linux-x86_64.ini']:add(r/'reaper-fixed-config'/name,'host-config/'+name)
manifest=[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p)} for name,p in sorted(selected.items())]
(out/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'raw-evidence.tar.gz','w:gz') as tar:
 for name,p in sorted(selected.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(out/'raw-evidence.tar.gz','r:gz') as tar:
 assert len(tar.getmembers())==len(manifest)
 for item in manifest:assert hashlib.sha256(tar.extractfile(item['path']).read()).hexdigest()==item['sha256']
print('verified archive',len(manifest),'files', (out/'raw-evidence.tar.gz').stat().st_size,'bytes',flush=True)
