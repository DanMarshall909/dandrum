import re,struct
project=froot/'fresh-restoration-input.rpp'
chunks=re.findall(r'<STATE\s*\n(.*?)\n\s*>',project.read_text(),re.S)
sealed=[base64.b64decode(c) for c in chunks]
assert len(sealed)==2
for slot,b in enumerate(sealed):
    assert b[:8]==b'DTRGSTAT' and struct.unpack_from('<I',b,8)[0]==3
    (froot/f'sealed-project-state-{slot}.bin').write_bytes(b)
for fixture in json.loads((froot/'selected-fixtures.json').read_text()):
    p=froot/'originals'/fixture['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==fixture['sha256']
    assert p.read_bytes() in sealed[0 if fixture['path']=='selected-a.wav' else 1]
    p.unlink()
assert not list((froot/'originals').iterdir()) and final_proc.poll()==0
old_pid=final_proc.pid
for d in ['fresh-cache','fresh-tmp']:(froot/d).mkdir()
fresh_env=dict(final_env,XDG_CACHE_HOME=str(froot/'fresh-cache'),TMPDIR=str(froot/'fresh-tmp'))
assert 'LD_PRELOAD' not in fresh_env
fresh_log=(froot/'fresh-reaper.log').open('w')
final_proc=subprocess.Popen(['pw-jack',str(reaper_bin),'-newinst','-nosplash','-cfgfile',str(root/'reaper-fixed-config/reaper.ini'),str(project),str(root/'watch-reaper.lua')],env=fresh_env,stdout=fresh_log,stderr=fresh_log,start_new_session=True)
children.append(final_proc)
time.sleep(2)
for w in visible('About REAPER'):key(w,'Escape')
assert final_proc.pid!=old_pid
mapped=root/'installed-fixed/lib/clap/DandrumTrigger.clap'
assert str(mapped) in Path('/proc/'+str(final_proc.pid)+'/maps').read_text()
assert 'pointer-diag' not in Path('/proc/'+str(final_proc.pid)+'/maps').read_text()
for i in [0,1]:
    restored=snapshot(i,f'fresh-restored-{i}')
    assert restored==sealed[i],f'fresh CLAP state {i} differs from sealed project input'
    metadata=json.loads(restored[24:24+int.from_bytes(restored[12:16],'little')])
    names_values=json.loads(request(f"local t=reaper.GetTrack(0,{i});local r={{}};for p=0,reaper.TrackFX_GetNumParams(t,0)-1 do local ok,name=reaper.TrackFX_GetParamName(t,0,p,'');assert(ok);if name:find('drums.',1,true)==1 then r[#r+1]=string.format('{{\"id\":\"%s\",\"value\":%.17g}}',name,reaper.TrackFX_GetParam(t,0,p)) end end;return '['..table.concat(r,',')..']'"))
    assert names_values==metadata['parameters'] and len(names_values)==23
    (froot/f'fresh-parameters-{i}.json').write_text(json.dumps(names_values,indent=2)+'\n')
(froot/'fresh-state-verification.json').write_text(json.dumps({'result':'PASS','old_pid':old_pid,'old_exit':0,'fresh_pid':final_proc.pid,'plugin_sha256':hashlib.sha256(mapped.read_bytes()).hexdigest(),'new_cache':str(froot/'fresh-cache'),'new_tmp':str(froot/'fresh-tmp'),'original_selected_files_absent':True,'state_bytes':[len(b) for b in sealed],'all_named_physical_parameters_per_instance':23,'comparison':'complete restored CLAP bytes and every named physical value match sealed project input','instrumentation_absent':True},indent=2)+'\n')
print('FRESH FINAL STATE PASS',flush=True)
request((root/'live-lifecycle-final.lua').read_text())
time.sleep(2.7)
print((froot/'live-editor-lifecycle-result.txt').read_text(),flush=True)
xd('mousemove',675,758);time.sleep(.5);frame('final-fresh-editor-reopened-feedback')
render('both-fresh',None);render('a-fresh',1);render('b-fresh',0)
print('FRESH FINAL DAW RENDERS COMPLETE',flush=True)
