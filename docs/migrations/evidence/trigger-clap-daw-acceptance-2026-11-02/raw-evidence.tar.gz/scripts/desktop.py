"""One-run native DAW qualification console; all output belongs to task 7.3."""
import atexit, json, os, signal, subprocess, time
from pathlib import Path
from PIL import ImageGrab

root = Path('/tmp/dandrum-task-7-3')
env = dict(os.environ, DISPLAY=':93', XDG_RUNTIME_DIR='/run/user/1000',
           XDG_CONFIG_HOME=str(root/'private-config'),
           XDG_CACHE_HOME=str(root/'private-cache'),
           CLAP_PATH=str(root/'installed/lib/clap'), QT_SCALE_FACTOR='1',
           LIBGL_ALWAYS_SOFTWARE='1')
env.pop('XAUTHORITY', None)
children = []

def stop():
    for child in reversed(children):
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try: child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=5)
    print('owned launchers stopped:', [(p.pid,p.returncode) for p in children], flush=True)

atexit.register(stop)
assert not Path('/tmp/.X11-unix/X93').exists(), 'display already owned'
xlog = (root/'xvfb.log').open('wb')
xserver = subprocess.Popen([str(root/'xvfb/usr/bin/Xvfb'), ':93', '-screen','0',
                            '1600x1200x24','-nolisten','tcp'], stdout=xlog,
                           stderr=subprocess.STDOUT, start_new_session=True)
children.append(xserver)
for _ in range(100):
    if Path('/tmp/.X11-unix/X93').exists(): break
    if xserver.poll() is not None: raise RuntimeError('Xvfb stopped')
    time.sleep(.05)
qlog = (root/'private-qtractor.log').open('wb')
daw = subprocess.Popen(['pw-jack',str(root/'squashfs-root/AppRun'),
                        str(root/'project/qualification.qtr')],env=env,cwd=root,
                       stdout=qlog,stderr=subprocess.STDOUT,start_new_session=True)
children.append(daw)
(root/'runtime.json').write_text(json.dumps({'display':':93','xvfb':xserver.pid,
                                            'qtractor':daw.pid},indent=2)+'\n')

def xd(*args):
    r=subprocess.run(['xdotool',*map(str,args)],env=env,capture_output=True,
                     text=True,timeout=10)
    if r.returncode: raise RuntimeError(r.stderr or str(r.returncode))
    return r.stdout.strip()

def windows():
    ids=xd('search','--onlyvisible','--name','.*').split()
    result=[{'id':i,'name':xd('getwindowname',i),
             'geometry':xd('getwindowgeometry','--shell',i)} for i in ids]
    print(json.dumps(result,indent=2),flush=True)
    return result

def frame(name='private'):
    p=root/(name+'.png')
    ImageGrab.grab(xdisplay=':93').save(p)
    print(str(p),flush=True)

def key(wid,*keys):
    xd('windowfocus',wid)
    for k in keys: xd('key','--clearmodifiers',k)

def click(x,y,button=1):
    xd('mousemove',x,y,'click',button)

time.sleep(2)
print('DAW launcher',daw.pid,'exit',daw.poll(),flush=True)
windows()
frame('private-startup')
