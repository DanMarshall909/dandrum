for name in ['gesture-ready','gesture-pressed','gesture-released']:
    (root/name).unlink(missing_ok=True)
(root/'command.lua').write_text((root/'gesture-observer.lua').read_text())
deadline=time.monotonic()+4
while not (root/'gesture-ready').exists():
    assert time.monotonic()<deadline,'REAPER gesture observation not ready'
    time.sleep(.025)
xd('mousemove',675,758,'mousedown',1)
time.sleep(.15)
xd('mousemove',675,735)
(root/'gesture-pressed').write_text('actual XTest mouse held after native motion')
time.sleep(.75)
xd('mouseup',1)
(root/'gesture-released').write_text('actual XTest mouse released')
time.sleep(2.3)
frame('native-gesture-followed-by-automation')
print((root/'native-gesture-automation-result.txt').read_text() if (root/'native-gesture-automation-result.txt').exists() else 'observation pending')
