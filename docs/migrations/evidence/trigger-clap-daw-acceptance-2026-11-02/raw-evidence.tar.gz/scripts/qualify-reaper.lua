local root = '/tmp/dandrum-task-7-3/'
local f = assert(io.open(root .. 'reaper-api-qualification.txt', 'w'))
f:write('version=' .. reaper.GetAppVersion() .. '\n')
reaper.InsertTrackAtIndex(0, true)
local track = reaper.GetTrack(0, 0)
reaper.GetSetMediaTrackInfo_String(track, 'P_NAME', 'Trigger A', true)
local fx = reaper.TrackFX_AddByName(track, 'CLAPi: Dandrum Trigger', false, -1)
f:write('fx=' .. fx .. '\n')
for i=0,reaper.TrackFX_GetCount(track)-1 do
 local ok,name=reaper.TrackFX_GetFXName(track,i,'')
 f:write('plugin='..name..'\n')
 f:write('params='..reaper.TrackFX_GetNumParams(track,i)..'\n')
 reaper.TrackFX_Show(track,i,3)
end
f:close()
reaper.Main_SaveProjectEx(0, root .. 'project/reaper-qualification.rpp', 0)
