assert(reaper.CountTracks(0)==0,'final replay must start with a new empty DAW project')
for i=0,1 do
 reaper.InsertTrackAtIndex(i,true); local t=reaper.GetTrack(0,i)
 reaper.GetSetMediaTrackInfo_String(t,'P_NAME',i==0 and 'Trigger A' or 'Trigger B',true)
 assert(reaper.TrackFX_AddByName(t,'CLAPi: Dandrum Trigger',false,-1)==0)
 assert(reaper.TrackFX_SetParam(t,0,2,i==0 and 0.5 or 1.5))
end
reaper.TrackFX_Show(reaper.GetTrack(0,0),0,3)
local f=assert(io.open('/tmp/dandrum-task-7-3/final/setup-ready','w'));f:write(reaper.GetAppVersion());f:close()
