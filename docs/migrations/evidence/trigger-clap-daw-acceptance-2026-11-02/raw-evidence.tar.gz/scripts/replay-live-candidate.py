for w in visible('About REAPER'):key(w,'Escape')
time.sleep(.3)
assert not visible('About REAPER'),'dismiss the ordinary evaluation notice before host acceptance'
maps=Path('/proc/'+str(final_proc.pid)+'/maps').read_text()
plugin=root/'installed-fixed/lib/clap/DandrumTrigger.clap'
assert str(plugin) in maps,'DAW must map the final installed CLAP'
(froot/'host-provenance.json').write_text(json.dumps({
    'pid':final_proc.pid,'version':(froot/'setup-ready').read_text(),
    'executable':str(Path('/proc/'+str(final_proc.pid)+'/exe').resolve()),
    'mapped_plugin':str(plugin),'plugin_sha256':hashlib.sha256(plugin.read_bytes()).hexdigest(),
    'display':':93','ime_configuration':'linux_ime=1',
},indent=2)+'\n')

first=None
for slot,filename in enumerate(['selected-a.wav','selected-b.wav']):
    request(f"reaper.TrackFX_Show(reaper.GetTrack(0,{1-slot}),0,2);reaper.TrackFX_Show(reaper.GetTrack(0,{slot}),0,3);return 'native editor shown'")
    time.sleep(.4)
    # Screen coordinates are bound to the retained 1600x1200/scale-one fixture.
    # The production source chooser and real GTK entry receive XTest input.
    click(305,663)
    deadline=time.monotonic()+5
    while not visible('Choose Trigger samples'):
        assert time.monotonic()<deadline,'native chooser did not open'
        time.sleep(.025)
    chooser=visible('Choose Trigger samples')[0]
    key(chooser,'ctrl+l');time.sleep(.3);key(chooser,'ctrl+a')
    xd('type','--clearmodifiers','--delay','20',str(froot/'originals'/filename))
    time.sleep(.3);key(chooser,'Return')
    wanted=(froot/'originals'/filename).read_bytes()
    deadline=time.monotonic()+8
    while True:
        state=snapshot(slot,f'instance-{slot}-selected')
        if state is not None and wanted in state:break
        assert time.monotonic()<deadline,'selected WAV was not admitted into CLAP host state'
        time.sleep(.05)
    time.sleep(.3);frame(f'final-selected-{slot}')
    if slot==0:first=state
    else:assert snapshot(0,'instance-a-after-b')==first,'B import changed A state'

request('''local root='/tmp/dandrum-task-7-3/final/'
reaper.GetSetProjectInfo(0,'PROJECT_SRATE',48000,true)
reaper.GetSetProjectInfo(0,'PROJECT_SRATE_USE',1,true)
for i=0,1 do
 local t=reaper.GetTrack(0,i)
 local gain=i==0 and 0.5 or 1.5
 assert(reaper.TrackFX_GetParam(t,0,2)==gain)
 local item=reaper.CreateNewMIDIItemInProj(t,0,1,false);local take=reaper.GetActiveTake(item)
 for _,time in ipairs({0.25,0.75}) do
  assert(reaper.MIDI_InsertNote(take,false,false,reaper.MIDI_GetPPQPosFromProjTime(take,time),reaper.MIDI_GetPPQPosFromProjTime(take,time+0.05),0,48,127,false))
 end
 local e=reaper.GetFXEnvelope(t,0,2,true);assert(e);reaper.SetTrackAutomationMode(t,1)
 for _,p in ipairs({{0,gain},{0.5,gain/2},{1,gain/2}}) do assert(reaper.InsertEnvelopePoint(e,p[1],p[2],1,0,false,true)) end
 reaper.Envelope_SortPoints(e);reaper.TrackFX_Show(t,0,2)
end
for k,v in pairs({RENDER_SETTINGS=0,RENDER_BOUNDSFLAG=0,RENDER_STARTPOS=0,RENDER_ENDPOS=1,RENDER_SRATE=48000,RENDER_CHANNELS=2,RENDER_NORMALIZE=0,RENDER_TAILFLAG=0}) do reaper.GetSetProjectInfo(0,k,v,true) end
reaper.GetSetProjectInfo_String(0,'RENDER_FILE',root..'renders',true)
reaper.GetSetProjectInfo_String(0,'RENDER_FORMAT','evaw',true)
reaper.Main_SaveProjectEx(0,root..'two-selected-automated.rpp',0)
return 'two independent samples, MIDI and physical-value automation saved'
''')

def render(name,muted):
    request(f"reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,0),'B_MUTE',{int(muted==0)});reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,1),'B_MUTE',{int(muted==1)});reaper.GetSetProjectInfo_String(0,'RENDER_PATTERN','{name}',true);reaper.Main_OnCommand(41824,0);return 'render complete'")
    assert (froot/'renders'/(name+'.wav')).is_file(),'missing actual DAW render'
    dismiss_finished()
    time.sleep(.2)

render('both-initial',None)
render('a-fresh',1)
render('b-fresh',0)
request("for i=0,1 do reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,i),'B_MUTE',0) end; reaper.Main_SaveProjectEx(0,'/tmp/dandrum-task-7-3/final/fresh-restoration-input.rpp',0);return 'unmuted project saved for fresh process'")
print('FINAL PHASE 1 COMPLETE: actual imports, isolated states, automation and three DAW renders',flush=True)
