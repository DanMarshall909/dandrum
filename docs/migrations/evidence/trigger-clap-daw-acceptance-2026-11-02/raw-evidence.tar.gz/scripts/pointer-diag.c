#include <gtk/gtk.h>
#include <webkit2/webkit2.h>
static const char *script =
"(()=>{let log=(...a)=>console.log('POINTER_DIAG '+JSON.stringify(a));"
"window.addEventListener('error',e=>log('error',e.message,e.error?.stack));"
"for(let type of ['pointerdown','pointermove','pointerup','pointercancel','blur'])window.addEventListener(type,e=>{if(type!=='pointermove'||e.buttons)log(type,e.target?.outerHTML?.slice(0,300),e.button,e.buttons,e.target?.closest?.('[data-knob]')?.getAttribute('data-knob'))},true);"
"const capture=Element.prototype.setPointerCapture;Element.prototype.setPointerCapture=function(id){log('capture',this.outerHTML.slice(0,300),id);try{return capture.call(this,id)}catch(e){log('capture-error',e.message);throw e}};"
"const backend=window.__DANDRUM__?.backend;if(backend){const get=backend.getNativeFunction;backend.getNativeFunction=function(name){const f=get.call(this,name);return (...a)=>{if(/Gesture|Parameter/.test(name))log('command',name,a);const p=f(...a);return Promise.resolve(p).then(r=>{if(/Gesture|Parameter/.test(name))log('reply',name,r);return r},e=>{log('rejection',name,e.message,e.code);throw e})}};}log('installed');})()";
static void visit(GtkWidget *widget, gpointer data) {
 if (WEBKIT_IS_WEB_VIEW(widget) && !g_object_get_data(G_OBJECT(widget),"pointer-diag")) {
  g_object_set_data(G_OBJECT(widget),"pointer-diag",GINT_TO_POINTER(1));
  webkit_settings_set_enable_write_console_messages_to_stdout(webkit_web_view_get_settings(WEBKIT_WEB_VIEW(widget)),TRUE);
  webkit_web_view_run_javascript(WEBKIT_WEB_VIEW(widget),script,NULL,NULL,NULL);
 }
 if(GTK_IS_CONTAINER(widget))gtk_container_foreach(GTK_CONTAINER(widget),visit,NULL);
}
static gboolean tick(gpointer data) {if(gdk_display_get_default()){GList *windows=gtk_window_list_toplevels();g_list_foreach(windows,(GFunc)visit,NULL);g_list_free(windows);}return G_SOURCE_CONTINUE;}
__attribute__((constructor)) static void start(void) {g_timeout_add(1000,tick,NULL);}
