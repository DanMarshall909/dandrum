local root='/tmp/dandrum-task-7-3/'
assert(reaper.CountTracks(0)==2,'fresh DAW project must have two restored tracks')
local f=assert(io.open(root..'fresh-restored-values.tsv','w'))
f:write('slot\tlevel\n')
for i=0,1 do
 local t=reaper.GetTrack(0,i); assert(reaper.TrackFX_GetCount(t)==1)
 local ok,name=reaper.TrackFX_GetFXName(t,0,''); assert(ok and name:find('Dandrum Trigger',1,true))
 local ok,chunk=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk'); assert(ok)
 local c=assert(io.open(root..'fresh-restored-'..i..'.b64','w')); c:write(chunk); c:close()
 f:write(string.format('%d\t%.17g\n',i,reaper.TrackFX_GetParam(t,0,2)))
end
f:close()
return 'fresh REAPER project state inspected'
