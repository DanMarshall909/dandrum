request("reaper.TrackFX_Show(reaper.GetTrack(0,0),0,2);reaper.TrackFX_Show(reaper.GetTrack(0,1),0,3);return 'show B before observing'")
time.sleep(1.5)
frame('final-gesture-ready-editor')
for name in ['gesture-ready','gesture-pressed','gesture-released']:
    (froot/name).unlink(missing_ok=True)
request((froot/'gesture-observer.lua').read_text())
deadline=time.monotonic()+4
while not (froot/'gesture-ready').exists():
    assert time.monotonic()<deadline,'REAPER gesture observation not ready'
    time.sleep(.025)
xd('mousemove',675,758,'mousedown',1);time.sleep(.15)
xd('mousemove',675,735)
(froot/'gesture-pressed').write_text('actual XTest mouse held after native motion')
time.sleep(.75)
xd('mouseup',1)
(froot/'gesture-released').write_text('actual XTest mouse released')
time.sleep(2.3)
frame('final-native-gesture-followed-by-automation')
print((froot/'native-gesture-automation-result.txt').read_text() if (froot/'native-gesture-automation-result.txt').exists() else 'observation pending')
