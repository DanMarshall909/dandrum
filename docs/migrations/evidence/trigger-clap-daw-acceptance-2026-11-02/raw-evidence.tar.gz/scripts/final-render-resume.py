def dismiss_finished():
    for w in visible('^Finished in'):
        try:key(w,'Escape')
        except RuntimeError as error:
            if 'BadWindow' not in str(error) or w in visible('^Finished in'):raise
            with (froot/'observer-races.jsonl').open('a') as log:
                log.write(json.dumps({'operation':'dismiss completed render window','window':w,'error':str(error),'disposition':'window already absent after successful render receipt'})+'\n')

def render(name,muted):
    request(f"reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,0),'B_MUTE',{int(muted==0)});reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,1),'B_MUTE',{int(muted==1)});reaper.GetSetProjectInfo_String(0,'RENDER_PATTERN','{name}',true);reaper.Main_OnCommand(41824,0);return 'render complete'")
    assert (froot/'renders'/(name+'.wav')).is_file(),'missing actual DAW render'
    dismiss_finished();time.sleep(.2)

dismiss_finished()
render('a-fresh',1)
render('b-fresh',0)
request("for i=0,1 do reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,i),'B_MUTE',0) end; reaper.Main_SaveProjectEx(0,'/tmp/dandrum-task-7-3/final/fresh-restoration-input.rpp',0);return 'unmuted project saved for fresh process'")
print('FINAL PHASE 1 COMPLETE',flush=True)
