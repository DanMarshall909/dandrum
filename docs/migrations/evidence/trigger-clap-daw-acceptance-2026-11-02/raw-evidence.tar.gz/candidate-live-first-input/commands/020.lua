local function run()
local root='/tmp/dandrum-task-7-3/final/'
reaper.GetSetProjectInfo(0,'PROJECT_SRATE',48000,true)
reaper.GetSetProjectInfo(0,'PROJECT_SRATE_USE',1,true)
for i=0,1 do
 local t=reaper.GetTrack(0,i)
 local gain=i==0 and 0.5 or 1.5
 assert(reaper.TrackFX_GetParam(t,0,2)==gain)
 local item=reaper.CreateNewMIDIItemInProj(t,0,1,false);local take=reaper.GetActiveTake(item)
 for _,time in ipairs({0.25,0.75}) do
  assert(reaper.MIDI_InsertNote(take,false,false,reaper.MIDI_GetPPQPosFromProjTime(take,time),reaper.MIDI_GetPPQPosFromProjTime(take,time+0.05),0,48,127,false))
 end
 local e=reaper.GetFXEnvelope(t,0,2,true);assert(e);reaper.SetTrackAutomationMode(t,1)
 for _,p in ipairs({{0,gain},{0.5,gain/2},{1,gain/2}}) do assert(reaper.InsertEnvelopePoint(e,p[1],p[2],1,0,false,true)) end
 reaper.Envelope_SortPoints(e);reaper.TrackFX_Show(t,0,2)
end
for k,v in pairs({RENDER_SETTINGS=0,RENDER_BOUNDSFLAG=0,RENDER_STARTPOS=0,RENDER_ENDPOS=1,RENDER_SRATE=48000,RENDER_CHANNELS=2,RENDER_NORMALIZE=0,RENDER_TAILFLAG=0}) do reaper.GetSetProjectInfo(0,k,v,true) end
reaper.GetSetProjectInfo_String(0,'RENDER_FILE',root..'renders',true)
reaper.GetSetProjectInfo_String(0,'RENDER_FORMAT','evaw',true)
reaper.Main_SaveProjectEx(0,root..'two-selected-automated.rpp',0)
return 'two independent samples, MIDI and physical-value automation saved'

end
return 'e9a8c754144f4a44ba76cf0dcdfa851e:'..tostring(run())
