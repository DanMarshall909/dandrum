local function run()
for i=0,1 do reaper.SetMediaTrackInfo_Value(reaper.GetTrack(0,i),'B_MUTE',0) end; reaper.Main_SaveProjectEx(0,'/tmp/dandrum-task-7-3/final/fresh-restoration-input.rpp',0);return 'unmuted project saved for fresh process'
end
return '6c6623a93da44ec6abd93ae75169ecb6:'..tostring(run())
