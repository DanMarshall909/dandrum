local function run()
return reaper.TrackFX_GetParam(reaper.GetTrack(0,1),0,2)
end
return '121cfd6241a04aab8a85ff8ec1d0df79:'..tostring(run())
