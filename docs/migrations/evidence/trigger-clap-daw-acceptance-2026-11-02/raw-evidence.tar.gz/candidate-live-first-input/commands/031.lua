local function run()
reaper.TrackFX_Show(reaper.GetTrack(0,1),0,3);reaper.SetTrackAutomationMode(reaper.GetTrack(0,1),0);return 'B'
end
return '508ca0635b5f44799c353d5ec6eefb4b:'..tostring(run())
