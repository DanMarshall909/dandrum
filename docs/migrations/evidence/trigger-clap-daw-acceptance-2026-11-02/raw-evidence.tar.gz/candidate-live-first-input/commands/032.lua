local function run()
return reaper.TrackFX_GetParam(reaper.GetTrack(0,1),0,2)
end
return 'b3f02ee14e694c19bf4ae72ec35245ea:'..tostring(run())
