local function run()
return 'global='..reaper.GetGlobalAutomationOverride()..', A='..reaper.GetTrackAutomationMode(reaper.GetTrack(0,0))..', B='..reaper.GetTrackAutomationMode(reaper.GetTrack(0,1))
end
return '6714f6ee2eed4549b64b8f1f923389c0:'..tostring(run())
