local function run()
reaper.TrackFX_Show(reaper.GetTrack(0,1),0,3);reaper.SetTrackAutomationMode(reaper.GetTrack(0,1),0);return 'B editor diagnostic'
end
return 'e95aa4f6e7114076ae895109ff69a927:'..tostring(run())
