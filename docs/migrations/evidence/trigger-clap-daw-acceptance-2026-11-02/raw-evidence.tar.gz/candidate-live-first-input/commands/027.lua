local function run()
return reaper.TrackFX_GetParam(reaper.GetTrack(0,1),0,2)
end
return '827c9452fa16487189dfbae41a1e29a2:'..tostring(run())
