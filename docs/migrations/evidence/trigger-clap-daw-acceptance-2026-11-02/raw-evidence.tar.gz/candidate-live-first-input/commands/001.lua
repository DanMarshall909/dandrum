local function run()
reaper.TrackFX_Show(reaper.GetTrack(0,1),0,2);reaper.TrackFX_Show(reaper.GetTrack(0,0),0,3);return 'native editor shown'
end
return '063b811641234f9f8856c27f1a66dd99:'..tostring(run())
