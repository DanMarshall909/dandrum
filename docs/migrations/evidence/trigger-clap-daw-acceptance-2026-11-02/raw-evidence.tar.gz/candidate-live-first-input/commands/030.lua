local function run()
return reaper.TrackFX_GetParam(reaper.GetTrack(0,1),0,2)
end
return '51e8684c0e2f4062aae8094086921132:'..tostring(run())
