local function run()
reaper.TrackFX_Show(reaper.GetTrack(0,0),0,2);reaper.TrackFX_Show(reaper.GetTrack(0,1),0,3);return 'native editor shown'
end
return 'df7df1b0c91646d188f474f131be2ff1:'..tostring(run())
