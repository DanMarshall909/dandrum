local function run()
local root='/tmp/dandrum-task-7-3/final/'
local a=reaper.GetTrack(0,0); local b=reaper.GetTrack(0,1)
reaper.TrackFX_Show(a,0,2); reaper.TrackFX_Show(b,0,3)
reaper.SetTrackAutomationMode(b,2)
for i=0,1 do reaper.SetMediaItemInfo_Value(reaper.GetTrackMediaItem(reaper.GetTrack(0,i),0),'D_LENGTH',10) end
reaper.SetEditCurPos(0.6,false,false)
reaper.OnPlayButton()
local out=assert(io.open(root..'native-gesture-automation.tsv','w'))
out:write('elapsed\tA\tB\tpressed\treleased\n')
local begin=reaper.time_precise(); local pressed_at=nil; local stable_held=0; local saw_change=false; local released_at=nil; local done=false
local function exists(p) local f=io.open(root..p,'r'); if f then f:close(); return true end; return false end
local function finish(ok,why)
 if done then return end; done=true; reaper.OnStopButton(); out:close()
 for i=0,1 do reaper.SetMediaItemInfo_Value(reaper.GetTrackMediaItem(reaper.GetTrack(0,i),0),'D_LENGTH',1) end
 local f=assert(io.open(root..'native-gesture-automation-result.txt','w')); f:write((ok and 'PASS' or 'FAIL')..'\n'..tostring(why)..'\n'); f:close()
end
local tick
local function body()
 local elapsed=reaper.time_precise()-begin
 local av=reaper.TrackFX_GetParam(a,0,2); local bv=reaper.TrackFX_GetParam(b,0,2)
 local pressed=exists('gesture-pressed'); local released=exists('gesture-released')
 out:write(string.format('%.9f\t%.9g\t%.9g\t%s\t%s\n',elapsed,av,bv,tostring(pressed),tostring(released))); out:flush()
 assert(av==0.25,'B native gesture disturbed A automation')
 if elapsed>0.15 and not exists('gesture-ready') then
  assert(bv==0.75,'B initial host automation'); local f=assert(io.open(root..'gesture-ready','w')); f:write('READY'); f:close()
 end
 if pressed and not pressed_at then pressed_at=elapsed end
 if pressed and not released and math.abs(bv-0.75)>0.01 then saw_change=true end
 if pressed and not released and elapsed-pressed_at>0.3 and elapsed-pressed_at<0.6 then
  assert(math.abs(bv-1.21)<0.000001,'held drag returned to host automation before mouse release')
  stable_held=stable_held+1
 end
 if released and not released_at then released_at=elapsed end
 if released_at and elapsed-released_at>2.0 then
  finish(saw_change and stable_held>=3 and bv==0.75,'B remains at native 1.21 during held drag, then returns to host automation 0.75 after release; A remains 0.25')
 elseif elapsed>8 then finish(false,'eight-second gesture observation deadline')
 else reaper.defer(tick) end
end
tick=function() local ok,err=pcall(body); if not ok then finish(false,err) end end
reaper.defer(tick)
return 'native gesture observer started'

end
return 'daa6e8397f1a44ccac08a159214dc883:'..tostring(run())
