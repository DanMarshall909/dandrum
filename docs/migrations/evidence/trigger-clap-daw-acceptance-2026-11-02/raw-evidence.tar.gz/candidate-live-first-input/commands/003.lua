local function run()
local t=reaper.GetTrack(0,0);local ok,s=reaper.TrackFX_GetNamedConfigParm(t,0,'clap_chunk');if not ok then return 'state pending' end;local f=assert(io.open('/tmp/dandrum-task-7-3/final/instance-0-selected.b64','w'));f:write(s);f:close();return 'state captured'
end
return 'dc5211acad7049bfa7f9b1fd762a2401:'..tostring(run())
