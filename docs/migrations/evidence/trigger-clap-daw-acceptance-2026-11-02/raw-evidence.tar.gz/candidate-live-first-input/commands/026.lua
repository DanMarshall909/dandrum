local function run()
reaper.OnStopButton();local b=reaper.GetTrack(0,1);reaper.SetTrackAutomationMode(b,0);assert(reaper.TrackFX_SetParam(b,0,2,0.75));return 'stopped manual B'
end
return 'd7135656719c4fe7ada7e5b35915a00e:'..tostring(run())
