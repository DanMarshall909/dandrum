from pathlib import Path
import os,json,hashlib,subprocess,shutil,tarfile,time
out=Path(__file__).parent/'session-foundation-coverage-final';scratch=Path(os.environ['DANDRUM_VERIFICATION_SCRATCH']);binding=json.loads((out/'binding.json').read_text());new=out/'replay-objects.tar.gz';receipt=out/'replay-object-derivation.json';assert not new.exists() and not receipt.exists()
def sha(path):
 d=hashlib.sha256()
 with path.open('rb') as f:
  while data:=f.read(1024*1024):d.update(data)
 return d.hexdigest()
strip=Path(shutil.which('strip')).resolve();cov=Path(subprocess.check_output(['/home/dan/.cargo/bin/rustc','--print','sysroot'],text=True).strip())/'lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-cov';rows=[]
with tarfile.open(new,'w:gz',compresslevel=6) as archive:
 for i,obj in enumerate(binding['objects']):
  original=Path(obj['path']);assert sha(original)==obj['sha256'];copy=scratch/original.name;shutil.copyfile(original,copy);before=copy.stat().st_size
  subprocess.run([str(strip),'--strip-debug',str(copy)],check=True,capture_output=True)
  argv=[str(cov),'export',str(copy),'--instr-profile',str(out/'merged.profdata')];actual=subprocess.run(argv,capture_output=True,check=True);expected=(out/('object-'+str(i)+'-export.stdout')).read_bytes();assert json.loads(actual.stdout)==json.loads(expected),'debug-free copy changed source-bound coverage export'
  rows.append({'original_path':str(original),'original_sha256':obj['sha256'],'original_bytes':before,'replay_member':copy.name,'replay_sha256':sha(copy),'replay_bytes':copy.stat().st_size,'expected_export_sha256':hashlib.sha256(expected).hexdigest(),'actual_export_sha256':hashlib.sha256(actual.stdout).hexdigest(),'argv':argv,'stderr':actual.stderr.decode()});archive.add(copy,arcname=copy.name,recursive=False);copy.unlink();assert sha(original)==obj['sha256']
with tarfile.open(new) as archive:
 assert len(archive.getmembers())==len(rows)
 for row in rows:
  d=hashlib.sha256();f=archive.extractfile(row['replay_member'])
  while data:=f.read(1024*1024):d.update(data)
  assert d.hexdigest()==row['replay_sha256']
record={'scope':'Current focused coverage replay completion. Only owned scratch copies are stripped of debug and archived after exact LLVM JSON export equality. Original cached ELFs, source snapshots, logs, profiles and tools remain unchanged. Original binding archive_pending=true is resolved by this independent completion receipt. No portable full-engine coverage claim.','complete':True,'binding_sha256':sha(out/'binding.json'),'strip':{'path':str(strip),'sha256':sha(strip)},'replay_archive':{'path':str(new),'sha256':sha(new),'bytes':new.stat().st_size},'objects':rows,'scope_gaps':['Raw source snapshots/profiles cover four measured executables; the separately passing1091ordinary engine unit cases are not an instrumented engine-unit executable in this focused scope.','C++ FFI, native physical input, browser ingress, portable restore, named-DAW and final release gates remain pending.']};receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'objects':len(rows),'replay_bytes':new.stat().st_size,'complete':True}),flush=True)
