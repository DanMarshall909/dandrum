from pathlib import Path
import subprocess,json,time,hashlib,sys
out=Path(__file__).parent;root=Path('/tmp/dandrum-lanes/integration');cargo='/home/dan/.cargo/bin/cargo';rows=[]
for owner,extra in [('instrument-session',[]),('trigger-host',[]),('clap-adapter',['--features','trigger-editor'])]:
 for action,args in [('fmt',['--','--check']),('test',['--offline','--locked',*extra,*(['--lib'] if owner=='clap-adapter' else [])]),('clippy',['--offline','--locked',*extra,'--all-targets','--no-deps','--','-D','warnings'])]:
  argv=[cargo,action,'--manifest-path','src/'+owner+'/Cargo.toml',*args];start=time.monotonic();p=subprocess.run(argv,cwd=root,capture_output=True);name=owner+'-'+action
  for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:
   with (out/(name+'.'+stream)).open('xb') as f:f.write(data)
  rows.append({'name':name,'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
  if p.returncode:sys.exit(p.returncode)
