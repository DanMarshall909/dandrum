from pathlib import Path
import os,subprocess,sys
scratch=Path(os.environ['DANDRUM_VERIFICATION_SCRATCH'])
env=dict(os.environ,DANDRUM_MODULE_LIBRARY_ROOT=str(scratch/'lib'),DANDRUM_USER_LIBRARY_ROOT=str(scratch/'modules'),RUST_TEST_THREADS='1')
sys.exit(subprocess.run(['scripts/check-rust-coverage'],env=env).returncode)
