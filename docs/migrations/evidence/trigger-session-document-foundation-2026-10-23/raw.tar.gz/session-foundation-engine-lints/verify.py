from pathlib import Path
import subprocess,json,hashlib,time,collections
out=Path(__file__).parent;rows=[];c='/home/dan/.cargo/bin/cargo'
for name,extra in [('strict',['--','-D','warnings']),('diagnostic',[])]:
 argv=[c,'clippy','--offline','--locked','--manifest-path','src/rust-engine/Cargo.toml','--all-targets','--no-deps','--message-format=json',*extra];t=time.monotonic();p=subprocess.run(argv,capture_output=True)
 for suffix,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  with (out/(name+'.'+suffix)).open('xb') as f:f.write(data)
 rows.append(dict(name=name,argv=argv,exit=p.returncode,seconds=time.monotonic()-t,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()))
(out/'phases.json').write_text(json.dumps(rows,indent=2)+'\n')
def key(path):
 result=collections.Counter()
 for line in path.read_text().splitlines():
  try:r=json.loads(line)
  except json.JSONDecodeError:continue
  if r.get('reason')!='compiler-message':continue
  m=r['message'];code=m.get('code');spans=[s for s in m.get('spans',[]) if s.get('is_primary')]
  if not spans:continue
  result[json.dumps([code,m['message'],[[s['file_name'],[t['text'] for t in s.get('text',[])]] for s in spans]],sort_keys=True)]+=1
 return result
baseline=Path('/tmp/dandrum-evidence/trigger-selected-snapshot-foundation/engine-diagnostic-current-run/stdout.log');before=key(baseline);after=key(out/'diagnostic.stdout');new=after-before;removed=before-after
(out/'reconciliation.json').write_text(json.dumps(dict(baseline=str(baseline),baseline_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest(),current_sha256=hashlib.sha256((out/'diagnostic.stdout').read_bytes()).hexdigest(),baseline_occurrences=sum(before.values()),current_occurrences=sum(after.values()),new=dict(new),removed=dict(removed),strict='FAIL retained, never waived'),indent=2)+'\n')
assert rows[0]['exit']==101 and rows[1]['exit']==0 and not new and not removed
print(json.dumps(rows),flush=True)
