from pathlib import Path
import os,subprocess,sys,json
scratch=Path(os.environ['DANDRUM_VERIFICATION_SCRATCH'])
env=dict(os.environ,DANDRUM_MODULE_LIBRARY_ROOT=str(scratch/'lib'),DANDRUM_USER_LIBRARY_ROOT=str(scratch/'modules'))
print(json.dumps({'library':env['DANDRUM_MODULE_LIBRARY_ROOT'],'user':env['DANDRUM_USER_LIBRARY_ROOT'],'scope':'Owned disposable test library roots; HOME and existing libraries/caches unchanged'}),flush=True)
sys.exit(subprocess.run(['/home/dan/.cargo/bin/cargo','test','--offline','--locked','--manifest-path','src/rust-engine/Cargo.toml','--lib','--','--test-threads=1'],env=env).returncode)
