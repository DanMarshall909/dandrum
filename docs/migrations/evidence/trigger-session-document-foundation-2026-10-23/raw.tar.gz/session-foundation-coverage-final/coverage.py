from pathlib import Path
import os,subprocess,shlex,json,time,hashlib,tarfile,shutil
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;c='/home/dan/.cargo/bin/cargo';cache=Path(os.environ['CARGO_TARGET_DIR']);env=dict(os.environ);base_env=dict(os.environ);rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,argv,child_env=None):
 start=time.monotonic();p=subprocess.run(argv,cwd=root,env=child_env if child_env is not None else env,capture_output=True)
 for suffix,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  with (out/(name+'.'+suffix)).open('xb') as f:f.write(data)
 rows.append({'name':name,'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'phases.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0,name;return p.stdout.decode()
names=set()
for owner in ['instrument-session','rust-engine']:
 shown=run(owner+'-show-env',[c,'llvm-cov','show-env','--manifest-path','src/'+owner+'/Cargo.toml','--sh'],base_env)
 for line in shown.splitlines():
  parts=shlex.split(line);assert len(parts)==2 and parts[0]=='export';key,sep,value=parts[1].partition('=');assert sep
  if key=='__CARGO_LLVM_COV_RUSTC_WRAPPER_CRATE_NAMES':names.update(value.split(','))
  else:env[key]=value
for key in ['CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR']:env[key]=str(cache)
assert env.get('__CARGO_LLVM_COV_RUSTC_WRAPPER_PRE_EXISTING')!=env.get('RUSTC_WRAPPER'), 'recursive coverage wrapper is forbidden'
env['__CARGO_LLVM_COV_RUSTC_WRAPPER_CRATE_NAMES']=','.join(sorted(names));profiles=out/'profiles';profiles.mkdir();env['LLVM_PROFILE_FILE']=str(profiles/'%m-%p.profraw');(out/'environment.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('CARGO','__CARGO','LLVM','RUSTC'))},indent=2)+'\n');objects=[]
for label,owner,selection in [('session-owner','instrument-session',['--lib','--test','session','--test','precise_clocks','--test','render_configuration'])]:
 txt=run(label+'-compile',[c,'test','--manifest-path','src/'+owner+'/Cargo.toml','--offline','--locked',*selection,'--no-run','--message-format=json']);records=[json.loads(l) for l in txt.splitlines() if l.startswith('{')];artifacts=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('profile',{}).get('test')];assert artifacts
 for n,artifact in enumerate(artifacts):
  elf=Path(artifact['executable']);assert elf.resolve().is_relative_to(cache.resolve());objects.append({'path':str(elf),'sha256':sha(elf),'artifact':artifact,'owner':owner,'selection':selection});run(label+'-execute-'+str(n),[str(elf),*(['a_derived_resource_set'] if owner=='rust-engine' else []),'--nocapture','--test-threads=1'])
tools=Path(subprocess.check_output(['/home/dan/.cargo/bin/rustc','--print','sysroot'],text=True).strip())/'lib/rustlib/x86_64-unknown-linux-gnu/bin';raw=sorted(profiles.glob('*.profraw'));assert raw;merged=out/'merged.profdata';run('merge',[str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in raw],'-o',str(merged)]);args=[objects[0]['path'],*[arg for obj in objects[1:] for arg in ['--object',obj['path']]],'--instr-profile',str(merged)];
for i,obj in enumerate(objects):
 individual=json.loads(run('object-'+str(i)+'-export',[str(tools/'llvm-cov'),'export',obj['path'],'--instr-profile',str(merged)]));actual={f['filename'] for d in individual['data'] for f in d['files']};assert any(p.endswith('/rust-engine/src/preparation.rs' if obj['owner']=='rust-engine' else '/instrument-session/src/lib.rs') for p in actual),'each executable must instrument its changed owning dependency'
export=json.loads(run('export',[str(tools/'llvm-cov'),'export',*args]));run('annotation',[str(tools/'llvm-cov'),'show',*args,'--show-line-counts-or-regions']);mapped={f['filename'] for d in export['data'] for f in d['files']}
for ending in ['/instrument-session/src/lib.rs','/rust-engine/src/preparation.rs']:assert any(p.endswith(ending) for p in mapped),ending
(out/'binding.json').write_text(json.dumps({'objects':objects,'archive_pending':True,'profiles':{p.name:sha(p) for p in raw},'merged_sha256':sha(merged),'tools':{n:sha(tools/n) for n in ['llvm-cov','llvm-profdata']},'scope':'Complete format-neutral Session lib/session/precise_clocks/render_configuration tests after typed target-factory refactor; engine getter measured through real Session consumers. No full-engine, host wire, browser, native input, portable state or release completion claim.'},indent=2)+'\n');print('coverage complete',len(objects),'ELFs',len(raw),'profiles',flush=True)

summary={f['filename']:f['summary'] for d in export['data'] for f in d['files'] if any(f['filename'].endswith(p) for p in ['/trigger-host/src/protocol.rs','/trigger-host/src/parameters.rs','/trigger-host/src/runtime.rs','/instrument-session/src/lib.rs','/clap-adapter/src/trigger/gui.rs','/rust-engine/src/preparation.rs'])};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
