import sys, pathlib, subprocess, time, json, hashlib, shutil, os
root=pathlib.Path('/tmp/dandrum-lanes/frontend')
evidence=pathlib.Path('/tmp/dandrum-lanes/evidence-webview-transport')
label=sys.argv[1]; args=sys.argv[2:]; phase=evidence/label; phase.mkdir()
files=['web/trigger/engine/native-webview-transport.mjs','web/trigger/tests/native-webview-transport.test.mjs']
sources={}
for f in files:
 p=root/f
 if p.exists():
  sources[f]=hashlib.sha256(p.read_bytes()).hexdigest(); shutil.copyfile(p,phase/p.name)
 else: sources[f]=None
env=os.environ.copy()
if 'coverage' in label:
 env['NODE_V8_COVERAGE']=str(phase/'v8')
 subprocess.run(['df','-h',str(root)],stdout=(phase/'disk.log').open('w'))
start=time.time()
result=subprocess.run(args,cwd=root/'web/trigger',env=env,stdout=(phase/'output.log').open('w'),stderr=subprocess.STDOUT)
record={'label':label,'cwd':str(root/'web/trigger'),'command':args,'sourceSha256':sources,'exitCode':result.returncode,'elapsedSeconds':time.time()-start,'startedUnix':start,'node':'v22.19.0'}
record['sourceAfterSha256']={f:hashlib.sha256((root/f).read_bytes()).hexdigest() if (root/f).exists() else None for f in files}
record['sourceUnchanged']=record['sourceAfterSha256']==sources
(phase/'run.json').write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps(record))
print((phase/'output.log').read_text()[-1600:])
