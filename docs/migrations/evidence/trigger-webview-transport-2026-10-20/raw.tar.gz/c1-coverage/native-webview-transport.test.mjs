import test from 'node:test';
import assert from 'node:assert/strict';
import {createWebViewTransport} from '../engine/native-webview-transport.mjs';
import {selectNativeTransport} from '../engine/native-transport.mjs';

function connection(options={}){
  const sent=[];
  const transport=createWebViewTransport({instanceId:'17',attachmentId:'23',postMessage:message=>sent.push(message),...options});
  return {...transport,sent,call:(method,...args)=>transport.descriptor.backend.getNativeFunction(method)(...args)};
}
function reply(requestId,result,overrides={}){
  return JSON.stringify({version:1,instanceId:'17',attachmentId:'23',requestId,status:'accepted',result,...overrides});
}

test('the selected backend publishes positional version-1 requests and settles actual correlated outcomes',async()=>{
  const broker=connection();
  const selected=selectNativeTransport({__DANDRUM__:broker.descriptor});
  assert.equal(selected.backendId,'juce-free');
  assert.deepEqual(selected.capabilities,{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false});
  const first=selected.backend.getNativeFunction('setParameter')('drums.level',.37,7);
  const second=broker.call('getSamplerSession');
  assert.deepEqual(broker.sent.map(JSON.parse),[
    {version:1,attachmentId:'23',requestId:'1',method:'setParameter',args:['drums.level',.37,7]},
    {version:1,attachmentId:'23',requestId:'2',method:'getSamplerSession',args:[]},
  ]);
  assert.equal(broker.receive(reply('2',{generation:19,parameters:[]})),'reply');
  assert.deepEqual(await second,{generation:19,parameters:[]});
  const rejected=assert.rejects(first,reason=>reason.code==='capabilityUnavailable');
  assert.equal(broker.receive(reply('1',undefined,{status:'rejected',error:{code:'capabilityUnavailable'}})),'reply');
  await rejected;
});

test('the backend gives each listener a removable registration token',()=>{
  const {descriptor:{backend}}=connection();
  const one=backend.addEventListener('parameterStateChanged',()=>{});
  const two=backend.addEventListener('parameterStateChanged',()=>{});
  assert.notEqual(one,two);
  assert.equal(backend.removeEventListener(one),true);
  assert.equal(backend.removeEventListener(one),false);
  assert.equal(backend.removeEventListener(two),true);
});
