/** Browser-side correlation for an already admitted version-1 native attachment. */
export function createWebViewTransport({instanceId,attachmentId,postMessage,nextRequestId='1'}){
  let next=BigInt(nextRequestId);
  const pending=new Map(),listeners=new Map();
  const backend={
    getNativeFunction:method=>(...args)=>new Promise((resolve,reject)=>{
      const requestId=String(next++);
      pending.set(requestId,{resolve,reject});
      postMessage(JSON.stringify({version:1,attachmentId,requestId,method,args}));
    }),
    addEventListener(event,listener){
      const token=Symbol(event);
      listeners.set(token,{event,listener});
      return token;
    },
    removeEventListener:token=>listeners.delete(token),
  };
  function receive(message){
    const envelope=JSON.parse(message);
    const request=pending.get(envelope.requestId);
    pending.delete(envelope.requestId);
    if(envelope.status==='accepted')request.resolve(envelope.result);
    else request.reject(envelope.error);
    return 'reply';
  }
  const descriptor={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend};
  return {descriptor,receive};
}
