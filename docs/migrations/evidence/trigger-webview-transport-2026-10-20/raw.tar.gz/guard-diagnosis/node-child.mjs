import {spawnSync} from 'node:child_process';
const script='/tmp/dandrum-lanes/frontend/web/trigger/scripts/check-components.mjs';
const fixture='/tmp/dandrum-lanes/evidence-webview-transport/guard-diagnosis/fixture';
const args=[script,fixture];
const result=spawnSync(process.execPath,args,{encoding:'utf8',stdio:'pipe'});
console.log(JSON.stringify({parentPid:process.pid,node:process.execPath,args,cwd:process.cwd(),nodeEnv:Object.fromEntries(Object.entries(process.env).filter(([k])=>k.startsWith('NODE'))),...result},null,2));
