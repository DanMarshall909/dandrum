import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {createWebViewTransport} from './frozen/native-webview-transport.mjs';
import {patchFromSession} from '/tmp/dandrum-lanes/frontend/web/trigger/engine/native-document.mjs';
import {parseSessionConnection} from '/tmp/dandrum-lanes/frontend/web/trigger/engine/session-connection.mjs';
const artifact='/tmp/dandrum-lanes/evidence-host-snapshot-final-verification/parser/actual-replies.json';
const bytes=readFileSync(artifact),data=JSON.parse(bytes);
const cases=[];
for(const [name,envelope] of Object.entries({initial:data.initial,applied:data.applied})){
  const sent=[];
  const broker=createWebViewTransport({instanceId:'9007199254740993',attachmentId:'1',nextRequestId:'90',postMessage:message=>sent.push(message)});
  const result=broker.descriptor.backend.getNativeFunction('getSamplerSession')();
  assert.deepEqual(JSON.parse(sent[0]),{version:1,attachmentId:'1',requestId:'90',method:'getSamplerSession',args:[]});
  assert.equal(broker.receive(JSON.stringify(envelope)),'reply');
  const actual=await result;
  assert.deepEqual(actual,envelope.result);
  const connection=parseSessionConnection(actual.connection),patch=patchFromSession(actual);
  assert.equal(connection.instanceId,'9007199254740993');assert.equal(connection.attachmentId,'1');
  assert.equal(connection.nextRequestId,'1');assert.equal(connection.revision,'0');
  assert.equal(patch.id,'dandrum.advanced-drum-kit');assert.equal(patch.assets.length,1);
  assert.equal(patch.regions.length,6);assert.equal(patch.rules.length,5);
  assert.equal(Object.keys(patch.params).length,23);
  assert.equal(patch.params['drums.level'].value,name==='initial'?.25:.5);
  assert.equal(broker.receive(JSON.stringify(envelope)),'ignored');
  const future=broker.descriptor.backend.getNativeFunction('getParameterState')();
  const closed=assert.rejects(future,error=>error.code==='closed');broker.dispose();await closed;
  cases.push({name,transportRequestId:'90',structuralNextRequestId:'1',level:patch.params['drums.level'].value});
}
console.log(JSON.stringify({artifact,artifactSha256:createHash('sha256').update(bytes).digest('hex'),cases,
  scope:'Retained real Rust accepted snapshot replies through frozen broker and unchanged production parsers; no Rust execution, native WebView, rejected-reply emitter or event-emitter calibration in this run.'},null,2));
