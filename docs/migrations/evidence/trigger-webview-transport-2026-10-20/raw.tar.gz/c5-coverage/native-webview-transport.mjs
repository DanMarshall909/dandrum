const encoder=new TextEncoder();
const U64_MAX=18446744073709551615n;
function decimal(value){
  return typeof value==='string'&&/^[1-9][0-9]{0,19}$/.test(value)&&BigInt(value)<=U64_MAX;
}
function failure(code){return Object.assign(new Error(code),{code});}

/** Browser-side correlation for an already admitted version-1 native attachment. */
export function createWebViewTransport({instanceId,attachmentId,postMessage,nextRequestId='1'}){
  if(!decimal(instanceId)||!decimal(attachmentId)||!decimal(nextRequestId)||typeof postMessage!=='function')throw failure('invalidConfiguration');
  let next=BigInt(nextRequestId);
  const pending=new Map(),listeners=new Map();
  const backend={
    getNativeFunction:method=>(...args)=>new Promise((resolve,reject)=>{
      if(next>U64_MAX)throw failure('identityExhausted');
      if(pending.size>=128)throw failure('pendingFull');
      if(typeof method!=='string'||!method)throw failure('invalidArguments');
      const requestId=String(next);
      let message;
      try{
        message=JSON.stringify({version:1,attachmentId,requestId,method,args},(_key,value)=>{
          if(['undefined','function','symbol','bigint'].includes(typeof value)
            ||(typeof value==='number'&&!Number.isFinite(value)))throw failure('invalidArguments');
          return value;
        });
      }catch{throw failure('invalidArguments');}
      if(encoder.encode(message).length>16*1024)throw failure('oversized');
      next++;
      pending.set(requestId,{resolve,reject});
      try{postMessage(message);}
      catch(error){
        if(pending.delete(requestId))reject(error);
      }
    }),
    addEventListener(event,listener){
      const token=Symbol(event);
      listeners.set(token,{event,listener});
      return token;
    },
    removeEventListener:token=>listeners.delete(token),
  };
  // Returns 'reply' for a settled request, or 'ignored' without changing pending calls.
  function receive(message){
    if(typeof message!=='string'||encoder.encode(message).length>64*1024)return 'ignored';
    let envelope;
    try{envelope=JSON.parse(message);}catch{return 'ignored';}
    if(!envelope||typeof envelope!=='object'||Array.isArray(envelope)
      ||envelope.version!==1||envelope.instanceId!==instanceId||envelope.attachmentId!==attachmentId)return 'ignored';
    if(!decimal(envelope.requestId)||Object.hasOwn(envelope,'event')
      ||Object.hasOwn(envelope,'sequence')||Object.hasOwn(envelope,'payload'))return 'ignored';
    if(envelope.status==='accepted'){
      if(!Object.hasOwn(envelope,'result')||Object.hasOwn(envelope,'error'))return 'ignored';
    }else if(envelope.status==='rejected'){
      if(Object.hasOwn(envelope,'result')||!envelope.error||Array.isArray(envelope.error)
        ||typeof envelope.error.code!=='string'||!envelope.error.code)return 'ignored';
    }else return 'ignored';
    const request=pending.get(envelope.requestId);
    if(!request)return 'ignored';
    pending.delete(envelope.requestId);
    if(envelope.status==='accepted')request.resolve(envelope.result);
    else request.reject(envelope.error);
    return 'reply';
  }
  const descriptor={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend};
  return {descriptor,receive};
}
