import test from 'node:test';
import assert from 'node:assert/strict';
import {createWebViewTransport} from '../engine/native-webview-transport.mjs';
import {selectNativeTransport} from '../engine/native-transport.mjs';

function connection(options={}){
  const sent=[];
  const transport=createWebViewTransport({instanceId:'17',attachmentId:'23',postMessage:message=>sent.push(message),...options});
  return {...transport,sent,call:(method,...args)=>transport.descriptor.backend.getNativeFunction(method)(...args)};
}
function reply(requestId,result,overrides={}){
  return JSON.stringify({version:1,instanceId:'17',attachmentId:'23',requestId,status:'accepted',result,...overrides});
}

test('the selected backend publishes positional version-1 requests and settles actual correlated outcomes',async()=>{
  const broker=connection();
  const selected=selectNativeTransport({__DANDRUM__:broker.descriptor});
  assert.equal(selected.backendId,'juce-free');
  assert.deepEqual(selected.capabilities,{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false});
  const first=selected.backend.getNativeFunction('setParameter')('drums.level',.37,7);
  const second=broker.call('getSamplerSession');
  assert.deepEqual(broker.sent.map(JSON.parse),[
    {version:1,attachmentId:'23',requestId:'1',method:'setParameter',args:['drums.level',.37,7]},
    {version:1,attachmentId:'23',requestId:'2',method:'getSamplerSession',args:[]},
  ]);
  assert.equal(broker.receive(reply('2',{generation:19,parameters:[]})),'reply');
  assert.deepEqual(await second,{generation:19,parameters:[]});
  const rejected=assert.rejects(first,reason=>reason.code==='capabilityUnavailable');
  assert.equal(broker.receive(reply('1',undefined,{status:'rejected',error:{code:'capabilityUnavailable'}})),'reply');
  await rejected;
});

test('the backend gives each listener a removable registration token',()=>{
  const {descriptor:{backend}}=connection();
  const one=backend.addEventListener('parameterStateChanged',()=>{});
  const two=backend.addEventListener('parameterStateChanged',()=>{});
  assert.notEqual(one,two);
  assert.equal(backend.removeEventListener(one),true);
  assert.equal(backend.removeEventListener(one),false);
  assert.equal(backend.removeEventListener(two),true);
});

test('connection identities and request cursors must be canonical nonzero u64 decimal strings',()=>{
  const invalid=[undefined,null,0,1,1n,'','0','01','+1','1.0','1e2',' 1','1 ','-1','١','18446744073709551616','9'.repeat(100)];
  for(const name of ['instanceId','attachmentId','nextRequestId']){
    for(const value of invalid){
      if(name==='nextRequestId'&&value===undefined)continue;
      assert.throws(()=>connection({[name]:value}),error=>error.code==='invalidConfiguration',`${name}: ${String(value)}`);
    }
  }
  for(const postMessage of [undefined,null,{},'send'])assert.throws(()=>connection({postMessage}),error=>error.code==='invalidConfiguration');
});

test('transport IDs retain precision above 2^53 and reject exhaustion without reusing the final u64',async()=>{
  for(const [seed,expected] of [['9007199254740993',['9007199254740993','9007199254740994']],['18446744073709551615',['18446744073709551615']]]){
    const broker=connection({instanceId:'18446744073709551615',nextRequestId:seed});
    for(const id of expected){
      const value=broker.call('getParameterState');
      assert.equal(JSON.parse(broker.sent.at(-1)).requestId,id);
      broker.receive(reply(id,{generation:33},{instanceId:'18446744073709551615'}));
      assert.deepEqual(await value,{generation:33});
    }
    if(seed==='18446744073709551615'){
      await assert.rejects(broker.call('getParameterState'),error=>error.code==='identityExhausted');
      assert.equal(broker.sent.length,1);
    }
  }
});

test('outgoing JSON is limited to 16 KiB of UTF-8 without retaining failed requests',async()=>{
  const broker=connection();
  // Compute the byte boundary independently from the literal wire envelope.
  const empty='{"version":1,"attachmentId":"23","requestId":"1","method":"unknown","args":[""]}';
  const fill='é'.repeat(Math.floor((16384-Buffer.byteLength(empty))/2));
  const exact=fill+'x'.repeat(16384-Buffer.byteLength(empty)-Buffer.byteLength(fill));
  const accepted=broker.call('unknown',exact);
  assert.equal(Buffer.byteLength(broker.sent[0]),16384);
  broker.receive(reply('1',null));assert.equal(await accepted,null);
  for(let index=0;index<129;index++){
    const rejected=assert.rejects(broker.call('unknown',exact+'é'),error=>error.code==='oversized');
    assert.equal(broker.sent.length,1);await rejected;
  }
  assert.equal(broker.sent.length,1);
  const next=broker.call('getParameterState');
  assert.equal(JSON.parse(broker.sent[1]).requestId,'2');
  broker.receive(reply('2','actual'));assert.equal(await next,'actual');
});

test('malformed method and non-JSON arguments reject before posting or retaining a request',async()=>{
  const broker=connection(),cycle={};cycle.self=cycle;
  for(const method of [null,undefined,12,{},'']){
    const rejected=assert.rejects(broker.call(method),error=>error.code==='invalidArguments');
    assert.equal(broker.sent.length,0);await rejected;
  }
  for(const arg of [undefined,()=>{},Symbol('value'),1n,NaN,Infinity,-Infinity,cycle,{nested:undefined},[undefined],{toJSON(){throw new Error('cannot serialize');}}]){
    await assert.rejects(broker.call('setParameter',arg),error=>error.code==='invalidArguments');
  }
  assert.deepEqual(broker.sent,[]);
  const pending=broker.call('setParameter','drums.level',.5,11);
  assert.equal(JSON.parse(broker.sent[0]).requestId,'1');
  broker.receive(reply('1',{status:'accepted'}));assert.deepEqual(await pending,{status:'accepted'});
});

test('at most 128 unresolved requests are retained and settlement frees capacity',async()=>{
  const broker=connection(),calls=Array.from({length:128},()=>broker.call('noteHeartbeat'));
  const full=broker.call('noteHeartbeat');
  assert.equal(broker.sent.length,128);
  await assert.rejects(full,error=>error.code==='pendingFull');
  broker.receive(reply('64',64));assert.equal(await calls[63],64);
  const replacement=broker.call('noteHeartbeat');
  assert.equal(JSON.parse(broker.sent.at(-1)).requestId,'129');
  for(let index=0;index<128;index++)if(index!==63)broker.receive(reply(String(index+1),index+1));
  broker.receive(reply('129',129));
  assert.deepEqual(await Promise.all([...calls,replacement]),Array.from({length:129},(_,index)=>index+1));
});

test('synchronous post failures reject their actual reason and release capacity without reusing IDs',async()=>{
  let shouldThrow=true;
  const failure=Object.assign(new Error('host rejected the post'),{code:'hostUnavailable'});
  const sent=[];
  const broker=connection({postMessage:message=>{sent.push(JSON.parse(message));if(shouldThrow)throw failure;}});
  for(let index=0;index<129;index++)await assert.rejects(broker.call('noteHeartbeat'),reason=>reason===failure);
  shouldThrow=false;
  const recovered=broker.call('noteHeartbeat');
  assert.equal(sent.length,130);assert.equal(sent.at(-1).requestId,'130');
  broker.receive(reply('130',{alive:true}));assert.deepEqual(await recovered,{alive:true});
});

test('a synchronous real reply can settle before postMessage returns or throws',async()=>{
  let broker;
  broker=connection({postMessage:message=>{
    const {requestId}=JSON.parse(message);
    assert.equal(broker.receive(reply(requestId,{generation:47})),'reply');
    throw new Error('after native reply');
  }});
  for(let index=0;index<129;index++)assert.deepEqual(await broker.call('getParameterState'),{generation:47});
});

test('malformed, foreign, unknown and retired replies leave unrelated promises pending',async()=>{
  const broker=connection(),outcomes=[];
  const one=broker.call('getSamplerSession').then(value=>outcomes.push(['one',value]));
  const two=broker.call('getParameterState').then(value=>outcomes.push(['two',value]));
  const malformed=[undefined,17,{},'', '{','null','[]','true',JSON.stringify({version:1}),
    reply('1','wrong',{version:2}),reply('1','wrong',{version:'1'}),reply('1','wrong',{instanceId:'18'}),
    reply('1','wrong',{attachmentId:'24'}),reply('1','wrong',{instanceId:17}),reply('1','wrong',{attachmentId:23}),
    ...['0','01','-1','1e0','18446744073709551616',1,null].map(requestId=>reply(requestId,'wrong')),
    reply('99','unknown'),reply('1','wrong',{status:'unexpected'}),reply('1',undefined),
    ...[undefined,null,[],{}, {code:7},{code:''}].map(error=>reply('1',undefined,{status:'rejected',error})),
    reply('1','wrong',{error:{code:'malformed'}}),reply('1','wrong',{status:'rejected',error:{code:'malformed'}}),
    reply('1','wrong',{event:'parameterStateChanged',sequence:'1',payload:{}}),
  ];
  for(const message of malformed)assert.equal(broker.receive(message),'ignored');
  await Promise.resolve();assert.deepEqual(outcomes,[]);
  assert.equal(broker.receive(reply('2',{actual:2})),'reply');await two;
  assert.equal(broker.receive(reply('2',{wrong:2})),'ignored');
  await Promise.resolve();assert.deepEqual(outcomes,[['two',{actual:2}]]);
  assert.equal(broker.receive(reply('1',{actual:1})),'reply');await one;
  assert.deepEqual(outcomes,[['two',{actual:2}],['one',{actual:1}]]);
});

test('received JSON admits exactly 64 KiB of UTF-8 and ignores larger messages',async()=>{
  const broker=connection(),pending=broker.call('getSamplerSession');
  const empty='{"version":1,"instanceId":"17","attachmentId":"23","requestId":"1","status":"accepted","result":""}';
  const fill='😀'.repeat(Math.floor((65536-Buffer.byteLength(empty))/4));
  const exact=fill+'x'.repeat(65536-Buffer.byteLength(empty)-Buffer.byteLength(fill));
  assert.equal(broker.receive(reply('1',exact+'é')),'ignored');
  assert.equal(Buffer.byteLength(reply('1',exact)),65536);
  assert.equal(broker.receive(reply('1',exact)),'reply');
  assert.equal(await pending,exact);
});
