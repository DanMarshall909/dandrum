const U64_MAX=18446744073709551615n;
function decimal(value){
  return typeof value==='string'&&/^[1-9][0-9]{0,19}$/.test(value)&&BigInt(value)<=U64_MAX;
}
function failure(code){return Object.assign(new Error(code),{code});}

/** Browser-side correlation for an already admitted version-1 native attachment. */
export function createWebViewTransport({instanceId,attachmentId,postMessage,nextRequestId='1'}){
  if(!decimal(instanceId)||!decimal(attachmentId)||!decimal(nextRequestId)||typeof postMessage!=='function')throw failure('invalidConfiguration');
  let next=BigInt(nextRequestId);
  const pending=new Map(),listeners=new Map();
  const backend={
    getNativeFunction:method=>(...args)=>new Promise((resolve,reject)=>{
      if(next>U64_MAX)throw failure('identityExhausted');
      const requestId=String(next++);
      pending.set(requestId,{resolve,reject});
      postMessage(JSON.stringify({version:1,attachmentId,requestId,method,args}));
    }),
    addEventListener(event,listener){
      const token=Symbol(event);
      listeners.set(token,{event,listener});
      return token;
    },
    removeEventListener:token=>listeners.delete(token),
  };
  function receive(message){
    const envelope=JSON.parse(message);
    const request=pending.get(envelope.requestId);
    pending.delete(envelope.requestId);
    if(envelope.status==='accepted')request.resolve(envelope.result);
    else request.reject(envelope.error);
    return 'reply';
  }
  const descriptor={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend};
  return {descriptor,receive};
}
