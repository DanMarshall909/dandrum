"""One-off frozen-source evidence repair; run only after explicit cache handback."""
from pathlib import Path
import os,subprocess,hashlib,json,time,signal,re,tarfile
root=Path('/tmp/dandrum-lanes/protocol');out=Path('/tmp/dandrum-evidence/controller-notes-review/final-coverage');target=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov');expected={'src/trigger-host/src/parameters.rs':'37b8e92e6507036084fcb99b9fabe717550d53fe2f36a2f046312e630cc3efea','src/trigger-host/tests/editor_note_controller.rs':'99b99000f9e35406e87d29325d4f6ae07a6354097a40a94544c7cfff68fbb08e'}
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
assert not out.exists();out.mkdir();(out/'tmp').mkdir()
assert git('rev-parse','HEAD').decode().strip()=='28caf6ca02861bebdf1a2e09e49c762682ed1cce';assert not git('diff','--cached','--name-only')
for n,v in expected.items():assert h(root/n)==v
snap={}
for folder in ('src/trigger-host/src','src/trigger-host/tests'):
 for p in sorted((root/folder).rglob('*')):
  if p.is_file():
   n=str(p.relative_to(root));snap[n]=h(p);s=out/'source'/n;s.parent.mkdir(parents=True,exist_ok=True);s.write_bytes(p.read_bytes())
for n in ('src/trigger-host/Cargo.toml','src/trigger-host/Cargo.lock'):snap[n]=h(root/n)
(out/'source-hashes.json').write_text(json.dumps(snap,indent=2)+'\n')

def profiles(label):
 files=sorted([*target.glob('*.profraw'),*target.glob('*.profdata')],key=lambda p:p.name.encode());entries=[{'path':p.name,'sha256':h(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in files]
 with tarfile.open(out/(label+'-profiles.tar.gz'),'w:gz') as tf:
  for p in files:tf.add(p,arcname=p.name,recursive=False)
 (out/(label+'-profiles.json')).write_text(json.dumps(entries,indent=2)+'\n');return entries
prior=profiles('previous')
for p in (target,out,out/'tmp'):assert p.resolve().stat().st_dev==Path('/tmp').stat().st_dev and not p.resolve().is_relative_to(Path('/dev/shm'))
env=os.environ.copy()
for k in list(env):
 if k.startswith('CARGO_PROFILE_') or k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTDOCFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LLVM_PROFILE_FILE'):env.pop(k,None)
env.update(PATH='/home/dan/.cargo/bin:/home/dan/.local/bin:/usr/bin:/bin',CARGO_TARGET_DIR=str(target),CARGO_LLVM_COV_TARGET_DIR=str(target),CARGO_LLVM_COV_BUILD_DIR=str(target),CARGO_BUILD_JOBS='1',TMPDIR=str(out/'tmp'),LLVM_PROFILE_FILE=str(target/'controller-notes-final-%p-%m.profraw'),CARGO_TERM_COLOR='never')

def resource():
 s=os.statvfs(target);ram=os.statvfs('/dev/shm');return {'disk_free':s.f_bavail*s.f_frsize,'shm_unused_output_volume_free':ram.f_bavail*ram.f_frsize,'memory_available':int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024}
def low(s):return s['disk_free']<1024**3 or s['memory_available']<4*1024**3
first=resource();assert not low(first),first
argv=['/home/dan/.cargo/bin/cargo','llvm-cov','--offline','--locked','--manifest-path','src/trigger-host/Cargo.toml','--lib','--tests','--json','--output-path',str(out/'full.json'),'-vv'];samples=[];started=time.monotonic();stop=None
with (out/'output.log').open('wb') as f:
 p=subprocess.Popen(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  s=resource();s['elapsed']=time.monotonic()-started;samples.append(s)
  if low(s):stop='Actual disk-output or memory floor';os.killpg(p.pid,signal.SIGINT);break
  time.sleep(.5)
 try:code=p.wait(timeout=30)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);code=p.wait(timeout=30)
r={'command':argv,'cwd':str(root),'head':git('rev-parse','HEAD').decode().strip(),'exit_code':code,'elapsed_seconds':time.monotonic()-started,'owned_pid_pgid':p.pid,'stop':stop,'environment':{k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','CARGO_BUILD_JOBS','TMPDIR','LLVM_PROFILE_FILE')},'resource_samples':samples,'floors':{'actual_disk_output_bytes':1024**3,'memory_bytes':4*1024**3},'shm':'Sampled UNUSED_BUILD_OUTPUT_VOLUME; no RAM floor PASS or cache deletion/relocation','source_hashes':expected,'log_sha256':h(out/'output.log')}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');assert code==0 and stop is None,r
text=(out/'output.log').read_text();counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',text)];assert sum(counts)==121 and len(counts)==10,counts
assert not re.search(r'test result:.*[1-9]\d* (?:failed|ignored|filtered out)',text)
binaries={}
for line in text.splitlines():
 if not re.search(r'\bRunning\b',line) or 'rustc --crate-name' in line:continue
 for n in re.findall(r'/tmp/dandrum-lanes/cache-host-snapshot-cov/debug/deps/[A-Za-z0-9_-]+',line):
  q=Path(n)
  if q.is_file() and q.read_bytes()[:4]==b'\x7fELF':binaries[n]={'sha256':h(q),'bytes':q.stat().st_size}
assert len(binaries)==10,binaries
current=profiles('result');assert any(e['path'].endswith('.profdata') for e in current) and any(e['path'].startswith('controller-notes-final-') and e['path'].endswith('.profraw') for e in current)
for n,v in snap.items():assert h(root/n)==v
(out/'binary-hashes.json').write_text(json.dumps(binaries,indent=2)+'\n')
report=json.loads((out/'full.json').read_text());files=[f for d in report['data'] for f in d['files'] if f['filename']==str(root/'src/trigger-host/src/parameters.rs')];assert len(files)==1
r.update(test_counts=counts,ordinary_tests=121,compilefail_doctests='Covered separately by author ordinary121+2; LLVMlib/tests intentionally excludes docs',binaries=binaries,coverage_report_sha256=h(out/'full.json'),parameters_summary=files[0]['summary'],raw_profiles_retained=len(current),source_unchanged=True,prior_profiles_preserved=len(prior));(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','ordinary_tests','coverage_report_sha256','parameters_summary','raw_profiles_retained','source_unchanged')}))
