from pathlib import Path
import hashlib,json,math,re,shlex
out=Path('/tmp/dandrum-evidence/controller-notes-review/final-coverage');root=Path('/tmp/dandrum-lanes/protocol');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=json.loads((out/'receipt.json').read_text());assert r['exit_code']==0 and r['stop'] is None
original=json.loads((out/'full.json').read_text());raw=json.loads((out/'reconstructed.json').read_text());metadata=original.pop('cargo_llvm_cov');assert metadata=={'version':'0.8.7','manifest_path':str(root/'src/trigger-host/Cargo.toml')}
rounding=[]
def check(a,b,path=''):
 assert type(a)==type(b) or isinstance(a,(int,float)) and isinstance(b,(int,float)),path
 if isinstance(a,dict):
  assert set(a)==set(b),path
  for k in a:check(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  assert len(a)==len(b),path
  for i,(x,y) in enumerate(zip(a,b)):check(x,y,path+'/'+str(i))
 elif a!=b:
  assert path.endswith('/percent') and math.isclose(a,b,rel_tol=0,abs_tol=1e-12),(path,a,b)
  rounding.append({'path':path,'cargo_reserialized':a,'direct_llvm_export':b,'difference':a-b})
check(original,raw);assert h(out/'reconstructed.profdata')==h(out/'retained-profiles/trigger-host.profdata')
txt=(out/'output.log').read_text();counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',txt)];assert len(counts)==10 and sum(counts)==121
bins={}
for line in txt.splitlines():
 if 'Running `' not in line or 'rustc --crate-name' in line or 'llvm-cov export' in line:continue
 for n in re.findall(r'/tmp/dandrum-lanes/cache-host-snapshot-cov/debug/deps/[A-Za-z0-9_-]+',line):
  p=Path(n)
  if p.is_file():
   with p.open('rb') as f:elf=f.read(4)==b'\x7fELF'
   if elf:bins[n]={'sha256':h(p),'bytes':p.stat().st_size}
assert len(bins)==10
for n,v in json.loads((out/'source-hashes.json').read_text()).items():assert h(root/n)==v
entries=json.loads((out/'result-profiles.json').read_text());assert len(entries)==11
for e in entries:assert h(out/'retained-profiles'/e['path'])==e['sha256']
def argv(needle):
 lines=[l.strip() for l in txt.splitlines() if 'Running `' in l and needle in l];assert len(lines)==1;return shlex.split(lines[0].split('`',1)[1].rsplit('`',1)[0])
export=argv('llvm-cov export');assert {export[i+1] for i,a in enumerate(export) if a=='-object'}==set(bins)
params=[f for d in original['data'] for f in d['files'] if f['filename']==str(root/'src/trigger-host/src/parameters.rs')];assert len(params)==1
complete={'raw_run_receipt_sha256':h(out/'receipt.json'),'ordinary_tests':121,'per_target_counts':counts,'doctests':'2authorordinary compilefaildocs; LLVMlib/tests excludes docs','binary_hashes':bins,'actual_child_profile_pattern':'trigger-host-%p-%m.profraw','tool_metadata':metadata,'raw_profiles_retained':10,'merged_profile_retained':True,'raw_profile_inventory_sha256':h(out/'result-profiles.json'),'profiles_archive_sha256':h(out/'result-profiles.tar.gz'),'reconstructed_profdata_matches_exactly':True,'all_export_paths_segments_expansions_functions_integer_counters_match_exactly':True,'derived_percent_rounding_differences':rounding,'original_profdata_merge_argv':argv('llvm-profdata merge'),'original_llvm_export_argv':export,'parameters_summary':params[0]['summary'],'source_unchanged':True,'qualifications':['First postprocessing assumed requestedprofileprefix; actual cargo-llvm-cov overrides to trigger-host, retained verbose child env proves it','Second postprocessing expected identical JSON. Cargo adds metadata and reserializes derivedpercent floats with lastdigit rounding. Actual profdata exact; all semantic data/counters exact, only recorded percent differences<=1e-12','Original raw receipt/log/profiles/reconstructed outputs/helpers preserved. Neither postprocessing failure is a behaviorRED or failing coverageexecution. No further test rerun needed.','Original author27 omitted binary hashes; fresh19.10s frozen-source121 run supplies raw/executed10binary/verboseinstrument/export binding']}
(out/'completion.json').write_text(json.dumps(complete,indent=2)+'\n');print(json.dumps({k:v for k,v in complete.items() if k not in ('binary_hashes','original_profdata_merge_argv','original_llvm_export_argv')}))
