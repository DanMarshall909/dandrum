from pathlib import Path
import hashlib,json,re,shlex,subprocess,tarfile,time
out=Path('/tmp/dandrum-evidence/controller-notes-review/final-coverage');root=Path('/tmp/dandrum-lanes/protocol');target=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=json.loads((out/'receipt.json').read_text());assert r['exit_code']==0 and r['stop'] is None;txt=(out/'output.log').read_text()
assert "LLVM_PROFILE_FILE='/tmp/dandrum-lanes/cache-host-snapshot-cov/trigger-host-%p-%m.profraw'" in txt
failure={'classification':'Postprocessing assumption failure, not test RED or failed coverage execution','expected_requested_profile_prefix':'controller-notes-final-','actual_cargo_llvm_cov_child_prefix':'trigger-host-','evidence':'Verbose child command overrides requested LLVM_PROFILE_FILE; all ten actual raw profiles and profdata already retained','raw_run_receipt_sha256':h(out/'receipt.json'),'raw_helper_sha256':h(out.parent/'capture-final-coverage.py')};(out/'postprocessing-correction.json').write_text(json.dumps(failure,indent=2)+'\n')
counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',txt)];assert len(counts)==10 and sum(counts)==121
bins={}
for line in txt.splitlines():
 if 'Running `' not in line or 'rustc --crate-name' in line or 'llvm-cov export' in line:continue
 for n in re.findall(r'/tmp/dandrum-lanes/cache-host-snapshot-cov/debug/deps/[A-Za-z0-9_-]+',line):
  p=Path(n)
  if p.is_file():
   with p.open('rb') as f:elf=f.read(4)==b'\x7fELF'
   if elf:bins[n]={'sha256':h(p),'bytes':p.stat().st_size}
assert len(bins)==10
entries=json.loads((out/'result-profiles.json').read_text());assert len(entries)==11 and sum(e['path'].endswith('.profraw') for e in entries)==10
rawdir=out/'retained-profiles';assert not rawdir.exists();rawdir.mkdir()
with tarfile.open(out/'result-profiles.tar.gz','r:gz') as tf:
 assert [m.name for m in tf.getmembers()]==[e['path'] for e in entries]
 for e in entries:
  assert '/' not in e['path'];b=tf.extractfile(e['path']).read();assert hashlib.sha256(b).hexdigest()==e['sha256'];(rawdir/e['path']).write_bytes(b)
profilelist=target/'trigger-host-profraw-list';rawnames=[Path(n).name for n in profilelist.read_text().splitlines() if n];assert set(rawnames)=={e['path'] for e in entries if e['path'].endswith('.profraw')};(out/'original-profraw-list.txt').write_bytes(profilelist.read_bytes());(out/'retained-profraw-list.txt').write_text(''.join(str(rawdir/n)+'\n' for n in rawnames))
def cmdline(needle):
 a=[line.strip() for line in txt.splitlines() if 'Running `' in line and needle in line];assert len(a)==1;return shlex.split(a[0].split('`',1)[1].rsplit('`',1)[0])
merge=cmdline('llvm-profdata merge');merge[merge.index('-f')+1]=str(out/'retained-profraw-list.txt');merge[merge.index('-o')+1]=str(out/'reconstructed.profdata');start=time.monotonic();p=subprocess.run(merge,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0,p.stderr;assert h(out/'reconstructed.profdata')==h(rawdir/'trigger-host.profdata')
export=cmdline('llvm-cov export');export=[('-instr-profile='+str(out/'reconstructed.profdata')) if a.startswith('-instr-profile=') else a for a in export]
objects=[export[i+1] for i,a in enumerate(export) if a=='-object'];assert set(objects)==set(bins)
with (out/'reconstructed.json').open('wb') as f:p=subprocess.run(export,stdout=f,stderr=subprocess.PIPE)
assert p.returncode==0,p.stderr
original=json.loads((out/'full.json').read_text());assert json.loads((out/'reconstructed.json').read_text())==original
for n,v in json.loads((out/'source-hashes.json').read_text()).items():assert h(root/n)==v
for n,v in bins.items():assert h(Path(n))==v['sha256']
files=[f for d in original['data'] for f in d['files'] if f['filename']==str(root/'src/trigger-host/src/parameters.rs')];assert len(files)==1
complete={'raw_run_receipt_sha256':h(out/'receipt.json'),'ordinary_tests':121,'compilefail_doctests':'Author separate ordinary run proves2; LLVMlib/tests excludes them','actual_emitted_profile_pattern':str(target/'trigger-host-%p-%m.profraw'),'binary_hashes':bins,'raw_profile_inventory_sha256':h(out/'result-profiles.json'),'profiles_archive_sha256':h(out/'result-profiles.tar.gz'),'profraw_list_sha256':h(out/'original-profraw-list.txt'),'reconstructed_profdata_matches_exactly':True,'reconstructed_export_matches_JSON_values':True,'reconstruction_seconds':time.monotonic()-start,'merge_argv':merge,'export_argv':export,'parameters_summary':files[0]['summary'],'source_unchanged':True,'postprocessing_correction_sha256':h(out/'postprocessing-correction.json'),'qualification':'Original author27 omitted binary hashes; this fresh frozen-source run supplies raw/binary/verbose instrument and export binding. First postprocess expected requested prefix; corrected against actual child env without rerunning tests or altering rawreceipt.'};(out/'completion.json').write_text(json.dumps(complete,indent=2)+'\n');print(json.dumps({k:v for k,v in complete.items() if k not in ('binary_hashes','merge_argv','export_argv')}))
