from pathlib import Path
import os, sys, subprocess, signal, time, json, hashlib, shutil, stat, re, shlex
ROOT=Path('/tmp/dandrum-lanes/protocol')
FIXTURE=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source')
EVIDENCE=Path('/tmp/dandrum-lanes/evidence-controller-notes-sourcefree')
TARGET=Path('/tmp/dandrum-lanes/cache-editor-guard')
TMP=EVIDENCE/'tmp'
EXPECTED=EVIDENCE/'root-before-map.json'
FLOORS={'disk_free_bytes':1024**3,'memory_available_bytes':4*1024**3}
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def resource():
 du=shutil.disk_usage('/tmp')
 su=shutil.disk_usage('/dev/shm')
 mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 return {'disk_free_bytes':du.free,'memory_available_bytes':mem,'unused_build_output_volume':{'path':'/dev/shm','free_bytes':su.free,'used_for_build_output':False}}
def write(name,obj): (EVIDENCE/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def records(base):
 out={}
 for part in ('CMakeLists.txt','src','tests','examples','schema','scripts','spikes'):
  p=base/part
  if not p.exists():continue
  scan=[]
  if p.is_file(): scan=[p]
  else:
   for parent,dirs,files in os.walk(p):
    dirs[:]=[d for d in dirs if d not in ('target','build','__pycache__')]
    scan.extend(Path(parent)/n for n in files)
  for q in scan:
   if q.is_symlink(): raise RuntimeError(f'symlink source input: {q}')
   s=q.stat();out[str(q.relative_to(base))]={'sha256':sha(q),'mode':oct(stat.S_IMODE(s.st_mode)),'mtime_ns':s.st_mtime_ns,'bytes':s.st_size}
 return out

def verify_sources():
 expected=json.loads(EXPECTED.read_text())
 assert records(ROOT)==expected,'frozen root changed'
 actual=records(FIXTURE)
 before=json.loads((EVIDENCE/'fixture-prebuild-map.json').read_text())
 assert set(actual)==set(expected)==set(before),'fixture source input set changed'
 updated={'src/trigger-host/src/parameters.rs','src/trigger-host/tests/editor_note_controller.rs'}
 assert all(actual[k]['sha256']==expected[k]['sha256'] for k in expected),'fixture source bytes changed'
 assert all(actual[k]['mode']==before[k]['mode'] and actual[k]['mtime_ns']==before[k]['mtime_ns'] for k in before if k not in updated),'retained fixture metadata changed'
 assert all(actual[k]['mode']==expected[k]['mode'] and actual[k]['mtime_ns']==expected[k]['mtime_ns'] for k in updated),'updated fixture metadata differs from frozen inputs'
 for tree in ('web','ui','third_party'): assert not (FIXTURE/tree).exists(),f'unexpected source tree {tree}'
def run(label,cmd,env):
 verify_sources(); r=resource();
 if r['disk_free_bytes']<FLOORS['disk_free_bytes'] or r['memory_available_bytes']<FLOORS['memory_available_bytes']:
  write('resource-stop.json',{'stage':label,'reason':'prelaunch-floor','resources':r,'floors':FLOORS}); raise RuntimeError('resource floor before launch')
 logpath=EVIDENCE/(label+'.log'); start=time.monotonic(); samples=[]; stop=None
 with logpath.open('wb') as log:
  p=subprocess.Popen(cmd,cwd=FIXTURE,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  last_notice=0
  while p.poll() is None:
   r=resource(); r['elapsed_seconds']=time.monotonic()-start; samples.append(r)
   if r['disk_free_bytes']<FLOORS['disk_free_bytes'] or r['memory_available_bytes']<FLOORS['memory_available_bytes']:
    stop={'reason':'resource-floor','resources':r}
   if label=='release-tests' and not stop:
    with logpath.open('rb') as lf:
     data=lf.read()
    matches=[line.decode('utf8','replace').strip() for line in data.splitlines() if re.search(rb'Compiling dandrum_(?:engine|instrument_session)(?: v| )',line)]
    if matches: stop={'reason':'unexpected-full-dependency-compile','lines':matches}
   if stop:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   now=time.monotonic()
   if now-last_notice>=30:
    print(json.dumps({'stage':label,'elapsed_seconds':round(now-start,1),'resources':r}),flush=True);last_notice=now
   time.sleep(.5)
  code=p.wait()
 record={'command':cmd,'cwd':str(FIXTURE),'effective_environment':{k:env[k] for k in sorted(env) if k in ['PATH','HOME','CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTC','RUSTDOC','LD_LIBRARY_PATH','LANG','LC_ALL','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR']},'exit':code,'elapsed_seconds':time.monotonic()-start,'pid':p.pid,'pgid':p.pid,'stop':stop,'resource_samples':samples,'minimum_resources':{'disk_free_bytes':min(s['disk_free_bytes'] for s in samples) if samples else r['disk_free_bytes'],'memory_available_bytes':min(s['memory_available_bytes'] for s in samples) if samples else r['memory_available_bytes'],'unused_build_output_volume_min_free_bytes':min(s['unused_build_output_volume']['free_bytes'] for s in samples) if samples else r['unused_build_output_volume']['free_bytes']},'final_resources':resource(),'raw_log_sha256':sha(logpath),'raw_log_bytes':logpath.stat().st_size}
 write(label+'-run.json',record); print(json.dumps({'stage':label,'exit':code,'elapsed_seconds':round(record['elapsed_seconds'],3),'pgid':p.pid,'stop':stop,'final_resources':record['final_resources']}),flush=True)
 verify_sources()
 if code!=0 or stop: raise RuntimeError(f'{label} failed or stopped; see retained run/log')
 return record

assert os.stat('/tmp').st_dev==os.stat(TARGET).st_dev==os.stat(TMP).st_dev
verify_sources()
# Actual complete argv, with ordinary Cargo release profile and instrumentation overrides removed.
env=dict(os.environ)
removed={}
for k in list(env):
 if k.startswith(('CARGO_PROFILE_','CARGO_LLVM_COV_','__CARGO_LLVM_COV_')) or k in ('RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LLVM_PROFILE_FILE','RUSTC_BOOTSTRAP','CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER'):
  removed[k]=env.pop(k)
env.update({'PATH':'/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin','CARGO_TARGET_DIR':str(TARGET),'CARGO_BUILD_JOBS':'1','CARGO_NET_OFFLINE':'true','CARGO_INCREMENTAL':'0','TMPDIR':str(TMP)})
commands=[('release-tests',['/home/dan/.cargo/bin/cargo','test','--release','--offline','--locked','--jobs','1','--manifest-path',str(FIXTURE/'src/trigger-host/Cargo.toml'),'-vv']),('dependencies',['/home/dan/.cargo/bin/cargo','tree','--offline','--locked','--manifest-path',str(FIXTURE/'src/trigger-host/Cargo.toml'),'--edges','normal','--prefix','none'])]
write('invocation.json',{'commands':[{'label':a,'argv':b,'cwd':str(FIXTURE)} for a,b in commands],'initial_resources':resource(),'floors':FLOORS,'removed_environment_variable_names':sorted(removed),'effective_environment':{k:env[k] for k in sorted(env) if k in ['PATH','HOME','CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTC','RUSTDOC','LD_LIBRARY_PATH','LANG','LC_ALL','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR']},'target_device':os.stat(TARGET).st_dev,'tmp_device':os.stat(TMP).st_dev,'profile_manifest':(FIXTURE/'src/trigger-host/Cargo.toml').read_text()})
results=[]
for label,cmd in commands: results.append(run(label,cmd,env))
# Derive real Cargo test counts, executed paths and current artifact hashes from verbose evidence.
log=(EVIDENCE/'release-tests.log').read_text(errors='replace')
counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',log)]
all_summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log)
binary_candidates=[]
for line in log.splitlines():
 if 'Running `' not in line: continue
 m=re.search(r'Running `([^`]+)`',line)
 if not m: continue
 try: argv=shlex.split(m.group(1))
 except ValueError: continue
 for token in argv:
  if str(TARGET/'release/deps') in token and Path(token).is_file():
   binary_candidates.append(Path(token)); break
binaries=[]
for p in dict.fromkeys(binary_candidates):
 binaries.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'mtime_ns':p.stat().st_mtime_ns})
# Capture fingerprint and dependency-info evidence related to every executed test executable.
fingerprint_root=TARGET/'release/.fingerprint'
fingerprints=[]
for p in fingerprint_root.glob('dandrum-trigger-host-*/*'):
 if p.is_file() and (p.name.endswith('.json') or p.name.endswith('.d') or p.name.startswith('dep-')):
  fingerprints.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'name':p.name})
# Include all dep-info files which name one of the target executables by its Cargo hash.
depinfos=[]
for p in (TARGET/'release/deps').glob('dandrum_trigger_host-*.d'):
 depinfos.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'mentions_parameters':b'src/trigger-host/src/parameters.rs' in p.read_bytes(),'mentions_new_test':b'src/trigger-host/tests/editor_note_controller.rs' in p.read_bytes()})
# Current test source is listed by integration dep-info; lib source in lib dep-info.
forbidden=['clack','wry','gtk','webkit','juce']
deps=(EVIDENCE/'dependencies.log').read_text(errors='replace')
normal_names=[line.split()[0] for line in deps.splitlines() if line.strip()]
forbidden_found=[n for n in normal_names if any(x in n.lower() for x in forbidden)]
write('executed-artifact-bindings.json',{'running_binary_count':len(binaries),'binaries':binaries,'test_counts_by_target':counts,'test_result_summaries':all_summaries,'fingerprint_files':fingerprints,'dep_info_files':depinfos,'compiler_invocation_lines':[line for line in log.splitlines() if 'Running `' in line and 'rustc' in line][:500],'cargo_compiling_lines':[line for line in log.splitlines() if line.startswith('   Compiling ')],'profile_flags_seen':sorted(set(x for x in ('-C opt-level=3','-C linker-plugin-lto','-C codegen-units=1') if x in log)),'dependency_names':normal_names,'forbidden_dependency_matches':forbidden_found})
# Final source maps and 589-input unchanged proof.
rootmap=records(ROOT); fixmap=records(FIXTURE)
write('root-after-map.json',rootmap);write('fixture-after-map.json',fixmap)
before=json.loads((EVIDENCE/'fixture-before-map.json').read_text())
expected=json.loads((EVIDENCE/'root-before-map.json').read_text())
unchanged=[k for k in before if k!='src/trigger-host/src/parameters.rs']
assert len(rootmap)==len(fixmap)==591 and rootmap==expected and set(rootmap)==set(fixmap)
assert all(rootmap[k]['sha256']==fixmap[k]['sha256'] for k in rootmap)
assert len(unchanged)==589
assert all(before[k]['sha256']==fixmap[k]['sha256'] and before[k]['mode']==fixmap[k]['mode'] and before[k]['mtime_ns']==fixmap[k]['mtime_ns'] for k in unchanged)
assert not forbidden_found
write('source-verification.json',{'root_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'root_source_input_count':len(rootmap),'fixture_source_input_count':len(fixmap),'root_before_after_equal':rootmap==expected,'fixture_matches_root_bytes':all(rootmap[k]['sha256']==fixmap[k]['sha256'] for k in rootmap),'fixture_updated_inputs':['src/trigger-host/src/parameters.rs','src/trigger-host/tests/editor_note_controller.rs'],'unchanged_589_byte_mode_mtime_proven':True,'new_or_removed_inputs':sorted(set(rootmap)^set(fixmap)),'only_sha_differences_from_prior_590':{'src/trigger-host/src/parameters.rs':{'old':json.loads((EVIDENCE/'fixture-before-map.json').read_text())['src/trigger-host/src/parameters.rs']['sha256'],'new':fixmap['src/trigger-host/src/parameters.rs']['sha256']},'src/trigger-host/tests/editor_note_controller.rs':fixmap['src/trigger-host/tests/editor_note_controller.rs']['sha256']},'absent_fixture_trees':['web','ui','third_party']})
print(json.dumps({'derived_test_counts':counts,'summaries':all_summaries,'executed_binaries':binaries,'forbidden_dependencies':forbidden_found,'sources':{'count':len(fixmap),'unchanged':len(unchanged)}},indent=2),flush=True)
