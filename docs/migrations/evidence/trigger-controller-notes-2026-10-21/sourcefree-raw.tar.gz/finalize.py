from pathlib import Path
import json,hashlib,re,shlex,os,subprocess
E=Path('/tmp/dandrum-lanes/evidence-controller-notes-sourcefree');ROOT=Path('/tmp/dandrum-lanes/protocol');TARGET=Path('/tmp/dandrum-lanes/cache-editor-guard');FIX=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source')
def H(b):return hashlib.sha256(b).hexdigest()
def sha(p):return H(p.read_bytes())
def read(n):return json.loads((E/n).read_text())
def write(n,o):(E/n).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
log=(E/'release-tests.log').read_text(errors='replace');deps=(E/'dependencies.log').read_text(errors='replace')
tr=read('release-tests-run.json');dr=read('dependencies-run.json');inv=read('invocation.json')
# Cargo -vv prefixes child commands with environment assignments. Select the first non-assignment token.
executed=[];running={}
for line in log.splitlines():
 m=re.match(r'\s+Running `([^`]+)`\s*$',line)
 if not m:continue
 try:argv=shlex.split(m.group(1))
 except ValueError:continue
 exe=next((x for x in argv if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*=',x)),None)
 if exe is None:continue
 p=Path(exe)
 if p.is_absolute() and p.parent==TARGET/'release/deps' and p.is_file() and os.access(p,os.X_OK):
  if p not in executed:executed.append(p);running[p]=line
summary_re=re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s')
summaries=[]
for line in log.splitlines():
 m=summary_re.search(line)
 if m:summaries.append({'status':m.group(1),'passed':int(m.group(2)),'failed':int(m.group(3)),'ignored':int(m.group(4)),'measured':int(m.group(5)),'filtered':int(m.group(6)),'elapsed_seconds':float(m.group(7)),'line':line})
counts=[x['passed'] for x in summaries]
assert len(executed)==10,[p.name for p in executed]
assert len(summaries)==11 and counts==[15,14,17,8,14,7,18,14,5,9,2],counts
assert all(x['status']=='ok' and x['failed']==x['ignored']==x['measured']==x['filtered']==0 for x in summaries)
assert sum(counts[:-1])==121 and counts[-1]==2
# Parse exact rustc --test command that generated each binary.
compiler=[]
for line in log.splitlines():
 if 'Running `' not in line or 'rustc --crate-name' not in line:continue
 m=re.search(r'Running `([^`]+)`',line)
 try:a=shlex.split(m.group(1)) if m else []
 except ValueError:continue
 exe=next((i for i,x in enumerate(a) if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*=',x)),None)
 if exe is None or not a[exe].endswith('/rustc'):continue
 try:crate=a[a.index('--crate-name')+1]
 except (ValueError,IndexError):continue
 if '--test' not in a:continue
 extra=next((a[i+1] for i,x in enumerate(a[:-1]) if x=='-C' and a[i+1].startswith('extra-filename=')),None)
 compiler.append({'crate_name':crate,'extra_filename':extra,'argv':a,'raw_line':line})
bins=[]
for p in executed:
 stem=p.name;crate,cratehash=stem.rsplit('-',1)
 expectedextra='extra-filename=-'+cratehash
 matches=[c for c in compiler if c['crate_name']==crate and c['extra_filename']==expectedextra]
 assert matches,f'no rustc --test binding for {stem}'
 d=p.with_name(stem+'.d');assert d.is_file(),f'missing dep-info for {stem}';db=d.read_bytes()
 fdir=TARGET/'release/.fingerprint'/('dandrum-trigger-host-'+cratehash);assert fdir.is_dir(),f'missing Cargo fingerprint directory {fdir}'
 fps=[]
 for f in fdir.iterdir():
  if f.is_file():fps.append({'path':str(f),'name':f.name,'bytes':f.stat().st_size,'sha256':sha(f)})
 assert fps,f'no fingerprints for {stem}'
 bins.append({'path':str(p),'crate_name':crate,'crate_hash':cratehash,'bytes':p.stat().st_size,'sha256_after_dependency_audit':sha(p),'mtime_ns':p.stat().st_mtime_ns,'direct_cargo_running_line':running[p],'rustc_test_invocation':matches[-1],'dep_info':{'path':str(d),'bytes':len(db),'sha256':sha(d),'mentions_parameters_source':b'src/parameters.rs' in db,'mentions_new_test_source':b'tests/editor_note_controller.rs' in db},'cargo_fingerprint_files':fps})
assert len({x['sha256_after_dependency_audit'] for x in bins})==10
assert any(x['crate_name']=='dandrum_trigger_host' and x['dep_info']['mentions_parameters_source'] for x in bins)
assert any(x['crate_name']=='editor_note_controller' and x['dep_info']['mentions_new_test_source'] for x in bins)
flags=sorted(set(x for x in ('-C opt-level=3','-C linker-plugin-lto','-C codegen-units=1') if x in log));assert flags==['-C codegen-units=1','-C linker-plugin-lto','-C opt-level=3'],flags
root0=read('root-before-map.json');root1=read('root-after-map.json');fix0=read('fixture-before-map.json');fix1=read('fixture-after-map.json');prior=json.loads(Path('/dev/shm/dandrum-beta-20261020/session-worker-sourcefree-success/source-manifest.json').read_text())
assert root0==root1 and len(root0)==591 and len(fix0)==590 and len(fix1)==591
assert set(root0)==set(fix1) and all(root0[k]['sha256']==fix1[k]['sha256'] for k in root0)
unchanged=[k for k in fix0 if k!='src/trigger-host/src/parameters.rs'];assert len(unchanged)==589
assert all(fix0[k]['sha256']==fix1[k]['sha256'] and fix0[k]['mode']==fix1[k]['mode'] and fix0[k]['mtime_ns']==fix1[k]['mtime_ns'] for k in unchanged)
assert set(fix1)-set(fix0)=={'src/trigger-host/tests/editor_note_controller.rs'}
updated=('src/trigger-host/src/parameters.rs','src/trigger-host/tests/editor_note_controller.rs')
assert all(fix1[k]['sha256']==root1[k]['sha256'] and fix1[k]['mode']==root1[k]['mode'] and fix1[k]['mtime_ns']==root1[k]['mtime_ns'] for k in updated)
assert all(root0[k]['sha256']==prior[k] for k in prior if k!='src/trigger-host/src/parameters.rs') and set(root0)-set(prior)=={'src/trigger-host/tests/editor_note_controller.rs'}
normal=[line.split()[0] for line in deps.splitlines() if line.strip()];forbidden=[n for n in normal if any(k in n.lower() for k in ('clack','wry','gtk','webkit','juce'))];assert not forbidden,forbidden
write('executed-artifact-bindings.json',{'actual_direct_test_executable_count':len(bins),'actual_direct_test_executables':bins,'ordinary_target_summaries':summaries[:-1],'compile_fail_doctest_summary':summaries[-1],'ordinary_test_total':sum(counts[:-1]),'doctest_total':counts[-1],'actual_compiler_invocation_count':len(compiler),'profile_flags_seen_in_actual_rustc_commands':flags,'normal_dependency_names':normal,'forbidden_dependency_matches':forbidden})
manifest={k:v['sha256'] for k,v in root0.items()};write('source-manifest.json',manifest)
root_map_sha=sha(E/'root-before-map.json');assert root_map_sha==sha(E/'root-after-map.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head=='28caf6ca02861bebdf1a2e09e49c762682ed1cce'
status=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True);expectedstatus={' M openspec/changes/add-juce-free-trigger-clap-editor/design.md',' M src/trigger-host/src/parameters.rs','?? src/trigger-host/tests/editor_note_controller.rs'};assert set(status.splitlines())==expectedstatus,status
assert subprocess.run(['git','diff','--cached','--quiet'],cwd=ROOT).returncode==0
assert tr['exit']==dr['exit']==0 and tr['stop'] is None and dr['stop'] is None
assert tr['minimum_resources']['disk_free_bytes']>=1024**3 and tr['minimum_resources']['memory_available_bytes']>=4*1024**3
assert os.stat('/tmp').st_dev==os.stat(TARGET).st_dev==os.stat(E/'tmp').st_dev
owned=[tr['pgid'],dr['pgid']];ps=subprocess.check_output(['ps','-eo','pid=,pgid=,args='],text=True).splitlines();survivors=[]
for line in ps:
 z=line.strip().split(None,2)
 if len(z)>=2 and z[1].isdigit() and int(z[1]) in owned:survivors.append(line)
assert not survivors,survivors
source={'head':head,'git_status':status,'staged_diff_empty':True,'root_inputs_before_after':591,'fixture_inputs_before_after':[590,591],'root_full_map_before_after_equal':True,'root_full_map_sha256':root_map_sha,'fixture_matches_root_all_591_bytes':True,'unchanged_589_fixture_bytes_mode_mtime_preserved':True,'updated_fixture_inputs_match_frozen_root_bytes_mode_mtime':list(updated),'input_set_change_from_prior_590':['src/trigger-host/tests/editor_note_controller.rs'],'changed_existing_input_from_prior_590':['src/trigger-host/src/parameters.rs'],'removed_inputs':[],'absent_fixture_trees':['web','ui','third_party'],'prior590_manifest_sha256':H(Path('/dev/shm/dandrum-beta-20261020/session-worker-sourcefree-success/source-manifest.json').read_bytes())}
write('source-verification.json',source)
receipt={'status':'PASS','scope':'Full unfiltered source-free default-release Rust host Cargo suite plus normal locked dependency-tree audit','head_source_binding':head,'source_manifest_sha256':sha(E/'source-manifest.json'),'root_full_input_map_sha256_before_after':root_map_sha,'root_inputs':591,'fixture_inputs_before':590,'fixture_inputs_after':591,'unchanged_fixture_inputs_byte_mode_mtime':589,'ordinary_test_total':sum(counts[:-1]),'compile_fail_doctest_total':counts[-1],'per_target_passed_counts':counts,'all_failed_ignored_measured_filtered_counts_zero':True,'executed_test_binary_count':len(bins),'binary_inventory':'executed-artifact-bindings.json','cargo_test_command':tr['command'],'cargo_test_cwd':tr['cwd'],'cargo_test_exit':tr['exit'],'cargo_test_elapsed_seconds':tr['elapsed_seconds'],'cargo_tree_command':dr['command'],'cargo_tree_exit':dr['exit'],'cargo_tree_elapsed_seconds':dr['elapsed_seconds'],'effective_environment':tr['effective_environment'],'removed_profile_instrumentation_variable_names':inv['removed_environment_variable_names'],'release_profile':'Default release, opt-level 3, LTO enabled, codegen-units 1; incremental disabled; one build job; no instrumentation/profile override','actual_rustc_profile_flags':flags,'cache':'Existing /tmp/dandrum-lanes/cache-editor-guard; preserved without clean/delete/relocation','private_tmpdir':str(E/'tmp'),'tmp_target_same_filesystem':True,'resource_floors_bytes':{'disk_free':1024**3,'memory_available':4*1024**3},'minimum_resources':tr['minimum_resources'],'final_resources':tr['final_resources'],'unused_build_output_volume':tr['final_resources']['unused_build_output_volume'],'forbidden_normal_dependency_matches':forbidden,'owned_process_groups':[tr['pgid'],dr['pgid']],'owned_process_survivors':survivors,'fixture_after_run_retained':True,'prior_success_evidence_untouched':True,'qualification':'Source-free Rust host and Rust normal-dependency audit only. No full CMake/native/CLAP/browser/beta/task-completion/publication claim.'}
write('receipt.json',receipt)
print(json.dumps({'status':'PASS','ordinary':sum(counts[:-1]),'doctests':counts[-1],'actual_executed_binaries':len(bins),'binary_names':[x['path'].rsplit('/',1)[-1] for x in bins],'root_map_equal_before_after':True,'fixture_bytes_match_root':True,'unchanged_589_mtime_proven':True,'profile_flags':flags,'forbidden_dependencies':forbidden,'minimum_resources':tr['minimum_resources'],'owned_survivors':survivors},indent=2))
