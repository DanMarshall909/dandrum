use dandrum_trigger_host::parameters::{ParameterController, ParameterError};
use dandrum_trigger_host::protocol::{Admission, AdmittedRequest};
use dandrum_trigger_host::runtime::{ControlEvent, RuntimeAudio, TimedEvent};
use dandrum_trigger_host::{
    ADVANCED_DRUM_KIT_DOCUMENT, ADVANCED_DRUM_KIT_SAMPLE, TriggerHostConfiguration,
};
use serde_json::{Value, json};
use std::{
    num::NonZeroU64,
    sync::mpsc,
    time::{Duration, Instant},
};

struct Fixture {
    directory: tempfile::TempDir,
}
impl Fixture {
    fn new() -> Self {
        let directory = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(directory.path().join("instrument/assets")).unwrap();
        let mut samples = vec![-0.125; 16384];
        samples[..4].copy_from_slice(&[-0.5, 0.25, -0.25, 0.5]);
        dandrum_engine::wav::write_wav_stereo_i16(
            std::fs::File::create(directory.path().join(ADVANCED_DRUM_KIT_SAMPLE)).unwrap(),
            48000,
            &samples,
            &samples,
        )
        .unwrap();
        let document = r#"
instrument: { id: dandrum.advanced-drum-kit, preset_schema_version: 1 }
assets:
  sample_sources:
    - id: drums
      path: assets/advanced-drums.wav
      regions:
        - { id: body, start_frame: 0, end_frame: 16384 }
        - { id: click, start_frame: 0, end_frame: 1 }
  sample_maps:
    - id: kit
      zones:
        - { id: kick, region: drums.click, key_range: [36, 36], velocity_range: [1, 127] }
ports:
  - { name: level, direction: input, signal: control, channels: 1, default: 1, min: 0, max: 4, maps_to: gain.gain }
  - { name: master, direction: output, signal: audio, channels: 2, maps_from: gain.audio_out }
preset_surface:
  parameters:
    - { name: drums.level, maps_to: level }
module_definitions:
  - type: sample_voice
    ports:
      - { name: audio, direction: output, signal: audio, channels: 2, maps_from: player.audio }
    modules:
      - { id: player, type: sample_player, static: { source: drums, region: body, channels: 2, mode: gated }, defaults: { pan: 0 } }
    connections:
      - { from: voice.gate, to: player.trigger }
      - { from: voice.gate, to: player.gate }
      - { from: voice.velocity, to: player.level }
modules:
  - { id: midi, type: midi_input }
  - { id: voices, type: poly, static: { definition: sample_voice, max_voices: 128, allocation: reject-new } }
  - { id: mapped, type: sample_map_player, static: { sample_map: kit, channels: 2, max_voices: 8 } }
  - { id: mixer, type: audio_mixer, static: { channels: 2 } }
  - { id: gain, type: gain, static: { channels: 2 } }
connections:
  - { from: midi.events, to: voices.notes }
  - { from: midi.events, to: mapped.note }
  - { from: voices.audio, to: mixer.inputs }
  - { from: mapped.audio, to: mixer.inputs }
  - { from: mixer.mix, to: gain.audio_in }
"#;
        std::fs::write(directory.path().join(ADVANCED_DRUM_KIT_DOCUMENT), document).unwrap();
        Self { directory }
    }
    fn open(&self) -> (ParameterController, Audio) {
        let (controller, audio) = ParameterController::open(
            self.directory.path(),
            TriggerHostConfiguration {
                sample_rate_hz: 48000,
                max_block_frames: 16,
            },
            NonZeroU64::new(1).unwrap(),
            4,
            8,
        )
        .unwrap();
        (controller, Audio::new(audio))
    }
}
enum AudioCommand {
    Render(Vec<TimedEvent>),
    Reset,
}
struct Audio {
    commands: mpsc::Sender<AudioCommand>,
    results: mpsc::Receiver<([f32; 16], [f32; 16])>,
    thread: Option<std::thread::JoinHandle<()>>,
}
impl Audio {
    fn new(mut audio: RuntimeAudio) -> Self {
        let (commands, input) = mpsc::channel();
        let (output, results) = mpsc::channel();
        let thread = std::thread::spawn(move || {
            while let Ok(command) = input.recv() {
                let (mut left, mut right) = ([0.; 16], [0.; 16]);
                let audit = allocation_counter::measure(|| match &command {
                    AudioCommand::Render(events) => {
                        audio.process_events(&mut left, &mut right, events).unwrap();
                    }
                    AudioCommand::Reset => {
                        audio.reset();
                    }
                });
                assert_eq!(
                    audit,
                    allocation_counter::AllocationInfo::default(),
                    "audio must neither allocate nor deallocate"
                );
                output.send((left, right)).unwrap();
            }
        });
        Self {
            commands,
            results,
            thread: Some(thread),
        }
    }
    fn command(&self, command: AudioCommand) -> ([f32; 16], [f32; 16]) {
        self.commands.send(command).unwrap();
        self.results.recv_timeout(Duration::from_secs(10)).unwrap()
    }
    fn render(&self, events: &[TimedEvent]) -> ([f32; 16], [f32; 16]) {
        self.command(AudioCommand::Render(events.to_vec()))
    }
    fn reset(&self) {
        self.command(AudioCommand::Reset);
    }
}
impl Drop for Audio {
    fn drop(&mut self) {
        let (dummy, _) = mpsc::channel();
        drop(std::mem::replace(&mut self.commands, dummy));
        self.thread.take().unwrap().join().unwrap();
    }
}
fn event(note: u8, velocity: u8) -> TimedEvent {
    TimedEvent {
        frame_offset: 0,
        event: ControlEvent::NoteOn { note, velocity },
    }
}
fn request(
    host: &mut ParameterController,
    attachment: &str,
    id: u64,
    method: &str,
    args: Value,
) -> AdmittedRequest {
    let message=json!({"version":1,"attachmentId":attachment,"requestId":id.to_string(),"method":method,"args":args}).to_string();
    match host.admit(&message).unwrap() {
        Admission::New(request) => request,
        _ => panic!("new request required"),
    }
}
fn silent(output: ([f32; 16], [f32; 16])) {
    assert_eq!(output, ([0.; 16], [0.; 16]));
}
fn tail(output: ([f32; 16], [f32; 16]), expected: f32) {
    assert_eq!((output.0[15], output.1[15]), (expected, expected));
}
#[test]
fn public_packaged_gated_sample_calibrates_signed_hold_release_and_velocity() {
    let fixture = Fixture::new();
    let (_host, audio) = fixture.open();
    let full = audio.render(&[event(60, 127)]);
    assert_eq!((full.0[0], full.1[0]), (-0.5, -0.5));
    tail(full, -0.125);
    tail(audio.render(&[]), -0.125);
    silent(audio.render(&[TimedEvent {
        frame_offset: 0,
        event: ControlEvent::NoteOff { note: 60 },
    }]));
    let half = audio.render(&[event(60, 64)]);
    assert_eq!(
        (half.0[0], half.1[0]),
        (-0.5 * (64.0 / 127.0), -0.5 * (64.0 / 127.0))
    );
    tail(half, -0.125 * (64.0 / 127.0));
}
#[test]
fn authenticated_owner_press_release_and_detach_preserve_host_voice_under_full_queue() {
    let fixture = Fixture::new();
    let (mut host, audio) = fixture.open();
    let owner = host.attach_editor().unwrap();
    let other = host.attach_editor().unwrap();
    let now = Instant::now();
    let on = request(
        &mut host,
        &owner.attachment_id,
        1,
        "noteOn",
        json!([60, 1.0, 1]),
    );
    host.apply_editor_note(&on, now).unwrap();
    assert_eq!(audio.render(&[]).0[0], -0.5);
    tail(audio.render(&[]), -0.125);
    let foreign = request(
        &mut host,
        &other.attachment_id,
        1,
        "noteOff",
        json!([60, 1]),
    );
    assert!(host.apply_editor_note(&foreign, now).is_err());
    tail(audio.render(&[]), -0.125);
    let off = request(
        &mut host,
        &owner.attachment_id,
        2,
        "noteOff",
        json!([60, 1]),
    );
    host.apply_editor_note(&off, now).unwrap();
    silent(audio.render(&[]));
    let unknown = request(
        &mut host,
        &owner.attachment_id,
        3,
        "noteOff",
        json!([61, 1]),
    );
    host.apply_editor_note(&unknown, now).unwrap();
    let on = request(
        &mut host,
        &owner.attachment_id,
        4,
        "noteOn",
        json!([60, 0.5, 1]),
    );
    host.apply_editor_note(&on, now).unwrap();
    let output = audio.render(&[event(62, 127)]);
    assert_eq!(output.0[0], -0.5 - 0.5 * (64.0 / 127.0));
    // Saturate the ordinary runtime queue via actual parameter commands.
    for id in 5..9 {
        let value = request(
            &mut host,
            &owner.attachment_id,
            id,
            "setParameter",
            json!(["drums.level", 0.25, 1]),
        );
        host.apply(&value).unwrap();
        while host.acknowledge_automation() {}
    }
    let full = request(
        &mut host,
        &owner.attachment_id,
        9,
        "setParameter",
        json!(["drums.level", 0.25, 1]),
    );
    assert_eq!(host.apply(&full), Err(ParameterError::QueueFull));
    host.detach_editor(&owner.attachment_id).unwrap();
    tail(audio.render(&[]), -0.125);
    tail(audio.render(&[]), -0.125);
    assert!(host.apply_editor_note(&on, now).is_err());
    assert_eq!(host.parameter_state().sequence, 4);
    assert_eq!(host.session().owner_snapshot().revision, 0);
    let stale = request(
        &mut host,
        &other.attachment_id,
        20,
        "noteOn",
        json!([61, 1.0, 0]),
    );
    assert_eq!(
        host.apply_editor_note(&stale, now),
        Err(ParameterError::StaleGeneration)
    );
    let unsupported = request(
        &mut host,
        &other.attachment_id,
        21,
        "getParameterState",
        json!([]),
    );
    assert_eq!(
        host.apply_editor_note(&unsupported, now),
        Err(ParameterError::UnsupportedCommand)
    );
    audio.reset();
    silent(audio.render(&[]));
}
#[test]
fn sealed_note_dispatch_rejects_alteration_foreign_replay_and_overtaken_requests() {
    let fixture = Fixture::new();
    let (mut host, audio) = fixture.open();
    let (mut foreign, _other_audio) = fixture.open();
    let owner = host.attach_editor().unwrap();
    let other = host.attach_editor().unwrap();
    let foreign_owner = foreign.attach_editor().unwrap();
    let now = Instant::now();
    let foreign_request = request(
        &mut foreign,
        &foreign_owner.attachment_id,
        1,
        "noteOn",
        json!([60, 1.0, 1]),
    );
    assert!(host.apply_editor_note(&foreign_request, now).is_err());
    let mut original = request(
        &mut host,
        &owner.attachment_id,
        1,
        "noteOn",
        json!([60, 1.0, 1]),
    );
    let original_command = original.command.clone();
    original.command = dandrum_trigger_host::protocol::EditorCommand::NoteOn {
        note: 61,
        velocity: 1.0,
        generation: 1,
    };
    assert!(host.apply_editor_note(&original, now).is_err());
    original.command = original_command;
    silent(audio.render(&[]));
    host.apply_editor_note(&original, now).unwrap();
    assert_eq!(audio.render(&[]).0[0], -0.5);
    assert!(
        host.apply_editor_note(&original, now).is_err(),
        "retained requests must never retrigger"
    );
    tail(audio.render(&[]), -0.125);
    let conflict = request(
        &mut host,
        &other.attachment_id,
        1,
        "noteOn",
        json!([60, 1.0, 1]),
    );
    assert!(matches!(
        host.apply_editor_note(&conflict, now),
        Err(ParameterError::Runtime(_))
    ));
    host.detach_editor(&owner.attachment_id).unwrap();
    silent(audio.render(&[]));
    assert!(
        host.apply_editor_note(&conflict, now).is_err(),
        "semantic rejection is terminal even after conflict clears"
    );
    let older = request(
        &mut host,
        &other.attachment_id,
        2,
        "noteOn",
        json!([61, 1.0, 1]),
    );
    let newer = request(
        &mut host,
        &other.attachment_id,
        3,
        "noteOff",
        json!([61, 1]),
    );
    host.apply_editor_note(&newer, now).unwrap();
    assert!(host.apply_editor_note(&older, now).is_err());
    silent(audio.render(&[]));
    let fresh = request(
        &mut host,
        &other.attachment_id,
        4,
        "noteOn",
        json!([61, 0.001, 1]),
    );
    host.apply_editor_note(&fresh, now).unwrap();
    assert_eq!(audio.render(&[]).0[0], -0.5 / 127.0);
    host.detach_editor(&other.attachment_id).unwrap();
    silent(audio.render(&[]));
}
