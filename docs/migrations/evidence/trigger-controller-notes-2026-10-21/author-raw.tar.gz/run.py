import os,sys,json,time,subprocess,pathlib,hashlib,shutil,signal
base=pathlib.Path('/tmp/dandrum-lanes/evidence-controller-notes'); name=sys.argv[1]; out=base/name;out.mkdir(exist_ok=True)
root=pathlib.Path('/tmp/dandrum-lanes/protocol');env=os.environ.copy();target='/tmp/dandrum-lanes/cache-host-snapshot-cov' if 'coverage' in name else '/tmp/dandrum-lanes/cache-protocol'
env.update(CARGO_TARGET_DIR=target,CARGO_BUILD_JOBS='1',TMPDIR=str(base/'tmp'))
if 'coverage' in name:env.update(CARGO_LLVM_COV_TARGET_DIR=target,CARGO_LLVM_COV_BUILD_DIR=target)
if name.startswith('27-'):
 env['LLVM_PROFILE_FILE']=target+'/trigger-host-%p-%m.profraw'
 used_paths=[pathlib.Path(target).resolve(),(base/'tmp').resolve(),base.resolve()]
 assert all(path.exists() and path.stat().st_dev != pathlib.Path('/dev/shm').stat().st_dev for path in used_paths), 'all output paths must resolve to existing disk filesystem'
 print('Disk-only paths verified: '+str(used_paths),flush=True)
cmd=sys.argv[2:]; hashes={}
for p in ['src/trigger-host/src/parameters.rs','src/trigger-host/src/runtime.rs','src/trigger-host/src/protocol.rs','src/trigger-host/tests/editor_note_controller.rs','src/trigger-host/Cargo.toml','src/trigger-host/Cargo.lock']:
 s=root/p
 if s.exists():hashes[p]=hashlib.sha256(s.read_bytes()).hexdigest(); d=out/'source'/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(s,d)
def resources():
 m={k:int(v.split()[0])*1024 for k,v in (line.split(':',1) for line in pathlib.Path('/proc/meminfo').read_text().splitlines())};return {'disk':shutil.disk_usage('/tmp').free,'shm':shutil.disk_usage('/dev/shm').free,'memory':m['MemAvailable']}
first=resources(); mins=first.copy();limits={'disk':2**30,'shm':256*2**20,'memory':4*2**30};stop=None;t=time.monotonic()
if name.startswith('27-'):
 limits.pop('shm');print('UNUSED_VOLUME /dev/shm: sampled only; no RAM output or target path; its 256MiB floor is not lowered or claimed PASS',flush=True)
if any(first[k]<v for k,v in limits.items()):raise SystemExit('resource launch guard failed '+str(first))
with (out/'output.log').open('w') as f:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  r=resources();mins={k:min(mins[k],v) for k,v in r.items()}
  if any(r[k]<v for k,v in limits.items()):stop=r;os.killpg(p.pid,signal.SIGTERM);break
  time.sleep(1)
 rc=p.wait()
receipt=dict(command=cmd,cwd=str(root),exit=rc,seconds=time.monotonic()-t,environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','TMPDIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','LLVM_PROFILE_FILE'] if k in env},source_hashes=hashes,resource_first=first,resource_min=mins,stop=stop)
if name.startswith('27-'):receipt['unused_volume']={'path':'/dev/shm','classification':'UNUSED_VOLUME','minimum_unchanged_bytes':256*2**20,'below_floor':mins['shm']<256*2**20,'reason':'All target/profile/report/TMPDIR outputs resolve to disk; no RAM output attempted; no RAM-floor PASS claimed'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));print((out/'output.log').read_text()[-4000:]);sys.exit(rc)
