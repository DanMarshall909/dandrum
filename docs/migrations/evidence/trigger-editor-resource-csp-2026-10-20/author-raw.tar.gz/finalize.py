import pathlib,json,hashlib,subprocess,shutil,os,time,re,struct,zlib
p=pathlib.Path('/tmp/dandrum-lanes/evidence-editor-resource-csp');root=pathlib.Path.cwd();h=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((p/n).read_text())
def put(n,x):(p/n).write_text(json.dumps(x,indent=2)+'\n')
final=load('release-fmt-hashes.json');assert len(final)==19
assert all(h((root/f).read_bytes())==v for f,v in final.items())
old=['src/trigger-editor/src/native_x11.rs','src/trigger-editor/tests/internal/native_x11.rs','src/trigger-editor/tests/internal/local_policy.rs'];new=['src/trigger-editor/tests/internal/resource_policy.rs','src/trigger-editor/tests/fixtures/resource-policy.mjs','src/trigger-editor/tests/fixtures/resource-policy.png'];paths=old+new
candidate={f:final[f] for f in paths};put('final-candidate-hashes.json',candidate);put('final-source-hashes.json',final);shutil.copytree(p/'release-fmt-source',p/'release-candidate-source')
labels=['initial-native-coverage','release-fast-coverage','release-clippy','release-ctest','release-build','release-fmt','release-diff','release-default-graph'];checks={}
for label in labels:
 assert load(label+'-hashes.json')==final
 run=load(label+'-run.json');assert run['exit']==0
 checks[label]={'snapshot':label+'-source','manifest':label+'-hashes.json','run':label+'-run.json','log':label+'.log','log_sha256':h((p/(label+'.log')).read_bytes()),'exit':run['exit'],'elapsed_seconds':run['elapsed_seconds']}
put('final-source-binding.json',{'final_source_manifest':'final-source-hashes.json','all19paths_identical':True,'native_coverage_reuse':'initial-native-coverage is exact final source. No new source/refactor after calibrated GREEN; retained names unchanged; no fresh native run solely for release prefix.','checks':checks})
phases={}
for label in ['baseline-unchanged-four-resources','red-four-resource-denials','green-header-only','red-calibrated-full-uri','green-calibrated-full-uri','initial-native-coverage','final-test-old-header-red','final-test-restored-header-green']:
 m=load(label+'-hashes.json');run=load(label+'-run.json');phases[label]={'manifest':label+'-hashes.json','snapshot':label+'-source','run':label+'-run.json','log':label+'.log','log_sha256':h((p/(label+'.log')).read_bytes()),'exit':run['exit'],'elapsed_seconds':run['elapsed_seconds'],'candidate_hashes':{f:m[f] for f in paths}}
red=load('final-test-old-header-red-hashes.json');green=load('final-test-restored-header-green-hashes.json');diff=[f for f in final if red[f]!=final[f]];assert diff==[old[0]];assert green==final
base_owner=subprocess.check_output(['git','show','HEAD:'+old[0]]);assert h(base_owner)==red[old[0]]
put('phase-source-binding.json',{'phases':phases,'final_test_oldheader_RED_vs_final_difference':diff,'RED_owner_equals_published_base':True,'final_test_GREEN_equals_all19release_source_paths':True,'calibration_failure':'green-header-only exit101 is solely blockedURI assumption: engine reports full known HTTP resource URLs, not origin-only. All four denials, exact effective/violated identities, enforce, local positives and zero postcalibration GETs already passed; not a new production defect/RED. Corrected fullURI tests then get genuine oldheaderRED and restoredGREEN.','redundant_comparable_attempt':'final-test oldheaderRED/restoredGREEN were already launched before root no-redundancy instruction arrived; preserved with no new source delta. No further identical native coverage rerun.'})
unchanged={}
for f,v in final.items():
 if f in paths:continue
 base=subprocess.check_output(['git','show','HEAD:'+f]);assert h(base)==v;unchanged[f]={'base_sha256':h(base),'current_sha256':v}
put('unchanged-boundary-hashes.json',{'base':'c3f6ca8adf93089dd08630151d1a4e70b11408be','unchanged13manifest_paths':unchanged,'new_native_test_paths':new,'changed_native_paths':old,'guard_limit':'No author source-free guard run. Root independently qualifies unchanged cfg/default boundary and complete586vs583input inventory; no old fullmanifest equality claim.'})
for lane,phase in [('native','initial'),('fast','release')]:
 data=load(phase+'-'+lane+'-coverage.json')['data'][0];put('final-'+lane+'-coverage-summary.json',{f['filename']:f['summary'] for f in data['files'] if f['filename'].endswith(('/src/native_x11.rs','/src/assets.rs'))})
a=load('initial-coverage-export-runs.json');b=load('release-fast-coverage-export-runs.json');assert a['binary_sha256']==b['binary_sha256'];put('instrumented-binary-binding.json',{'native_export':'initial-coverage-export-runs.json','fast_export':'release-fast-coverage-export-runs.json','same_binary_sha256':a['binary_sha256'],'source_manifests_equal':True})
bundle=pathlib.Path('/dev/shm/dandrum-beta-20261020/editor-cmake/clap/DandrumTrigger.resources/editor');bundlehash={str(f.relative_to(bundle)):{'sha256':h(f.read_bytes()),'length':f.stat().st_size} for f in sorted(bundle.rglob('*')) if f.is_file()};assert len(bundlehash)==14;put('production-bundle-input-hashes.json',{'directory':str(bundle),'files':bundlehash,'external_font_fixture':'fonts/91c841fdfa8e7b94.ttf','external_font_identity':bundlehash['fonts/91c841fdfa8e7b94.ttf'],'scope':'Unmodified existing silent-preview bundle; no fake native backend.'})
png=(root/new[2]).read_bytes();offset=8;chunks=[];data=b''
while offset<len(png):
 n=struct.unpack('>I',png[offset:offset+4])[0];t=png[offset+4:offset+8];body=png[offset+8:offset+8+n];crc=struct.unpack('>I',png[offset+8+n:offset+12+n])[0];assert zlib.crc32(t+body)==crc;chunks.append(t.decode());data+=body if t==b'IDAT' else b'';offset+=12+n
assert struct.unpack('>II',png[16:24])==(1,1);assert zlib.decompress(data)==b'\x00\xff\x00\x00\xff';put('png-independent-validation.json',{'sha256':h(png),'chunks':chunks,'all_chunk_CRCs_valid':True,'IHDR_dimensions':[1,1],'decompressed_scanline_hex':zlib.decompress(data).hex(),'length':len(png)})
shutil.copyfile('/dev/shm/dandrum-beta-20261020/editor-cmake/Testing/Temporary/LastTest.log',p/'release-ctest-LastTest.log')
versions={}
for name,cmd in {'rustc':['/home/dan/.cargo/bin/rustc','--version'],'cargo':['/home/dan/.cargo/bin/cargo','--version'],'clippy':['/home/dan/.cargo/bin/cargo','clippy','--version'],'rustfmt':['/home/dan/.cargo/bin/cargo','fmt','--version'],'ctest':['/home/dan/.local/bin/ctest','--version'],'gtk_webkit':['pkg-config','--modversion','gtk+-3.0','webkit2gtk-4.1']}.items():versions[name]={'command':cmd,'output':subprocess.check_output(cmd,text=True)}
put('tool-versions.json',versions)
processes=[]
for proc in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  argv=[x.decode(errors='replace') for x in (proc/'cmdline').read_bytes().split(b'\0') if x]
  if not argv:continue
  exe=pathlib.Path(argv[0]).name
  if exe in ['cargo','rustc','rustdoc'] or (argv[0].startswith('/dev/shm/dandrum-beta-20261020/editor-target/') and 'dandrum_trigger_editor-' in argv[0]):
   env=(proc/'environ').read_bytes().split(b'\0');owned=b'CARGO_TARGET_DIR=/dev/shm/dandrum-beta-20261020/editor-target' in env or argv[0].startswith('/dev/shm/dandrum-beta-20261020/editor-target/')
   if owned:processes.append({'pid':proc.name,'argv':argv})
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not processes
put('release-operational.json',{'time':time.time(),'owned_processes':processes,'runtime_status':subprocess.check_output(['git','status','--porcelain'],text=True),'runtime_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'main_status':subprocess.check_output(['git','-C','/home/dan/code/dandrum','status','--porcelain'],text=True),'main_HEAD':subprocess.check_output(['git','-C','/home/dan/code/dandrum','rev-parse','HEAD'],text=True).strip(),'free_bytes':{f:os.statvfs(f).f_bavail*os.statvfs(f).f_frsize for f in ['/tmp','/dev/shm','/run/user/1000']}})
print(json.dumps(candidate,indent=2));print('all19paths source-bound;8checks pass;0ownedprocesses')
