import pathlib,json,hashlib,subprocess,shutil,os,time,re,struct,zlib
p=pathlib.Path('/tmp/dandrum-lanes/evidence-editor-resource-csp');root=pathlib.Path.cwd();h=lambda b:hashlib.sha256(b).hexdigest();load=lambda n:json.loads((p/n).read_text())
def put(n,x):(p/n).write_text(json.dumps(x,indent=2)+'\n')
bundle=pathlib.Path('/dev/shm/dandrum-beta-20261020/editor-cmake/clap/DandrumTrigger.resources/editor');bundlehash={str(f.relative_to(bundle)):{'sha256':h(f.read_bytes()),'length':f.stat().st_size} for f in sorted(bundle.rglob('*')) if f.is_file()};assert len(bundlehash)==15;put('production-bundle-input-hashes.json',{'directory':str(bundle),'staged_files':bundlehash,'declared14asset_files':{f:v for f,v in bundlehash.items() if f!='fonts/.gitattributes'},'extra_unserved_file':'fonts/.gitattributes (outside exact14resolver table; untouched)', 'external_font_fixture':'fonts/91c841fdfa8e7b94.ttf','external_font_identity':bundlehash['fonts/91c841fdfa8e7b94.ttf'],'scope':'Unmodified existing silent-preview bundle; no fake native backend.'})
png=(root/new[2]).read_bytes();offset=8;chunks=[];data=b''
while offset<len(png):
 n=struct.unpack('>I',png[offset:offset+4])[0];t=png[offset+4:offset+8];body=png[offset+8:offset+8+n];crc=struct.unpack('>I',png[offset+8+n:offset+12+n])[0];assert zlib.crc32(t+body)==crc;chunks.append(t.decode());data+=body if t==b'IDAT' else b'';offset+=12+n
assert struct.unpack('>II',png[16:24])==(1,1);assert zlib.decompress(data)==b'\x00\xff\x00\x00\xff';put('png-independent-validation.json',{'sha256':h(png),'chunks':chunks,'all_chunk_CRCs_valid':True,'IHDR_dimensions':[1,1],'decompressed_scanline_hex':zlib.decompress(data).hex(),'length':len(png)})
shutil.copyfile('/dev/shm/dandrum-beta-20261020/editor-cmake/Testing/Temporary/LastTest.log',p/'release-ctest-LastTest.log')
versions={}
for name,cmd in {'rustc':['/home/dan/.cargo/bin/rustc','--version'],'cargo':['/home/dan/.cargo/bin/cargo','--version'],'clippy':['/home/dan/.cargo/bin/cargo','clippy','--version'],'rustfmt':['/home/dan/.cargo/bin/cargo','fmt','--version'],'ctest':['/home/dan/.local/bin/ctest','--version'],'gtk_webkit':['pkg-config','--modversion','gtk+-3.0','webkit2gtk-4.1']}.items():versions[name]={'command':cmd,'output':subprocess.check_output(cmd,text=True)}
put('tool-versions.json',versions)
processes=[]
for proc in pathlib.Path('/proc').glob('[0-9]*'):
 try:
  argv=[x.decode(errors='replace') for x in (proc/'cmdline').read_bytes().split(b'\0') if x]
  if not argv:continue
  exe=pathlib.Path(argv[0]).name
  if exe in ['cargo','rustc','rustdoc'] or (argv[0].startswith('/dev/shm/dandrum-beta-20261020/editor-target/') and 'dandrum_trigger_editor-' in argv[0]):
   env=(proc/'environ').read_bytes().split(b'\0');owned=b'CARGO_TARGET_DIR=/dev/shm/dandrum-beta-20261020/editor-target' in env or argv[0].startswith('/dev/shm/dandrum-beta-20261020/editor-target/')
   if owned:processes.append({'pid':proc.name,'argv':argv})
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not processes
put('release-operational.json',{'time':time.time(),'owned_processes':processes,'runtime_status':subprocess.check_output(['git','status','--porcelain'],text=True),'runtime_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'main_status':subprocess.check_output(['git','-C','/home/dan/code/dandrum','status','--porcelain'],text=True),'main_HEAD':subprocess.check_output(['git','-C','/home/dan/code/dandrum','rev-parse','HEAD'],text=True).strip(),'free_bytes':{f:os.statvfs(f).f_bavail*os.statvfs(f).f_frsize for f in ['/tmp','/dev/shm','/run/user/1000']}})
print('remaining metadata validated;15staged files include14declared assets+unservedfonts/.gitattributes;0ownedprocesses')
