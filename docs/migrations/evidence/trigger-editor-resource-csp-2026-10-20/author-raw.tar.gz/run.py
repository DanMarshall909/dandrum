import subprocess,time,json,os,pathlib,sys,hashlib,shutil
p=pathlib.Path('/tmp/dandrum-lanes/evidence-editor-resource-csp');label=sys.argv[1]
cmd=sys.argv[2:] or ['/home/dan/.cargo/bin/cargo','test','--locked','--offline','--jobs','2','--manifest-path','src/trigger-editor/Cargo.toml','--features','native-x11','--lib','native_x11::tests::real_child_loads_local_content_and_drops_without_owning_the_host_parent','--','--ignored','--exact','--nocapture','--test-threads=1']
env={'CARGO_TARGET_DIR':'/dev/shm/dandrum-beta-20261020/editor-target','DISPLAY':':10.0','GDK_BACKEND':'x11','TMPDIR':'/dev/shm/dandrum-beta-20261020/editor-scratch','DANDRUM_TRIGGER_EDITOR_BUNDLE_DIR':'/dev/shm/dandrum-beta-20261020/editor-cmake/clap/DandrumTrigger.resources/editor'}
snap=p/(label+'-source');snap.mkdir();shutil.copytree('src/trigger-editor',snap/'src/trigger-editor');shutil.copyfile('CMakeLists.txt',snap/'CMakeLists.txt');(snap/'tests/python').mkdir(parents=True);shutil.copyfile('tests/python/test_engine_only_build.py',snap/'tests/python/test_engine_only_build.py')
(p/(label+'-hashes.json')).write_text(json.dumps({str(f.relative_to(snap)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(snap.rglob('*')) if f.is_file()},indent=2)+'\n')
t=time.monotonic()
with (p/(label+'.log')).open('w') as log:r=subprocess.run(cmd,env=dict(os.environ,**env),stdout=log,stderr=subprocess.STDOUT)
(p/(label+'-run.json')).write_text(json.dumps({'cwd':os.getcwd(),'command':cmd,'env':env,'exit':r.returncode,'elapsed_seconds':time.monotonic()-t},indent=2)+'\n');print(r.returncode);sys.exit(r.returncode)
