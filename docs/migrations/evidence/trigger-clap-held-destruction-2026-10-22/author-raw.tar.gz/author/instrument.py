from pathlib import Path
import json,subprocess,os,sys,hashlib
out=Path('/tmp/dandrum-evidence/g3-held-destruction'); label=sys.argv[1];kind=sys.argv[2]
recipe = 'trigger_parameters-test-rustc.json' if kind == 'native' else 'ordinary-dso-rustc.json'
capture=json.loads((out/recipe).read_text())
directory=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g3-held-destruction')/label;directory.mkdir(parents=True,exist_ok=False)
command=list(capture['command']);command[command.index('--out-dir')+1]=str(directory);command+=['-C','instrument-coverage']
host_override=os.environ.get('DANDRUM_COVERAGE_HOST_RLIB')
if host_override:
 original_host=[(i,arg) for i,arg in enumerate(command) if i and command[i-1]=='--extern' and arg.startswith('dandrum_trigger_host=')]
 assert len(original_host)==1
 command[original_host[0][0]]='dandrum_trigger_host='+host_override

env=os.environ.copy();env.update(capture['environment'])
for key in ('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS','RUSTC_WRAPPER','LD_PRELOAD','LLVM_PROFILE_FILE'):env.pop(key,None)
env['RUST_MIN_STACK']='16777216'
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt={'capture':capture,'command':command,'cwd':capture['cwd'],'environment':{k:env[k] for k in capture['environment'] if k in env},'only_diff':'outdir redirect plus -C instrument-coverage;16MiB builder stack only; no runtime override','compiler':subprocess.check_output([command[0],'-Vv'],text=True),'source_sha256':{str(p):h(p) for p in Path(capture['cwd']).joinpath('src').rglob('*.rs')},'extern_sha256':{arg:h(arg.split('=',1)[1]) for i,arg in enumerate(command) if i and command[i-1]=='--extern'}}
if host_override:
 receipt['only_diff']+='; exact actual host extern replaced with explicitly instrumented same-recipe rlib'
 receipt['original_host_extern']=original_host[0][1]
 receipt['host_override']=host_override
(out/(label+'-instrument.json')).write_text(json.dumps(receipt,indent=2))
result=subprocess.run(command,cwd=capture['cwd'],env=env);receipt['exit']=result.returncode
(out/(label+'-instrument.json')).write_text(json.dumps(receipt,indent=2));sys.exit(result.returncode)
