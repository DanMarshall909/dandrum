from pathlib import Path
import subprocess,sys
out=Path('/tmp/dandrum-evidence/g3-held-destruction')
cases=[
'structural_native::copied_native_mapping_survives_lost_reply_and_view_loss',
'copied_native_parameter_state_is_an_authenticated_numeric_dto',
'copied_native_parameter_flush_delivers_host_accepted_gestures',
'copied_native_automation_survives_rejected_output_activation_failures_and_audio_return',
'copied_native_gui_requires_host_timer',
'copied_native_gui_rejects_refused_host_timer',
'copied_native_host_timer_delivers_a_later_rendered_parameter_edit',
'copied_native_timer_rollback_retains_disabled_cleanup_and_retries',
'copied_native_view_independent_source_collects_accepted_automation_credits',
'copied_native_host_feedback_updates_rendered_control_without_polling_or_undo_pollution',
'copied_native_invalid_stopped_flush_preserves_uncollected_automation_ownership',
'copied_native_parameter_callbacks_allocate_and_destroy_nothing_while_gui_services',
]
cases += [
'note_native::copied_native_destroy_releases_held_activity_once_and_reconnects',
'note_native::copied_native_gated_sample_outlasts_short_fixture_and_releases',
'note_native::copied_native_heartbeat_renews_held_note_past_original_deadline',
'note_native::copied_native_live_attachment_expires_renewed_note_and_preserves_host_voice',
]
import json,time
receipts=[]
logs=out/'final-candidate-native-cases';logs.mkdir(exist_ok=True)
for case in cases:
 start=time.monotonic()
 with open(logs/(case+'.stdout.log'),'wb') as stdout,open(logs/(case+'.stderr.log'),'wb') as stderr:
  result=subprocess.run([sys.executable,str(out/'native.py'),'final-product-build',case],stdout=stdout,stderr=stderr)
 receipts.append({'case':case,'exit':result.returncode,'seconds':time.monotonic()-start})
 (out/'final-candidate-native-cases.json').write_text(json.dumps(receipts,indent=2))
 print(receipts[-1],flush=True)
 if result.returncode:sys.exit(result.returncode)
print('Verified final exact parameter/structural/note cases:',len(cases))
