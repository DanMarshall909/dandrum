from pathlib import Path
import json,subprocess,hashlib,sys
out=Path('/tmp/dandrum-evidence/g3-held-destruction'); label=sys.argv[1]; directory=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g3-held-destruction')/label;elf=directory/'libdandrum_clap_adapter.so'
if not elf.exists(): elf=next(p for p in directory.glob('trigger_parameters-*') if p.is_file() and p.suffix=='')
tools=Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin');raw=list((directory/'profiles').glob('*.profraw'));assert raw
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();merged=directory/'coverage.profdata';export=out/(label+'-raw-export.json')
commands=[[str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in raw],'-o',str(merged)],[str(tools/'llvm-cov'),'export',str(elf),'--instr-profile='+str(merged)]]
receipt={'tool_versions':{n:subprocess.check_output([str(tools/n),'--version'],text=True) for n in ('llvm-profdata','llvm-cov')},'tool_sha256':{n:h(tools/n) for n in ('llvm-profdata','llvm-cov')},'elf':str(elf),'elf_sha256':h(elf),'profiles':{str(p):h(p) for p in raw},'commands':commands}
for i,command in enumerate(commands):
 with open(out/(label+'-export-'+str(i)+'.stderr.log'),'wb') as err:
  if i:
   with open(export,'wb') as stdout:r=subprocess.run(command,stdout=stdout,stderr=err)
  else:r=subprocess.run(command,stdout=subprocess.DEVNULL,stderr=err)
 assert r.returncode==0
receipt['export_sha256']=h(export)
data=json.loads(export.read_text());functions=[]
for d in data['data']:
 for f in d['functions']:
  if '/trigger/gui.rs' in '\n'.join(f['filenames']) and any(n in f['name'] for n in ('8dispatch','15parameter_reply','16parameter_values','15parameter_error','13command_error','14service_editor','16destroy_editor','18cleanup_attachment','7destroy','copied_native_destroy','HeldAudio')):
   functions.append({'name':f['name'],'count':f['count'],'regions':f['regions']})
receipt['dispatch_functions']=functions;(out/(label+'-coverage-binding.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps(functions,indent=2))
