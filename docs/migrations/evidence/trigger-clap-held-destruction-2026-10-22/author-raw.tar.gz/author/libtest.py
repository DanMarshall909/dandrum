import pathlib,json,hashlib,sys,os
from exact import run_exact
assert 'RUST_MIN_STACK' not in os.environ and 'LD_PRELOAD' not in os.environ
out=pathlib.Path('/tmp/dandrum-evidence/g3-held-destruction');binding=json.loads((out/(sys.argv[1]+'-binding.json')).read_text());elf=binding['test'];assert hashlib.sha256(pathlib.Path(elf).read_bytes()).hexdigest()==binding['test_sha256']
sys.exit(run_exact(elf,sys.argv[2],False))
