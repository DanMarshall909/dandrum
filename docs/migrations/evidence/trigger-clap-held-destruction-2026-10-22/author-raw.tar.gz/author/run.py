import os,sys,json,time,hashlib,pathlib,subprocess,shutil,signal,resource
ROOT=pathlib.Path(os.environ.get('DANDRUM_EVIDENCE_SOURCE_ROOT','/tmp/dandrum-lanes/runtime'))
OUT=pathlib.Path('/tmp/dandrum-evidence/g3-held-destruction')
label,target,*command=sys.argv[1:]
assert target in ("/tmp/dandrum-lanes/cache-editor-guard", "/tmp/dandrum-lanes/cache-host-snapshot-cov"), "only an absolute loaned target is authorized"
env=os.environ.copy()
env.update(CARGO_TARGET_DIR=target,CARGO_LLVM_COV_TARGET_DIR='/tmp/dandrum-lanes/cache-host-snapshot-cov',CARGO_LLVM_COV_BUILD_DIR='/tmp/dandrum-lanes/cache-host-snapshot-cov',CARGO_BUILD_JOBS='1',TMPDIR=str(OUT/'tmp'),DANDRUM_TRIGGER_GUI_PLUGIN_PATH=str(OUT/'installed/DandrumTrigger.clap'))
def resources():
 mem={line.split(':')[0]:int(line.split()[1])*1024 for line in open('/proc/meminfo') if line.startswith(('MemAvailable:','MemTotal:'))}
 processes=[]
 for d in pathlib.Path('/proc').iterdir():
  if not d.name.isdigit(): continue
  try:
   comm=(d/'comm').read_text().strip()
   if comm in ('cargo','rustc','rust-lld','ld','cc','clang','cc1'):
    processes.append({'pid':int(d.name),'comm':comm,'cmdline':(d/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')})
  except (FileNotFoundError,PermissionError,ProcessLookupError): pass
 return {'disk_free_bytes':shutil.disk_usage('/tmp').free,**mem,'builders':processes}
initial=resources()
assert initial['disk_free_bytes']>=1073741824 and initial['MemAvailable']>=4294967296,initial
# Builders are sampled; only this launched process group is stopped by the guard.
sources={}
for crate in os.environ.get('DANDRUM_EVIDENCE_SOURCE_CRATES','clap-adapter').split(','):
 for p in (ROOT/'src'/crate).rglob('*'):
  if p.is_file() and (crate in ('trigger-editor','clap-adapter') or p.suffix in ('.rs','.js','.mjs') or p.name in ('Cargo.toml','Cargo.lock')) and 'target' not in p.parts:
   rel=p.relative_to(ROOT); data=p.read_bytes(); sources[str(rel)]=hashlib.sha256(data).hexdigest()
   dest=OUT/label/'source'/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
receipt={'core_limit_bytes':0,'command':command,'cwd':str(ROOT),'environment':{k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','CARGO_BUILD_JOBS','TMPDIR','DANDRUM_TRIGGER_GUI_PLUGIN_PATH')},'native_environment':{k:env.get(k) for k in ('DISPLAY','GDK_BACKEND','XAUTHORITY','LLVM_PROFILE_FILE')},'source_sha256':sources,'resource_before':initial,'cache_sizes':subprocess.check_output(['du','-sb','/tmp/dandrum-lanes/cache-runtime','/tmp/dandrum-lanes/cache-editor-guard','/tmp/dandrum-lanes/cache-host-snapshot-cov'],text=True),'output_paths':{k:os.path.realpath(env[k]) for k in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','TMPDIR')}}
(OUT/(label+'.json')).write_text(json.dumps(receipt,indent=2))
start=time.monotonic(); samples=[]; stopped=None
with open(OUT/(label+'.stdout.log'),'wb') as stdout,open(OUT/(label+'.stderr.log'),'wb') as stderr:
 proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_CORE,(0,0)))
 receipt['owned_process_group']=proc.pid
 (OUT/(label+'.json')).write_text(json.dumps(receipt,indent=2))
 while proc.poll() is None:
  now=resources(); samples.append({'elapsed_seconds':time.monotonic()-start,**now})
  if now['disk_free_bytes']<1073741824 or now['MemAvailable']<4294967296:
   stopped='resource floor'; os.killpg(proc.pid,signal.SIGTERM); break
  if time.monotonic()-start>600:
   stopped='bounded setup deadline'; os.killpg(proc.pid,signal.SIGTERM); break
  time.sleep(1)
 try: code=proc.wait(timeout=10)
 except subprocess.TimeoutExpired:
  os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
receipt.update(exit=code,seconds=time.monotonic()-start,resource_after=resources(),stop_reason=stopped)
(OUT/(label+'.samples.json')).write_text(json.dumps(samples,indent=2))
(OUT/(label+'.json')).write_text(json.dumps(receipt,indent=2))
print(json.dumps({'label':label,'exit':code,'seconds':receipt['seconds'],'stop_reason':stopped,'resource_after':receipt['resource_after']}))
sys.exit(code)
