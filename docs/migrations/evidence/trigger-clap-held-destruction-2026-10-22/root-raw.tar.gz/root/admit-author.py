from pathlib import Path
import hashlib,json,subprocess
out=Path('/tmp/dandrum-evidence/g3-held-native-fixture');author=Path('/tmp/dandrum-evidence/g3-held-destruction');runtime=Path('/tmp/dandrum-lanes/runtime');root=Path('/tmp/dandrum-lanes/integration');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((author/'evidence-manifest.json').read_text());total=0
for name,expected in manifest.items():
 p=author/name;assert p.is_file() and not p.is_symlink() and '..' not in Path(name).parts;assert sha(p)==expected,name;total+=p.stat().st_size
path='src/clap-adapter/tests/internal/trigger_note_native.rs';expected='edb8ff581897df35ed3f70415b8ea5037d17770145563e387827bf6656266aee';assert sha(runtime/path)==expected
cache=runtime/'cache-editor-guard';rows=[]
for p in sorted(cache.rglob('*')):
 if p.is_symlink():rows.append(dict(path=str(p.relative_to(cache)),symlink=str(p.readlink())))
 elif p.is_file():rows.append(dict(path=str(p.relative_to(cache)),mode=p.stat().st_mode&0o777,size=p.stat().st_size,sha256=sha(p)))
assert rows==json.loads(Path('/tmp/dandrum-evidence/g3-note-publication/runtime-preserved-cache-baseline.json').read_text())
git=lambda p,*a:subprocess.check_output(['git',*a],cwd=p).decode().strip()
assert git(runtime,'rev-parse','HEAD')==git(root,'rev-parse','HEAD')=='16a4dafa1994211ddad2d80e22038f20e3e61f19'
assert set(line[3:] for line in subprocess.check_output(['git','status','--porcelain'],cwd=runtime).decode().splitlines())=={path,'cache-editor-guard/'}
assert set(line[3:] for line in subprocess.check_output(['git','status','--porcelain'],cwd=root).decode().splitlines())=={'CMakeLists.txt','tests/python/test_engine_only_build.py'}
p=subprocess.run(['ps','-C','cargo,rustc,cmake,ctest','-o','pid,ppid,etime,args'],stdout=subprocess.PIPE);assert p.returncode==1 and p.stdout.decode().strip()=='PID    PPID     ELAPSED COMMAND'
r=dict(evidence_files=len(manifest),evidence_bytes=total,evidence_manifest_sha256=sha(author/'evidence-manifest.json'),handoff_sha256=sha(author/'handoff.md'),source_path=path,source_sha256=expected,cache_files=len(rows),actual_host_builder_inventory=p.stdout.decode(),ownership='Explicit source and both native/LLVM cache handback accepted; root sole writer/builder now.');(out/'author-release-admitted.json').write_text(json.dumps(r,indent=2)+'\n')
(out/'integration-before').mkdir(exist_ok=True);(out/'integration-before'/'trigger_note_native.rs').write_bytes((root/path).read_bytes());(root/path).write_bytes((runtime/path).read_bytes())
mirrors=[]
for path in ['CMakeLists.txt','tests/python/test_engine_only_build.py']:
 before=sha(runtime/path);(runtime/path).write_bytes((root/path).read_bytes());mirrors.append(dict(path=path,before_sha256=before,after_sha256=sha(runtime/path)))
(out/'source-integration.json').write_text(json.dumps(dict(source=r,registration_mirrors=mirrors),indent=2)+'\n');print(json.dumps(r))
