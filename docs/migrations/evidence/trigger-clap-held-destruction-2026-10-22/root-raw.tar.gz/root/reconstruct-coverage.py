from pathlib import Path
import hashlib,json,subprocess,time
out=Path('/tmp/dandrum-evidence/g3-held-native-fixture');author=Path('/tmp/dandrum-evidence/g3-held-destruction');root=Path('/tmp/dandrum-lanes/integration');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();runs={};selected=[]
for kind in ['dso','host']:
 b=json.loads((author/f'held-{kind}-final-coverage-binding.json').read_text());assert sha(Path(b['elf']))==b['elf_sha256']
 for p,h in b['profiles'].items():assert sha(Path(p))==h
 for tool,h in b['tool_sha256'].items():assert sha(Path(b['commands'][0 if tool=='llvm-profdata' else 1][0]))==h
 original=author/f'held-{kind}-final-raw-export.json';assert sha(original)==b['export_sha256'];profile=out/f'root-{kind}.profdata';merge=b['commands'][0].copy();merge[merge.index('-o')+1]=str(profile);export=b['commands'][1].copy();export[-1]='--instr-profile='+str(profile);start=time.monotonic()
 for command,label in [(merge,'merge'),(export,'export')]:
  p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30);(out/f'root-{kind}-{label}.stderr.log').write_bytes(p.stderr);assert p.returncode==0
  if label=='export':(out/f'root-{kind}-raw-export.json').write_bytes(p.stdout)
 regenerated=out/f'root-{kind}-raw-export.json';assert json.loads(regenerated.read_text())==json.loads(original.read_text()),'Regenerated LLVM data differs';data=json.loads(regenerated.read_text())['data'][0]
 rows=[]
 for f in data['functions']:
  name=f['name'];wanted=(kind=='dso' and ('destroy_editor' in name or 'cleanup_attachment' in name or ('PluginGuiImpl7destroy' in name))) or (kind=='host' and ('copied_native_destroy_releases_held_activity_once_and_reconnects' in name or 'HeldAudio' in name))
  if not wanted:continue
  suffix='src/clap-adapter/src/trigger/gui.rs' if kind=='dso' else 'src/clap-adapter/tests/internal/trigger_note_native.rs'
  regions=[r for r in f['regions'] if r[7]==0 and f['filenames'][r[5]].endswith('/'+suffix)]
  assert regions;row=dict(name=name,source=suffix,source_sha256=sha(root/suffix),function_count=f['count'],source_regions=len(regions),positive_source_regions=sum(r[4]>0 for r in regions),zero_hit_spans=[r[:4] for r in regions if r[4]==0]);rows.append(row)
 assert rows
 runs[kind]=dict(binding_sha256=sha(author/f'held-{kind}-final-coverage-binding.json'),elf_sha256=b['elf_sha256'],raw_profiles=len(b['profiles']),regenerated_export_sha256=sha(regenerated),original_export_sha256=sha(original),regeneration_seconds=time.monotonic()-start,functions=rows)
r=dict(runs=runs,qualification='Fresh root merge/export from rehashed raw profiles and actual ELFs using verified exact tools; parsed LLVM data equals author final exports. File-identified code regions only, no branch/whole-owner/universal-callback proof. Production unchanged; normal cleanup error spans disclosed. Host profile pair includes exact-list invocation and actual case, not two test executions.');(out/'root-final-coverage-assessment.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:[dict(name=x['name'],regions=x['source_regions'],positive=x['positive_source_regions']) for x in v['functions']] for k,v in runs.items()}))
