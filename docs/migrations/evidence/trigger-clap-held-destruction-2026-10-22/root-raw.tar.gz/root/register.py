from pathlib import Path
import json,hashlib,sys
root=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g3-held-native-fixture');phase=sys.argv[1];assert phase in ('test','implementation')
path='tests/python/test_engine_only_build.py' if phase=='test' else 'CMakeLists.txt';p=root/path;before=p.read_bytes();expected={'test':'929fd0ae87f491bd19c0e9d328f0206b9b1df738d25c86a3c09b590083d9f2a4','implementation':'f90b6efbe6383b4f7d8d4c72d856f81e4c81d5a98ae5ee374483517672b70b7b'}[phase];assert hashlib.sha256(before).hexdigest()==expected
s=before.decode();selector='note_native::copied_native_destroy_releases_held_activity_once_and_reconnects'
if phase=='test':
 old='''            "trigger-clap-native-parameter-note-expiry":
                "note_native::copied_native_live_attachment_expires_renewed_note_and_preserves_host_voice",
''';new=old+f'            "trigger-clap-native-parameter-note-destroy":\n                "{selector}",\n';assert s.count(old)==1;s=s.replace(old,new)
else:
 old='                note-hold note-heartbeat note-expiry)';new='                note-hold note-heartbeat note-expiry note-destroy)';assert s.count(old)==1;s=s.replace(old,new)
 old='                note_native::copied_native_live_attachment_expires_renewed_note_and_preserves_host_voice)';new='                note_native::copied_native_live_attachment_expires_renewed_note_and_preserves_host_voice\n                '+selector+')';assert s.count(old)==1;s=s.replace(old,new)
assert not (out/(phase+'-before')).exists();(out/(phase+'-before')).write_bytes(before);p.write_text(s);r=dict(phase=phase,path=path,before_sha256=expected,after_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Root-owned Integration registration only; native author/caches still leased separately, no Runtime changes or builder launched.');(out/(phase+'-edit.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
