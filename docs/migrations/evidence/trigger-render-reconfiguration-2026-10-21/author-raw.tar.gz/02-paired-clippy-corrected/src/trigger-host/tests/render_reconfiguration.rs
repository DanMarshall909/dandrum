use dandrum_trigger_host::parameters::{
    AutomationEvent, ParameterController, ParameterError, ParameterReply, SessionJobProgress,
};
use dandrum_trigger_host::protocol::{Admission, AdmittedRequest};
use dandrum_trigger_host::runtime::{ControlEvent, RuntimeAudio, RuntimeError, TimedEvent};
use dandrum_trigger_host::{
    ADVANCED_DRUM_KIT_DOCUMENT, ADVANCED_DRUM_KIT_SAMPLE, TriggerHostConfiguration,
};
use serde_json::{Value, json};
use std::{num::NonZeroU64, path::Path};

fn configuration(rate: u32, frames: u32) -> TriggerHostConfiguration {
    TriggerHostConfiguration {
        sample_rate_hz: rate,
        max_block_frames: frames,
    }
}
struct Fixture(tempfile::TempDir);
impl Fixture {
    fn new() -> Self {
        let directory = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(directory.path().join("instrument/assets")).unwrap();
        let repository = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        for (source, destination) in [
            (
                "examples/patches/advanced-drum-kit.yaml",
                ADVANCED_DRUM_KIT_DOCUMENT,
            ),
            (
                "examples/patches/assets/advanced-drums.wav",
                ADVANCED_DRUM_KIT_SAMPLE,
            ),
        ] {
            std::fs::copy(repository.join(source), directory.path().join(destination)).unwrap();
        }
        Self(directory)
    }
    fn open(
        &self,
        config: TriggerHostConfiguration,
        events: usize,
    ) -> (ParameterController, RuntimeAudio) {
        ParameterController::open(
            self.0.path(),
            config,
            NonZeroU64::new(1).unwrap(),
            events,
            256,
        )
        .unwrap()
    }
}
struct Editor {
    instance: String,
    attachment: String,
    request: u64,
}
impl Editor {
    fn attach(host: &mut ParameterController) -> Self {
        let connection = host.attach_editor().unwrap();
        Self {
            instance: connection.instance_id,
            attachment: connection.attachment_id,
            request: 0,
        }
    }
    fn command(
        &mut self,
        host: &mut ParameterController,
        method: &str,
        args: Value,
    ) -> AdmittedRequest {
        self.request += 1;
        let message = json!({"version":1,"attachmentId":self.attachment,"requestId":self.request.to_string(),"method":method,"args":args}).to_string();
        match host.admit(&message).unwrap() {
            Admission::New(request) => request,
            _ => panic!("new public request required"),
        }
    }
    fn set(&mut self, host: &mut ParameterController, id: &str, normalized: f64) -> ParameterReply {
        let generation = host.parameter_state().generation;
        let request = self.command(host, "setParameter", json!([id, normalized, generation]));
        host.apply(&request).unwrap()
    }
    fn map(&mut self, host: &mut ParameterController, note: u8) -> u64 {
        let id = host.session().next_request_id().unwrap().0;
        let revision = host.session().owner_snapshot().revision;
        let request = self.command(
            host,
            "setInstrumentZoneKeyRange",
            json!([
                self.instance,
                self.attachment,
                id.to_string(),
                revision.to_string(),
                "kit",
                "kick",
                note,
                note
            ]),
        );
        host.admit_session_command(&request).unwrap();
        id
    }
}
fn ready(host: &mut ParameterController) {
    let completion = host.take_session_preparation().unwrap().prepare();
    host.submit_session_completion(completion).unwrap();
}
fn automation(host: &mut ParameterController) -> Vec<AutomationEvent> {
    let mut events = Vec::new();
    while let Some(event) = host.peek_automation() {
        events.push(event);
        assert!(host.acknowledge_automation());
    }
    events
}
fn on(note: u8, frame_offset: u32) -> TimedEvent {
    TimedEvent {
        frame_offset,
        event: ControlEvent::NoteOn {
            note,
            velocity: 100,
        },
    }
}
fn render<const N: usize>(audio: &mut RuntimeAudio, events: &[TimedEvent]) -> ([f32; N], [f32; N]) {
    let (mut left, mut right) = ([1.0; N], [1.0; N]);
    let audit = allocation_counter::measure(|| {
        assert!(
            !audio
                .process_events(&mut left, &mut right, events)
                .unwrap()
                .admission_closed
        );
    });
    assert_eq!(
        audit,
        allocation_counter::AllocationInfo::default(),
        "actual callbacks allocate and destroy nothing"
    );
    (left, right)
}

#[test]
fn paired_controller_service_preserves_nonzero_restore_epoch_and_ui_settlement_without_servicing_jobs()
 {
    let fixture = Fixture::new();
    let (mut host, mut audio) = fixture.open(configuration(48_000, 16), 4);
    let mut editor = Editor::attach(&mut host);
    let mut saved = Vec::new();
    host.save_state(&mut saved).unwrap();
    host.load_state(&mut saved.as_slice()).unwrap();
    assert!(host.service_quiescent(&mut audio).unwrap().adopted);
    assert_eq!(
        editor.set(&mut host, "drums.level", 0.125),
        ParameterReply::Accepted {
            generation: 2,
            sequence: 1
        }
    );
    automation(&mut host);
    let first = render::<16>(
        &mut audio,
        &[
            TimedEvent {
                frame_offset: 3,
                event: ControlEvent::Parameter {
                    index: 3,
                    value: 0.5,
                },
            },
            on(36, 3),
        ],
    );
    assert_eq!((first.0[3], first.1[3]), (-0.125, -0.25));
    assert_eq!(
        editor.set(&mut host, "drums.level", 0.375),
        ParameterReply::Accepted {
            generation: 2,
            sequence: 2
        }
    );
    automation(&mut host);
    editor.map(&mut host, 60);
    ready(&mut host);
    let prior = host.session().owner_snapshot();
    let values = host.parameter_state();
    assert!(!host.service_quiescent(&mut audio).unwrap().adopted);
    assert_eq!(
        host.session().owner_snapshot(),
        prior,
        "runtime service cannot publish a ready structural job"
    );
    assert_eq!(
        host.parameter_state(),
        values,
        "runtime service cannot settle queued UI work"
    );
    assert_eq!(
        host.service_session_jobs().unwrap(),
        SessionJobProgress::Completed
    );
    let accepted = host.session().owner_snapshot();
    assert_eq!(
        accepted.revision, 2,
        "accepted revision differs from the real restore epoch1"
    );
    let before = host.parameter_state();
    assert_eq!(
        (before.generation, before.sequence, before.reset_cancelled),
        (3, 1, false)
    );
    assert_eq!(before.parameters[2].value, 0.125);
    assert!(host.service_quiescent(&mut audio).unwrap().adopted);
    assert_eq!(host.parameter_state(), before);
    assert_eq!(host.session().owner_snapshot(), accepted);
    let prior_ui = host.take_feedback().unwrap();
    assert_eq!(
        (
            prior_ui.sequence,
            prior_ui.frame_offset,
            prior_ui.parameters[0].value
        ),
        (1, 0, 0.125)
    );
    let prior_host = host.take_feedback().unwrap();
    assert_eq!(
        (
            prior_host.sequence,
            prior_host.frame_offset,
            prior_host.parameters[0].value
        ),
        (1, 3, 0.75)
    );
    assert!(host.take_feedback().is_none());
    let changed = render::<16>(&mut audio, &[on(60, 3)]);
    assert_eq!(&changed.0[..3], &[0.0; 3]);
    assert_eq!(&changed.1[..3], &[0.0; 3]);
    assert_eq!((changed.0[3], changed.1[3]), (-0.375, -0.75));
    let settled = host.parameter_state();
    assert_eq!(
        (
            settled.generation,
            settled.sequence,
            settled.parameters[2].value
        ),
        (3, 2, 0.375)
    );
    assert_eq!(host.take_feedback().unwrap().sequence, 2);
    assert_eq!(
        editor.set(&mut host, "drums.level", 0.25),
        ParameterReply::Accepted {
            generation: 3,
            sequence: 3
        }
    );
    let (mut foreign, mut foreign_audio) = fixture.open(configuration(48_000, 16), 4);
    assert_eq!(
        host.service_quiescent(&mut foreign_audio),
        Err(ParameterError::Runtime(RuntimeError::ForeignEndpoints))
    );
    assert_eq!(
        foreign.service_quiescent(&mut audio),
        Err(ParameterError::Runtime(RuntimeError::ForeignEndpoints))
    );
    assert_eq!(host.session().owner_snapshot(), accepted);
}
