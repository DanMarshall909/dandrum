import pathlib,tarfile,json,hashlib,subprocess,shlex,shutil,sys
base=pathlib.Path('/tmp/dandrum-lanes/evidence-render-reconfiguration');target=pathlib.Path('/tmp/dandrum-lanes/cache-host-snapshot-cov')
phase,slug,report,output=sys.argv[1:];run=base/phase;out=base/output;profiles=out/'profiles';profiles.mkdir()
archive=run/'result-profiles.tar.gz'
with tarfile.open(archive) as tf:
 for member in tf.getmembers():
  assert pathlib.Path(member.name).name==member.name
  (profiles/member.name).write_bytes(tf.extractfile(member).read())
original=(target/(slug+'-profraw-list')).read_text();(out/'profile-list-original.txt').write_text(original)
raws=[profiles/pathlib.Path(line).name for line in original.splitlines()];assert all(p.exists() for p in raws)
(out/'profile-list.txt').write_text(''.join(str(p)+'\n' for p in raws))
llvm=pathlib.Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin')
merge=[str(llvm/'llvm-profdata'),'merge','-sparse','-f',str(out/'profile-list.txt'),'-o',str(out/'remerged.profdata')]
merged=subprocess.run(merge,check=True,capture_output=True);(out/'merge.stderr').write_bytes(merged.stderr)
assert (out/'remerged.profdata').read_bytes()==(profiles/(slug+'.profdata')).read_bytes()
log=(run/'output.log').read_text();line=next(x for x in log.splitlines() if 'llvm-cov export' in x)
command=shlex.split(line.split('`')[1]);objects=[pathlib.Path(command[i+1]) for i,x in enumerate(command) if x=='-object']
recorded=json.loads((run/'binary-hashes.json').read_text())
executed=[]
for line in log.splitlines():
 if line.strip().startswith('Running `'+str(target/'debug/deps')):
  argv=shlex.split(line.split('`')[1]);executed.append(pathlib.Path(argv[0]))
assert set(executed)==set(objects)
assert len(raws)==len(objects)
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==recorded[str(p)]['sha256'] for p in objects)
command=[('-instr-profile='+str(out/'remerged.profdata')) if x.startswith('-instr-profile=') else x for x in command]
result=subprocess.run(command,check=True,capture_output=True);(out/'direct-export.json').write_bytes(result.stdout);(out/'direct-export.stderr').write_bytes(result.stderr)
actual=json.loads(result.stdout);expected=json.loads((run/report).read_text())
def normalize(x):
 if isinstance(x,dict):return {k:normalize(v) for k,v in x.items() if k not in ('percent','cargo_llvm_cov')}
 if isinstance(x,list):return [normalize(v) for v in x]
 return x
assert normalize(actual)==normalize(expected)
differences=[]
def compare(a,b,path=''):
 if isinstance(a,dict):
  for key in a:
   if key in b:compare(a[key],b[key],path+'/'+key)
 elif isinstance(a,list):
  for index,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(index))
 elif a!=b:
  assert path.endswith('/percent') and abs(a-b)<=1e-12
  differences.append(dict(path=path,direct=a,cargo_reserialized=b,difference=a-b))
compare(actual,expected)
fp=out/'fingerprints'
for d in (target/'debug/.fingerprint').iterdir():
 if d.name.startswith(('dandrum-trigger-host-','dandrum_instrument_session-','dandrum_engine-')):
  for p in d.iterdir():
   if p.is_file():
    dest=fp/d.name/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
proof=dict(archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),raw_count=len(raws),raw_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in raws},merge_command=merge,merged_byte_identical=True,profile_sha256=hashlib.sha256((out/'remerged.profdata').read_bytes()).hexdigest(),actual_executed_binaries={str(p):recorded[str(p)] for p in objects},export_command=command,export_semantics='All paths, segments, expansions, functions, regions, counters and integer summaries exact. Derived percentage presentation and cargo_llvm_cov metadata qualified separately.',derived_percent_differences=differences,additional_cargo_metadata=expected.get('cargo_llvm_cov'),source_binding=json.loads((run/'receipt.json').read_text())['source_hashes'],freeze_sha256=hashlib.sha256((base/'author-freeze-watermark.json').read_bytes()).hexdigest(),fingerprints={str(p.relative_to(fp)):hashlib.sha256(p.read_bytes()).hexdigest() for p in fp.rglob('*') if p.is_file()})
(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:proof[k] for k in ('raw_count','merged_byte_identical','profile_sha256','export_semantics','derived_percent_differences')}))
