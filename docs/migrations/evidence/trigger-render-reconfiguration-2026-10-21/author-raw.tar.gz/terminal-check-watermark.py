import pathlib,json,hashlib,os,shutil,subprocess,stat
base=pathlib.Path('/tmp/dandrum-lanes/evidence-render-reconfiguration');root=pathlib.Path('/tmp/dandrum-lanes/runtime');freeze=json.loads((base/'author-freeze-watermark.json').read_text());changes=[]
for name,expected in freeze['owned'].items():
 p=root/name;s=p.stat();actual=dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),mode=stat.S_IMODE(s.st_mode),size=s.st_size,mtime_ns=s.st_mtime_ns)
 assert actual==expected,(name,actual,expected)
 assert all(json.loads(p.read_text())['source_hashes'][name]==expected['sha256'] for p in [base/'19-watermark-full-host/receipt.json',base/'20-watermark-host-cov/receipt.json'])
 if name.startswith('src/instrument-session/'):
  assert all(json.loads(p.read_text())['source_hashes'][name]==expected['sha256'] for p in [base/'07-full-session/receipt.json',base/'10-full-session-cov/receipt.json'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==freeze['head']
live=[]
for path in base.glob('*/receipt.json'):
 pid=json.loads(path.read_text())['pid']
 try:os.kill(pid,0)
 except ProcessLookupError:continue
 else:live.append({'phase':path.parent.name,'pid':pid})
assert not live,live
builders=[]
for path in pathlib.Path('/proc').iterdir():
 if not path.name.isdecimal():continue
 try:comm=(path/'comm').read_text().strip()
 except (FileNotFoundError,PermissionError,ProcessLookupError):continue
 if comm in {'cargo','cargo-llvm-cov','rustc','clippy-driver','llvm-cov','llvm-profdata'}:builders.append({'pid':int(path.name),'comm':comm})
assert not builders,builders
mem={line.split(':')[0]:int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines()}
resources=dict(disk=shutil.disk_usage('/tmp').free,ramfs=shutil.disk_usage('/dev/shm').free,memory=mem['MemAvailable'])
assert resources['disk']>=1024**3 and resources['memory']>=4*1024**3
result=dict(resources=resources,ramfs='unused output volume; no task output/cache/profile/TMPDIR writes',source_freeze_exact=True,head=freeze['head'],root_design_sha256=hashlib.sha256((root/'openspec/changes/add-juce-free-trigger-clap-editor/design.md').read_bytes()).hexdigest(),status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True),live_owned_phase_processes=live,rust_or_llvm_builder_processes=builders,caches={'ordinary':'/tmp/dandrum-lanes/cache-runtime','coverage':'/tmp/dandrum-lanes/cache-host-snapshot-cov'},output_paths_resolve_to_disk=True,tools={name:subprocess.check_output(cmd,text=True).strip() for name,cmd in {'cargo':['/home/dan/.cargo/bin/cargo','--version'],'rustc':['/home/dan/.cargo/bin/rustc','--version'],'cargo-llvm-cov':['/home/dan/.cargo/bin/cargo','llvm-cov','--version']}.items()})
(base/'terminal-resources-watermark.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
