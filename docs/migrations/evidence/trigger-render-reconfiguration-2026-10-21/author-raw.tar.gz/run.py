import os, sys, subprocess, time, json, pathlib, hashlib, shutil, signal, tarfile
root=pathlib.Path('/tmp/dandrum-lanes/runtime'); evidence=pathlib.Path('/tmp/dandrum-lanes/evidence-render-reconfiguration')
phase=sys.argv[1]; command=sys.argv[2:]; dest=evidence/phase; dest.mkdir(exist_ok=False)
cov='llvm-cov' in command
ordinary='/tmp/dandrum-lanes/cache-runtime'; coverage='/tmp/dandrum-lanes/cache-host-snapshot-cov'
env=os.environ.copy(); env.update(PATH='/home/dan/.cargo/bin:/home/dan/.local/bin:/usr/bin:/bin',CARGO_TARGET_DIR=coverage if cov else ordinary,CARGO_LLVM_COV_TARGET_DIR=coverage,CARGO_LLVM_COV_BUILD_DIR=coverage,CARGO_BUILD_JOBS='1',TMPDIR=str(evidence/'tmp'))
paths=sorted(set([p for d in ['src/trigger-host/src','src/trigger-host/tests','src/instrument-session/src','src/instrument-session/tests'] for p in root.joinpath(d).rglob('*.rs')]+[root/'src/trigger-host/Cargo.toml',root/'src/trigger-host/Cargo.lock']))
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
for name in ['src/trigger-host/src/runtime.rs','src/trigger-host/src/parameters.rs','src/trigger-host/src/lib.rs','src/instrument-session/src/lib.rs','src/trigger-host/tests/render_reconfiguration.rs','src/instrument-session/tests/render_configuration.rs']:
 p=root/name
 if p.exists():
  saved=dest/name; saved.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,saved)
def binary_hashes():
 result={}
 names={'dandrum_trigger_host','dandrum_instrument_session','session','render_configuration','render_reconfiguration','editor_note_controller','runtime','runtime_quiescent','editor_notes','parameters','protocol','packaged_resources','snapshot','session_jobs','state'}
 for p in pathlib.Path(coverage).glob('debug/deps/*'):
  if p.is_file() and p.name.split('-')[0] in names and os.access(p,os.X_OK):
   result[str(p)]=dict(size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 return result
if cov:
 (dest/'previous-binary-hashes.json').write_text(json.dumps(binary_hashes(),indent=2)+'\n')
 profiles=list(pathlib.Path(coverage).glob('*.prof*'))
 with tarfile.open(dest/'previous-profiles.tar.gz','w:gz') as archive:
  for p in profiles: archive.add(p,arcname=p.name)
 (dest/'previous-profile-hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in profiles},indent=2)+'\n')
def resource():
 mem={line.split(':')[0]:int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines()}
 return dict(disk=shutil.disk_usage('/tmp').free,ramfs=shutil.disk_usage('/dev/shm').free,memory=mem['MemAvailable'])
def low(r): return r['disk']<1024**3 or r['memory']<4*1024**3
assert not pathlib.Path(env['CARGO_TARGET_DIR']).resolve().is_relative_to('/dev/shm')
assert not pathlib.Path(env['TMPDIR']).resolve().is_relative_to('/dev/shm')
start=time.monotonic(); samples=[resource()]; reason=None
if low(samples[0]): raise SystemExit('Resource floor before launch '+str(samples[0]))
with (dest/'output.log').open('w') as log:
 proc=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll() is None:
  time.sleep(.5); sample=resource(); samples.append(sample)
  if low(sample):
   reason='resource floor'; os.killpg(proc.pid,signal.SIGTERM); proc.wait(); break
 result=dict(command=command,cwd=str(root),environment={k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','CARGO_BUILD_JOBS','TMPDIR')},head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),source_hashes=hashes,exit=proc.returncode,duration_seconds=time.monotonic()-start,pid=proc.pid,resource_first=samples[0],resource_last=samples[-1],resource_min={k:min(s[k] for s in samples) for k in samples[0]},stop_reason=reason,ramfs_status='unused volume sampled; no output/profile/TMPDIR path resolves to RAM; floor is not an output-target gate',resolved_output_paths={k:str(pathlib.Path(env[k]).resolve()) for k in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','TMPDIR')})
 (dest/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
 if cov:
  profiles=list(pathlib.Path(coverage).glob('*.prof*'))
  with tarfile.open(dest/'result-profiles.tar.gz','w:gz') as archive:
   for p in profiles: archive.add(p,arcname=p.name)
  (dest/'binary-hashes.json').write_text(json.dumps(binary_hashes(),indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('exit','duration_seconds','resource_min','stop_reason')})); print((dest/'output.log').read_text()[-2500:]); sys.exit(proc.returncode)
