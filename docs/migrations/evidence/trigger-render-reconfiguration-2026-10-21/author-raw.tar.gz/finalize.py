import pathlib,json,hashlib,collections,re,datetime
base=pathlib.Path('/tmp/dandrum-lanes/evidence-render-reconfiguration');root=pathlib.Path('/tmp/dandrum-lanes/runtime')
def read(name):return json.loads((base/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
freeze=read('author-freeze-watermark.json');terminal=read('terminal-resources-watermark.json')
assert terminal['source_freeze_exact'] and not terminal['live_owned_phase_processes'] and not terminal['rust_or_llvm_builder_processes']
phases={'host_fmt':'17-watermark-fmt-check','host_clippy':'18-watermark-clippy','host_tests':'19-watermark-full-host','host_llvm':'20-watermark-host-cov','host_profile_proof':'21-watermark-host-proof','session_fmt':'07-session-fmt-check','session_clippy':'12-final-session-clippy','session_tests':'07-full-session','session_llvm':'10-full-session-cov','session_profile_proof':'11-session-profile-proof','openspec':'13-openspec-validate-explicit-node','diff_check':'14-diff-check'}
gates={}
for name,phase in phases.items():
 receipt=read(phase+'/receipt.json');assert receipt['exit']==0
 gates[name]={'phase':phase,'exit':receipt['exit'],'seconds':receipt['duration_seconds'],'receipt_sha256':sha(base/phase/'receipt.json'),'command':receipt['command']}
def counts(phase):return [int(x) for x in re.findall(r'test result: ok\. (\d+) passed;', (base/phase/'output.log').read_text())]
host=counts(phases['host_tests']);assert sum(host[:-1])==138 and host[-1]==2
assert sum(counts(phases['host_llvm']))==138
assert sum(counts(phases['session_tests']))==33 and sum(counts(phases['session_llvm']))==33
q=read('coverage-qualification.json');data=read('20-watermark-host-cov/host.json')['data'][0]
for name,ranges in {'runtime.rs':[(275,315),(478,502)],'parameters.rs':[(625,697)]}.items():
 path=str(root/'src/trigger-host/src'/name);regions=collections.Counter();functions=collections.Counter()
 for f in data['functions']:
  own=[r for r in f['regions'] if f['filenames'][r[5]]==path and r[7]==0]
  if own:functions[tuple(own[0][:4])]+=f['count']
  for r in own:regions[tuple(r[:4])]+=r[4]
 cut=next(i for i,l in enumerate(pathlib.Path(path).read_text().splitlines(),1) if l=='#[cfg(test)]')
 selected={k:v for k,v in regions.items() if any(lo<=k[0]<=hi for lo,hi in ranges)}
 q['owners'][name]={'llvm_summary':next(f['summary'] for f in data['files'] if f['filename']==path),'merged_normal_code_source_coordinates':{'production_functions':sum(k[0]<cut for k in functions),'production_functions_hit':sum(k[0]<cut and v>0 for k,v in functions.items()),'production_regions':sum(k[0]<cut for k in regions),'production_regions_hit':sum(k[0]<cut and v>0 for k,v in regions.items()),'production_unhit_regions':[k for k,v in regions.items() if k[0]<cut and not v]},'new_boundary_regions':{'source_ranges':ranges,'total':len(selected),'hit':sum(v>0 for v in selected.values()),'unhit':[k for k,v in selected.items() if not v],'counts':{str(k):v for k,v in selected.items()}}}
merged=collections.Counter()
for f in q['session_owner']['owned_render_preparation']:
 for r in f['normal_regions']:merged[tuple(r[:4])]+=r[4]
q['session_owner']['merged_owned_render_source_coordinates']={'regions':len(merged),'hit':sum(v>0 for v in merged.values()),'unhit':[k for k,v in merged.items() if not v]}
q['final_host_phase']='20-watermark-host-cov';q['renewed_freeze']='author-freeze-watermark.json';q['watermark_oracle']='16-watermark-characterization: same admitted onset rejected as ReplayedEditorNote after reconfiguration, immediate PASS, production unchanged.'
(base/'coverage-qualification-watermark.json').write_text(json.dumps(q,indent=2)+'\n')
errors=[
 'Initial existing Session characterization snapshot was retained after its immediate-PASS run before further changes; the driver snapshot/hash scope was corrected, and subsequent full33-test exact-source evidence binds the maintained test. Original qualification retained.',
 'Strict Clippy caught an unused attachment test binding and a bool assertion comparison; corrected, original failures retained.',
 'Atomic GREEN exposed author oracle errors: automation physical1.0 versus normalized.25; document generation1 versus invented press2; unavailable redo protocol replaced with supported real undo; invalid blocks zero output; off-control ownership oracle corrected from exact0 to signed negative live allocation delta. No production workaround or protocol expansion.',
 'First final fmt check preceded formatting of strengthened tests and failed; rustfmt applied and fresh checks pass.',
 'OpenSpec launcher lacked nvm in evidence-driver PATH and never launched: setup failure, not RED. setup-error.json retained; explicit installed Node/OpenSpec run passes.',
 'Watermark assertion added only under root explicit narrow freeze reopening. Original freeze/gates/proofs preserved; renewed host gates/proof bind new test hash. Unchanged Session owner proof reused by exact hash.'
]
proofs={}
for label,path in {'host':'21-watermark-host-proof/proof.json','session':'11-session-profile-proof/proof.json'}.items():
 p=read(path);proofs[label]={'path':path,'sha256':sha(base/path),'raw_count':p['raw_count'],'executed_binary_count':len(p['actual_executed_binaries']),'merged_byte_identical':p['merged_byte_identical'],'merged_profile_sha256':p['profile_sha256'],'integer_export_semantics':p['export_semantics'],'derived_percent_differences':p['derived_percent_differences'],'archive_sha256':p['archive_sha256'],'fingerprint_file_count':len(p['fingerprints'])}
completion={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'Author implementation and required format-neutral gates complete; fresh root-owned independent review and normal publication pending. Task4.1/beta remain open.','head':freeze['head'],'freeze':'author-freeze-watermark.json','freeze_sha256':sha(base/'author-freeze-watermark.json'),'original_freeze_preserved':'author-freeze.json','owned':freeze['owned'],'counts':{'new_host_public_tests':10,'new_session_public_characterizations':3,'full_host':138,'host_compile_fail_doctests':2,'full_session':33,'atomic_focused_then':{'new_host_integration_tests':9,'existing_runtime_quiescent_integration_tests':7,'total':16}},'gates':gates,'profiles_and_executed_binaries':proofs,'session_proof_reuse':'session-final-proof-reuse.json','coverage_qualification':'coverage-qualification-watermark.json','baseline':{'host':'baseline-reuse.json: exact prior301641 source inputs,128host+2docs/fullLLVM reused before code','session':'00-session-baseline: full30 owning LLVM before changes;00-characterization-cov: existing uncovered Busy/resource/commit Busy edges characterized with33tests before visibility change'},'tdd':{'owned_api':{'red':'01-owned-api-red: E0624 missing public visibility','green':'01-owned-green','coverage':'01-owned-cov'},'controller_service':{'red':'02-paired-service-red: E0599 missing API','green':'02-paired-service-green','coverage':'02-paired-cov'},'preflight_noop':{'red':'03-preflight-red: absent API/report','green':'03-preflight-green','coverage':'03-preflight-cov'},'atomic_transaction':{'red':'04-atomic-red-expanded:5 genuine assertion failures','green':'04-atomic-green-invalid-block-oracle:9pass after disclosed test-oracle corrections','coverage':'04-atomic-cov:9new+7existing=16'},'oracle_strengthening':['05-public-oracles-characterization: installed-worker variant and independent PCM/foreign-pair strengthening immediatePASS10','16-watermark-characterization: root-authorized same-admitted-note replay immediatePASS10'], 'refactor':'Assessments retained in criterion coverage directories. Small cohesive precommit adapter/lease; existing covered editor adoption helper reused, endpoint identity extraction covered. No new module.'},'author_errors':errors,'limits':q['limits'],'terminal':'terminal-resources-watermark.json','cache_handback':{'ordinary':'/tmp/dandrum-lanes/cache-runtime','llvm':'/tmp/dandrum-lanes/cache-host-snapshot-cov','state':'All author build/test/LLVM/profile processes terminal; no further target access. Returned exclusively to root now. No deletion/relocation/cleanup.','all_output_and_TMPDIR_on_disk':True},'candidate_paths':list(freeze['owned']),'noncandidate_evidence':'draft-host-tests.rs and phase/source snapshots are historical evidence, not candidate test routes. Root dirty design remains root-owned; no author Git/index/docs changes.'}
(base/'completion.json').write_text(json.dumps(completion,indent=2)+'\n')
print(json.dumps({'completion':'completion.json','final_freeze_sha256':completion['freeze_sha256'],'counts':completion['counts'],'profiles':proofs},indent=2))
