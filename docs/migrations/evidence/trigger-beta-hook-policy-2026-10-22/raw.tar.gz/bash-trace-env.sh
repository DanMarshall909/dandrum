trap 'printf "%s:%s\n" "${BASH_SOURCE[0]}" "$LINENO" >> "$DANDRUM_HOOK_TRACE"' DEBUG
