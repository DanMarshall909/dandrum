use crate::EditorAssets;

#[derive(Debug, PartialEq, Eq)]
pub enum NativeError {
    Unavailable,
}

pub struct NativeEditor;

impl NativeEditor {
    pub const WIDTH: u16 = 1200;
    pub const HEIGHT: u16 = 800;

    pub fn create(
        _parent: u32,
        _assets: EditorAssets,
        _on_message: impl Fn(String) + 'static,
    ) -> Result<Self, NativeError> {
        Err(NativeError::Unavailable)
    }

    pub fn service() -> Result<usize, NativeError> {
        Ok(0)
    }
}

#[cfg(test)]
#[path = "../tests/internal/native_x11.rs"]
mod tests;
