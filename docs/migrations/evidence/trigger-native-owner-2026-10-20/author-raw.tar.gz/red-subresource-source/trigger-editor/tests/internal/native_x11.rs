use super::*;
use gtk::prelude::*;
use std::{
    cell::RefCell,
    rc::Rc,
    time::{Duration, Instant},
};
use x11rb::{
    COPY_DEPTH_FROM_PARENT,
    connection::Connection,
    protocol::xproto::{ConnectionExt, CreateWindowAux, MapState, WindowClass},
};
#[path = "../common/mod.rs"]
mod common;

#[test]
#[ignore = "requires real Linux X11, GTK3 and WebKitGTK; native boundary lane"]
fn real_child_loads_local_content_and_drops_without_owning_the_host_parent() {
    gtk::init().expect("GTK on the host UI thread");
    let (x, screen) = x11rb::connect(None).unwrap();
    let root = x.setup().roots[screen].root;
    let parent = x.generate_id().unwrap();
    x.create_window(
        COPY_DEPTH_FROM_PARENT,
        parent,
        root,
        0,
        0,
        1400,
        900,
        0,
        WindowClass::INPUT_OUTPUT,
        0,
        &CreateWindowAux::new(),
    )
    .unwrap()
    .check()
    .unwrap();
    x.map_window(parent).unwrap().check().unwrap();
    let baseline = gtk::Window::list_toplevels().len();
    for cycle in 0..2 {
        let package = common::Package::new();
        for file in common::FILES {
            package.write(file, b"fixture");
        }
        package.write("index.html", b"<!doctype html><script src='/app.js'></script>");
        package.write("app.js", b"window.ipc.postMessage('local-owner-ready')");
        let messages = Rc::new(RefCell::new(Vec::new()));
        let callback_lifetime = Rc::new(());
        let weak = Rc::downgrade(&callback_lifetime);
        let sink = messages.clone();
        let owner = NativeEditor::create(
            parent,
            EditorAssets::open(package.root()).unwrap(),
            move |message| {
                let _keep_alive = &callback_lifetime;
                sink.borrow_mut().push(message);
            },
        )
        .expect("native owner accepts a real host parent");
        let children = x.query_tree(parent).unwrap().reply().unwrap().children;
        assert_eq!(
            children.len(),
            1,
            "one direct editor child in cycle {cycle}"
        );
        let child = children[0];
        let geometry = x.get_geometry(child).unwrap().reply().unwrap();
        assert_eq!(
            (geometry.x, geometry.y, geometry.width, geometry.height),
            (0, 0, NativeEditor::WIDTH, NativeEditor::HEIGHT)
        );
        assert_eq!(
            x.get_window_attributes(child)
                .unwrap()
                .reply()
                .unwrap()
                .map_state,
            MapState::UNMAPPED
        );
        let deadline = Instant::now() + Duration::from_secs(15);
        while messages.borrow().is_empty() && Instant::now() < deadline {
            assert!(
                NativeEditor::service().unwrap() <= 64,
                "one finite host tick"
            );
            std::thread::sleep(Duration::from_millis(5));
        }
        assert_eq!(&*messages.borrow(), &["local-owner-ready"]);
        drop(owner);
        for _ in 0..8 {
            NativeEditor::service().unwrap();
        }
        assert!(
            x.query_tree(parent)
                .unwrap()
                .reply()
                .unwrap()
                .children
                .is_empty(),
            "owner drop releases its child"
        );
        assert_eq!(
            gtk::Window::list_toplevels().len(),
            baseline,
            "no retained GTK toplevel"
        );
        assert!(
            weak.upgrade().is_none(),
            "view-owned IPC closure is released"
        );
        assert_eq!(
            &*messages.borrow(),
            &["local-owner-ready"],
            "no late callback after drop"
        );
    }
    x.destroy_window(parent).unwrap().check().unwrap();
}
