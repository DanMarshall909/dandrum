import subprocess,time,json,os,pathlib,sys,hashlib,shutil
p=pathlib.Path('/tmp/dandrum-lanes/evidence-native-editor');label=sys.argv[1]
old=json.loads((p/'red-run.json').read_text());cmd=sys.argv[2:] or old['command'];env=dict(old['env']);env['TMPDIR']='/dev/shm/dandrum-beta-20261020/editor-scratch'
snap=p/(label+'-source');snap.mkdir();shutil.copytree('src/trigger-editor',snap/'src/trigger-editor');shutil.copyfile('CMakeLists.txt',snap/'CMakeLists.txt')
(p/(label+'-hashes.json')).write_text(json.dumps({str(f.relative_to(snap)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(snap.rglob('*')) if f.is_file()},indent=2)+'\n')
t=time.monotonic()
with (p/(label+'.log')).open('w') as log:r=subprocess.run(cmd,env=dict(os.environ,**env),stdout=log,stderr=subprocess.STDOUT)
(p/(label+'-run.json')).write_text(json.dumps({'cwd':os.getcwd(),'command':cmd,'env':env,'exit':r.returncode,'elapsed_seconds':time.monotonic()-t},indent=2)+'\n');print(r.returncode)
