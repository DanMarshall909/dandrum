# Invalid state with live feedback — bounded Followup assignment

DD-20261014-JUCE-FREE-HOST-ADAPTERS same full-beta continuation, current published
base65cb337183edd6586db1965e88c331b77678cc04/treeee8657bb6a5a34534fa940269d07cdeac7c029d5.
Prior lostack-B checkpoint independently PASS round1 manifest381c1d3374a9f418fb9552a048e9b02462282cbe8670b566819c0ad3ae560ecc,
normal-hook commit73.35053s/push15.078763s and4lane FF; mainclean68dd655 and1766cache entries retained.
Full two-round finalization archivec9f005c89c8fa46ab09ec1020c5e3252bd1ac483e3424fc446a0216fc103c9dc contains61verifiedmembers.
Fresh assignment-preflight.json fetch/ref/sixlane/actualidle passes, disk4867223552/MemAvailable12062478336;
no new branch/worktree, prior-dispositioned unrelated refs unchanged. Baseline direct rustfmt check passes
for current parent source66eff974299cb0f2b72d877bb6cef57ee9906e1a7af0e64eef86a72d9b9004e6. No deletion authority.
Read shared/project rules, relevant TDD/agentic skills, fresh next-status/next-apply and every contextFile.

Owning accepted scenario: Invalid state preserves the running Trigger instance.
Criterion: while the actual existing X11/React view and same active audio endpoint remain,
invalid CLAP state fails with accepted session/saved document+resource/public value/feedback intact;
subsequent real offset1 host feedback and actual parameter Undo remain usable without polling,
echo or structural history pollution. No new protocol/state policy or product repair is authorized.

Evidence/role map: format-neutral invalid_states_and_failing_streams_preserve_every_accepted_field_and_pending_feedback_and_commands
has independent state-boundary PASS (trigger-state-2026-10-20); copied DSO state_restores_fresh_mapping_and_physical_values_and_invalid_tail_preserves_running_audio
has independent product PASS (trigger-clap-product-2026-10-21). Existing G2 copied_native_host_feedback_updates_rendered_control_without_polling_or_undo_pollution
independently proves same actual React/CLAP physical value/offset1 signed output/authenticated event/no-polling/Undo boundary.
They leave the live-view invalid-load join unasserted; no new decision/state shape/authority mechanism is being designed.
This is Followup using qualified least-resource gpt-6-luna/high /root/vst3_loader_readiness_1629; readiness report.md maps exact assertions.
Stop for root if a real defect/new unproved boundary emerges; no weaker oracle or production repair by fiat.

ONLY maintained source lease offered: /tmp/dandrum-lanes/runtime/src/clap-adapter/tests/trigger_parameters.rs,
only existing copied_native_host_feedback_updates_rendered_control_without_polling_or_undo_pollution case and
minimal local helpers genuinely needed. Keep selector/CMake/Python registration and other test behaviors.
No new test module/framework/dependency/feature/spec/map/task/docs/Git/tracker edits. Root owns all other scopes.

Use report.md as preparation (its source snapshot95d06dff; relevant feedback source unchanged through65cb).
After physical0.5 edit/exact balanced ID3 B/V/E, valid empty stopped flush collects accepted credits;
assert no extra automation. Pin full accepted session, exact saved bytes, parameter DTO/public0.5,
normalized0.125 and generation1/sequence1, history0/0, actual child/live browser/bootstrap composite.
Start the existing endpoint before invalid loads. Keep same endpoint/view/authority through rejection
and later existing host-feedback block; no successful restore/view replacement/reset between invalid cases.
Use real PluginState.load on main. Include late semantic invalid candidate with changed valid document
mapping36to60 and changed earlier allowed drums.level2, plus invalid last parameter, so partial publication
is observable; assert replacements really alter candidate fields. Existing dynamic invalid-category table
can be reused concisely for malformed/version/resource/duplicate/out-of-range/oversize/truncated state.
A short-reading success stream is not an error; if adding failing Read, return prefix then actual Err.
No full native per-category DOM replay is required: each failure checks unchanged state/feedback/save/value
and same child/authority, followed by one real existing host-feedback/Undo roundtrip after all rejects.
Do not label CLAP opaque error as a specific decoder category without direct evidence; credit collection
avoids deliberately masking with Busy, while owner/dynamic tests separately prove codec categories.

Install/reset existing no-poll/no-echo observer after explicit baseline/rejection reads. Retain original
MIDI36frame0/physical2frame1 exact stereo[-0.25,-716/32768], authenticated consumed event/offset/generation/settled watermark,
DOM normalized0.5/text2, no getter/setParameter feedback calls, actual rendered headerUndo ID3 B/V/E tophysical1,
sequence2/unchanged structural history, fresh offset3 signed[-0.5,-358/32768] with leading zeros.
Original case must remain nonzero exact selector. Ensure newly introduced failure paths return/deactivate any
owned endpoint and destroy view/child before parent, without hiding the original assertion failure. Keep finite
existing test timeout/dispatch; no new sleeps/polling/private success hook or continuously advancing audio claim.

Acknowledge exclusive source and ordinary cache lease BEFORE edits/builds:
ordinary /tmp/dandrum-lanes/cache-editor-guard only; NOT Runtime's untracked /tmp/dandrum-lanes/runtime/cache-editor-guard/1766evidence.
Root retains cache-runtime and cache-host-snapshot-cov. Author evidence /tmp/dandrum-evidence/g3-invalid-live-feedback.
Root offers use of existing mutable warm native build /tmp/dandrum-evidence/g3-lost-ack-native-fixture/native-build
for normal exact feedback CTest/fixture preparation. Its build artifacts/Testing transient files may update;
all previous top-level raw logs/archives/manifests stay immutable. Keep own full new logs/receipts under new author evidence.
Using same build cache avoids needless path-induced test recompiles. Do not replace unrelated build/cache roots.
Physical/tmp only, serialize heavy/native operations, directjobs1; existing maintained fixture hardcodedjobs2
is permitted under1GiB disk/4GiB MemAvailable floors at measured headroom. Retain finite owned process groups/commands.
No cache deletion/relocation, downloads/installs/newbranches/worktrees/DAW/devices/server/OSinput/settings.
Inherited assigned X11 DISPLAY=:10.0,GDK_BACKEND=x11,XAUTHORITY=/home/dan/.Xauthority; no cookie/access changes.
Actual native socket access uses authorized escalation. Resource measurements before any significant run.

Before edit explain behavior/oracles and compare accepted baseline coverage; test-first characterization
of existing production may pass immediately, no artificial RED. Retain genuine setup/compile/lint/native
failures distinctly and exact measured command/cwd/env/duration/exit/stdout/stderr/source hashes at launch/end.
Ordinary exact case through maintained preparation fixture, changed-file format and strict alltargetClippy
are your final checks. Root will do full maintained native lane and source-bound focused LLVM after explicit
handback; do not build another cargo-llvm-cov debug graph or generate an omitted-test zero-library report.
This division is intentional to avoid duplicate coverage/native runs, not a completion waiver. You stop
before criterion completion while root verifies/integrates/reviews/publishes. No next behavior start.

Capture actual Cargo compiler-artifact JSON/selected/copied test+DSO/resources hashes, production app identity,
source before/final snapshots and change-only scope. Distinguish author ordinary artifact from root's later
ordinary artifact; do not copy prose hashes between builds. Coverage remains pending root; never count it passed.
Review production/test refactors proportionately while green; no production change or general extraction expected.
Hand back exact final source SHA and manifest plus ordinary cache/native-build lease explicitly idle/released,
no active/pending commands/builds/nativeworkers, preserved excluded cache/main audit. Root accepts sole ownership,
then does combined native/LLVM/link/spec checks and fresh independent exact review/normal hooks/publication.
No task/full-beta closure. Mutation remains expressly excluded; retain all reusable caches/evidence.
