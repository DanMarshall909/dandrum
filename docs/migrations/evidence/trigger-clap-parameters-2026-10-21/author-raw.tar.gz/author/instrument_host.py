from pathlib import Path
import json,subprocess,os,sys,hashlib
out=Path('/tmp/dandrum-evidence/g2-parameter-delivery');capture_path=out/'dandrum_trigger_host-lib-rustc.json';capture=json.loads(capture_path.read_text());label=sys.argv[1]
directory=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g2-parameter-delivery')/label;directory.mkdir(parents=True,exist_ok=False)
command=list(capture['command']);command[command.index('--out-dir')+1]=str(directory);command+=['-C','instrument-coverage']
env=os.environ.copy();env.update(capture['environment'])
for key in ('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS','RUSTC_WRAPPER','LD_PRELOAD','LLVM_PROFILE_FILE'):env.pop(key,None)
env['RUST_MIN_STACK']='16777216'
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt={'capture':capture,'capture_sha256':h(capture_path),'command':command,'cwd':capture['cwd'],'environment':{k:env[k] for k in capture['environment'] if k in env},'only_diff':'Exact current Cargo host recipe; outdir redirect plus -C instrument-coverage;16MiB builder stack only','compiler':subprocess.check_output([command[0],'-Vv'],text=True),'source_sha256':{str(p):h(p) for p in Path(capture['cwd']).joinpath('src').rglob('*.rs')},'extern_sha256':{arg:h(arg.split('=',1)[1]) for i,arg in enumerate(command) if i and command[i-1]=='--extern'}}
(out/(label+'-instrument.json')).write_text(json.dumps(receipt,indent=2));r=subprocess.run(command,cwd=capture['cwd'],env=env);receipt['exit']=r.returncode
if r.returncode==0:
 libs=list(directory.glob('libdandrum_trigger_host-*.rlib'));assert len(libs)==1;receipt['rlib']=str(libs[0]);receipt['rlib_sha256']=h(libs[0])
(out/(label+'-instrument.json')).write_text(json.dumps(receipt,indent=2));sys.exit(r.returncode)
