import pathlib,json,hashlib,sys,os,subprocess
from exact import run_exact
assert 'RUST_MIN_STACK' not in os.environ and 'LD_PRELOAD' not in os.environ
out=pathlib.Path('/tmp/dandrum-evidence/g2-parameter-delivery');binding=json.loads((out/(sys.argv[1]+'-binding.json')).read_text());elf=binding['test'];assert hashlib.sha256(pathlib.Path(elf).read_bytes()).hexdigest()==binding['test_sha256']
listing=subprocess.check_output([elf,'--list'],text=True);names=[line[:-6] for line in listing.splitlines() if line.endswith(': test')];assert len(names)==int(sys.argv[2]),(len(names),names)
for name in names:
 code=run_exact(elf,name,False)
 if code:sys.exit(code)
print('Verified exact tests:',len(names))
