use super::dispatch;
use dandrum_trigger_host::{
    ADVANCED_DRUM_KIT_DOCUMENT, ADVANCED_DRUM_KIT_SAMPLE, TriggerHostConfiguration,
    parameters::ParameterController, runtime::RuntimeAudio,
};
use serde_json::{Value, json};
use std::{num::NonZeroU64, path::PathBuf};

fn controller(events: usize, automation: usize) -> (tempfile::TempDir, ParameterController, RuntimeAudio, String) {
    let package = tempfile::tempdir().unwrap();
    let root = package.path();
    std::fs::create_dir_all(root.join("instrument/assets")).unwrap();
    let repository = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..");
    for (source, destination) in [
        ("examples/patches/advanced-drum-kit.yaml", ADVANCED_DRUM_KIT_DOCUMENT),
        ("examples/patches/assets/advanced-drums.wav", ADVANCED_DRUM_KIT_SAMPLE),
    ] {
        std::fs::copy(repository.join(source), root.join(destination)).unwrap();
    }
    let (mut controller, audio) = ParameterController::open(root, TriggerHostConfiguration {
        sample_rate_hz: 48000, max_block_frames: 16,
    }, NonZeroU64::new(19).unwrap(), events, automation).unwrap();
    let attachment = controller.attach_editor().unwrap().attachment_id;
    (package, controller, audio, attachment)
}
fn call(controller: &mut ParameterController, attachment: &str, id: u64, method: &str, args: Value) -> Value {
    let id = id.to_string();
    let message = json!({"version":1,"attachmentId":attachment,"requestId":id,"method":method,"args":args}).to_string();
    serde_json::from_str(&dispatch(controller, attachment, &id, &message).unwrap()).unwrap()
}
#[test]
fn current_dispatch_preserves_snapshot_notes_admission_and_capability_errors() {
    let (_package, mut controller, _audio, attachment) = controller(8, 8);
    let snapshot = call(&mut controller, &attachment, 1, "getSamplerSession", json!([]));
    assert_eq!(snapshot["status"], "accepted");
    assert_eq!(snapshot["instanceId"], "19");
    assert_eq!(snapshot["attachmentId"], attachment);
    assert_eq!(snapshot["requestId"], "1");
    assert_eq!(call(&mut controller, &attachment, 2, "noteOn", json!([36, 0.5, 1]))["result"], Value::Null);
    assert_eq!(call(&mut controller, &attachment, 3, "noteOff", json!([36, 1]))["status"], "accepted");
    assert_eq!(call(&mut controller, &attachment, 4, "noteHeartbeat", json!([]))["error"]["code"], "capabilityUnavailable");
    assert_eq!(call(&mut controller, &attachment, 5, "setParameter", json!(["drums.level", 2, 1]))["error"]["code"], "invalidArguments");
    assert_eq!(controller.parameter_state().sequence, 0);
}
