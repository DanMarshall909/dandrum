from pathlib import Path
import subprocess,sys,hashlib
out=Path('/tmp/dandrum-evidence/g2-parameter-delivery');app=out/'installed/DandrumTrigger.resources/editor/app.js';expected='4b9ce5a356fea5f22703f9046c77a80ac616c00242348a12fe81f58fe4f760f2'
cases=[
'copied_trigger_editor_exposes_the_actual_clap_gui_extension',
'copied_native_editor_lifecycle_initializes_the_real_react_session_and_preserves_audio',
'copied_editor_scan_and_configuration_only_do_not_make_code_resident',
'copied_editor_rejects_wrong_loaded_entry_identity_before_gtk_without_state_or_audio_loss',
'copied_editor_failed_native_parent_attempt_retains_only_code_and_preserves_audio',
]
assert hashlib.sha256(app.read_bytes()).hexdigest()==expected
for case in cases:
 subprocess.run([sys.executable,str(out/'native.py'),'final-trigger_gui',case],check=True)
 assert hashlib.sha256(app.read_bytes()).hexdigest()==expected,'G1 copied-asset observer restored exact original app'
print('Verified final exact G1 cases:',len(cases),'; G1 observer only temporarily augments copied app; original hash restored after every case')
