from pathlib import Path
import subprocess,sys
out=Path('/tmp/dandrum-evidence/g2-parameter-delivery')
cases=[
'copied_native_parameter_state_is_an_authenticated_numeric_dto',
'copied_native_parameter_flush_delivers_host_accepted_gestures',
'copied_native_automation_survives_rejected_output_activation_failures_and_audio_return',
'copied_native_gui_requires_host_timer',
'copied_native_gui_rejects_refused_host_timer',
'copied_native_host_timer_delivers_a_later_rendered_parameter_edit',
'copied_native_timer_rollback_retains_disabled_cleanup_and_retries',
'copied_native_view_independent_source_collects_accepted_automation_credits',
'copied_native_host_feedback_updates_rendered_control_without_polling_or_undo_pollution',
'copied_native_invalid_stopped_flush_preserves_uncollected_automation_ownership',
'copied_native_parameter_callbacks_allocate_and_destroy_nothing_while_gui_services',
]
for case in cases:subprocess.run([sys.executable,str(out/'native.py'),'110-final-formatted-native-build',case],check=True)
print('Verified final exact parameter/native cases:',len(cases))
