from pathlib import Path
import subprocess,os,json,re
out=Path('/tmp/dandrum-evidence/g2-parameter-delivery');cargo='/home/dan/.cargo/bin/cargo';manifest='src/clap-adapter/Cargo.toml';target='/tmp/dandrum-lanes/cache-editor-guard'
checks=[('116-final-rustfmt',[cargo,'fmt','--manifest-path',manifest,'--check'])]
for label,features in [('117-final-editor-clippy',['--features','trigger-editor']),('118-final-default-clippy',['--no-default-features']),('119-final-plain-trigger-clippy',['--no-default-features','--features','trigger'])]:
 checks.append((label,[cargo,'clippy','--manifest-path',manifest,'--release','--offline','--locked','--jobs','1',*features,'--lib','--tests','--','-D','warnings']))
for label,command in checks:subprocess.run(['python3',str(out/'run.py'),label,target,*command],check=True)
receipts=[]
for label,features in [('120-final-default-dev-graph',[]),('120-final-plain-trigger-dev-graph',['--features','trigger'])]:
 command=[cargo,'tree','--manifest-path',manifest,'--offline','--locked','--edges','normal,build,dev','--prefix','none',*features]
 result=subprocess.run(command,capture_output=True,text=True,check=True);(out/(label+'.stdout.log')).write_text(result.stdout);(out/(label+'.stderr.log')).write_text(result.stderr)
 forbidden=[line for line in result.stdout.splitlines() if re.match(r'(?i)^(wry\b|gtk(?:\b|-)|gdk(?:\b|-)|webkit|javascriptcore|juce\b|dandrum-trigger-editor\b)',line)]
 assert not forbidden,(label,forbidden);receipts.append({'label':label,'command':command,'exit':result.returncode,'forbidden_native_packages':forbidden})
(out/'120-final-headless-development-graphs.json').write_text(json.dumps(receipts,indent=2));print('Final formatting/strict Clippy and default/plain native-free development graphs passed')
