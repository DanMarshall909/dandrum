"""One-off execution of the maintained suite using an explicitly leased warm target."""
import importlib.util,json,sys,unittest
from pathlib import Path
root=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g2-native-fixture')
spec=importlib.util.spec_from_file_location('engine_only_boundary',root/'tests/python/test_engine_only_build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class SharedCache(m.ClapProofBuildTest):
 @classmethod
 def setUpClass(cls):
  super().setUpClass();original=cls.cargo_target;cls.cargo_target=Path('/tmp/dandrum-lanes/cache-runtime');assert cls.cargo_target.is_dir()
  (out/'root-build-boundary-cache-binding.json').write_text(json.dumps({'maintained_suite':'ClapProofBuildTest','source_fixture':str(cls.source),'preserved_original_cache':str(original),'actual_shared_target':str(cls.cargo_target),'scope':'Same maintained tests and copied source without third_party/web/ui; only task-owned output cache redirected to the returned existing warm cache to preserve reusable dependencies.'},indent=2)+'\n')
suite=unittest.defaultTestLoader.loadTestsFromTestCase(SharedCache);result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(0 if result.wasSuccessful() else 1)
