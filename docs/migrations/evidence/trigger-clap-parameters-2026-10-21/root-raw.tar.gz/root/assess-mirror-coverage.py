import collections
import hashlib
import json
from pathlib import Path

evidence = Path('/tmp/dandrum-evidence/g2-parameter-delivery')
root = Path('/tmp/dandrum-lanes/runtime')
binding = json.loads((evidence / 'mirror-refined-coverage-binding.json').read_text())
hash_file = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert hash_file(binding['elf']) == binding['elf_sha256']
for path, expected in binding['profiles'].items():
    assert hash_file(path) == expected
export_path = evidence / 'mirror-refined-raw-export.json'
assert hash_file(export_path) == binding['export_sha256']
relative = 'src/clap-adapter/src/trigger/automation.rs'
frozen = evidence / '31-mirror-refined-instrument-build/source' / relative
assert hash_file(frozen) == hash_file(root / relative)
regions = collections.defaultdict(list)
raw_summary = None
zero_segments = []
for unit in json.loads(export_path.read_text())['data']:
    for function in unit['functions']:
        for region in function['regions']:
            name = function['filenames'][region[5]]
            if name.endswith('/trigger/automation.rs'):
                # Include original region kind and expansion file index; every
                # counted owner region here is ordinary code (kind0, file0).
                key = tuple(region[:4] + region[6:])
                regions[key].append(region[4])
    for file in unit['files']:
        if file['filename'].endswith('/trigger/automation.rs'):
            raw_summary = file['summary']
            zero_segments = [s for s in file['segments'] if s[3] and s[2] == 0 and not s[5]]
assert len(regions) == 62
assert not [key for key, counts in regions.items() if not any(counts)]
assert not zero_segments
result = {
    'owner': relative,
    'source_sha256': hash_file(frozen),
    'elf_sha256': binding['elf_sha256'],
    'raw_profiles_verified': len(binding['profiles']),
    'export_sha256': binding['export_sha256'],
    'aggregate_unique_source_code_regions': len(regions),
    'aggregate_source_code_regions_executed': sum(any(v) for v in regions.values()),
    'counted_non_gap_zero_segments': zero_segments,
    'raw_llvm_file_summary_unmodified': raw_summary,
    'assessment': 'All62 distinct source code regions execute across the measured generic instantiations. This satisfies source-region execution gate. Raw LLVM file summary independently reports61/62 regions and54/55 lines and remains disclosed; no claim that every path of every instantiation executes, no branch coverage claim, and execution alone is not assertion proof.',
    'limit': 'Only exact source/ELF/profile/export measured here; not final native timer/feedback acceptance or callback allocation proof.',
}
Path('/tmp/dandrum-evidence/g2-native-fixture/root-mirror-coverage-assessment.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('source_sha256', 'raw_profiles_verified', 'aggregate_unique_source_code_regions', 'aggregate_source_code_regions_executed')}))
