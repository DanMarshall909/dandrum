import gzip,hashlib,io,json,tarfile
from pathlib import Path
base=Path('/tmp/dandrum-evidence/g2-native-fixture');dest=Path('/tmp/dandrum-lanes/integration/docs/migrations/evidence/trigger-clap-parameters-2026-10-21');entries={}
def add(p,name):
 data=p.read_bytes();assert not data.startswith(b'\x7fELF') and len(data)<3*1024**2,p;entries[name]=data
for p in sorted(base.iterdir()):
 if p.is_file() and p.suffix in ('.py','.json','.log'):add(p,'root/'+p.name)
for p in sorted((base/'sandbox-denied').iterdir()):
 if p.is_file():add(p,'sandbox-denied/'+p.name)
for fixture in ('trigger-clap-native-fixture','trigger-clap-parameters-fixture'):
 for p in sorted((base/'native-build'/fixture/'evidence').iterdir()):
  if p.is_file():add(p,'native-prepare/'+fixture+'/'+p.name)
for name in ('CTestTestfile.cmake','CMakeCache.txt'):add(base/'native-build'/name,'native-configuration/'+name)
binding_path=base/'root-build-boundary-cache-binding.json';binding=json.loads(binding_path.read_text());work=Path(binding['preserved_original_cache']).parent
for p in sorted(work.glob('*.log')):
 if p.stat().st_mtime_ns>=binding_path.stat().st_mtime_ns:add(p,'build-boundary/'+p.name)
index={n:{'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d)} for n,d in entries.items()};entries['meta/index.json']=(json.dumps({'scope':'Root executed checks, copied-source fixture logs, actual Cargo prepare records, sandbox-only failure and qualifiers. No compiler/cache/binary/profile contents.','files':index},indent=2,sort_keys=True)+'\n').encode()
p=dest/'root-raw.tar.gz';assert not p.exists()
with p.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
 for name,data in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(p,'r:gz') as tar:
 assert set(tar.getnames())==set(entries)
 for m in tar:assert tar.extractfile(m).read()==entries[m.name]
r={'archive':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'members':len(entries),'build_boundary_log_count':sum(n.startswith('build-boundary/') for n in index),'every_member_byte_verified':True};(dest/'root-archive.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
