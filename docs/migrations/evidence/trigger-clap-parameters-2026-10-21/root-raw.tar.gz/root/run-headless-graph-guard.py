import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest

root = Path('/tmp/dandrum-lanes/runtime')
evidence = Path('/tmp/dandrum-evidence/g2-native-fixture')
prior = Path('/tmp/dandrum-evidence/g2-parameter-delivery/11-dispatch-native-green/source/src/clap-adapter/Cargo.toml')
spec = importlib.util.spec_from_file_location('engine_boundary', root / 'tests/python/test_engine_only_build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
mode = sys.argv[1]
class Guard(m.ClapProofBuildTest):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        manifest = cls.source / 'src/clap-adapter/Cargo.toml'
        if mode == 'red':
            manifest.write_bytes(prior.read_bytes())
        binding = {'mode': mode, 'fixture': str(cls.source),
                   'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
                   'test_sha256': hashlib.sha256((root / 'tests/python/test_engine_only_build.py').read_bytes()).hexdigest(),
                   'note': 'RED substitutes retained pre-gating manifest only in task-owned copied fixture; no shared production edit.'}
        (evidence / ('headless-graph-' + mode + '-binding.json')).write_text(json.dumps(binding, indent=2) + '\n')
suite = unittest.TestSuite([Guard('test_headless_clap_development_dependencies_exclude_native_editor')])
result = unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
