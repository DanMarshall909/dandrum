import hashlib,json,re,subprocess
from pathlib import Path
root=Path('/tmp/dandrum-lanes/runtime');p=root/'docs/migrations/juce-free-clap-dependencies.json';r=json.loads(p.read_text())
lock=root/'src/clap-adapter/Cargo.lock';prior=subprocess.check_output(['git','show','HEAD:src/clap-adapter/Cargo.lock'],cwd=root,text=True)
def fields(text):return dict(re.findall(r'^([a-z_-]+) = "([^"\n]*)"$',text,re.M))
def packages(text):return [fields(block) for block in text.split('[[package]]')[1:]]
before=packages(prior);after=packages(lock.read_text())
def ids(data):return {(v['name'],v['version'],v.get('source')) for v in data}
assert ids(before)==ids(after)
registry=Path('/home/dan/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f');entries=[]
for name,version,role in [('rtrb','0.3.2','Optional trigger-editor production mirror; same pinned package as format-neutral host'),('webkit2gtk','2.0.2','Optional Linux trigger-editor direct binding for actual native test observation; enables no v2_40 feature'),('clap-sys','0.5.0','Test-only direct dependency for standard typed CLAP GUI reentrancy fixture')]:
 base=registry/(name+'-'+version);manifest=fields((base/'Cargo.toml').read_text().split('[package]',1)[1].split('\n[',1)[0]);assert manifest['name']==name and manifest['version']==version
 pkg=next(v for v in after if v['name']==name and v['version']==version)
 files={n:{'sha256':hashlib.sha256((base/n).read_bytes()).hexdigest(),'bytes':(base/n).stat().st_size} for n in ('LICENSE','LICENSE-MIT','LICENSE-APACHE') if (base/n).exists()}
 assert files
 entries.append({'name':name,'version':version,'checksum':pkg['checksum'],'role':role,'license_declaration':manifest['license'],'packaged_manifest_sha256':hashlib.sha256((base/'Cargo.toml').read_bytes()).hexdigest(),'license_files':files})
r['trigger_editor_parameter_increment']={'scope':'Developer-only G2 parameter-delivery source. Existing G1 native lifetime proof and headless product remain separate. Full GUI/recovery, DAW and beta acceptance stay open.','features':{'production_extension_addition':'clack-extensions/timer','default':[],'maintained_CMake_product':'trigger (headless)','native_test_feature':'trigger-editor'},'direct_edges':entries,'resolved_package_identity_change':{'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'added':[],'removed':[],'comparison':'Unique name/version/source identities in Cargo.lock; direct edges change, resolved package versions/sources do not.'},'adapter_lockfile_sha256':hashlib.sha256(lock.read_bytes()).hexdigest(),'dependency_boundary':'Default and plain Trigger normal/build/dev graphs exclude GTK/WebKit/Wry/JUCE; the maintained offline Cargo-tree regression test owns this check. The format-neutral trigger-host crate gains no native or format dependency.','license_limit':'Cached package manifest declarations and exact license bytes are provenance; they do not replace the installed product redistribution audit.'}
p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['trigger_editor_parameter_increment'],indent=2))
