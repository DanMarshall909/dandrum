import hashlib,json,shutil,subprocess
from pathlib import Path
source=Path('/tmp/dandrum-lanes/runtime');dest=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g2-native-fixture');base='954c549732537b95203e4b2a71c9bfeff2f2bb9a'
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git(dest,'status','--porcelain')=='';assert git(dest,'rev-parse','HEAD')==git(source,'rev-parse','HEAD')==git(dest,'rev-parse','refs/remotes/origin/feat/juce-free-host-adapters')==base
m=json.loads(Path('/tmp/dandrum-evidence/g2-parameter-delivery/final-source-artifact-manifest.json').read_text());paths=[p for p in m if p.startswith('src/')]+['CMakeLists.txt','README.md','docs/migrations/juce-free-clap-dependencies.json','openspec/changes/add-juce-free-trigger-clap-editor/design.md','scripts/prepare-trigger-clap-native.py','tests/python/test_engine_only_build.py','tests/python/test_trigger_native_fixture.py'];assert len(paths)==17
rows=[]
for name in sorted(paths):
 p=source/name;q=dest/name;assert p.is_file() and not p.is_symlink();before=hashlib.sha256(q.read_bytes()).hexdigest() if q.exists() else None
 if name.startswith('src/'):assert hashlib.sha256(p.read_bytes()).hexdigest()==m[name]['sha256']
 q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);digest=hashlib.sha256(p.read_bytes()).hexdigest();assert hashlib.sha256(q.read_bytes()).hexdigest()==digest
 rows.append({'path':name,'before_sha256':before,'sha256':digest,'mode':oct(p.stat().st_mode&0o777)})
record={'source':str(source),'destination':str(dest),'base':base,'files':rows,'excluded':['Runtime/cache-editor-guard accidental reusable target','all targets/caches/binaries/raw profiles','author evidence (not yet curated)','main checkout']};(out/'source-integration.json').write_text(json.dumps(record,indent=2)+'\n');print('copied and hash-verified',len(rows),'explicit source/doc paths')
