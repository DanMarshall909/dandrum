import hashlib,json
from pathlib import Path
b=Path('/tmp/dandrum-evidence/g2-parameter-delivery');out=Path('/tmp/dandrum-evidence/g2-native-fixture/root-feedback-coverage-assessment.json')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
regions={};records=[]
for label,build in [('feedback-owner','91-feedback-owner-instrument-build'),('feedback-native','93-feedback-native-instrument-build')]:
 binding=json.loads((b/(label+'-coverage-binding.json')).read_text());export=b/(label+'-raw-export.json')
 assert sha(export)==binding['export_sha256'];assert sha(binding['elf'])==binding['elf_sha256']
 for p,h in binding['profiles'].items():assert sha(p)==h
 build_record=json.loads((b/(build+'.json')).read_text());src='src/clap-adapter/src/trigger/gui.rs';source_sha=build_record['source_sha256'][src]
 assert sha(b/build/'source'/src)==source_sha
 raw=json.loads(export.read_text());found=0
 for data in raw['data']:
  for function in data['functions']:
   if '14service_editor' not in function['name']:continue
   found+=1
   for r in function['regions']:
    if r[7]!=0:continue
    filename=function['filenames'][r[5]]
    assert filename.endswith('/'+src)
    key=tuple(r[:4])+tuple(r[7:]);regions[key]=regions.get(key,0)+r[4]
 assert found>0
 records.append({'label':label,'export_sha256':sha(export),'elf_sha256':binding['elf_sha256'],'profile_count':len(binding['profiles']),'source_gui_sha256':source_sha,'function_records':found})
assert records[0]['source_gui_sha256']==records[1]['source_gui_sha256']
assert len(regions)==53 and all(v>0 for v in regions.values())
r={'records':records,'service_editor_distinct_source_regions':len(regions),'source_regions_with_positive_count':sum(v>0 for v in regions.values()),'never_hit':[k for k,v in regions.items() if not v],'scope':'Root independently verified actual ELF/profile/export/frozen GUI hashes and merged code regions by source range+kind across2 existing source-bound fixture exports. No root test/build execution; no branch/every-instantiation/full-GUI claim.'}
out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
