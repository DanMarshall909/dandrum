import hashlib,json,re
from pathlib import Path
root=Path('/home/dan/code/dandrum');p=root/'docs/migrations/trigger-clap-beta-notices.json';j=json.loads(p.read_text());metadata=json.loads(Path('/tmp/dandrum-task-8-1/dependency-metadata-final.json').read_text())
identities={tuple(m.groups()) for l in Path('/tmp/dandrum-task-8-1/dependency-tree-final.txt').read_text().splitlines() if (m:=re.match(r'^([^ ]+) v([^ ]+)',l))}
old={(x['name'],x['version']):x for x in j['rust_packages']};entries=[];digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for package in metadata['packages']:
 key=(package['name'],package['version'])
 if key not in identities:continue
 entry={'name':package['name'],'version':package['version'],'source':package['source'] or 'first-party','license_declaration':package['license']}
 source=Path(package['manifest_path']).parent
 if package['source']:
  checksum=source/'.cargo-checksum.json'
  if checksum.is_file():entry['checksum']=json.loads(checksum.read_text())['package']
  elif key in old and 'checksum' in old[key]:entry['checksum']=old[key]['checksum']
  files=[x for x in source.iterdir() if x.is_file() and re.match(r'(?i)^(licen[cs]e|copying|notice)',x.name)]
  entry['license_files']=[{'name':x.name,'sha256':digest(x)} for x in sorted(files)]
 entries.append(entry)
assert {(x['name'],x['version']) for x in entries}==identities
j['rust_packages']=sorted(entries,key=lambda x:(x['name'],x['version']))
j['inputs']['cargo_lock_sha256']=digest(root/'src/clap-adapter/Cargo.lock');j['inputs']['package_lock_sha256']=digest(root/'web/trigger/package-lock.json')
j['first_party_license_status']='Private/local beta only, as directed by the project owner on 2026-11-02; no first-party distribution licence selected.'
for x in j['javascript_runtime_packages']:
 source=root/'web/trigger/node_modules'/x['name'];x['license_files']=[{'name':f.name,'sha256':digest(f)} for f in sorted(source.iterdir()) if f.is_file() and re.match(r'(?i)^(licen[cs]e|copying|notice)',f.name)]
p.write_text(json.dumps(j,indent=2,sort_keys=True)+'\n')
print(len(entries),'runtime Rust packages;',sum(not x.get('license_files') for x in entries if x['source']!='first-party'),'third-party source archives have no top-level licence text')
