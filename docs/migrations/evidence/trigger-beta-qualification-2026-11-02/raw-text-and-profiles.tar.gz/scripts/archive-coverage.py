import sys,json,shlex,hashlib,tarfile,subprocess,io,tempfile,shutil,os
from pathlib import Path
name,logpath,reportpath=sys.argv[1:];root=Path('/home/dan/code/dandrum');base=Path('/tmp/dandrum-task-8-1');private=root/'.git/codex/trigger-beta-qualification-20261102';private.mkdir(parents=True,exist_ok=True,mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commands=[]
for line in Path(logpath).read_text().splitlines():
 if 'Running `' in line and 'llvm-cov export ' in line:commands.append(shlex.split(line.split('`',1)[1].rsplit('`',1)[0]))
assert len(commands)==1,len(commands)
command=commands[0];objects=[command[i+1] for i,x in enumerate(command) if x=='-object'];profile=Path(next(x.split('=',1)[1] for x in command if x.startswith('-instr-profile=')));rawlist=profile.parent/(profile.stem+'-profraw-list');inputs={};mapped={}
for i,path in enumerate(objects):
 p=Path(path);p=p if p.is_absolute() else root/p;arc=f'objects/{i:03d}-{p.name}';inputs[arc]=p;mapped[path]=arc
inputs['profile/merged.profdata']=profile
if rawlist.exists():
 for i,line in enumerate(rawlist.read_text().splitlines()):
  p=Path(line);p=p if p.is_absolute() else root/p;assert p.is_file(),p;inputs[f'raw/{i:03d}-{p.name}']=p
inputs['report.json']=Path(reportpath)
manifest={arc:{'original':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for arc,p in inputs.items()}
replay=[command[0],*['-instr-profile=profile/merged.profdata' if x.startswith('-instr-profile=') else mapped.get(x,x) for x in command[1:]]]
binding={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'command':command,'replay_command':replay,'llvm_cov_sha256':sha(Path(command[0])),'files':manifest,'scope':name,'distribution':'Private/local replay archive; do not stage or upload the compiled binaries.'}
archive=private/f'{name}-replay.tar.gz'
with os.fdopen(os.open(archive,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb') as output:
 with tarfile.open(fileobj=output,mode='w:gz',compresslevel=6,dereference=True) as tar:
  for arc,p in inputs.items():tar.add(p,arcname=arc,recursive=False)
  data=json.dumps(binding,indent=2).encode();m=tarfile.TarInfo('binding.json');m.size=len(data);m.mode=0o600;tar.addfile(m,io.BytesIO(data))
  sources=subprocess.check_output(['git','archive','--format=tar','HEAD','--','src/rust-engine','src/trigger-host'],cwd=root)
  with tarfile.open(fileobj=io.BytesIO(sources)) as source:
   for m in source.getmembers():
    if m.isfile():
     data=source.extractfile(m);m.name='source/'+m.name;tar.addfile(m,data)
subprocess.run([sys.executable,str(base/'verify-coverage-archive.py'),name],check=True)
