import collections,hashlib,json
from pathlib import Path
root=Path('/home/dan/code/dandrum'); crate=root/'src/rust-engine'

def missing(name):
 result={}
 for line in (Path('/tmp/dandrum-task-8-1/logs')/name).read_text().split('Uncovered Lines:')[-1].splitlines():
  if ': ' not in line:continue
  path,ns=line.split(': ',1)
  if not path.startswith(str(crate)):continue
  result[path]={int(n) for n in ns.split(', ') if n.isdigit()}
 return result
unit=missing('engine-coverage-baseline.log');full=missing('engine-full-coverage-before-lint.log')
held={'clippy::items_after_test_module','clippy::new_without_default'}
seen=set();edits=collections.defaultdict(list);counts=collections.Counter();skipped=[]
for raw in Path('/tmp/dandrum-task-8-1/engine-clippy-after-ffi.jsonl').read_text().splitlines():
 try:item=json.loads(raw)
 except ValueError:continue
 if item.get('reason')!='compiler-message':continue
 m=item['message'];code=(m.get('code')or{}).get('code');primary=next((s for s in m['spans'] if s['is_primary']),None)
 if m['level']!='error' or not code or not primary:continue
 key=(code,primary['file_name'],primary['byte_start'])
 if key in seen:continue
 seen.add(key)
 for child in m['children']:
  spans=[s for s in child.get('spans',[]) if s.get('suggested_replacement') is not None]
  if not spans or not all(s.get('suggestion_applicability')=='MachineApplicable' for s in spans):continue
  path=crate/primary['file_name'];unexecuted=unit.get(str(path),set())&full.get(str(path),set())
  if path.name in ('ffi.rs','sound_workbench_ffi.rs') or code in held or set(range(primary['line_start'],primary['line_end']+1))&unexecuted:
   skipped.append([code,primary['file_name'],primary['line_start']]);continue
  assert all(s['file_name']==primary['file_name'] for s in spans)
  proposed=[(s['byte_start'],s['byte_end'],s['suggested_replacement'].encode(),code) for s in spans]
  collision=any(not (b<=c or d<=a) for a,b,_,_ in proposed for c,d,_,_ in edits[path])
  if collision:
   skipped.append([code,primary['file_name'],primary['line_start'],'overlapping suggestion']);continue
  edits[path].extend(proposed);counts[code]+=1
  break
records=[]
for path,changes in sorted(edits.items()):
 original=path.read_bytes();new=original
 for a,b,replacement,code in sorted(changes,reverse=True):
  assert 0<=a<=b<=len(original)
  new=new[:a]+replacement+new[b:]
 path.write_bytes(new)
 records.append({'path':str(path.relative_to(root)),'before_sha256':hashlib.sha256(original).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest(),'edits':[[a,b,r.decode(),c] for a,b,r,c in changes]})
Path('/tmp/dandrum-task-8-1/covered-clippy-edits.json').write_text(json.dumps({'records':records,'counts':dict(counts),'held':skipped},indent=2)+'\n')
print('applied',sum(counts.values()),'diagnostics in',len(records),'files');print(dict(counts));print('held',len(skipped))
