import os,json,subprocess,hashlib,secrets,time,re,datetime
from pathlib import Path
root=Path('/home/dan/code/dandrum');base=Path('/tmp/dandrum-task-8-1');evidence=root/'docs/migrations/evidence/trigger-clap-installed-beta-2026-10-30';installed=base/'installed';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory():
 files=sorted(p for p in installed.rglob('*') if p.is_file());assert not any(p.is_symlink() for p in installed.rglob('*'));return [{'path':str(p.relative_to(installed)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
before=inventory();(base/'installed-manifest.json').write_text(json.dumps({'root':str(installed),'files':before},indent=2)+'\n')
cmd=['./scripts/cargo','test','--locked','--manifest-path','src/clap-adapter/Cargo.toml','--features','trigger-editor','--test','trigger_dynamic','--no-run','--message-format=json']
with (base/'offline-dynamic-build.jsonl').open('w') as out,(base/'logs/offline-dynamic-build.log').open('w') as err:subprocess.run(cmd,cwd=root,env=dict(os.environ,CARGO_NET_OFFLINE='true'),stdout=out,stderr=err,check=True)
records=[json.loads(l) for l in (base/'offline-dynamic-build.jsonl').read_text().splitlines() if l.startswith('{')];records=[x for x in records if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='trigger_dynamic' and x.get('executable')];assert len(records)==1
hosts={'dynamic':Path(records[0]['executable']),'gui':root/'build/cache-native/trigger-clap-native-fixture/trigger-gui-test'};xvfb=Path('/tmp/dandrum-task-7-3/xvfb/usr/bin/Xvfb')
provenance={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'dynamic_command':cmd,'dynamic_compiler_artifact':records[0],'gui_binding':json.loads((root/'build/cache-native/trigger-clap-native-fixture/binding.json').read_text()),'hosts':{k:{'path':str(p),'sha256':sha(p)} for k,p in hosts.items()},'xvfb':{'path':str(xvfb),'sha256':sha(xvfb)}}
(base/'offline-host-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
for kind in ['headless','gui']:
 s=(evidence/('isolated-'+kind+'.sh')).read_text().replace('/home/dan/code/.worktrees/dandrum/feat-juce-free-host-adapters','/home/dan/code/dandrum').replace('/tmp/dandrum-trigger-7-1-build',str(base))
 (base/('isolated-'+kind+'.sh')).write_text(s)
auth=base/'offline-Xauthority';subprocess.run(['xauth','-f',str(auth),'add',':93','.',secrets.token_hex(16)],check=True,capture_output=True);auth.chmod(0o600)
outer=os.readlink('/proc/self/ns/net');receipts=[]
for kind,host,expected in [('headless',hosts['dynamic'],3),('gui',hosts['gui'],1)]:
 cmd=['bwrap','--die-with-parent','--ro-bind','/','/','--unshare-net','--unshare-pid','--proc','/proc','--dev','/dev','--tmpfs','/home/dan/code','--tmpfs','/home/dan/.cargo','--tmpfs','/home/dan/.cache','--tmpfs','/tmp','--ro-bind',str(installed),'/tmp/installed','--ro-bind',str(host),'/tmp/host','--ro-bind',str(base/('isolated-'+kind+'.sh')),'/tmp/run']
 if kind=='gui':cmd+=['--ro-bind',str(xvfb),'/tmp/Xvfb','--ro-bind',str(auth),'/tmp/Xauthority']
 cmd+=['--setenv','DANDRUM_HOST_NET_NS',outer,'--chdir','/tmp/installed','--','/bin/sh','/tmp/run'];started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();log=base/'logs'/('offline-'+kind+'.log')
 with log.open('w') as out:r=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=90)
 text=log.read_text();count=text.count('test result: ok. 1 passed');receipt={'name':kind,'command':cmd,'outer_net':outer,'started_utc':started,'elapsed_seconds':time.monotonic()-t,'exit_status':r.returncode,'expected_tests':expected,'observed_exact_passes':count};receipts.append(receipt);(base/'offline-checks.json').write_text(json.dumps(receipts,indent=2)+'\n');print(kind,r.returncode,count,flush=True)
 assert r.returncode==0 and count==expected
assert inventory()==before,'installed bytes changed';print('source/cache-hidden offline proof passes; installed bytes unchanged')
