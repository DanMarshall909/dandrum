from pathlib import Path
import json,subprocess,sys
root=Path('/home/dan/code/dandrum');p=root/'docs/migrations/trigger-clap-beta-notices.json';original=p.read_bytes();j=json.loads(original)
label=sys.argv[1]
try:
 item=next(x for x in j['rust_packages'] if x['name']=='smartstring');item['license_files'][0]['sha256']='0'*64;p.write_text(json.dumps(j,indent=2,sort_keys=True)+'\n')
 r=subprocess.run(['python3','-B','tests/python/test_trigger_clap_install.py','TriggerClapInstallTest.test_notices_pin_the_current_runtime_dependency_and_font_inputs'],cwd=root,capture_output=True,text=True)
 (Path('/tmp/dandrum-task-8-1/logs')/(label+'.log')).write_text(r.stdout+r.stderr)
 if r.returncode==0 or 'runtime Rust licence text changed: smartstring' not in r.stderr:
  print('Licence pin guard calibration FAIL: fault was not diagnosed');sys.exit(1)
 print('Licence pin guard calibration PASS: exact changed-source-text diagnostic')
finally:p.write_bytes(original)
