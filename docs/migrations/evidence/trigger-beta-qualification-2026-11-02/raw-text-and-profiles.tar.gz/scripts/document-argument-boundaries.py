from pathlib import Path
import re
root=Path('src/rust-engine/src/graph_processor')
shared='Shared signal kernel borrows independent prepared and reference state fields'
reference='Independent reference DSP consumes named control-port buffers without rebuilding state wrappers'
items={
 'arena_processing.rs':{
  'process_sample_player_state':shared,'process_sample_slicer_state':shared,'process_sample_map_player_state':shared,
  'process_note_to_control_state':shared,'process_adsr_state':shared,
 },
 'block.rs':{
  'process_block_compiled':'Allocating reference renderer keeps independent graph, state, event and output owners explicit',
  'process_block_compiled_polyphonic':'Allocating reference renderer keeps independent graph, state, event and output owners explicit',
 },
 'dispatch.rs':{'process_module':'Reference dispatch keeps module state, port inputs and block coordinates explicit'},
 'processing.rs':{'process_adsr':reference,'process_sampler':reference,'process_envelope_follower':reference,'process_dynamics_processor':reference},
 'realtime_graph_processor.rs':{'render_polyphonic_from_plan':'Reference renderer borrows allocator, voice queues, global queues and scratch storage independently'},
}
count=0
for file,names in items.items():
 p=root/file;s=p.read_text()
 if file=='arena_processing.rs':
  s=s.replace('#[allow(clippy::too_many_arguments)]\n','')
 for name,reason in names.items():
  pattern=re.compile(r'(?m)^([ \t]*)(?:pub(?:\([^\n)]*\))? )?fn '+re.escape(name)+r'\(')
  matches=list(pattern.finditer(s));assert len(matches)==1,(file,name,len(matches))
  m=matches[0];indent=m[1]
  attr=indent+'#[expect(clippy::too_many_arguments, reason = "'+reason+'")]\n'
  s=s[:m.start()]+attr+s[m.start():];count+=1
 p.write_text(s)
print('function-level argument expectations',count,'; removed three old unexplained function-level allow attributes')
assert count==13
