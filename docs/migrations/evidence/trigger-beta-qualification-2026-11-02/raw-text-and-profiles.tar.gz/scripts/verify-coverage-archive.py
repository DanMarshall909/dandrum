import math
import sys,json,tarfile,tempfile,subprocess,shutil,hashlib
from pathlib import Path
name=sys.argv[1];base=Path('/tmp/dandrum-task-8-1');archive=Path('/home/dan/code/dandrum/.git/codex/trigger-beta-qualification-20261102')/(name+'-replay.tar.gz');sha=lambda data:hashlib.sha256(data).hexdigest()
with tempfile.TemporaryDirectory(prefix=name+'-replay-',dir=base) as work:
 work=Path(work)
 with tarfile.open(archive) as tar:
  binding=json.load(tar.extractfile('binding.json'))
  for arc,item in binding['files'].items():
   p=work/arc;p.parent.mkdir(parents=True,exist_ok=True)
   with tar.extractfile(arc) as src,p.open('wb') as dst:shutil.copyfileobj(src,dst)
   assert sha(p.read_bytes())==item['sha256'],arc
 with (work/'replayed.json').open('wb') as out:subprocess.run(binding['replay_command'],cwd=work,stdout=out,stderr=subprocess.PIPE,check=True)
 a=(work/'report.json').read_bytes();b=(work/'replayed.json').read_bytes();ja=json.loads(a);jb=json.loads(b)
 print({'original_bytes':len(a),'replayed_bytes':len(b),'byte_equal':a==b,'stripped_equal':a.strip()==b.strip(),'json_equal':ja==jb})
 metadata=ja.pop('cargo_llvm_cov',None)
 assert metadata is not None and 'cargo_llvm_cov' not in jb
 def normalize(x):
  if isinstance(x,list):return [normalize(v) for v in x]
  if isinstance(x,dict):
   result={k:normalize(v) for k,v in x.items()}
   if 'percent' in x and 'count' in x and 'covered' in x:
    expected=100*x['covered']/x['count'] if x['count'] else 0
    assert math.isclose(x['percent'],expected,rel_tol=1e-12,abs_tol=1e-10),'invalid derived percentage'
    result['percent']=expected
   return result
  return x
 if normalize(ja)!=normalize(jb):
  def diff(a,b,path=''):
   if not isinstance(a,(dict,list)) and a==b:return False
   if type(a)!=type(b):print('type',path,type(a),type(b),str(a)[:100],str(b)[:100]);return True
   if isinstance(a,dict):
    if a.keys()!=b.keys():print('keys',path,a.keys(),b.keys());return True
    return any(diff(a[k],b[k],path+'/'+str(k)) for k in a)
   if isinstance(a,list):
    if len(a)!=len(b):print('length',path,len(a),len(b));return True
    return any(diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b)))
   if a!=b:print('value',path,str(a)[:250],str(b)[:250]);return True
   return False
  diff(ja,jb);raise SystemExit(1)
 receipt={'scope':name,'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'producer_report_sha256':sha(a),'replayed_report_sha256':sha(b),'all_counters_and_source_locations_match':True,'percentages_verified_against_equal_counts':True,'percentage_absolute_tolerance':1e-10,'cargo_llvm_cov_metadata_retained':metadata,'replay_byte_exact_match':a==b,'input_count':len(binding['files']),'input_bytes':sum(x['bytes'] for x in binding['files'].values()),'source_commit':binding['source_commit'],'source_tree':binding['source_tree'],'llvm_cov_sha256':binding['llvm_cov_sha256']}
 (base/(name+'-replay-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');(base/(name+'-replay-binding.json')).write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps(receipt))
