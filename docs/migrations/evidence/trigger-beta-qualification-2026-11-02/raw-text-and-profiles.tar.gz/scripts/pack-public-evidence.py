from pathlib import Path
import json,tarfile,hashlib,re,io,subprocess
base=Path('/tmp/dandrum-task-8-1');out=Path('/home/dan/code/dandrum/docs/migrations/evidence/trigger-beta-qualification-2026-11-02');out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files={}
for p in (base/'logs').glob('*.log'):files['logs/'+p.name]=p
for p in base.glob('*.json'):files[p.name]=p
for p in base.glob('*.txt'):files[p.name]=p
for p in base.glob('*.py'):files['scripts/'+p.name]=p
for p in base.glob('isolated-*.sh'):files['scripts/'+p.name]=p
for directory in ['osv-current-20261102','dependency-system-review','browser-coverage-pipeline']:
 for p in (base/directory).rglob('*'):
  if p.is_file() and p.suffix in ['.json','.jsonl','.txt','.toml','.lock','.py','.md'] and 'glib-source' not in p.parts:files[directory+'/'+str(p.relative_to(base/directory))]=p
for name in ['cleanup.json','command.json','guardian-proof.json']:
 files['native-run/'+name]=base/'native-run'/name
# Node's raw counters remain untouched for first-party script records; unrelated
# dependency/internal script data is outside this packet's coverage scope.
node=base/'frontend-final-node-v8';scoped=base/'scoped-node-profiles';scoped.mkdir(exist_ok=True)
for p in node.glob('*.json'):
 j=json.loads(p.read_text());j['result']=[x for x in j['result'] if x.get('url','').startswith('file:///home/dan/code/dandrum/') and '/node_modules/' not in x['url']]
 j.pop('source-map-cache',None)
 if j['result']:
  target=scoped/p.name;target.write_text(json.dumps(j,separators=(',',':')));files['node-v8/'+p.name]=target
pattern=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}|sk-proj-[A-Za-z0-9_-]{30,}|AKIA[0-9A-Z]{16})')
manifest=[]
for name,p in sorted(files.items()):
 data=p.read_bytes();assert not data.startswith(b'\x7fELF') and not pattern.search(data),name
 manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive=out/'raw-text-and-profiles.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(files)
 for item in manifest:assert hashlib.sha256(tar.extractfile(item['path']).read()).hexdigest()==item['sha256']
(out/'archive-manifest.json').write_text(json.dumps({'source_commit':'7ea453e2510fdd3c40f40248699356b2440bcf16','source_tree':'27931fd3c9ba889b35302318268ffdb006470f14','archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'all_members_verified':True,'files':manifest},indent=2)+'\n')
for name in ['installed-manifest.json','engine-coverage-summary.json','host-coverage-summary.json','ctest-results.json','engine-final-replay-receipt.json','host-final-replay-receipt.json','installed-replay-receipt.json','final-execution-notes.json']:(out/name).write_bytes((base/name).read_bytes())
print('Public evidence:',len(files),'verified text/profile members;',archive.stat().st_size,'bytes. No product/test ELF binaries.')
