"""One qualification run in a task-owned X11 desktop; no persistent service."""
import os,subprocess,time,signal,json,datetime
from pathlib import Path
root=Path('/home/dan/code/dandrum');base=Path('/tmp/dandrum-task-8-1');children=[];receipts=[]
env=dict(os.environ,DISPLAY=':93',GDK_BACKEND='x11',XDG_RUNTIME_DIR='/run/user/'+str(os.getuid()),XDG_CONFIG_HOME=str(base/'native-config'),XDG_CACHE_HOME=str(base/'native-cache'),LIBGL_ALWAYS_SOFTWARE='1',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2')
env.pop('XAUTHORITY',None)
def launch(cmd,name):
 log=(base/'logs'/(name+'.log')).open('wb');child=subprocess.Popen(cmd,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);children.append(child);return child
try:
 if Path('/tmp/.X11-unix/X93').exists():raise RuntimeError('Refusing to reuse an unowned X11 display93')
 server=launch(['/tmp/dandrum-task-7-3/xvfb/usr/bin/Xvfb',':93','-screen','0','1600x1200x24','-nolisten','tcp','-ac'],'native-xvfb')
 for _ in range(100):
  if server.poll() is not None:raise RuntimeError('Owned Xvfb stopped before readiness')
  if Path('/tmp/.X11-unix/X93').exists():break
  time.sleep(.05)
 else:raise RuntimeError('Owned Xvfb did not become ready')
 wm=launch(['dbus-run-session','--','xfwm4','--replace','--compositor=off','--sm-client-disable'],'native-window-manager');time.sleep(1)
 if wm.poll() is not None:raise RuntimeError('Owned window manager stopped before readiness')
 (base/'native-runtime.json').write_text(json.dumps({'display':':93','xvfb_pid':server.pid,'wm_pid':wm.pid,'private_xdg_config':env['XDG_CONFIG_HOME'],'private_xdg_cache':env['XDG_CACHE_HOME']},indent=2)+'\n')
 commands=[('ctest-final',['/home/dan/.local/bin/ctest','--test-dir','build/cache-native','--output-on-failure','--parallel','1','--no-tests=error','-V']),('official-validator-trigger',['/home/dan/.cache/dandrum-trigger-beta/clap-validator-0.4.1/clap-validator','validate','--json',str(base/'installed/lib/clap/DandrumTrigger.clap')]),('official-validator-proof',['/home/dan/.cache/dandrum-trigger-beta/clap-validator-0.4.1/clap-validator','validate','--json',str(root/'build/cache-native/clap/DandrumHeadlessProof.clap')])]
 for label,cmd in commands:
  started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
  with (base/'logs'/(label+'.log')).open('w') as out:r=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
  receipts.append(dict(name=label,command=cmd,cwd=str(root),started_utc=started,elapsed_seconds=time.monotonic()-t,exit_status=r.returncode));(base/'native-checks.json').write_text(json.dumps(receipts,indent=2)+'\n');print(label,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
finally:
 for child in reversed(children):
  if child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
 (base/'native-shutdown.json').write_text(json.dumps({'owned_direct_children':[{'pid':p.pid,'exit_status':p.returncode} for p in children]},indent=2)+'\n')
