from pathlib import Path
import re

handles={
 'DandrumKernelInstrument':'kernel instrument',
 'DandrumKernelUiSnapshot':'UI snapshot',
 'DandrumKernelWaveformSource':'retained waveform source',
 'DandrumRealtimeEventQueue':'realtime event queue',
 'DandrumSoundFixtureRender':'fixture-render result',
 'DandrumSoundMatch':'sound-match result',
 'DandrumGraphProposal':'graph-proposal result',
}
pattern=re.compile(r'#\[unsafe\(no_mangle\)\]\n(pub unsafe extern "C" fn (\w+)\((.*?)\)\s*(?:->[^\{]+)?\{)',re.S)
counts=[]
for file in ['ffi.rs','sound_workbench_ffi.rs']:
 p=Path('src/rust-engine/src')/file;s=p.read_text();n=0
 def add(m):
  global n
  n+=1
  name=m[2];args=[tuple(x.strip().split(':',1)) for x in m[3].split(',') if ':' in x]
  args=[(a,t.strip()) for a,t in args]
  docs=[]
  if name.endswith('_destroy'):
   a,t=args[0]
   docs=[f'`{a}` must be null or the original owning pointer to a live',
         f'{handles[t.split()[-1]]} returned by its matching creation function.',
         'All access to this handle and its borrowed views must have ended. The',
         'non-null pointer is consumed exactly once and must not be used afterward.']
  elif name=='dandrum_kernel_render':
   docs=['A non-null `engine` must be a live kernel instrument, exclusively',
         'accessible for this call, including against metadata reads and destruction.',
         'Nonempty descriptor arrays must contain their declared number of initialized',
         'views; each channel-pointer array must contain `channel_count` initialized',
         'pointers. Accessed input channels must hold `frames` readable floats and',
         'output channels must hold `frames` aligned writable floats. Keep descriptor',
         'and pointer arrays unchanged, and output buffers disjoint from them and the',
         'instrument. All inputs are copied before outputs are written, so ordinary',
         'input/output sample-buffer reuse is allowed. Bus `name` fields are unused.']
  else:
   for a,t in args:
    typ=t.split()[-1]
    if t.startswith('*') and typ in handles:
     docs += [f'A non-null `{a}` must point to a live {handles[typ]}.']
     docs += (['Access must be exclusive for this call, including against reads and',
               'destruction; the handle is not internally synchronized.'] if t.startswith('*mut') else
              ['Keep it alive and free of concurrent mutation or destruction during the call.'])
    elif t=='*const c_char':
     docs += [f'A non-null `{a}` must point to a readable NUL-terminated C string',
              'that remains valid throughout the call; invalid UTF-8 is rejected.']
    elif t.startswith('*mut') and typ!='c_void':
     if typ in ['c_char','u8']:
      cap=next((b for b,_ in args if b==a+'_capacity'),None)
      if cap is None: cap=next((b for b,_ in args if b in ('buffer_capacity','capacity')),None)
      assert cap,(name,a,args)
      docs += [f'A non-null `{a}` must be writable for `{cap}` bytes',
               'and must not overlap storage borrowed from a handle.']
     elif name=='dandrum_kernel_waveform_reduce':
      docs += ['A non-null `output` must be aligned writable storage for `bucket_count`',
               'buckets, disjoint from the retained source. Prior initialization is not',
               'required; invalid requests leave the destination unchanged.']
     elif name=='dandrum_kernel_prepared_source_copy_channel':
      docs += ['A non-null `output` must be aligned writable storage for `frame_count`',
               'floats, disjoint from the retained source. Prior initialization is not',
               'required; invalid requests leave the destination unchanged.']
     else:
      docs += [f'A non-null `{a}` must designate aligned writable storage for one',
               f'`{typ}`, without overlapping a handle or its borrowed storage.',
               'Its previous contents need not be initialized.']
   if name=='dandrum_kernel_prepare_file':
    docs += ['A nonempty `declarations` array must contain `declaration_count` initialized',
             'records with readable NUL-terminated `name` strings for this call.']
   if name in ['dandrum_kernel_waveform_source_info','dandrum_kernel_ui_source',
               'dandrum_kernel_ui_region','dandrum_kernel_ui_slice','dandrum_kernel_ui_map',
               'dandrum_kernel_ui_zone']:
    owner='source' if name.endswith('_source_info') else 'snapshot'
    docs += [f'Returned string views borrow `{owner}`-owned UTF-8 byte ranges,',
             f'not C strings; keep `{owner}` alive while reading them.']
   if any('Callback' in t for _,t in args):
    docs += ['Any callback and its `context` must remain valid until this synchronous',
             'call returns. Callbacks must not unwind across the C ABI or invalidate',
             'borrowed arguments. They are not retained after return. A null callback',
             'is allowed; a non-null callback must handle its supplied context.']
  assert docs,name
  return '/// # Safety\n'+''.join('/// '+line+'\n' for line in docs)+m[0]
 s=pattern.sub(add,s);p.write_text(s);counts.append((file,n))
print(counts)
assert counts==[('ffi.rs',35),('sound_workbench_ffi.rs',39)]
