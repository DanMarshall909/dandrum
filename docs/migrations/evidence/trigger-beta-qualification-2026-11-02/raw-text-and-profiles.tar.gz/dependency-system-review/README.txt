Task8.1 dependency/system evidence, private/local beta only.

review.json summarizes verified native versions and named primary advisory records.
glib-source-proof.json binds the current 204-package notice inventory and 6678 Rust source files to the bounded no-caller conclusion. Copied GLib files retain the exact inspected source.
license-archive-inspection.json binds five missing-text cached archives and the smartstring LICENCE.md spelling correction.
installed-versions.txt and cached-apt-policy.txt retain local package observations.
The sibling osv-current-20261102 packet records all-registry lockfile queries, calibration and residual catalogue limitations.

No dependency-clean, whole-system exploitability, OS update or redistribution-clearance claim. Native GLib, Soup and WebKit limitations remain explicit. The Rust GLib version is affected but its vulnerable iterator has no supported production source caller found.
