import datetime, hashlib, json, pathlib, re, subprocess, time, urllib.request
ROOT=pathlib.Path('/home/dan/code/dandrum')
OUT=pathlib.Path(__file__).resolve().parent
DOCS={'querybatch':'https://google.github.io/osv.dev/post-v1-querybatch/','query':'https://google.github.io/osv.dev/post-v1-query/','vuln':'https://google.github.io/osv.dev/get-v1-vulns/'}
def save(path,data):
 p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def request(path,payload=None):
 data=None if payload is None else json.dumps(payload,separators=(',',':')).encode()
 req=urllib.request.Request('https://api.osv.dev/v1/'+path,data=data,headers={'Content-Type':'application/json','User-Agent':'dandrum-task-8.1-read-only-audit'},method='GET' if payload is None else 'POST')
 start=time.monotonic()
 with urllib.request.urlopen(req,timeout=30) as response:
  raw=response.read();status=response.status
 if status!=200:raise RuntimeError('unexpected HTTP status '+str(status))
 return json.loads(raw),raw,round(time.monotonic()-start,3)
start=now();inventory={};sources=[]
calibration_payload={'queries':[{'package':{'ecosystem':'crates.io','name':'glib'},'version':'0.18.5'},{'package':{'ecosystem':'crates.io','name':'zip'},'version':'8.6.0'},{'package':{'ecosystem':'crates.io','name':'rtrb'},'version':'0.3.2'}]}
save('calibration-request.json',calibration_payload)
calibration_response,calibration_raw,calibration_elapsed=request('querybatch',calibration_payload)
(OUT/'calibration-response.json').write_bytes(calibration_raw)
expected_controls=['RUSTSEC-2024-0429','GHSA-m665-v7pm-7grj','RUSTSEC-2026-0274']
checks={name:any(v['id']==expected for v in result.get('vulns',[])) for name,expected,result in zip(['glib','zip','rtrb'],expected_controls,calibration_response['results'])}
if len(calibration_response['results'])!=3 or not all(checks.values()):raise RuntimeError('known-vulnerable positive control failed')
for relative in ['src/rust-engine/Cargo.lock','src/instrument-session/Cargo.lock','src/trigger-host/Cargo.lock','src/clap-adapter/Cargo.lock']:
 raw=(ROOT/relative).read_bytes();dest=OUT/'source'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 sources.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
 for block in raw.decode().split('[[package]]')[1:]:
  item={}
  for line in block.splitlines():
   match=re.match(r'^(name|version|source|checksum) = (".*")$',line)
   if match:item[match[1]]=json.loads(match[2])
  key=(item['name'],item['version'],item.get('source'))
  if key not in inventory:inventory[key]={**item,'lockfiles':[]}
  inventory[key]['lockfiles'].append(relative)
for relative in ['src/rust-engine/Cargo.toml','src/instrument-session/Cargo.toml','src/trigger-host/Cargo.toml','src/clap-adapter/Cargo.toml','src/trigger-editor/Cargo.toml','docs/migrations/trigger-clap-beta-notices.json']:
 raw=(ROOT/relative).read_bytes();dest=OUT/'source'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);sources.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
command=['/home/dan/.cargo/bin/cargo','tree','--offline','--locked','--manifest-path','src/clap-adapter/Cargo.toml','--features','trigger-editor','--target','x86_64-unknown-linux-gnu','--edges','normal,build','--prefix','none','--format','{p}']
r=subprocess.run(command,cwd=ROOT,capture_output=True,text=True);(OUT/'production-tree.stdout').write_text(r.stdout);(OUT/'production-tree.stderr').write_text(r.stderr)
if r.returncode:raise RuntimeError('cargo tree failed')
production={(m.group(1),m.group(2)) for line in r.stdout.splitlines() if (m:=re.match(r'^([^ ]+) v([^ ]+)',line))}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
rows=sorted(inventory.values(),key=lambda x:(x['name'],x['version'],x.get('source','')))
queries=[];mapping=[];skipped=[];git={}
for item in rows:
 item['trigger_normal_build']=(item['name'],item['version']) in production
 if item.get('source','').startswith('registry+https://github.com/rust-lang/crates.io-index'):
  mapping.append({'kind':'crates.io-version','packages':[item]});queries.append({'package':{'ecosystem':'crates.io','name':item['name']},'version':item['version']})
 elif item.get('source','').startswith('git+'):
  git.setdefault(item['source'].rsplit('#',1)[1],[]).append(item)
 else:skipped.append({'identity':item,'reason':'first-party local/path package; no external advisory catalog identity'})
for commit,items in git.items():
 mapping.append({'kind':'git-commit-query','packages':items,'limit':'commit query covers matching OSV GIT records only; empty result does not establish repository advisory coverage'});queries.append({'commit':commit})
save('source-snapshot.json',{'head':head,'started_utc':start,'files':sources,'production_tree_command':command,'production_tree_package_count':len(production),'api_docs':DOCS})
save('inventory.json',{'packages':rows,'queries':queries,'query_mapping':mapping,'skipped':skipped})
all_ids=[set() for _ in queries];pages=[];pending=[(i,q) for i,q in enumerate(queries)];counter=0
while pending:
 batch=pending[:100];pending=pending[100:];counter+=1
 if counter>30:raise RuntimeError('pagination budget exceeded; remaining results unverified')
 payload={'queries':[q for _,q in batch]};save('requests/batch-%03d.json'%counter,payload)
 response,raw,elapsed=request('querybatch',payload);p=OUT/('responses/batch-%03d.json'%counter);p.parent.mkdir(exist_ok=True);p.write_bytes(raw)
 results=response.get('results')
 if not isinstance(results,list) or len(results)!=len(batch):raise RuntimeError('querybatch response alignment failure')
 for (index,query),result in zip(batch,results):
  all_ids[index].update(v['id'] for v in result.get('vulns',[]))
  if result.get('next_page_token'):pending.append((index,{**query,'page_token':result['next_page_token']}))
 pages.append({'batch':counter,'query_indices':[i for i,_ in batch],'elapsed_seconds':elapsed,'response_sha256':hashlib.sha256(raw).hexdigest()})
 print('batch',counter,'queries',len(batch),'elapsed',elapsed,flush=True)
ids=sorted(set().union(*all_ids));details={}
for advisory in ids:
 detail,raw,elapsed=request('vulns/'+advisory);p=OUT/'advisories'/(advisory+'.json');p.parent.mkdir(exist_ok=True);p.write_bytes(raw);details[advisory]=detail
print('advisory detail records',len(ids),flush=True)
results=[]
for q,m,advisories in zip(queries,mapping,all_ids):
 results.append({'query':q,'mapping':m,'advisory_ids':sorted(advisories)})
groups=[]
for advisory,d in details.items():
 groups.append({'id':advisory,'aliases':d.get('aliases',[]),'summary':d.get('summary'),'withdrawn':d.get('withdrawn'),'database_specific':d.get('database_specific'),'affected':d.get('affected',[]),'severity':d.get('severity',[])})

summary={'started_utc':start,'completed_utc':now(),'head':head,'lockfile_unique_identities':len(rows),'registry_version_queries':sum(m['kind']=='crates.io-version' for m in mapping),'git_commit_queries':len(git),'first_party_skipped':skipped,'query_count':len(queries),'query_with_matches':sum(bool(x) for x in all_ids),'advisory_record_count':len(ids),'pagination_complete':not pending,'pages':pages,'known_vulnerable_calibration':checks,'results':results,'advisories':groups,'limits':['OSV catalog lookup, not source-code exploitability analysis or a guarantee of absence of vulnerabilities','Full four-lockfile scope includes build/dev/other-target packages; production membership is separately recorded','Git commit empty result does not prove repository coverage; local/path first-party packages skipped','Native system libraries and JavaScript outside this Rust scan']}
save('summary.json',summary)
if not all(checks.values()):raise RuntimeError('known-vulnerable positive control failed')
print(json.dumps({k:summary[k] for k in ['registry_version_queries','git_commit_queries','query_count','query_with_matches','advisory_record_count','pagination_complete','known_vulnerable_calibration']}),flush=True)
