from pathlib import Path
import json,hashlib,subprocess,tarfile,gzip,io
root=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/native-handler-cmake-registration');dest=root/'docs/migrations/evidence/trigger-native-handler-2026-10-21'
assert json.loads((out/'source-free.json').read_text())['exit']==0
files={}
for f in out.iterdir():
 if f.is_file():files['root/'+f.name]=f
work=root/'build/engine-only-regression'
for f in work.glob('*.log'):files['source-free/'+f.name]=f
fixtures=sorted(work.glob('fixture-*/source/CMakeLists.txt'),key=lambda f:f.stat().st_mtime_ns)
fixture=fixtures[-1].parent
assert (fixture/'CMakeLists.txt').read_bytes()==(root/'CMakeLists.txt').read_bytes()
assert (fixture/'tests/python/test_engine_only_build.py').read_bytes()==(root/'tests/python/test_engine_only_build.py').read_bytes()
manifest={str(f.relative_to(fixture)):hashlib.sha256(f.read_bytes()).hexdigest() for f in fixture.rglob('*') if f.is_file() and 'build' not in f.relative_to(fixture).parts and '__pycache__' not in f.parts}
(out/'source-free-inputs.json').write_text(json.dumps({'fixture':str(fixture),'excluded_source_trees':['third_party','web','ui'],'sha256':manifest},indent=2)+'\n');files['root/source-free-inputs.json']=out/'source-free-inputs.json'
archive=dest/'root.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tf:
 for name,f in sorted(files.items()):
  data=f.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(data))
(dest/'root-artifacts.json').write_text(json.dumps({'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':{n:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for n,f in sorted(files.items())}},indent=2)+'\n')
checks={p.stem:json.loads(p.read_text()) for p in out.glob('*.json') if p.stem in ['green','red','native-maintained-runtime','native-zero-test-rejected','native-guard-calibration','source-free','scoped-spec','canonical-spec','spec-coverage','diff-check']}
(dest/'root-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
base=git('rev-parse','HEAD').decode().strip();assert base==git('rev-parse','origin/feat/juce-free-host-adapters').decode().strip()
paths=['CMakeLists.txt','tests/python/test_engine_only_build.py','src/trigger-editor/src/native_x11.rs','src/trigger-editor/tests/internal/native_x11.rs']+[str(f.relative_to(root)) for f in dest.rglob('*') if f.is_file()]
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
entries=[]
for p in sorted(paths):
 mode,obj,stage=git('ls-files','--stage','--',p).decode().split()[:3];assert stage=='0';status=git('status','--porcelain=v1','--',p).decode().strip('\n')[:2];entries.append({'path':p,'status':status,'mode':mode,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest(),'staged_object':obj})
m={'base':base,'current':base,'upstream_ref':'origin/feat/juce-free-host-adapters','upstream':base,'integration_base':base,'index_tree':git('write-tree').decode().strip(),'worktree':str(root),'paths':entries,'excluded_runtime_wip':['openspec/changes/add-juce-free-trigger-clap-editor/design.md','src/clap-adapter/Cargo.toml','src/clap-adapter/Cargo.lock','src/clap-adapter/src/trigger.rs','src/clap-adapter/src/trigger/gui.rs','src/clap-adapter/tests/trigger_gui.rs','src/clap-adapter/tests/fixtures/trigger-gui-native-observer.js'],'post_PASS_envelope':['Recompute unchanged manifest, named validations git diff --check/git diff --cached --check; inspect status/diff/cached/log; commit exact staged tree with normal hooks message Release application handlers with the native editor; unchanged upstream fetch then normal push HEAD:feat/juce-free-host-adapters; fast-forward synchronized feature and existing lanes only preserving Runtime G1 WIP; append exact commit/result tracker note; no source/content changes, no cleanup deletion.'],'scope':'Independently useful NativeEditor resource handler lifetime repair and maintained CMake native test registration only; no OpenSpec task closure, no G1/beta completion claim','review_evidence':str(dest.relative_to(root))}
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'paths':len(entries),'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),'index_tree':m['index_tree'],'root_archive_bytes':archive.stat().st_size,'sourcefree_inputs':len(manifest)}))
