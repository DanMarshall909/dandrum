from pathlib import Path
import tarfile,gzip,hashlib,json,io,re
root=Path('/tmp/dandrum-lanes/integration');src=Path('/tmp/dandrum-lanes/evidence-trigger-native-gui');dest=root/'docs/migrations/evidence/trigger-native-handler-2026-10-21';dest.mkdir(parents=True,exist_ok=True)
files={}
for f in src.iterdir():
 if f.is_file() and re.match(r'^(5[4-9]|[6-8][0-9]|9[0-3])-',f.name):files['author/'+f.name]=f
for d in [x.name for x in src.iterdir() if x.is_dir() and re.match(r'^(5[4-9]|[6-8][0-9]|9[0-3])-',x.name)]:
 for f in (src/d).rglob('*'):
  if f.is_file():files['author/'+str(f.relative_to(src))]=f
j=json.loads((src/'93-native-handler-repair-checkpoint.json').read_text())
for s in j['final_profiles']:
 f=Path(s);files['coverage-profiles/'+f.name]=f
for s in ['/tmp/dandrum-lanes/cache-host-snapshot-cov/trigger-native-handler-owner-20261021/refactor/coverage.profdata']:
 f=Path(s)
 if f.is_file():files['coverage-profiles/'+f.name]=f
archive=dest/'author.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tf:
 for name,f in sorted(files.items()):
  data=f.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(data))
manifest={n:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for n,f in sorted(files.items())}
(dest/'author-artifacts.json').write_text(json.dumps({'archive':'author.tar.gz','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':manifest},indent=2)+'\n')
(dest/'coverage-qualification.json').write_text(json.dumps({'final_summary':j['coverage_summary'],'qualification':j['coverage_qualification'],'ordinary_elf_sha256':j['ordinary_test_elf_sha256'],'instrumented_elf_sha256':j['final_instrumented_elf_sha256'],'scope':'Existing standalone locked editor graph; exact owner instrumented, dependencies uninstrumented. RED retained-context calibration used earlier combined consumer graph with 17 transitive differences, not equivalent lock. No performance/allocator claim.','mutation':'Explicitly excluded by user.','changed_core_coordinates':'36 helper/wrapper, 6 guard Drop, 3 owner-release all have positive execution; not all emitted copies and no branch100 claim.'},indent=2)+'\n')
print(json.dumps({'archive_bytes':archive.stat().st_size,'members':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
