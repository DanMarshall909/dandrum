import os,pathlib,subprocess,json,time,hashlib,resource,shutil
root=pathlib.Path('/tmp/dandrum-lanes/runtime'); out=pathlib.Path('/tmp/dandrum-evidence/native-handler-cmake-registration'); build=out/'native-build'
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
build.mkdir(exist_ok=True)
target=build/'rust-target'
if not target.exists(): target.symlink_to('/tmp/dandrum-lanes/cache-editor-guard',target_is_directory=True)
assert target.resolve()==pathlib.Path('/tmp/dandrum-lanes/cache-editor-guard')
env=dict(os.environ,DISPLAY=':10.0',GDK_BACKEND='x11',XAUTHORITY='/home/dan/.Xauthority',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='1')
for k in ('LD_PRELOAD','RUST_MIN_STACK','RUSTFLAGS','LLVM_PROFILE_FILE'): env.pop(k,None)
def run(name,args,expected=0):
 assert shutil.disk_usage('/tmp').free>1073741824
 t=time.monotonic()
 with (out/(name+'.stdout.log')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:
  p=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=1200)
 r=dict(command=args,cwd=str(root),exit=p.returncode,seconds=time.monotonic()-t,source_sha256={x:hashlib.sha256((root/x).read_bytes()).hexdigest() for x in ('CMakeLists.txt','tests/python/test_engine_only_build.py','src/trigger-editor/src/native_x11.rs','src/trigger-editor/tests/internal/native_x11.rs')})
 (out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n'); print(name,p.returncode,round(r['seconds'],2),flush=True)
 assert p.returncode==expected,r
 return r
run('native-configure',['cmake','-S',str(root),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DDANDRUM_ENGINE_ONLY=ON','-DDANDRUM_CLAP_PROOF=ON','-DDANDRUM_TRIGGER_CLAP_EDITOR=ON','-DDANDRUM_TRIGGER_EDITOR_NATIVE_X11=ON','-DDANDRUM_TRIGGER_EDITOR_BUNDLE_DIR=/tmp/dandrum-lanes/evidence-trigger-native-gui/current-native-build'])
run('native-stage',['cmake','--build',str(build),'--target','dandrum-trigger-resources','--parallel','2'])
run('native-maintained-runtime',['ctest','--test-dir',str(build),'--verbose','-R','^trigger-editor-native-(x11|handler-lifetime)$'])
text=(out/'native-maintained-runtime.stdout.log').read_text()
assert text.count('running 1 test')==2 and '100% tests passed' in text
# Fault injection is limited to generated disposable CTest metadata, never source.
p=build/'CTestTestfile.cmake'; original=p.read_bytes(); needle=b'native_x11::tests::destroy_releases_application_handlers_while_framework_context_remains'; assert original.count(needle)==1
try:
 p.write_bytes(original.replace(needle,b'native_x11::tests::deliberately_missing_lifetime_calibration'))
 run('native-zero-test-rejected',['ctest','--test-dir',str(build),'--verbose','-R','^trigger-editor-native-handler-lifetime$'],8)
 negative=(out/'native-zero-test-rejected.stdout.log').read_text()
 assert 'running 0 tests' in negative and 'Error regular expression found in output. Regex=[running 0 tests]' in negative and 'running 0 tests' in negative
finally: p.write_bytes(original)
assert p.read_bytes()==original
(out/'native-guard-calibration.json').write_text(json.dumps(dict(positive='two actual exact native tests; fixture prepared automatically',negative='Rust exits zero with zero tests; CTest rejects FAIL_REGULAR_EXPRESSION running 0 tests',generated_ctest_restored_sha256=hashlib.sha256(original).hexdigest(),bundle='current-native-build, production React silent-preview library calibration; no G1 acceptance claim'),indent=2)+'\n')
