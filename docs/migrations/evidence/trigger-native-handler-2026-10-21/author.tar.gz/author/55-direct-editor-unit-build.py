import os,json,pathlib,hashlib,subprocess,sys
out=pathlib.Path('/tmp/dandrum-lanes/evidence-trigger-native-gui');capture=json.loads((out/'54-exact-owner-rustc.json').read_text());original=capture['command'];command=[];externs={};i=0
while i<len(original):
 arg=original[i]
 if arg=='--crate-type':
  assert original[i+1]=='lib';command.append('--test');i+=2;continue
 if arg=='--out-dir':
  command += [arg,'/tmp/dandrum-lanes/cache-editor-guard/release/native-handler-unit'];i+=2;continue
 if arg=='--extern':
  name,path=original[i+1].split('=',1);meta=pathlib.Path(path);archive=meta.with_suffix('.rlib');assert archive.is_file()
  externs[name]={'metadata_path':str(meta),'metadata_sha256':hashlib.sha256(meta.read_bytes()).hexdigest(),'link_archive_path':str(archive),'link_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
  command += [arg,name+'='+str(archive)];i+=2;continue
 command.append(arg);i+=1
pathlib.Path('/tmp/dandrum-lanes/cache-editor-guard/release/native-handler-unit').mkdir(exist_ok=True)
session_keys=('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS')
build_environment={k:v for k,v in capture['environment'].items() if k not in session_keys}
env=os.environ.copy();env.update(build_environment);env.pop('RUSTC_WRAPPER',None)
for key in session_keys:env.pop(key,None)
label=sys.argv[1]
receipt={'captured_command':original,'test_command':command,'cwd':capture['cwd'],'environment':build_environment,'omitted_session_only_keys':[k for k in session_keys if k in capture['environment']],'differences':['--crate-type lib -> --test','--out-dir existing release/native-handler-unit','same compiled dependency unit .rmeta -> corresponding .rlib for executable linkage'],'externs':externs,'compiler':subprocess.check_output([command[0],'-Vv'],text=True),'graph_qualification':'Actual consumer combined adapter lock graph, not standalone editor lock graph; no dependency compilation or profile change.'}
(out/(label+'-compiler-binding.json')).write_text(json.dumps(receipt,indent=2))
run=subprocess.run(command,cwd=capture['cwd'],env=env)
receipt['exit']=run.returncode
elf=pathlib.Path('/tmp/dandrum-lanes/cache-editor-guard/release/native-handler-unit/dandrum_trigger_editor-5b7c2f7721a19d80')
if run.returncode==0:
 receipt.update(test_elf=str(elf),test_elf_sha256=hashlib.sha256(elf.read_bytes()).hexdigest(),test_dt_needed=subprocess.check_output(['readelf','-d',str(elf)],text=True))
(out/(label+'-compiler-binding.json')).write_text(json.dumps(receipt,indent=2))
raise SystemExit(run.returncode)
