#!/usr/bin/python3
import os,sys,json,pathlib
if '--crate-name' in sys.argv and sys.argv[sys.argv.index('--crate-name')+1]=='dandrum_trigger_editor':
 keys=[k for k in os.environ if k.startswith('CARGO_') or k in ('RUST_MIN_STACK','LD_LIBRARY_PATH','TMPDIR')]
 pathlib.Path('/tmp/dandrum-lanes/evidence-trigger-native-gui/54-exact-owner-rustc.json').write_text(json.dumps({'cwd':os.getcwd(),'command':sys.argv[1:],'environment':{k:os.environ[k] for k in sorted(keys)}},indent=2))
os.execv(sys.argv[1],sys.argv[1:])
