#!/usr/bin/env bash
set -euo pipefail
for owner in rust-engine instrument-session trigger-host clap-adapter; do
  cargo fmt --manifest-path "src/$owner/Cargo.toml" --check
done
cargo clippy --manifest-path src/trigger-host/Cargo.toml --all-targets --offline --locked -- -D warnings
cargo clippy --manifest-path src/instrument-session/Cargo.toml --all-targets --offline --locked -- -D warnings
cargo clippy --manifest-path src/clap-adapter/Cargo.toml --features trigger-editor --all-targets --offline --locked -- -D warnings
cargo build --manifest-path src/clap-adapter/Cargo.toml --features trigger --lib --offline --locked
fixture="$TMPDIR/copied-trigger"
mkdir -p "$fixture/DandrumTrigger.resources/instrument/assets"
cp "$CARGO_TARGET_DIR/debug/libdandrum_clap_adapter.so" "$fixture/DandrumTrigger.clap"
cp examples/patches/advanced-drum-kit.yaml "$fixture/DandrumTrigger.resources/instrument/advanced-drum-kit.yaml"
cp examples/patches/assets/advanced-drums.wav "$fixture/DandrumTrigger.resources/instrument/assets/advanced-drums.wav"
sha256sum "$fixture/DandrumTrigger.clap"
export DANDRUM_TRIGGER_CLAP_PLUGIN_PATH="$fixture/DandrumTrigger.clap"
cargo test --manifest-path src/clap-adapter/Cargo.toml --features trigger --test trigger_dynamic --offline --locked
openspec validate add-juce-free-trigger-beta-products --strict
scripts/check-spec-coverage
git diff --check
