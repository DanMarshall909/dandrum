#!/usr/bin/env bash
set -euo pipefail
cargo build --manifest-path src/clap-adapter/Cargo.toml --features trigger --lib --offline --locked
fixture="$TMPDIR/copied-trigger"
mkdir -p "$fixture/DandrumTrigger.resources/instrument/assets"
cp "$CARGO_TARGET_DIR/debug/libdandrum_clap_adapter.so" "$fixture/DandrumTrigger.clap"
cp examples/patches/advanced-drum-kit.yaml "$fixture/DandrumTrigger.resources/instrument/advanced-drum-kit.yaml"
cp examples/patches/assets/advanced-drums.wav "$fixture/DandrumTrigger.resources/instrument/assets/advanced-drums.wav"
sha256sum "$fixture/DandrumTrigger.clap" "$fixture/DandrumTrigger.resources/instrument/advanced-drum-kit.yaml" "$fixture/DandrumTrigger.resources/instrument/assets/advanced-drums.wav"
export DANDRUM_TRIGGER_CLAP_PLUGIN_PATH="$fixture/DandrumTrigger.clap"
cargo test --manifest-path src/clap-adapter/Cargo.toml --features trigger --test trigger_dynamic --offline --locked invalid_portable_metadata_is_refused_before_any_foreign_payload_read -- --exact --nocapture
