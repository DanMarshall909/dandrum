#!/usr/bin/env bash
set -euo pipefail
python3 /home/dan/code/dandrum/.git/codex/trigger-recovery-20261026/clap-portable-stream-coverage/measure.py
python3 /home/dan/code/dandrum/.git/codex/trigger-recovery-20261026/clap-portable-stream-coverage/extend-dynamic.py
