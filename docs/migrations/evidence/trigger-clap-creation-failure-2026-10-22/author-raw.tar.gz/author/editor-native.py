from pathlib import Path
import subprocess,sys,json,time
from exact import run_exact
out=Path('/tmp/dandrum-evidence/g3-creation-failure');elf=str(out/'dandrum_trigger_editor');names=[s[:-6] for s in subprocess.check_output([elf,'--list','--ignored'],text=True).splitlines() if s.endswith(': test')];assert len(names)==2;results=[]
for name in names:
 start=time.monotonic();code=run_exact(elf,name,True);results.append({'case':name,'exit':code,'seconds':time.monotonic()-start});(out/'editor-native-cases.json').write_text(json.dumps(results,indent=2))
 if code:sys.exit(code)
