from pathlib import Path
import subprocess,sys,json,time
from exact import run_exact
out=Path('/tmp/dandrum-evidence/g3-creation-failure');results=[]
for binary,count in [('dandrum_clap_adapter',13),('dandrum_trigger_editor',4)]:
 elf=str(out/binary);all_names={s[:-6] for s in subprocess.check_output([elf,'--list'],text=True).splitlines() if s.endswith(': test')};ignored={s[:-6] for s in subprocess.check_output([elf,'--list','--ignored'],text=True).splitlines() if s.endswith(': test')};names=sorted(all_names-ignored);assert len(names)==count
 for name in names:
  start=time.monotonic();code=run_exact(elf,name,False);results.append({'binary':binary,'case':name,'exit':code,'seconds':time.monotonic()-start});(out/'owner-fast-cases.json').write_text(json.dumps(results,indent=2))
  if code:sys.exit(code)
