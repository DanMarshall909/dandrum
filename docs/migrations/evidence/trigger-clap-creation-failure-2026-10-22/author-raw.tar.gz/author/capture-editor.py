from pathlib import Path
import os,sys,subprocess,hashlib,json,signal
out=Path('/tmp/dandrum-evidence/g3-creation-failure');p=Path('/tmp/dandrum-lanes/runtime/src/trigger-editor/src/native_x11.rs');stat=p.stat();before=hashlib.sha256(p.read_bytes()).hexdigest()
def interrupted(*args):raise InterruptedError('resource guard interrupted capture')
signal.signal(signal.SIGTERM,interrupted)
command=['/home/dan/.cargo/bin/cargo','build','--release','--manifest-path','src/clap-adapter/Cargo.toml','--features','trigger-editor','--lib','--offline','--locked','--message-format=json']
env=dict(os.environ,RUSTC_WRAPPER=str(out/'capture.py'))
receipt={'path':str(p),'before_sha256':before,'original_atime_ns':stat.st_atime_ns,'original_mtime_ns':stat.st_mtime_ns,'original_mode':stat.st_mode,'command':command}
try:
 os.utime(p,None)
 r=subprocess.run(command,env=env);receipt['exit']=r.returncode
finally:
 os.utime(p,ns=(stat.st_atime_ns,stat.st_mtime_ns));after=p.stat();receipt.update(after_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),restored_mtime_ns=after.st_mtime_ns,restored_atime_ns=after.st_atime_ns,restored_mode=after.st_mode)
 (out/'editor-metadata-refresh.json').write_text(json.dumps(receipt,indent=2))
 assert receipt['after_sha256']==before and after.st_mtime_ns==stat.st_mtime_ns and after.st_mode==stat.st_mode
sys.exit(r.returncode)
