from pathlib import Path
import hashlib,json,sys,shutil
out=Path('/tmp/dandrum-evidence/g3-creation-failure')
label=sys.argv[1]; records=[json.loads(s) for s in (out/(label+'.stdout.log')).read_text().splitlines() if s.startswith('{')]; records=[r for r in records if r.get('reason')=='compiler-artifact']
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
libs={f for r in records if r['target']['name']=='dandrum_clap_adapter' and not r['profile']['test'] for f in r['filenames'] if f.endswith('.so')};assert len(libs)==1,libs
library=Path(libs.pop());dest=out/'installed';dest.mkdir(exist_ok=True);shutil.copy2(library,dest/'DandrumTrigger.clap')
tests={r['executable'] for r in records if r['target']['name']=='trigger_parameters' and r.get('executable')}
if tests:
 assert len(tests)==1; test=Path(tests.pop());shutil.copy2(test,out/'trigger_parameters');test_binding={'source':str(test),'copy':str(out/'trigger_parameters'),'sha256':h(test)}
else:test_binding=None
binding={'library':{'source':str(library),'copy':str(dest/'DandrumTrigger.clap'),'sha256':h(library)},'test':test_binding,'cargo_log_sha256':h(out/(label+'.stdout.log'))}
(out/(label+'-binding.json')).write_text(json.dumps(binding,indent=2));print(json.dumps(binding))
