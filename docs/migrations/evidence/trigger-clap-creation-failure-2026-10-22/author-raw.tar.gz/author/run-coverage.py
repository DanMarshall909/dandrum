from pathlib import Path
import json,sys,os,shutil,subprocess,hashlib
out=Path('/tmp/dandrum-evidence/g3-creation-failure');root=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g3-creation-failure');dest=out/'installed/DandrumTrigger.clap';dso=root/'dso-final/libdandrum_clap_adapter.so';tests=[p for p in (root/'test').glob('trigger_parameters-*') if p.is_file() and not p.suffix];assert len(tests)==1
profiles=root/'final-profiles';profiles.mkdir(exist_ok=False)
normal=json.loads((out/'ordinary-product-build-binding.json').read_text())['library'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert h(normal['source'])==normal['sha256'];env=dict(os.environ,LLVM_PROFILE_FILE=str(profiles/'%m-%p.profraw'));assert 'RUST_MIN_STACK' not in env and 'LD_PRELOAD' not in env
command=[str(tests[0]),'--exact','creation_failure_native::copied_native_ipc_registration_failure_cleans_up_and_retries_preserving_state','--ignored','--nocapture'];receipt={'command':command,'profile_pattern':env['LLVM_PROFILE_FILE'],'test':str(tests[0]),'test_sha256':h(tests[0]),'instrumented_dso':str(dso),'dso_sha256':h(dso),'ordinary_dso':normal}
try:
 shutil.copy2(dso,dest);receipt['copy_sha256']=h(dest);r=subprocess.run(command,env=env,timeout=60);receipt['exit']=r.returncode
finally:
 shutil.copy2(normal['source'],dest);receipt['restored_sha256']=h(dest);receipt['profiles']={str(p):h(p) for p in profiles.glob('*.profraw')};(out/'final-coverage-execution-binding.json').write_text(json.dumps(receipt,indent=2));assert h(dest)==normal['sha256']
sys.exit(r.returncode)
