"""One-off installed-library signal query; creates no widget/display/application."""
from pathlib import Path
import ctypes as c,ctypes.util,hashlib,json,time
start=time.monotonic()
g=c.CDLL(ctypes.util.find_library('gobject-2.0'));gtk=c.CDLL(ctypes.util.find_library('gtk-3'))
class Query(c.Structure):
 _fields_=[('signal_id',c.c_uint),('signal_name',c.c_char_p),('itype',c.c_size_t),('signal_flags',c.c_uint),('return_type',c.c_size_t),('n_params',c.c_uint),('param_types',c.POINTER(c.c_size_t))]
gtk.gtk_widget_get_type.argtypes=[];gtk.gtk_widget_get_type.restype=c.c_size_t
kind=gtk.gtk_widget_get_type();g.g_type_class_ref.argtypes=[c.c_size_t];g.g_type_class_ref.restype=c.c_void_p
owner=g.g_type_class_ref(kind);assert owner
try:
 g.g_signal_lookup.argtypes=[c.c_char_p,c.c_size_t];g.g_signal_lookup.restype=c.c_uint
 signal=g.g_signal_lookup(b'parent-set',kind);assert signal
 g.g_signal_query.argtypes=[c.c_uint,c.POINTER(Query)];q=Query();g.g_signal_query(signal,c.byref(q))
 assert q.signal_id==signal and q.signal_name==b'parent-set'
 assert not (q.signal_flags & (1<<6)), 'parent-set disallows emission hooks'
 Callback=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_uint,c.c_void_p,c.c_void_p)
 calls=[]
 @Callback
 def callback(hint,count,values,data):calls.append(count);return 1
 g.g_signal_add_emission_hook.argtypes=[c.c_uint,c.c_uint,Callback,c.c_void_p,c.c_void_p];g.g_signal_add_emission_hook.restype=c.c_ulong
 hook=g.g_signal_add_emission_hook(signal,0,callback,None,None);assert hook
 g.g_signal_remove_emission_hook.argtypes=[c.c_uint,c.c_ulong];g.g_signal_remove_emission_hook(signal,hook)
 assert not calls
 r=dict(signal=q.signal_name.decode(),signal_id=signal,flags=q.signal_flags,no_hooks_bit_set=False,hook_id=hook,hook_registration_and_removal='PASS',emissions_observed=0,scope='Installed GTK/GObject query and temporary hook registration only; no widget, WebKit, display, app or actual plugin failure injection. Does not qualify emission timing or cleanup.',seconds=time.monotonic()-start,header_sha256=hashlib.sha256(Path('/usr/include/glib-2.0/gobject/gsignal.h').read_bytes()).hexdigest())
 Path('/tmp/dandrum-evidence/g3-native-note-readiness/parent-set-query.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
finally:
 g.g_type_class_unref.argtypes=[c.c_void_p];g.g_type_class_unref(owner)
