"""One-off fresh-manager API calibration; no WebView/window/plugin/display."""
from pathlib import Path
import ctypes as c,ctypes.util,json,resource,time
resource.setrlimit(resource.RLIMIT_CORE,(0,0));start=time.monotonic()
g=c.CDLL(ctypes.util.find_library('gobject-2.0'));glib=c.CDLL(ctypes.util.find_library('glib-2.0'));w=c.CDLL(ctypes.util.find_library('webkit2gtk-4.1'))
w.webkit_user_content_manager_new.argtypes=[];w.webkit_user_content_manager_new.restype=c.c_void_p
manager=w.webkit_user_content_manager_new();assert manager
try:
 w.webkit_user_content_manager_get_type.argtypes=[];w.webkit_user_content_manager_get_type.restype=c.c_size_t
 g.g_signal_lookup.argtypes=[c.c_char_p,c.c_size_t];g.g_signal_lookup.restype=c.c_uint
 signal=g.g_signal_lookup(b'script-message-received',w.webkit_user_content_manager_get_type());assert signal
 glib.g_quark_from_string.argtypes=[c.c_char_p];glib.g_quark_from_string.restype=c.c_uint;detail=glib.g_quark_from_string(b'ipc')
 g.g_signal_has_handler_pending.argtypes=[c.c_void_p,c.c_uint,c.c_uint,c.c_int];g.g_signal_has_handler_pending.restype=c.c_int
 pending=lambda:bool(g.g_signal_has_handler_pending(manager,signal,0,1))
 specific=lambda:bool(g.g_signal_has_handler_pending(manager,signal,detail,1))
 before=pending();assert before is False
 Callback=c.CFUNCTYPE(None,c.c_void_p,c.c_void_p,c.c_void_p)
 calls=[]
 @Callback
 def callback(obj,result,data):calls.append(True)
 g.g_signal_connect_data.argtypes=[c.c_void_p,c.c_char_p,Callback,c.c_void_p,c.c_void_p,c.c_uint];g.g_signal_connect_data.restype=c.c_ulong
 handler=g.g_signal_connect_data(manager,b'script-message-received',callback,None,None,0);assert handler
 connected=pending();specific_connected=specific();assert connected and not specific_connected
 w.webkit_user_content_manager_register_script_message_handler.argtypes=[c.c_void_p,c.c_char_p];w.webkit_user_content_manager_register_script_message_handler.restype=c.c_int
 first=bool(w.webkit_user_content_manager_register_script_message_handler(manager,b'ipc'));second=bool(w.webkit_user_content_manager_register_script_message_handler(manager,b'ipc'))
 assert first and not second
 g.g_signal_handler_disconnect.argtypes=[c.c_void_p,c.c_ulong];g.g_signal_handler_disconnect(manager,handler)
 after=pending();assert after is False and not calls
 r=dict(command=['python3','/tmp/dandrum-evidence/g3-native-note-readiness/query-ipc-handler.py'],signal_id=signal,detail=detail,before_pending=before,connected_generic_pending_any_detail=connected,connected_generic_pending_for_ipc=specific_connected,after_disconnect_pending=after,first_registration=first,duplicate_registration=second,callbacks_observed=len(calls),seconds=time.monotonic()-start,scope='Installed fresh UserContentManager only, no WebView/window/plugin/display. Calibrates generic-handler matching with detail0 (nonzero ipc detail misses it) and duplicate registration; actual Wry-manager injection/cleanup remains unexecuted.')
 Path('/tmp/dandrum-evidence/g3-native-note-readiness/ipc-handler-query.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
finally:
 g.g_object_unref.argtypes=[c.c_void_p];g.g_object_unref(manager)
