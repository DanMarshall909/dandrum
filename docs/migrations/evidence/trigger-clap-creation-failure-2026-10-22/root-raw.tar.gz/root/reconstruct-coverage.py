from pathlib import Path
import hashlib,json,subprocess,time
out=Path('/tmp/dandrum-evidence/g3-creation-native-fixture');author=Path('/tmp/dandrum-evidence/g3-creation-failure');root=Path('/tmp/dandrum-lanes/integration');assert (out/'author-release-admitted.json').is_file()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();b=json.loads((author/'final-coverage-binding.json').read_text())
for path,h in b['objects'].items():assert sha(Path(path))==h
for path,h in b['profiles'].items():assert sha(Path(path))==h
for i,tool in enumerate(('llvm-profdata','llvm-cov')):assert sha(Path(b['commands'][i][0]))==b['tool_sha256'][tool]
merge=list(b['commands'][0]);merge[merge.index('-o')+1]=str(out/'root-final.profdata');export=list(b['commands'][1]);export[-1]='--instr-profile='+str(out/'root-final.profdata');start=time.monotonic()
for label,cmd in [('merge',merge),('export',export)]:
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);(out/f'root-final-{label}.stderr.log').write_bytes(p.stderr);assert p.returncode==0
 if label=='export':(out/'root-final-raw-export.json').write_bytes(p.stdout)
original=author/'coverage/export.json';assert json.loads(original.read_text())==json.loads((out/'root-final-raw-export.json').read_text())
rows=[]
for f in json.loads(original.read_text())['data'][0]['functions']:
 suffix='src/clap-adapter/tests/internal/trigger_creation_failure_native.rs'
 wanted=any(x.endswith('/'+suffix) for x in f['filenames'])
 if not wanted:
  suffix='src/trigger-editor/src/native_x11.rs';wanted='create_initialized' in f['name'] and any(x.endswith('/'+suffix) for x in f['filenames'])
 if not wanted:
  suffix='src/clap-adapter/src/trigger/gui.rs';wanted=any(v in f['name'] for v in ('10set_parent','18cleanup_attachment')) and any(x.endswith('/'+suffix) for x in f['filenames'])
 if not wanted:continue
 regions=[r for r in f['regions'] if r[7]==0 and f['filenames'][r[5]].endswith('/'+suffix)]
 rows.append(dict(name=f['name'],source=suffix,source_sha256=sha(root/suffix),function_count=f['count'],source_regions=len(regions),positive_source_regions=sum(r[4]>0 for r in regions),zero_hit_spans=[r[:4] for r in regions if r[4]==0],ipc_failure_regions=[r for r in regions if suffix.endswith('native_x11.rs') and r[0] in (131,132)]))
assert rows and any(r['ipc_failure_regions'] and all(v[4]==1 for v in r['ipc_failure_regions']) for r in rows)
x=dict(binding_sha256=sha(author/'final-coverage-binding.json'),objects=b['objects'],profiles=b['profiles'],original_export_sha256=sha(original),regenerated_export_sha256=sha(out/'root-final-raw-export.json'),commands=[merge,export],exit=[0,0],seconds=time.monotonic()-start,functions=rows,scope='Independent fresh merge/export from rehashed exact tools,2 actual ELFs and2 raw profiles; parsed export equality. File-identified code regions only, IPC disconnection/failure return executed once and successful retry executes same constructor. Unhit existing generic error/closure and fixture-defense regions disclosed. No branch, whole-owner or universal callback-quiescence claim.')
(out/'root-final-coverage-assessment.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps([dict(name=r['name'],regions=r['source_regions'],positive=r['positive_source_regions'],failure_regions=r['ipc_failure_regions']) for r in rows]))
