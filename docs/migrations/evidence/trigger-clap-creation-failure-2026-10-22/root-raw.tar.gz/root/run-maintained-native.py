"""One-off root checkpoint; execute only after the author returns all cache loans."""
import argparse, hashlib, json, os, resource, shutil, signal, subprocess, time
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--caches-returned',action='store_true');args=parser.parse_args();assert args.caches_returned
assert Path('/tmp/dandrum-evidence/g3-creation-native-fixture/author-release-admitted.json').is_file()
root=Path('/tmp/dandrum-lanes/runtime');out=Path('/tmp/dandrum-evidence/g3-creation-native-fixture');build=out/'native-build';bundle=Path('/tmp/dandrum-lanes/evidence-trigger-native-gui/current-native-build')
cache=Path('/tmp/dandrum-lanes/cache-editor-guard');resource.setrlimit(resource.RLIMIT_CORE,(0,0));build.mkdir(exist_ok=True)
target=build/'rust-target'
if not target.exists():target.symlink_to(cache,target_is_directory=True)
assert target.is_symlink() and target.resolve()==cache
paths=['CMakeLists.txt','README.md','docs/migrations/juce-free-clap-dependencies.json','openspec/changes/add-juce-free-trigger-clap-editor/design.md','scripts/prepare-trigger-clap-native.py','tests/python/test_engine_only_build.py','tests/python/test_trigger_native_fixture.py','src/clap-adapter/Cargo.toml','src/clap-adapter/Cargo.lock','src/clap-adapter/src/trigger.rs','src/clap-adapter/src/trigger/gui.rs','src/clap-adapter/src/trigger/automation.rs','src/clap-adapter/tests/trigger_gui.rs','src/clap-adapter/tests/trigger_parameters.rs','src/clap-adapter/tests/internal/trigger_gui_dispatch.rs','src/clap-adapter/tests/internal/trigger_timer.rs','src/trigger-host/src/protocol.rs','src/clap-adapter/tests/internal/trigger_structural_native.rs','src/clap-adapter/tests/internal/trigger_note_native.rs','src/clap-adapter/tests/internal/trigger_creation_failure_native.rs']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():return {p:sha(root/p) for p in paths}
def resources():
 memory={line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if len(line.split())>=2 and line.split()[1].isdigit()}
 return {'disk_free_bytes':shutil.disk_usage('/tmp').free,'memory_available_bytes':memory['MemAvailable']}
def sufficient(r):return r['disk_free_bytes']>1024**3 and r['memory_available_bytes']>4*1024**3
env=dict(os.environ,DISPLAY=':10.0',GDK_BACKEND='x11',XAUTHORITY='/home/dan/.Xauthority',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='1',TMPDIR=str(out/'tmp'))
Path(env['TMPDIR']).mkdir(exist_ok=True)
for key in ('LD_PRELOAD','RUST_MIN_STACK','RUSTFLAGS','LLVM_PROFILE_FILE','RUSTC_WRAPPER','CARGO_ENCODED_RUSTFLAGS'):env.pop(key,None)
def run(name,command):
 before=resources();assert sufficient(before),before
 source=sources();start=time.monotonic();stopped=None
 with (out/(name+'.stdout.log')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:
  child=subprocess.Popen(command,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  while child.poll() is None:
   current=resources()
   if not sufficient(current) or time.monotonic()-start>2500:
    stopped='resource floor' if not sufficient(current) else 'outer timeout';os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    break
   time.sleep(.25)
 r={'command':command,'cwd':str(root),'environment':{k:env[k] for k in ('DISPLAY','GDK_BACKEND','XAUTHORITY','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','TMPDIR')},'source_sha256':source,'exit':child.returncode,'seconds':time.monotonic()-start,'resource_before':before,'resource_after':resources(),'stop_reason':stopped,'owned_process_group':child.pid}
 (out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(name,r['exit'],round(r['seconds'],3),flush=True)
 assert sources()==source,'source drift during checkpoint';assert r['exit']==0 and stopped is None,r
 return (out/(name+'.stdout.log')).read_text()
assert all(sha(root/p)==sha(Path('/tmp/dandrum-lanes/integration')/p) for p in paths), 'Runtime maintained inputs must match integrated candidate bytes'
assert sha(bundle/'app.js')=='4b9ce5a356fea5f22703f9046c77a80ac616c00242348a12fe81f58fe4f760f2'
run('root-native-configure',['cmake','-S',str(root),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DDANDRUM_ENGINE_ONLY=ON','-DDANDRUM_CLAP_PROOF=ON','-DDANDRUM_TRIGGER_CLAP_EDITOR=ON','-DDANDRUM_TRIGGER_EDITOR_NATIVE_X11=ON','-DDANDRUM_TRIGGER_EDITOR_BUNDLE_DIR='+str(bundle)])
run('root-native-stage',['cmake','--build',str(build),'--target','dandrum-trigger-resources','--parallel','2'])
text=run('root-native-inventory',['ctest','--test-dir',str(build),'--show-only=json-v1'])
inventory=json.loads(text);selected=[t for t in inventory['tests'] if t['name'].startswith('trigger-clap-native-')];assert len(selected)==25,len(selected)
text=run('root-native-maintained',['ctest','--test-dir',str(build),'--verbose','-R','^trigger-clap-native-'])
assert '100% tests passed, 0 tests failed out of 25' in text and 'running 0 tests' not in text
bindings={}
for fixture in ('trigger-clap-native-fixture','trigger-clap-parameters-fixture'):
 b=json.loads((build/fixture/'binding.json').read_text())
 for artifact in b['artifacts'].values():assert sha(Path(artifact['source']))==artifact['source_sha256']==artifact['copy_sha256']==sha(build/fixture/artifact['copy'])
 for p in bundle.rglob('*'):
  if p.is_file():assert sha(p)==sha(build/fixture/'DandrumTrigger.resources/editor'/p.relative_to(bundle))
 for rel,source in [('instrument/advanced-drum-kit.yaml','examples/patches/advanced-drum-kit.yaml'),('instrument/assets/advanced-drums.wav','examples/patches/assets/advanced-drums.wav')]:assert sha(root/source)==sha(build/fixture/'DandrumTrigger.resources'/rel)
 bindings[fixture]=b
(out/'root-actual-cargo-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
(out/'root-native-result.json').write_text(json.dumps({'ctests':25,'fast_driver_case':1,'native_rust_outer_cases':22,'nested_allocator_child':1,'expected_source_sha256':sources(),'bundle_app_sha256':sha(bundle/'app.js'),'scope':'Actual maintained fixtures and25 CTests, exact Cargo source/copy artifact and full editor/instrument resource hashes. Developer-only native injected creation-failure checkpoint; no whole-G3/task/full-beta readiness claim. Existing zero-filter guard calibration is reused; current all-case property assertions are separate configuration evidence.'},indent=2)+'\n')
