from pathlib import Path
import json,hashlib,sys
root=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g3-creation-native-fixture');phase=sys.argv[1];assert phase in ('test','implementation')
path='tests/python/test_engine_only_build.py' if phase=='test' else 'CMakeLists.txt';p=root/path;before=p.read_bytes();expected={'test':'ac5aaa2bc86f628d202b708f4e14bc1f722703210444eae8c299e9f205a9527e','implementation':'5789a0651208ed6b51b99051d437231ca94f981f359433a02e24f98b0644766d'}[phase];assert hashlib.sha256(before).hexdigest()==expected
s=before.decode();selector='creation_failure_native::copied_native_ipc_registration_failure_cleans_up_and_retries_preserving_state'
if phase=='test':
 old='            "trigger-clap-native-parameter-note-destroy":\n                "note_native::copied_native_destroy_releases_held_activity_once_and_reconnects",\n'
 new=old+f'            "trigger-clap-native-parameter-creation-failure":\n                "{selector}",\n';assert s.count(old)==1;s=s.replace(old,new)
else:
 old='                note-hold note-heartbeat note-expiry note-destroy)';new='                note-hold note-heartbeat note-expiry note-destroy creation-failure)';assert s.count(old)==1;s=s.replace(old,new)
 old='                note_native::copied_native_destroy_releases_held_activity_once_and_reconnects)';new='                note_native::copied_native_destroy_releases_held_activity_once_and_reconnects\n                '+selector+')';assert s.count(old)==1;s=s.replace(old,new)
assert not (out/(phase+'-before')).exists();(out/(phase+'-before')).write_bytes(before);p.write_text(s);r=dict(phase=phase,path=path,before_sha256=expected,after_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Root-owned Integration registration only; native author/caches still leased separately, no Runtime changes or builder launched.');(out/(phase+'-edit.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
