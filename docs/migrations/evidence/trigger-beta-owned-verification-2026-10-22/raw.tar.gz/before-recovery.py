#!/usr/bin/env python3
"""Run a Linux verification command with owned scratch and retained evidence."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import uuid


class RunError(Exception):
    """The requested lifecycle cannot safely proceed."""


def allocated_bytes(root):
    return sum(path.lstat().st_blocks * 512 for path in [root, *root.rglob('*')])


def owned_workers(token):
    """Return pidfds only for live same-user workers carrying this run's marker."""
    marker = ('DANDRUM_VERIFICATION_TOKEN=' + token).encode()
    workers = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        fd = None
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            stat = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
            if stat[0] == 'Z' or marker not in (proc / 'environ').read_bytes().split(b'\0'):
                continue
            fd = os.pidfd_open(int(proc.name))
            current = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
            if current[19] == stat[19]:
                workers.append(({'pid': int(proc.name), 'start': stat[19]}, fd))
                fd = None
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            # Unrelated authentication processes can deny /proc access. Never
            # signal an unverified PID; this is an inherited-marker contract.
            continue
        finally:
            if fd is not None:
                os.close(fd)
    return workers


def stop_workers(token):
    stopped = {}
    for sig, seconds in ((signal.SIGTERM, 0.25), (signal.SIGKILL, 1.0)):
        deadline = time.monotonic() + seconds
        while True:
            workers = owned_workers(token)
            if not workers:
                return list(stopped.values())
            for identity, fd in workers:
                try:
                    signal.pidfd_send_signal(fd, sig)
                    stopped[(identity['pid'], identity['start'])] = identity
                except ProcessLookupError:
                    pass
                finally:
                    os.close(fd)
            if time.monotonic() >= deadline:
                break
            time.sleep(0.01)
    raise RunError('workers-still-running: scratch preserved')


def run(directory, command):
    directory = directory.absolute()
    try:
        directory.mkdir(mode=0o700)
    except FileExistsError as error:
        raise RunError(f"run-directory-exists: {directory}") from error
    scratch = directory / 'scratch'
    scratch.mkdir(mode=0o700)
    before = shutil.disk_usage(directory).free
    token = uuid.uuid4().hex
    command_exit = None
    launch_error = None
    cancelled = [None]

    def request_stop(signum, frame):
        cancelled[0] = signum

    previous = {sig: signal.signal(sig, request_stop) for sig in (signal.SIGINT, signal.SIGTERM)}
    try:
        with (directory / 'stdout.log').open('wb') as stdout, \
                (directory / 'stderr.log').open('wb') as stderr:
            try:
                process = subprocess.Popen(
                    command, env=dict(os.environ, TMPDIR=str(scratch),
                                      DANDRUM_VERIFICATION_TOKEN=token),
                    stdout=stdout, stderr=stderr, start_new_session=True)
                while process.poll() is None and cancelled[0] is None:
                    time.sleep(0.01)
                stopped = stop_workers(token)
                command_exit = process.wait(timeout=1)
            except OSError as error:
                launch_error = str(error)
                stopped = stop_workers(token)
                print(f'launch-failed: {error}', file=sys.stderr)
        allocated = allocated_bytes(scratch)
        shutil.rmtree(scratch)
        (directory / 'cleanup.json').write_text(json.dumps({
            'command_exit': command_exit, 'launch_error': launch_error,
            'cancel_signal': cancelled[0], 'stopped_workers': stopped,
            'scratch_removed': not scratch.exists(),
            'scratch_allocated_bytes': allocated, 'remaining_workers': [],
            'free_before_bytes': before, 'free_after_bytes': shutil.disk_usage(directory).free,
        }, indent=2) + '\n')
        if cancelled[0] is not None:
            return 128 + cancelled[0]
        return command_exit if command_exit is not None else 1
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    execute = sub.add_parser('run')
    execute.add_argument('--directory', type=Path, required=True)
    execute.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    if not command:
        parser.error('run requires a command')
    try:
        return run(args.directory, command)
    except (RunError, OSError) as error:
        print(f"owned-verification: {error}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
