#!/usr/bin/env python3
"""Run a Linux verification command with owned scratch and retained evidence."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid


class RunError(Exception):
    """The requested lifecycle cannot safely proceed."""


def allocated_bytes(root):
    return sum(path.lstat().st_blocks * 512 for path in [root, *root.rglob('*')])


def owned_workers(token):
    """Return pidfds only for live same-user workers carrying this run's marker."""
    marker = ('DANDRUM_VERIFICATION_TOKEN=' + token).encode()
    workers = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        fd = None
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            stat = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
            if stat[0] == 'Z' or marker not in (proc / 'environ').read_bytes().split(b'\0'):
                continue
            fd = os.pidfd_open(int(proc.name))
            current = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
            if current[19] == stat[19]:
                workers.append(({'pid': int(proc.name), 'start': stat[19]}, fd))
                fd = None
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            # Unrelated authentication processes can deny /proc access. Never
            # signal an unverified PID; this is an inherited-marker contract.
            continue
        finally:
            if fd is not None:
                os.close(fd)
    return workers


def stop_workers(token):
    stopped = {}
    for sig, seconds in ((signal.SIGTERM, 0.25), (signal.SIGKILL, 1.0)):
        deadline = time.monotonic() + seconds
        while True:
            workers = owned_workers(token)
            if not workers:
                return list(stopped.values())
            for identity, fd in workers:
                try:
                    signal.pidfd_send_signal(fd, sig)
                    stopped[(identity['pid'], identity['start'])] = identity
                except ProcessLookupError:
                    pass
                finally:
                    os.close(fd)
            if time.monotonic() >= deadline:
                break
            time.sleep(0.01)
    raise RunError('workers-still-running: scratch preserved')


def file_identity(path):
    stat = path.lstat()
    return [stat.st_dev, stat.st_ino]


def context():
    return {'uid': os.getuid(),
            'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
            'pid_namespace': os.readlink('/proc/self/ns/pid')}


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    with temporary.open('w') as output:
        output.write(json.dumps(value, indent=2) + '\n')
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary, path)


def validate_owner(directory):
    owner_path = directory / 'owner.json'
    checksum_path = directory / 'owner.sha256'
    if (directory.is_symlink() or owner_path.is_symlink() or checksum_path.is_symlink()
            or (directory / 'lock').is_symlink()):
        raise RunError('owner-path: refusing a symlink')
    raw = owner_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != checksum_path.read_text().strip():
        raise RunError('owner-checksum: ownership record changed')
    try:
        owner = json.loads(raw)
    except ValueError as error:
        raise RunError('owner-invalid: malformed record') from error
    if (not isinstance(owner, dict) or owner.get('schema') != 1
            or owner.get('owner') != 'run-owned-verification.py'
            or owner.get('directory') != str(directory)
            or owner.get('directory_identity') != file_identity(directory)
            or not isinstance(owner.get('token'), str)
            or re.fullmatch('[0-9a-f]{32}', owner['token']) is None):
        raise RunError('owner-invalid: unrecognized run identity')
    if any(owner.get(key) != value for key, value in context().items()):
        raise RunError('owner-context: recovery requires the same user, boot and PID namespace')
    scratch = directory / 'scratch'
    if os.path.lexists(scratch):
        if scratch.is_symlink() or file_identity(scratch) != owner.get('scratch_identity'):
            raise RunError('scratch-identity: replaced scratch is preserved')
    else:
        progress = directory / 'progress.json'
        if not progress.is_file() or json.loads(progress.read_text()).get('phase') != 'removing':
            raise RunError('scratch-identity: unrecorded missing scratch')
    return owner


def lock_run(lock):
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as error:
        raise RunError('run-active: controller or recovery still holds the run') from error


def finish(directory, owner, command_exit, launch_error, cancelled, stopped, recovered):
    validate_owner(directory)
    scratch = directory / 'scratch'
    if scratch.exists():
        allocated = allocated_bytes(scratch)
    else:
        allocated = json.loads((directory / 'progress.json').read_text())['scratch_allocated_bytes']
    receipt = {'command_exit': command_exit, 'launch_error': launch_error,
               'cancel_signal': cancelled, 'stopped_workers': stopped,
               'scratch_removed': True, 'scratch_allocated_bytes': allocated,
               'remaining_workers': [], 'recovered': recovered,
               'free_before_bytes': owner['free_before_bytes']}
    # Persist the deletion transition before unlinking; recovery may complete
    # this phase if the controller dies between removal and its final receipt.
    write_json(directory / 'progress.json', {**receipt, 'phase': 'removing'})
    if scratch.exists():
        shutil.rmtree(scratch)
    receipt['free_after_bytes'] = shutil.disk_usage(directory).free
    write_json(directory / 'cleanup.json', receipt)


def run(directory, command):
    directory = directory.absolute()
    try:
        directory.mkdir(mode=0o700)
    except FileExistsError as error:
        raise RunError(f'run-directory-exists: {directory}') from error
    directory = directory.resolve()
    with (directory / 'lock').open('xb') as lock:
        lock_run(lock)
        scratch = directory / 'scratch'
        scratch.mkdir(mode=0o700)
        owner = {'schema': 1, 'owner': 'run-owned-verification.py',
                 'directory': str(directory), 'directory_identity': file_identity(directory),
                 'scratch_identity': file_identity(scratch), 'token': uuid.uuid4().hex,
                 'command': command, 'cwd': os.getcwd(), **context(),
                 'free_before_bytes': shutil.disk_usage(directory).free}
        write_json(directory / 'owner.json', owner)
        (directory / 'owner.sha256').write_text(
            hashlib.sha256((directory / 'owner.json').read_bytes()).hexdigest() + '\n')
        command_exit = None
        launch_error = None
        cancelled = [None]

        def request_stop(signum, frame):
            cancelled[0] = signum

        previous = {sig: signal.signal(sig, request_stop) for sig in (signal.SIGINT, signal.SIGTERM)}
        try:
            with (directory / 'stdout.log').open('wb') as stdout, \
                    (directory / 'stderr.log').open('wb') as stderr:
                try:
                    process = subprocess.Popen(
                        command, env=dict(os.environ, TMPDIR=str(scratch),
                                          DANDRUM_VERIFICATION_TOKEN=owner['token']),
                        stdout=stdout, stderr=stderr, start_new_session=True)
                    while process.poll() is None and cancelled[0] is None:
                        time.sleep(0.01)
                    validate_owner(directory)
                    stopped = stop_workers(owner['token'])
                    command_exit = process.wait(timeout=1)
                except OSError as error:
                    launch_error = str(error)
                    stopped = stop_workers(owner['token'])
                    print(f'launch-failed: {error}', file=sys.stderr)
            finish(directory, owner, command_exit, launch_error, cancelled[0], stopped, False)
            if cancelled[0] is not None:
                return 128 + cancelled[0]
            return command_exit if command_exit is not None else 1
        finally:
            for sig, handler in previous.items():
                signal.signal(sig, handler)


def recover(directory):
    directory = directory.absolute()
    owner = validate_owner(directory)
    with (directory / 'lock').open('rb') as lock:
        lock_run(lock)
        owner = validate_owner(directory)
        if (directory / 'cleanup.json').is_file() and not (directory / 'scratch').exists():
            return 0
        stopped = stop_workers(owner['token'])
        finish(directory, owner, None, None, None, stopped, True)
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    execute = sub.add_parser('run')
    execute.add_argument('--directory', type=Path, required=True)
    execute.add_argument('command', nargs=argparse.REMAINDER)
    recovery = sub.add_parser('recover')
    recovery.add_argument('--directory', type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.operation == 'recover':
            return recover(args.directory)
        command = args.command[1:] if args.command[:1] == ['--'] else args.command
        if not command:
            parser.error('run requires a command')
        return run(args.directory, command)
    except (RunError, OSError, ValueError) as error:
        print(f'owned-verification: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
