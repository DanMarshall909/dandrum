import importlib.util,json,pathlib,sys,time,unittest
spec=importlib.util.spec_from_file_location('owned_tests',sys.argv[1]); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
timings={}
class Result(unittest.TextTestResult):
 def startTest(self,test):
  self.started=time.monotonic();super().startTest(test)
 def stopTest(self,test):
  timings[test.id()]=time.monotonic()-self.started;super().stopTest(test)
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(getattr(module,name)) for name in sys.argv[3:])
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
pathlib.Path(sys.argv[2]).write_text(json.dumps(timings,indent=2)+'\n')
sys.exit(not result.wasSuccessful())
