import os,sys
_target=os.environ["DANDRUM_TRACE_TARGET"]
_fd=os.open(os.environ["DANDRUM_TRACE_LOG"],os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
def _trace(frame,event,arg):
 if event=="line" and frame.f_code.co_filename==_target: os.write(_fd,(str(frame.f_lineno)+"\n").encode())
 return _trace
sys.settrace(_trace)
