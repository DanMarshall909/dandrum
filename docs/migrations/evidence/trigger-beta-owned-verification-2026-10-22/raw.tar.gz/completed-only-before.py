#!/usr/bin/env python3
"""Run a Linux verification command with owned scratch and retained evidence."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def allocated_bytes(root):
    return sum(path.lstat().st_blocks * 512 for path in [root, *root.rglob('*')])


def run(directory, command):
    directory = directory.absolute()
    directory.mkdir(mode=0o700)
    scratch = directory / 'scratch'
    scratch.mkdir(mode=0o700)
    before = shutil.disk_usage(directory).free
    with (directory / 'stdout.log').open('wb') as stdout, \
            (directory / 'stderr.log').open('wb') as stderr:
        result = subprocess.run(command, env=dict(os.environ, TMPDIR=str(scratch)),
                                stdout=stdout, stderr=stderr)
    allocated = allocated_bytes(scratch)
    shutil.rmtree(scratch)
    (directory / 'cleanup.json').write_text(json.dumps({
        'command_exit': result.returncode, 'scratch_removed': not scratch.exists(),
        'scratch_allocated_bytes': allocated, 'remaining_workers': [],
        'free_before_bytes': before, 'free_after_bytes': shutil.disk_usage(directory).free,
    }, indent=2) + '\n')
    return result.returncode


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    execute = sub.add_parser('run')
    execute.add_argument('--directory', type=Path, required=True)
    execute.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    if not command:
        parser.error('run requires a command')
    return run(args.directory, command)


if __name__ == '__main__':
    raise SystemExit(main())
