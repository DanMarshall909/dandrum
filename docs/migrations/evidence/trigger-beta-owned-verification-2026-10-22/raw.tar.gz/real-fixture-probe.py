import json,os,pathlib,sys,unittest
sys.path.insert(0,sys.argv[1])
import test_engine_only_build as fixture
fixture.CMAKE='/home/dan/.local/bin/cmake'
fixture.CTEST='/home/dan/.local/bin/ctest'
class Probe(fixture.EngineBuildFixture):
 def test_contract(self):
  self.assertEqual(self.source.parent.parent,pathlib.Path(os.environ['DANDRUM_VERIFICATION_SCRATCH']))
  self.assertFalse((self.source/'third_party').exists())
  self.assertFalse((self.source/'web').exists())
  self.assertTrue((self.source/'.githooks/pre-push').is_file())
  self.assertEqual(self.cargo_target,fixture.ROOT/'build/engine-only-regression/cargo-target')
  self.assertFalse(self.cargo_target.is_relative_to(self.fixture_root))
  build,code,output=self.configure('owned-cleanup-contract', '-DDANDRUM_ENGINE_ONLY=ON')
  self.assertEqual(code,0,output)
  cache=(build/'CMakeCache.txt').read_text()
  self.assertNotIn('DANDRUM_NODE_EXECUTABLE:',cache)
  self.assertEqual((build/'rust-target').resolve(),self.cargo_target.resolve())
  code,output=self.command('owned-cleanup-contract-inventory',[fixture.CTEST,'--test-dir',str(build),'--show-only=json-v1'])
  self.assertEqual(code,0,output)
  names={t['name'] for t in json.loads(output)['tests']}
  self.assertTrue({'mutation-hook','engine-build-fixture-cleanup','owned-verification-fast','owned-verification-slow'}.issubset(names))
  code,output=self.command('owned-cleanup-contract-checks',[fixture.CTEST,'--test-dir',str(build),'--no-tests=error','--output-on-failure','-R','^(mutation-hook|engine-build-fixture-cleanup)$'])
  self.assertEqual(code,0,output)
  self.assertIn('100% tests passed',output)
  _,code,output=self.configure('owned-cleanup-contract-reject','-DDANDRUM_ENGINE_ONLY=ON','-DDANDRUM_NATIVE_ONLY=ON')
  self.assertNotEqual(code,0,output)
  self.assertIn('DANDRUM_ENGINE_ONLY cannot be combined with DANDRUM_NATIVE_ONLY',' '.join(output.split()))
  print(json.dumps({'source':str(self.source),'target':str(self.cargo_target),'source_free':True,'configured_tests':sorted(names)}))
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Probe))
sys.exit(not result.wasSuccessful())
