from pathlib import Path
import hashlib,json,tarfile
out=Path(__file__).parent;root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');dest=root/'docs/migrations/evidence/trigger-native-pending-recovery-2026-10-29';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();members={}
def add(p,name=None):
 p=Path(p);assert p.is_file() and not p.is_symlink();key=name or str(p.relative_to(out));assert key not in members;members[key]=p
for name in ['recovery-native-correlated-red-run','recovery-native-correlated-red-configured-run','recovery-native-current-green-run','recovery-native-full-run','recovery-official-run','recovery-source-free-run','recovery-final-spec-run']:
 directory=out/name;r=json.loads((directory/'cleanup.json').read_text());assert r['scratch_removed'] and not r['remaining_workers'],name
 for p in sorted(directory.iterdir()):
  if p.is_file():add(p)
for p in sorted((out.parent/'rb1').iterdir()):
 if p.is_file():add(p,'browser-rb1/'+p.name)
for p in sorted((out/'recovery-official').iterdir()):
 if p.is_file():add(p)
for name in ['recovery-native-correlated-red.json','recovery-native-final-replay.json','recovery-native-correlated-red-configured-x11.log','recovery-native-current-green-x11.log','recovery-native-full-x11.log','recovery-official-x11.log','validator-tooling.json','package-native-recovery.py']:add(out/name)
run=out/'recovery-source-free-run';start=(run/'owner.json').stat().st_mtime_ns;end=(run/'cleanup.json').stat().st_mtime_ns;logs=[]
for p in sorted((root/'build/engine-only-regression').glob('*.log')):
 if start<=p.stat().st_mtime_ns<=end:
  add(p,'source-free-command-logs/'+p.name);logs.append({'name':p.name,'sha256':sha(p),'mtime_ns':p.stat().st_mtime_ns})
assert logs
log_index=out/'recovery-source-free-command-logs.json';log_index.write_text(json.dumps({'run_start_ns':start,'run_end_ns':end,'logs':logs,'scope':'Only logs written during this sole owned source-free run; script/base/source overlay identify exact controlled commands. Older logs excluded, shared caches preserved.'},indent=2)+'\n');add(log_index)
paths=['CMakeLists.txt','src/clap-adapter/tests/internal/trigger_selection_native.rs']
for n in paths:add(root/n,'source/'+n)
red=json.loads((out/'recovery-native-correlated-red.json').read_text());assert all(sha(root/n)==red['source'][n] for n in paths),'native case changed between historical and current runs'
external=[]
for n in ['recovery-native-correlated-red-replay.tar.gz','recovery-native-final-replay.tar.gz']:
 p=out/n;external.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
dest.mkdir();index=[]
with tarfile.open(dest/'raw.tar.gz','x:gz',compresslevel=1) as tf:
 for name,p in sorted(members.items()):index.append({'path':name,'sha256':sha(p),'bytes':p.stat().st_size});tf.add(p,arcname=name,recursive=False)
with tarfile.open(dest/'raw.tar.gz') as tf:
 assert len(tf.getmembers())==len(index)
 for row in index:assert hashlib.sha256(tf.extractfile(row['path']).read()).hexdigest()==row['sha256']
digest=sha(dest/'raw.tar.gz');(dest/'raw-index.json').write_text(json.dumps({'archive_sha256':digest,'members':index},indent=2)+'\n')
(dest/'binding.json').write_text(json.dumps({'base':'ebba80a5597692ce45f39adc4260dfa09c508167','source':{n:sha(root/n) for n in paths},'raw_archive_sha256':digest,'external_replays':external,'current_product_sha256':'2fe7909da6f10b68291e6e18b18f1769d010866d6b359c5811e34231200fafdc','current_browser_sha256':'fdc851e369e1567cc5fe0a919f9b388f2d156249078af1ebb5beba697c3aeed8','scope':'Actual copiedReact/Wry/GTK selected-import lost-reply/full-recreation recovery under real capacity-one runtime backpressure. Automatic current-job polling, one publication/native history, signed PCM, Undo/Redo and independent instance. Historical6ac frontend calibration is correlated after implementation, not falsely dated before it.','checks':'278Node and types/components from unchanged ebba; current33native122.14s,newcase2.01s,14Chromium7.0s,9sourcefree203.235s,fmt/strictalltargetadapterClippy,active+52canonicalstrictspec/map631/392/239,currentunfilteredofficial34success10explicitSKIP0FAIL. Exact host-owner192+2doctests/2object2profileLLVM unchanged7b separately committed.','limits':'Component/acquisition and real synthetic-host callback proof, not physical input/device, uninterrupted selected-audio, installed/offline, namedDAW or portable-state acceptance. No task/scenario closure. Mutation excluded, VST3/standalone deferred. StrictengineClippy129unchangedbaselineFAIL explicit.'},indent=2)+'\n');print(json.dumps({'members':len(index),'source_free_logs':len(logs),'bytes':(dest/'raw.tar.gz').stat().st_size,'sha256':digest}))
