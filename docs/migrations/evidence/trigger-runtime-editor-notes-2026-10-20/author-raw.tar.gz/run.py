import os, sys, subprocess, time, json, pathlib, hashlib, shutil, signal
root=pathlib.Path('/tmp/dandrum-lanes/runtime'); evidence=pathlib.Path('/tmp/dandrum-lanes/evidence-runtime-notes')
phase=sys.argv[1]; command=sys.argv[2:]; dest=evidence/phase; dest.mkdir(exist_ok=False)
env=os.environ.copy(); cache='/tmp/dandrum-lanes/cache-host-snapshot-cov' if 'llvm-cov' in command else '/tmp/dandrum-lanes/cache-runtime'
env.update(CARGO_TARGET_DIR=cache,CARGO_LLVM_COV_TARGET_DIR='/tmp/dandrum-lanes/cache-host-snapshot-cov',CARGO_LLVM_COV_BUILD_DIR='/tmp/dandrum-lanes/cache-host-snapshot-cov',CARGO_BUILD_JOBS='2',TMPDIR='/tmp')
paths=['src/trigger-host/src/runtime.rs','src/trigger-host/tests/editor_notes.rs','src/trigger-host/tests/runtime.rs','src/trigger-host/tests/support/editor_notes.rs','src/trigger-host/Cargo.toml','src/trigger-host/Cargo.lock']
hashes={}
for name in paths:
 p=root/name
 if p.exists():
  data=p.read_bytes(); hashes[name]=hashlib.sha256(data).hexdigest(); saved=dest/name; saved.parent.mkdir(parents=True,exist_ok=True); saved.write_bytes(data)
def resource():
 mem={line.split(':')[0]:int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines()}
 return dict(disk=shutil.disk_usage('/tmp').free,ramfs=shutil.disk_usage('/dev/shm').free,memory=mem['MemAvailable'])
start=time.monotonic(); samples=[resource()]; reason=None
if samples[0]['disk']<1024**3 or samples[0]['ramfs']<256*1024**2 or samples[0]['memory']<4*1024**3:
 raise SystemExit('Resource floor before launch '+str(samples[0]))
with (dest/'output.log').open('w') as log:
 proc=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll() is None:
  time.sleep(.5); sample=resource(); samples.append(sample)
  if sample['disk']<1024**3 or sample['ramfs']<256*1024**2 or sample['memory']<4*1024**3:
   reason='resource floor'; os.killpg(proc.pid,signal.SIGTERM); proc.wait(); break
 result=dict(command=command,cwd=str(root),environment={k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','CARGO_BUILD_JOBS','TMPDIR')},source_hashes=hashes,exit=proc.returncode,duration_seconds=time.monotonic()-start,pid=proc.pid,resource_first=samples[0],resource_last=samples[-1],resource_min={k:min(s[k] for s in samples) for k in samples[0]},stop_reason=reason)
 (dest/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('exit','duration_seconds','resource_min','stop_reason')})); print((dest/'output.log').read_text()[-4000:]); sys.exit(proc.returncode)
