use dandrum_engine::patch::RenderSettings;
use dandrum_engine::preparation::{HostBuses, PreparationContext};
use dandrum_instrument_session::InstrumentSession;
use dandrum_trigger_host::TriggerHostConfiguration;
use dandrum_trigger_host::runtime::{
    ControlEvent, PreparedRuntime, RuntimeAudio, RuntimeControl, TimedEvent, runtime_handoff,
};

const FRAMES: usize = 16;
const PREFIX_L: [f32; 4] = [8191.0 / 32768.0, -0.5, 24575.0 / 32768.0, -0.25];
const PREFIX_R: [f32; 4] = [8191.0 / 65536.0, -0.25, 24575.0 / 65536.0, -0.125];
const TAIL: (f32, f32) = (-0.125, -0.0625);

struct Fixture {
    _directory: tempfile::TempDir,
    session: InstrumentSession,
}

impl Fixture {
    fn new(mode: &str, voices: usize) -> Self {
        let directory = tempfile::tempdir().unwrap();
        let mut left = vec![TAIL.0; 16_384];
        let mut right = vec![TAIL.0; 16_384];
        left[..4].copy_from_slice(&[0.25, -0.5, 0.75, -0.25]);
        right[..4].copy_from_slice(&[0.25, -0.5, 0.75, -0.25]);
        dandrum_engine::wav::write_wav_stereo_i16(
            std::fs::File::create(directory.path().join("hit.wav")).unwrap(),
            48_000,
            &left,
            &right,
        )
        .unwrap();
        let yaml = format!(
            r#"
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{{ id: body, start_frame: 0, end_frame: 16384 }}]
ports:
  - {{ name: master, direction: output, signal: audio, channels: 2, maps_from: voices.audio }}
module_definitions:
  - type: sample_voice
    ports:
      - {{ name: audio, direction: output, signal: audio, channels: 2, maps_from: player.audio }}
    modules:
      - {{ id: player, type: sample_player, static: {{ source: hit, region: body, channels: 2, mode: {mode} }}, defaults: {{ pan: -0.5 }} }}
    connections:
      - {{ from: voice.gate, to: player.trigger }}
      - {{ from: voice.gate, to: player.gate }}
modules:
  - {{ id: midi, type: midi_input }}
  - {{ id: voices, type: poly, static: {{ definition: sample_voice, max_voices: {voices}, allocation: reject-new }} }}
connections:
  - {{ from: midi.events, to: voices.notes }}
"#
        );
        let session = InstrumentSession::new_for_planar_host(
            &yaml,
            PreparationContext::new(directory.path(), 48_000),
            RenderSettings {
                sample_rate_hz: 48_000,
                block_size_frames: FRAMES as u32,
                duration_frames: FRAMES as u64,
            },
            HostBuses::new().with_output("master", 2),
        )
        .unwrap();
        Self {
            _directory: directory,
            session,
        }
    }

    fn runtime(&self, capacity: usize) -> (RuntimeControl, RuntimeAudio) {
        runtime_handoff(self.prepared(), capacity).unwrap()
    }

    fn prepared(&self) -> PreparedRuntime {
        PreparedRuntime::new(
            self.session.prepared(),
            TriggerHostConfiguration {
                sample_rate_hz: 48_000,
                max_block_frames: FRAMES as u32,
            },
        )
        .unwrap()
    }
}

fn on(note: u8, frame_offset: u32) -> TimedEvent {
    TimedEvent {
        frame_offset,
        event: ControlEvent::NoteOn {
            note,
            velocity: 100,
        },
    }
}
fn off(note: u8, frame_offset: u32) -> TimedEvent {
    TimedEvent {
        frame_offset,
        event: ControlEvent::NoteOff { note },
    }
}

fn render(audio: &mut RuntimeAudio, events: &[TimedEvent]) -> ([f32; FRAMES], [f32; FRAMES]) {
    let (mut left, mut right) = ([1.0; FRAMES], [1.0; FRAMES]);
    let allocations = allocation_counter::measure(|| {
        audio.process_events(&mut left, &mut right, events).unwrap();
    });
    assert_eq!(
        (
            allocations.count_total,
            allocations.count_current,
            allocations.bytes_current
        ),
        (0, 0, 0),
        "callback must neither allocate nor destroy ownership"
    );
    (left, right)
}

fn assert_tail(output: &([f32; FRAMES], [f32; FRAMES]), voices: usize) {
    assert_eq!(output.0, [TAIL.0 * voices as f32; FRAMES]);
    assert_eq!(output.1, [TAIL.1 * voices as f32; FRAMES]);
}

#[test]
fn signed_gated_child_releases_at_host_offset_but_one_shot_keeps_its_tail() {
    for mode in ["gated", "one_shot"] {
        let fixture = Fixture::new(mode, 4);
        let (_, mut audio) = fixture.runtime(4);
        let first = render(&mut audio, &[on(60, 0)]);
        assert_eq!(&first.0[..4], &PREFIX_L);
        assert_eq!(&first.1[..4], &PREFIX_R);
        assert_eq!(&first.0[4..], &[TAIL.0; 12]);
        assert_eq!(&first.1[4..], &[TAIL.1; 12]);
        assert_tail(&render(&mut audio, &[]), 1);
        let released = render(&mut audio, &[off(60, 7)]);
        assert_eq!(&released.0[..7], &[TAIL.0; 7]);
        assert_eq!(&released.1[..7], &[TAIL.1; 7]);
        let tail = if mode == "gated" { (0.0, 0.0) } else { TAIL };
        assert_eq!(&released.0[7..], &[tail.0; 9]);
        assert_eq!(&released.1[7..], &[tail.1; 9]);
        assert_tail(&render(&mut audio, &[]), usize::from(mode == "one_shot"));
    }
}

#[test]
fn detaching_editor_releases_its_gated_child_and_preserves_unrelated_host_note_across_threads() {
    let fixture = Fixture::new("gated", 4);
    let (mut control, mut audio) = fixture.runtime(4);
    let owner = std::num::NonZeroU64::new(17).unwrap();
    control.editor_note_on(owner, 60, 100).unwrap();
    let (output_tx, output_rx) = std::sync::mpsc::channel();
    let (continue_tx, continue_rx) = std::sync::mpsc::channel();
    let worker = std::thread::spawn(move || {
        output_tx.send(render(&mut audio, &[on(61, 0)])).unwrap();
        continue_rx.recv().unwrap();
        output_tx.send(render(&mut audio, &[])).unwrap();
        output_tx.send(render(&mut audio, &[off(61, 7)])).unwrap();
        audio // Return all graph ownership for destruction on control.
    });
    let first = output_rx.recv().unwrap();
    assert_eq!(&first.0[..4], &PREFIX_L.map(|value| value * 2.0));
    assert_eq!(&first.1[..4], &PREFIX_R.map(|value| value * 2.0));
    assert_eq!(&first.0[4..], &[TAIL.0 * 2.0; 12]);
    control.detach_editor_notes(owner);
    control.detach_editor_notes(owner);
    continue_tx.send(()).unwrap();
    let detached = output_rx.recv().unwrap();
    let host_released = output_rx.recv().unwrap();
    let audio = worker.join().unwrap();
    assert_tail(&detached, 1);
    assert_eq!(&host_released.0[..7], &[TAIL.0; 7]);
    assert_eq!(&host_released.1[..7], &[TAIL.1; 7]);
    assert_eq!(&host_released.0[7..], &[0.0; 9]);
    assert_eq!(&host_released.1[7..], &[0.0; 9]);
    drop(audio);
}

#[test]
fn rejected_editor_values_and_conflicting_owner_preserve_the_held_note() {
    use dandrum_trigger_host::runtime::RuntimeError;
    let fixture = Fixture::new("gated", 4);
    let (mut control, mut audio) = fixture.runtime(4);
    let owner = std::num::NonZeroU64::new(17).unwrap();
    let other = std::num::NonZeroU64::new(18).unwrap();
    control.editor_note_on(owner, 60, 100).unwrap();
    for (note, velocity) in [(128, 100), (60, 0), (60, 128)] {
        assert_eq!(
            control.editor_note_on(owner, note, velocity),
            Err(RuntimeError::InvalidEvent)
        );
    }
    assert_eq!(
        control.editor_note_on(other, 60, 100),
        Err(RuntimeError::EditorOwnerConflict)
    );
    assert_eq!(
        control.editor_note_off(owner, 128),
        Err(RuntimeError::InvalidEvent)
    );
    assert_eq!(
        control.editor_note_off(other, 60),
        Err(RuntimeError::EditorOwnerConflict)
    );
    control.detach_editor_notes(other);
    let first = render(&mut audio, &[]);
    assert_eq!(&first.0[..4], &PREFIX_L);
    assert_eq!(&first.1[..4], &PREFIX_R);
    assert_tail(&render(&mut audio, &[]), 1);
    control.editor_note_on(owner, 60, 100).unwrap();
    let retriggered = render(&mut audio, &[]);
    assert_eq!(&retriggered.0[..4], &PREFIX_L);
    assert_eq!(&retriggered.1[..4], &PREFIX_R);
    control.detach_editor_notes(owner);
    assert_tail(&render(&mut audio, &[]), 0);
}

#[test]
fn ordinary_unheard_tap_plays_once_but_detach_cancels_held_and_released_onsets() {
    let owner = std::num::NonZeroU64::new(17).unwrap();
    for mode in ["gated", "one_shot"] {
        let fixture = Fixture::new(mode, 4);
        for (release, detach) in [(true, false), (false, true), (true, true)] {
            let (mut control, mut audio) = fixture.runtime(4);
            control.editor_note_on(owner, 60, 100).unwrap();
            if release {
                control.editor_note_off(owner, 60).unwrap();
                control.editor_note_off(owner, 60).unwrap();
            }
            if detach {
                control.detach_editor_notes(owner);
            }
            let first = render(&mut audio, &[]);
            if detach {
                assert_tail(&first, 0);
            } else {
                assert_eq!(&first.0[..4], &PREFIX_L);
                assert_eq!(&first.1[..4], &PREFIX_R);
                assert_eq!(&first.0[4..], &[TAIL.0; 12]);
                assert_eq!(&first.1[4..], &[TAIL.1; 12]);
            }
            for _ in 0..3 {
                assert_tail(
                    &render(&mut audio, &[]),
                    usize::from(!detach && mode == "one_shot"),
                );
            }
        }
    }
}

#[test]
fn host_takes_over_editor_pitch_at_its_offset_and_editor_cleanup_cannot_release_host() {
    let fixture = Fixture::new("gated", 4);
    let (mut control, mut audio) = fixture.runtime(4);
    let owner = std::num::NonZeroU64::new(17).unwrap();
    control.editor_note_on(owner, 60, 100).unwrap();
    let first = render(&mut audio, &[]);
    assert_eq!(&first.0[..4], &PREFIX_L);
    let takeover = render(&mut audio, &[on(60, 5)]);
    assert_eq!(&takeover.0[..5], &[TAIL.0; 5]);
    assert_eq!(&takeover.1[..5], &[TAIL.1; 5]);
    assert_eq!(&takeover.0[5..9], &PREFIX_L);
    assert_eq!(&takeover.1[5..9], &PREFIX_R);
    assert_eq!(&takeover.0[9..], &[TAIL.0; 7]);
    assert_eq!(&takeover.1[9..], &[TAIL.1; 7]);
    control.editor_note_off(owner, 60).unwrap();
    control.detach_editor_notes(owner);
    assert_tail(&render(&mut audio, &[]), 1);
    let released = render(&mut audio, &[off(60, 7)]);
    assert_eq!(&released.0[..7], &[TAIL.0; 7]);
    assert_eq!(&released.1[..7], &[TAIL.1; 7]);
    assert_eq!(&released.0[7..], &[0.0; 9]);
    assert_eq!(&released.1[7..], &[0.0; 9]);
}

#[test]
fn host_held_and_touched_pitch_suppresses_editor_until_later_untouched_block() {
    let fixture = Fixture::new("gated", 4);
    let owner = std::num::NonZeroU64::new(17).unwrap();
    for keep_held in [true, false] {
        let (mut control, mut audio) = fixture.runtime(4);
        let first = render(&mut audio, &[on(60, 0)]);
        assert_eq!(&first.0[..4], &PREFIX_L);
        control.editor_note_on(owner, 60, 100).unwrap();
        if !keep_held {
            control.editor_note_off(owner, 60).unwrap();
        }
        assert_tail(&render(&mut audio, &[]), 1);
        let released = render(&mut audio, &[off(60, 7)]);
        assert_eq!(&released.0[..7], &[TAIL.0; 7]);
        assert_eq!(&released.1[..7], &[TAIL.1; 7]);
        assert_eq!(&released.0[7..], &[0.0; 9]);
        assert_eq!(&released.1[7..], &[0.0; 9]);
        let next = render(&mut audio, &[]);
        if keep_held {
            assert_eq!(&next.0[..4], &PREFIX_L);
            assert_eq!(&next.1[..4], &PREFIX_R);
        } else {
            assert_tail(&next, 0);
        }
        control.detach_editor_notes(owner);
        assert_tail(&render(&mut audio, &[]), 0);
    }
    let (mut control, mut audio) = fixture.runtime(4);
    control.editor_note_on(owner, 60, 100).unwrap();
    let touched = render(&mut audio, &[on(60, 3), off(60, 11)]);
    assert_eq!(&touched.0[..3], &[0.0; 3]);
    assert_eq!(&touched.1[..3], &[0.0; 3]);
    assert_eq!(&touched.0[3..7], &PREFIX_L);
    assert_eq!(&touched.1[3..7], &PREFIX_R);
    assert_eq!(&touched.0[7..11], &[TAIL.0; 4]);
    assert_eq!(&touched.1[7..11], &[TAIL.1; 4]);
    assert_eq!(&touched.0[11..], &[0.0; 5]);
    let resumed = render(&mut audio, &[]);
    assert_eq!(&resumed.0[..4], &PREFIX_L);
    assert_eq!(&resumed.1[..4], &PREFIX_R);
}

#[test]
fn stale_attachment_cleanup_cannot_cancel_new_owner_or_release_its_sounding_child() {
    use dandrum_trigger_host::runtime::RuntimeError;
    let fixture = Fixture::new("gated", 4);
    let old = std::num::NonZeroU64::new(17).unwrap();
    let new = std::num::NonZeroU64::new(18).unwrap();
    for heard in [false, true] {
        let (mut control, mut audio) = fixture.runtime(4);
        control.editor_note_on(old, 60, 100).unwrap();
        if heard {
            let first = render(&mut audio, &[]);
            assert_eq!(&first.0[..4], &PREFIX_L);
            assert_eq!(&first.1[..4], &PREFIX_R);
        }
        control.editor_note_off(old, 60).unwrap();
        control.editor_note_on(new, 60, 90).unwrap();
        control.detach_editor_notes(old);
        let replacement = render(&mut audio, &[]);
        assert_eq!(&replacement.0[..4], &PREFIX_L);
        assert_eq!(&replacement.1[..4], &PREFIX_R);
        assert_eq!(
            control.editor_note_off(old, 60),
            Err(RuntimeError::EditorOwnerConflict)
        );
        control.detach_editor_notes(old);
        assert_tail(&render(&mut audio, &[]), 1);
        control.detach_editor_notes(new);
        assert_tail(&render(&mut audio, &[]), 0);
    }
}

#[test]
fn saturation_fixture_calibrates_real_graph_capacity_and_sixty_four_gated_children() {
    let fixture = Fixture::new("gated", 128);
    let graph = dandrum_engine::graph_processor::RealtimeGraphProcessor::from_compiled_patch(
        fixture.session.prepared().compiled_patch().clone(),
        48_000.0,
        &dandrum_engine::PreparedSamplerAssets::empty(),
        FRAMES,
    );
    assert_eq!(graph.pending_event_capacity(), 128);
    let (_, mut audio) = fixture.runtime(64);
    let notes: Vec<_> = (0..64).map(|note| on(note, 0)).collect();
    let first = render(&mut audio, &notes);
    assert_eq!(&first.0[..4], &PREFIX_L.map(|value| value * 64.0));
    assert_eq!(&first.1[..4], &PREFIX_R.map(|value| value * 64.0));
    assert_tail(&render(&mut audio, &[]), 64);
    let releases: Vec<_> = (0..64).map(|note| off(note, 7)).collect();
    let released = render(&mut audio, &releases);
    assert_eq!(&released.0[..7], &[TAIL.0 * 64.0; 7]);
    assert_eq!(&released.1[..7], &[TAIL.1 * 64.0; 7]);
    assert_eq!(&released.0[7..], &[0.0; 9]);
    assert_eq!(&released.1[7..], &[0.0; 9]);
}
