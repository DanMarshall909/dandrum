import json, pathlib, re, hashlib, subprocess, shutil
base=pathlib.Path('/tmp/dandrum-lanes/evidence-runtime-notes'); root=pathlib.Path('/tmp/dandrum-lanes/runtime')
data=json.loads((base/'09-refactor-coverage.json').read_text())['data'][0]
source=root/'src/trigger-host/src/runtime.rs'; lines=source.read_text().splitlines(); cutoff=next(i+1 for i,line in enumerate(lines) if line=='#[cfg(test)]')
file=next(f for f in data['files'] if f['filename'].endswith('/src/trigger-host/src/runtime.rs'))
regions={}; functions={}; emitted=[]
for fn in data['functions']:
    own=[r for r in fn['regions'] if fn['filenames'][r[5]].endswith('/src/trigger-host/src/runtime.rs') and r[7]==0]
    if not own: continue
    first=own[0]
    if first[0]<cutoff:
        key=tuple(first[:4]);functions[key]=max(functions.get(key,0),fn['count']);emitted.append(fn['count'])
    for r in own:
        if r[0]<cutoff:
            key=tuple(r[:4]);regions[key]=max(regions.get(key,0),r[4])
analysis={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'production_end_before_line':cutoff,'llvm_whole_file_summary_including_test_module':file['summary'],'production_emitted_functions':{'covered':sum(c>0 for c in emitted),'total':len(emitted)},'production_distinct_functions_by_first_code_region':{'covered':sum(c>0 for c in functions.values()),'total':len(functions)},'production_distinct_code_regions_by_coordinates':{'covered':sum(c>0 for c in regions.values()),'total':len(regions)},'uncovered_production_regions':[{'coordinates':k,'source':lines[k[0]-1]}for k,c in sorted(regions.items()) if not c]}
(base/'final-coverage-analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
paths=['src/trigger-host/src/runtime.rs','src/trigger-host/tests/editor_notes.rs','src/trigger-host/tests/support/editor_notes.rs','src/trigger-host/tests/runtime.rs']
source_hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
receipts={p.parent.name:json.loads(p.read_text()) for p in base.glob('*/receipt.json')}
pgids={r['pid'] for r in receipts.values()}
processes=subprocess.run(['ps','-eo','pid,pgid,comm'],check=True,capture_output=True,text=True).stdout.splitlines()
owned=[]
for row in processes[1:]:
    parts=row.split()
    if int(parts[1]) in pgids:owned.append(row)
resources={'disk_free':shutil.disk_usage('/tmp').free,'ramfs_free':shutil.disk_usage('/dev/shm').free,'memory_available':next(int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))}
log=(base/'final-all-host-tests/output.log').read_text(); counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed',log)]
final={'head':subprocess.run(['git','rev-parse','HEAD'],cwd=root,check=True,capture_output=True,text=True).stdout.strip(),'source_hashes':source_hashes,'normal_host_test_count':sum(counts),'final_gates':{name:{key:receipts[name][key] for key in ['command','exit','duration_seconds','source_hashes','resource_min']} for name in ['final-all-host-tests','final-clippy','final-fmt','09-refactor-coverage']},'owned_processes_remaining':owned,'resources':resources,'released_caches':['/tmp/dandrum-lanes/cache-runtime','/tmp/dandrum-lanes/cache-host-snapshot-cov']}
(base/'final-freeze.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps({'head':final['head'],'source_hashes':source_hashes,'normal_tests':sum(counts),'coverage':analysis['llvm_whole_file_summary_including_test_module'],'emitted_functions':analysis['production_emitted_functions'],'distinct_functions':analysis['production_distinct_functions_by_first_code_region'],'distinct_regions':analysis['production_distinct_code_regions_by_coordinates'],'owned_processes_remaining':owned,'resources':resources},indent=2))
