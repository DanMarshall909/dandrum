    fn gated_runtime_for_checked_failures() -> (RuntimeControl, RuntimeAudio) {
        let directory = tempfile::tempdir().unwrap();
        let mut sample = vec![-0.125; 1024];
        sample[..4].copy_from_slice(&[0.25, -0.5, 0.75, -0.25]);
        dandrum_engine::wav::write_wav_stereo_i16(
            std::fs::File::create(directory.path().join("gated.wav")).unwrap(),
            48_000,
            &sample,
            &sample,
        )
        .unwrap();
        let yaml = r#"
assets:
  sample_sources:
    - id: hit
      path: gated.wav
      regions: [{ id: body, start_frame: 0, end_frame: 1024 }]
ports:
  - { name: master, direction: output, signal: audio, channels: 2, maps_from: voices.audio }
module_definitions:
  - type: sample_voice
    ports:
      - { name: audio, direction: output, signal: audio, channels: 2, maps_from: player.audio }
    modules:
      - { id: player, type: sample_player, static: { source: hit, region: body, channels: 2, mode: gated }, defaults: { pan: -0.5 } }
    connections:
      - { from: voice.gate, to: player.trigger }
      - { from: voice.gate, to: player.gate }
modules:
  - { id: midi, type: midi_input }
  - { id: voices, type: poly, static: { definition: sample_voice, max_voices: 4, allocation: reject-new } }
connections:
  - { from: midi.events, to: voices.notes }
"#;
        let session = dandrum_instrument_session::InstrumentSession::new_for_planar_host(
            yaml,
            dandrum_engine::preparation::PreparationContext::new(directory.path(), 48_000),
            dandrum_engine::patch::RenderSettings {
                sample_rate_hz: 48_000,
                block_size_frames: 16,
                duration_frames: 16,
            },
            dandrum_engine::preparation::HostBuses::new().with_output("master", 2),
        )
        .unwrap();
        runtime_handoff(
            PreparedRuntime::new(
                session.prepared(),
                TriggerHostConfiguration {
                    sample_rate_hz: 48_000,
                    max_block_frames: 16,
                },
            )
            .unwrap(),
            4,
        )
        .unwrap()
    }

    fn callback(audio: &mut RuntimeAudio) -> ([f32; 16], [f32; 16]) {
        let (mut left, mut right) = ([1.0; 16], [1.0; 16]);
        let measured =
            allocation_counter::measure(|| audio.process(&mut left, &mut right).unwrap());
        assert_eq!(
            (
                measured.count_total,
                measured.count_current,
                measured.bytes_current
            ),
            (0, 0, 0)
        );
        (left, right)
    }

    fn assert_gated_prefix(output: ([f32; 16], [f32; 16])) {
        assert_eq!(
            &output.0[..4],
            &[8191.0 / 32768.0, -0.5, 24575.0 / 32768.0, -0.25]
        );
        assert_eq!(
            &output.1[..4],
            &[8191.0 / 65536.0, -0.25, 24575.0 / 65536.0, -0.125]
        );
        assert_eq!(&output.0[4..], &[-0.125; 12]);
        assert_eq!(&output.1[4..], &[-0.0625; 12]);
    }

    fn fill_actual_graph_queue(audio: &mut RuntimeAudio, available: usize) {
        let capacity = audio.state.current.0.graph.pending_event_capacity();
        assert_eq!(capacity, 128);
        for _ in 0..capacity - available {
            assert!(audio.state.current.0.graph.try_note_off_at(127, 0));
        }
    }

    #[test]
    fn failed_checked_release_retains_gate_and_new_owner_onset_until_release_succeeds() {
        let (mut control, mut audio) = gated_runtime_for_checked_failures();
        let old = NonZeroU64::new(17).unwrap();
        let new = NonZeroU64::new(18).unwrap();
        control.editor_note_on(old, 60, 100).unwrap();
        assert_gated_prefix(callback(&mut audio));
        control.editor_note_off(old, 60).unwrap();
        control.editor_note_on(new, 60, 100).unwrap();
        fill_actual_graph_queue(&mut audio, 0);
        assert_eq!(callback(&mut audio), ([-0.125; 16], [-0.0625; 16]));
        assert_gated_prefix(callback(&mut audio));
        control.detach_editor_notes(old);
        assert_eq!(callback(&mut audio), ([-0.125; 16], [-0.0625; 16]));
        control.detach_editor_notes(new);
        assert_eq!(callback(&mut audio), ([0.0; 16], [0.0; 16]));
    }

    #[test]
    fn failed_checked_onset_and_ordinary_takeover_keep_their_pending_work() {
        let (mut control, mut audio) = gated_runtime_for_checked_failures();
        let owner = NonZeroU64::new(17).unwrap();
        control.editor_note_on(owner, 60, 100).unwrap();
        fill_actual_graph_queue(&mut audio, 0);
        assert_eq!(callback(&mut audio), ([0.0; 16], [0.0; 16]));
        assert_gated_prefix(callback(&mut audio));
        control
            .try_send(ControlEvent::NoteOn {
                note: 60,
                velocity: 100,
            })
            .unwrap();
        fill_actual_graph_queue(&mut audio, 0);
        assert_eq!(callback(&mut audio), ([-0.125; 16], [-0.0625; 16]));
        assert_gated_prefix(callback(&mut audio));
        control.detach_editor_notes(owner);
        assert_eq!(callback(&mut audio), ([-0.125; 16], [-0.0625; 16]));
        control
            .try_send(ControlEvent::NoteOff { note: 60 })
            .unwrap();
        fill_actual_graph_queue(&mut audio, 0);
        assert_eq!(callback(&mut audio), ([-0.125; 16], [-0.0625; 16]));
        assert_eq!(callback(&mut audio), ([0.0; 16], [0.0; 16]));
    }

    #[test]
    fn checked_takeover_release_success_does_not_lose_queued_onset_when_only_one_slot_was_free() {
        let (mut control, mut audio) = gated_runtime_for_checked_failures();
        let owner = NonZeroU64::new(17).unwrap();
        control.editor_note_on(owner, 60, 100).unwrap();
        assert_gated_prefix(callback(&mut audio));
        control
            .try_send(ControlEvent::NoteOn {
                note: 60,
                velocity: 100,
            })
            .unwrap();
        fill_actual_graph_queue(&mut audio, 1);
        assert_eq!(callback(&mut audio), ([0.0; 16], [0.0; 16]));
        assert_gated_prefix(callback(&mut audio));
        control.detach_editor_notes(owner);
        assert_eq!(callback(&mut audio), ([-0.125; 16], [-0.0625; 16]));
    }

