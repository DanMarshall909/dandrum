use dandrum_engine::patch::RenderSettings;
use dandrum_engine::preparation::{HostBuses, PreparationContext};
use dandrum_instrument_session::InstrumentSession;
use dandrum_trigger_host::TriggerHostConfiguration;
use dandrum_trigger_host::runtime::{
    ControlEvent, PreparedRuntime, RuntimeAudio, RuntimeControl, TimedEvent, runtime_handoff,
};

const FRAMES: usize = 16;
const PREFIX_L: [f32; 4] = [8191.0 / 32768.0, -0.5, 24575.0 / 32768.0, -0.25];
const PREFIX_R: [f32; 4] = [-0.25, 8191.0 / 32768.0, -0.5, 24575.0 / 32768.0];
const TAIL: (f32, f32) = (-0.125, -0.0625);

struct Fixture {
    _directory: tempfile::TempDir,
    session: InstrumentSession,
}

impl Fixture {
    fn new(mode: &str, voices: usize) -> Self {
        let directory = tempfile::tempdir().unwrap();
        let mut left = vec![TAIL.0; 16_384];
        let mut right = vec![TAIL.1; 16_384];
        left[..4].copy_from_slice(&[0.25, -0.5, 0.75, -0.25]);
        right[..4].copy_from_slice(&[-0.25, 0.25, -0.5, 0.75]);
        dandrum_engine::wav::write_wav_stereo_i16(
            std::fs::File::create(directory.path().join("hit.wav")).unwrap(),
            48_000,
            &left,
            &right,
        )
        .unwrap();
        let yaml = format!(
            r#"
assets:
  sample_sources:
    - id: hit
      path: hit.wav
      regions: [{{ id: body, start_frame: 0, end_frame: 16384 }}]
ports:
  - {{ name: master, direction: output, signal: audio, channels: 2, maps_from: voices.audio }}
module_definitions:
  - type: sample_voice
    ports:
      - {{ name: audio, direction: output, signal: audio, channels: 2, maps_from: player.audio }}
    modules:
      - {{ id: player, type: sample_player, static: {{ source: hit, region: body, channels: 2, mode: {mode} }} }}
    connections:
      - {{ from: voice.gate, to: player.trigger }}
      - {{ from: voice.gate, to: player.gate }}
modules:
  - {{ id: midi, type: midi_input }}
  - {{ id: voices, type: poly, static: {{ definition: sample_voice, max_voices: {voices}, allocation: reject-new }} }}
connections:
  - {{ from: midi.events, to: voices.notes }}
"#
        );
        let session = InstrumentSession::new_for_planar_host(
            &yaml,
            PreparationContext::new(directory.path(), 48_000),
            RenderSettings {
                sample_rate_hz: 48_000,
                block_size_frames: FRAMES as u32,
                duration_frames: FRAMES as u64,
            },
            HostBuses::new().with_output("master", 2),
        )
        .unwrap();
        Self { _directory: directory, session }
    }

    fn runtime(&self, capacity: usize) -> (RuntimeControl, RuntimeAudio) {
        runtime_handoff(self.prepared(), capacity).unwrap()
    }

    fn prepared(&self) -> PreparedRuntime {
        PreparedRuntime::new(
            self.session.prepared(),
            TriggerHostConfiguration {
                sample_rate_hz: 48_000,
                max_block_frames: FRAMES as u32,
            },
        )
        .unwrap()
    }
}

fn on(note: u8, frame_offset: u32) -> TimedEvent {
    TimedEvent { frame_offset, event: ControlEvent::NoteOn { note, velocity: 100 } }
}
fn off(note: u8, frame_offset: u32) -> TimedEvent {
    TimedEvent { frame_offset, event: ControlEvent::NoteOff { note } }
}

fn render(audio: &mut RuntimeAudio, events: &[TimedEvent]) -> ([f32; FRAMES], [f32; FRAMES]) {
    let (mut left, mut right) = ([1.0; FRAMES], [1.0; FRAMES]);
    let allocations = allocation_counter::measure(|| {
        audio.process_events(&mut left, &mut right, events).unwrap();
    });
    assert_eq!((allocations.count_total, allocations.count_current, allocations.bytes_current), (0, 0, 0), "callback must neither allocate nor destroy ownership");
    (left, right)
}

fn assert_tail(output: &([f32; FRAMES], [f32; FRAMES]), voices: usize) {
    assert_eq!(output.0, [TAIL.0 * voices as f32; FRAMES]);
    assert_eq!(output.1, [TAIL.1 * voices as f32; FRAMES]);
}

#[test]
fn signed_gated_child_releases_at_host_offset_but_one_shot_keeps_its_tail() {
    for mode in ["gated", "one_shot"] {
        let fixture = Fixture::new(mode, 4);
        let (_, mut audio) = fixture.runtime(4);
        let first = render(&mut audio, &[on(60, 0)]);
        assert_eq!(&first.0[..4], &PREFIX_L);
        assert_eq!(&first.1[..4], &PREFIX_R);
        assert_eq!(&first.0[4..], &[TAIL.0; 12]);
        assert_eq!(&first.1[4..], &[TAIL.1; 12]);
        assert_tail(&render(&mut audio, &[]), 1);
        let released = render(&mut audio, &[off(60, 7)]);
        assert_eq!(&released.0[..7], &[TAIL.0; 7]);
        assert_eq!(&released.1[..7], &[TAIL.1; 7]);
        let tail = if mode == "gated" { (0.0, 0.0) } else { TAIL };
        assert_eq!(&released.0[7..], &[tail.0; 9]);
        assert_eq!(&released.1[7..], &[tail.1; 9]);
        assert_tail(&render(&mut audio, &[]), usize::from(mode == "one_shot"));
    }
}
