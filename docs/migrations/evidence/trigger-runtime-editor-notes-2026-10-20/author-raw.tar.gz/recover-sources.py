from pathlib import Path
import subprocess,hashlib,json
root=Path('/tmp/dandrum-lanes/runtime'); base=Path('/tmp/dandrum-lanes/evidence-runtime-notes'); s=(root/'src/trigger-host/src/runtime.rs').read_text()
def archive(label,s,expected):
 p=base/('reconstructed-'+label)/'runtime.rs';p.parent.mkdir(exist_ok=True);p.write_text(s);subprocess.run(['/home/dan/.cargo/bin/rustfmt','--edition','2024',str(p)],check=True)
 actual=hashlib.sha256(p.read_bytes()).hexdigest();print(label,actual,'MATCH' if actual==expected else 'MISMATCH');return p.read_text()
# Reverse the documented host-priority change from currently intact source.
s=s.replace('    host_held: [bool; 128],\n','').replace('            host_held: [false; 128],\n','')
a=s.index('        let mut touched = [false; 128];');b=s.index('        // A producer may refill concurrently.',a);s=s[:a]+s[b:]
a=s.index('                self.apply_event(event.event, 0, event.command_sequence, &mut report)?;');b=s.index('            }\n        }\n',a);s=s[:a]+'                self.apply_event(event.event, 0, event.command_sequence, &mut report);\n'+s[b:]
s=s.replace('self.reconcile_editor_notes(&touched);','self.reconcile_editor_notes();').replace('self.apply_event(event.event, event.frame_offset, 0, &mut report)?;','self.apply_event(event.event, event.frame_offset, 0, &mut report);').replace('fn reconcile_editor_notes(&mut self, touched: &[bool; 128])','fn reconcile_editor_notes(&mut self)')
a=s.index('            if self.host_held[pitch] || touched[pitch] {');b=s.index('            let onset',a);s=s[:a]+s[b:]
a=s.index('    fn apply_event(');b=s.index('            ControlEvent::Parameter { index, value } => {',a)
s=s[:a]+'''    fn apply_event(
        &mut self,
        event: ControlEvent,
        frame_offset: u32,
        command_sequence: u64,
        report: &mut ProcessReport,
    ) {
        match event {
            ControlEvent::NoteOn { note, velocity } => {
                self.current.0.graph.note_on_at(note, velocity, 0)
            }
            ControlEvent::NoteOff { note } => self.current.0.graph.note_off_at(note, 0),
'''+s[b:]
s=s.replace('        Ok(())\n    }\n}\n\nimpl Processor {','    }\n}\n\nimpl Processor {',1)
s=archive('02-tap-green',s,'40107723e0b32554b2a1d32a387ab824bf3f2d3a9b186c4be722965e33e8ae02')
# Reverse the documented ordinary-tap change.
s=s.replace('    editor_publishers: [Option<NonZeroU64>; 128],\n','').replace('        editor_publishers: [None; 128],\n','').replace('    editor_seen: [u64; 128],\n','').replace('            editor_seen: [0; 128],\n','').replace('        self.editor_publishers[pitch] = Some(owner);\n','')
a=s.index('    /// Ordinary release retains');b=s.index('    pub(crate) fn restoring',a)
s=s[:a]+'''    /// Detachment is bounded and needs no event-queue slot. The audio endpoint
    /// retains the release obligation until the graph accepts its note-off.
    pub fn detach_editor_notes(&mut self, owner: NonZeroU64) {
        for (pitch, held) in self.editor_owners.iter_mut().enumerate() {
            if *held == Some(owner) {
                *held = None;
                let sequence = self.editor_intent[pitch].load(Ordering::Relaxed) >> 14;
                self.editor_intent[pitch].store(sequence << 14, Ordering::Release);
            }
        }
    }

'''+s[b:]
s=s.replace('            let onset = ((intent >> 7) & 127) as u8;\n            if onset != 0\n                && (velocity != 0 || sequence != self.editor_seen[pitch])','            if velocity != 0').replace('.try_note_on_at(pitch as u8, onset, 0)','.try_note_on_at(pitch as u8, velocity, 0)').replace('                self.editor_seen[pitch] = sequence;\n','')
s=archive('01b-readiness-green',s,'9da13bd0a0373978991e642365ba5af988fe21fdfbe9cb65f2723729c3b6ed9e')
# Reverse the readiness helper/test to the prior formatted detach closure.
s=s.replace('    pub(crate) fn activation_available(&self) -> bool {\n        !self.in_flight\n    }\n\n','').replace('if !self.activation_available() {','if self.in_flight {').replace('if !self.activation_available() ||','if self.in_flight ||')
a=s.index('    #[test]\n    fn activation_readiness');b=s.index('    #[test]\n    fn parameter_snapshot_does_not_close',a);s=s[:a]+s[b:]
archive('01-detach-regression',s,'e6919d1ccd9b66b2faebc4f57f490a276c7122840746baf9bade32a193be2c7d')
