"""One-off affected source-free optimized host verification; preserve warm caches."""
from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time
root=Path('/tmp/dandrum-lanes/runtime');out=Path('/tmp/dandrum-lanes/evidence-runtime-notes-sourcefree');out.mkdir(exist_ok=False)
fixture=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source');priorpath=Path('/tmp/dandrum-lanes/evidence-host-snapshot-integration-retry/source-manifest.json');prior=json.loads(priorpath.read_text());current={'CMakeLists.txt':hashlib.sha256((root/'CMakeLists.txt').read_bytes()).hexdigest()}
for part in ('src','tests','examples','schema','scripts','spikes'):
 for parent,dirs,files in os.walk(root/part):
  dirs[:]=[d for d in dirs if d not in ('target','build','__pycache__')]
  for name in files:
   p=Path(parent)/name;assert not p.is_symlink();current[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
for name,digest in prior.items():assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest,name
changes={n:dict(previous_sha256=prior.get(n),current_sha256=d) for n,d in current.items() if prior.get(n)!=d};assert set(prior)<=set(current);assert len(current)==589
for name in changes:
 p=fixture/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
# Freshen owned crate inputs to invalidate old cross-worktree debug/release products.
mtimes=[]
for directory in (fixture/'src/trigger-host/src',fixture/'src/trigger-host/tests'):
 for p in directory.rglob('*.rs'):
  before=p.stat().st_mtime_ns;digest=hashlib.sha256(p.read_bytes()).hexdigest();os.utime(p,None);assert hashlib.sha256(p.read_bytes()).hexdigest()==digest;mtimes.append(dict(path=str(p.relative_to(fixture)),before=before,after=p.stat().st_mtime_ns,sha256=digest))
for name,digest in current.items():assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest,name
assert not any((fixture/n).exists() for n in ('web','ui','third_party'))
(out/'source-manifest.json').write_text(json.dumps(current,indent=2)+'\n');(out/'fixture-update.json').write_text(json.dumps(dict(prior_manifest=str(priorpath),changes=changes,timestamp_only_invalidation=mtimes),indent=2)+'\n')
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_TARGET_DIR='/tmp/dandrum-lanes/cache-editor-guard',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',TMPDIR='/tmp')
commands=[('release-tests',['/home/dan/.cargo/bin/cargo','test','--release','--offline','--locked','--jobs','2','--manifest-path',str(fixture/'src/trigger-host/Cargo.toml')]),('dependencies',['/home/dan/.cargo/bin/cargo','tree','--offline','--locked','--manifest-path',str(fixture/'src/trigger-host/Cargo.toml'),'--edges','normal','--prefix','none'])];results=[]
for label,argv in commands:
 start=time.monotonic();samples=[];stop=None
 with (out/(label+'.log')).open('wb') as log:
  proc=subprocess.Popen(argv,cwd=fixture,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   disk=os.statvfs('/tmp');ram=os.statvfs('/dev/shm');mem=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;s=dict(elapsed_seconds=time.monotonic()-start,disk=disk.f_bavail*disk.f_frsize,ram=ram.f_bavail*ram.f_frsize,mem=mem);samples.append(s)
   if s['disk']<1024**3 or s['ram']<256*1024**2 or mem<4*1024**3:stop='resource floor; stopped owned process group and preserved all caches';os.killpg(proc.pid,signal.SIGINT);break
   time.sleep(.25)
  code=proc.wait()
 r=dict(argv=argv,cwd=str(fixture),environment={k:env[k] for k in ('PATH','CARGO_TARGET_DIR','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','TMPDIR')},exit_code=code,elapsed_seconds=time.monotonic()-start,pgid=proc.pid,stop_reason=stop,resource_samples=samples,log_sha256=hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest());(out/(label+'.json')).write_text(json.dumps(r,indent=2)+'\n');results.append(r);assert code==0,(label,code,stop)
for name,digest in current.items():assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
names={line.split()[0].lower() for line in (out/'dependencies.log').read_text().splitlines() if line.strip()};assert not any(any(token in name for token in ('clack','wry','webkit','gtk','juce')) for name in names)
import re
counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', (out/'release-tests.log').read_text())];assert sum(counts)==90,counts
record=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),source_inputs=len(current),all_inputs_match=True,absent_trees=['web','ui','third_party'],tests=sum(counts),qualification='Affected actual source-free optimized Cargo host tests and dependency audit in retained fixture; not fresh complete default-profile guard, CMake artifact restaging, browser/native CLAP or full beta acceptance.',results=[dict(gate=label,exit_code=r['exit_code'],elapsed_seconds=r['elapsed_seconds']) for (label,_),r in zip(commands,results)],caches_preserved=True)
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
