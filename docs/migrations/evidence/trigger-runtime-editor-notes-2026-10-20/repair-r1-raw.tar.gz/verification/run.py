import os,sys,subprocess,time,json,pathlib,hashlib,shutil,signal
root=pathlib.Path('/tmp/dandrum-lanes/runtime');base=pathlib.Path('/run/user/1000/dandrum-beta-20261020');evidence=base/'runtime-notes-r1-evidence';target=base/'runtime-notes-r1-target';scratch=base/'runtime-notes-r1-scratch'
phase=sys.argv[1];command=sys.argv[2:];dest=evidence/phase;dest.mkdir(exist_ok=False)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(target),CARGO_LLVM_COV_TARGET_DIR=str(target),CARGO_LLVM_COV_BUILD_DIR=str(target),CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',TMPDIR=str(scratch))
keys=['CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','CARGO_BUILD_JOBS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','TMPDIR'];hashes={}
for rel in ['src/trigger-host/src/runtime.rs','src/trigger-host/tests/editor_notes.rs','src/trigger-host/tests/runtime.rs','src/trigger-host/tests/support/editor_notes.rs','src/trigger-host/Cargo.toml','src/trigger-host/Cargo.lock']:
 p=root/rel;data=p.read_bytes();hashes[rel]=hashlib.sha256(data).hexdigest();copy=dest/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(data)
def resources():
 return {'target_free':shutil.disk_usage(base).free,'disk_free':shutil.disk_usage('/tmp').free,'ramfs_free':shutil.disk_usage('/dev/shm').free,'memory_available':next(int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))}
def low(r):return r['target_free']<256*1024**2 or r['disk_free']<1024**3 or r['ramfs_free']<256*1024**2 or r['memory_available']<4*1024**3
start=time.monotonic();samples=[resources()];reason=None;pid=None;code=None
if low(samples[0]):reason='resource floor before launch'
else:
 with (dest/'output.log').open('w') as log:
  proc=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);pid=proc.pid
  while proc.poll() is None:
   time.sleep(.5);samples.append(resources())
   if low(samples[-1]):
    reason='resource floor';os.killpg(pid,signal.SIGTERM);proc.wait();break
  code=proc.returncode
receipt={'command':command,'cwd':str(root),'environment':{k:env[k] for k in keys},'profile':'Cargo dev/test opt0 with only debuginfo overridden to0; debug assertions/overflow checks/default panic unchanged; verbose commands are authoritative','source_hashes':hashes,'exit':code,'pid':pid,'duration_seconds':time.monotonic()-start,'resource_first':samples[0],'resource_last':samples[-1],'resource_min':{k:min(r[k] for r in samples) for k in samples[0]},'stop_reason':reason}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['exit','duration_seconds','resource_min','stop_reason']}));log=dest/'output.log';print(log.read_text()[-3500:] if log.exists() else 'No command launched');sys.exit(code if code is not None else 99)
