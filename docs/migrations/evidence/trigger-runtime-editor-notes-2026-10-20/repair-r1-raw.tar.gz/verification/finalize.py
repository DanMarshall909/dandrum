from pathlib import Path
import hashlib,json,re,subprocess,shutil
base=Path('/run/user/1000/dandrum-beta-20261020/runtime-notes-r1-evidence');root=Path('/tmp/dandrum-lanes/runtime')
paths=['src/trigger-host/src/runtime.rs','src/trigger-host/tests/editor_notes.rs','src/trigger-host/tests/support/editor_notes.rs','src/trigger-host/tests/runtime.rs']
hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths};assert hashes[paths[0]]=='3db6c16c237c0bbb024e57b34b72507dcf70111ead88c3c6b88f66df08d81c0b'
receipts={p.parent.name:json.loads(p.read_text()) for p in base.glob('*/receipt.json')}
for receipt in receipts.values():
 assert receipt['exit']==0
 for p,h in hashes.items():assert receipt['source_hashes'][p]==h
pgids={r['pid'] for r in receipts.values()};rows=subprocess.run(['ps','-eo','pid,pgid,comm'],check=True,text=True,capture_output=True).stdout.splitlines()[1:];owned=[r for r in rows if int(r.split()[1]) in pgids]
cov=json.loads((base/'focused-coverage.json').read_text())['data'][0];source=(root/paths[0]).read_text().splitlines();cutoff=next(i+1 for i,l in enumerate(source) if l=='#[cfg(test)]');file=next(f for f in cov['files'] if f['filename'].endswith('/src/trigger-host/src/runtime.rs'));regions={};functions={};emitted=[]
for f in cov['functions']:
 own=[r for r in f['regions'] if f['filenames'][r[5]].endswith('/src/trigger-host/src/runtime.rs') and r[7]==0]
 if not own:continue
 if own[0][0]<cutoff:
  key=tuple(own[0][:4]);functions[key]=max(functions.get(key,0),f['count']);emitted.append(f['count'])
 for r in own:
  if r[0]<cutoff:
   key=tuple(r[:4]);regions[key]=max(regions.get(key,0),r[4])
coverage={'whole_file_including_unit_tests':file['summary'],'production_emitted_functions':[sum(c>0 for c in emitted),len(emitted)],'production_distinct_functions_by_first_region':[sum(c>0 for c in functions.values()),len(functions)],'production_distinct_regions':[sum(c>0 for c in regions.values()),len(regions)],'uncovered_production_regions':[{'coordinates':k,'source':source[k[0]-1]} for k,c in sorted(regions.items()) if not c]};(base/'coverage-analysis.json').write_text(json.dumps(coverage,indent=2)+'\n')
checks={}
for name,r in receipts.items():
 log=(base/name/'output.log').read_text();checks[name]={'exit':r['exit'],'seconds':r['duration_seconds'],'passed_tests':sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed',log)),'resource_min':r['resource_min']}
flags=[]
for phase in ['01-editor-velocity-characterization','03-all-host-tests','05-clippy','06-focused-coverage']:
 for line in (base/phase/'output.log').read_text().splitlines():
  if ('--crate-name dandrum_trigger_host ' in line or '--crate-name editor_notes ' in line or '__CARGO_LLVM_COV_RUSTC_WRAPPER_RUSTFLAGS' in line):flags.append({'phase':phase,'command':line})
(base/'actual-profile-commands.json').write_text(json.dumps(flags,indent=2)+'\n')
final={'head':(base/'head.txt').read_text().strip(),'source_hashes':hashes,'checks':checks,'profile':'Cargo dev/test opt0 with CARGO_PROFILE_DEV_DEBUG=0 and CARGO_PROFILE_TEST_DEBUG=0; not default-symbol debug profile; assertions/overflow/panic settings unchanged; actual compiler commands retained','coverage':coverage,'owned_processes_remaining':owned,'resources':{p:shutil.disk_usage(p).free for p in ['/run/user/1000','/tmp','/dev/shm']},'target_returned':'/run/user/1000/dandrum-beta-20261020/runtime-notes-r1-target','scratch_returned':'/run/user/1000/dandrum-beta-20261020/runtime-notes-r1-scratch'}
(base/'final-freeze.json').write_text(json.dumps(final,indent=2)+'\n');print(json.dumps({k:final[k] for k in ['head','source_hashes','checks','owned_processes_remaining','resources']},indent=2));print(json.dumps({k:v for k,v in coverage.items() if k!='uncovered_production_regions'},indent=2))
