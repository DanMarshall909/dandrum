# Whole-candidate review refresh: revised publication manifest

**PASS** for manifest `fccb5f1789369f021741fa90ffb723634df25de07f2811860f60da6d7cbae3e0`, unchanged tree `806bebe8d08e797a4e4276772e1fd948bf528ffd`, and its exact revised finite envelope. Required corrections: none.

This verdict supersedes the prior manifest/envelope verdict for current publication. Original reports and manifests remain retained as historical evidence. The full task/criterion matrices, test-oracle, architecture, coverage limitations and broader-scope exclusions in `report.md` remain applicable; `refresh-report.md` supplies the independent post-cleanup complete candidate/evidence recheck. Its earlier contextual reading of the old blanket cache-preservation wording is superseded by the explicit truthful replacement described here.

## Full-candidate reassessment

The original13 status/mode/object/content rows and tree are identical. Rechecked all13 current path digests and the whole binary staged diff against retained candidate evidence after the new freeze. Base/current/intended upstream/integration identities remain the same; there is no source/test/packet/task/spec/map/dependency/resource modification. The immediately preceding independent refresh rehashed all542 archive members,26 external artifacts and1766 Runtime cache files, verified19 source bindings, four lane preconditions, main cleanliness and tracker preimage. The envelope-only revision does not invalidate those observations or the source-bound execution evidence. No new test execution is claimed or required for this administrative correction.

Parsed and compared both entire manifests. Exactly three top-level fields change: `post_PASS_envelope`, `tracker_update` (template digest only), and added `separate_approved_cleanup_receipt`. All other fields match the original independently reconstructed candidate identity. The receipt hash is `7d3ad580181c8945e4fb549ded9861acb9058aeeb7d90ee15dc6ca0a9e0f2182`, matching the inspected four-directory cleanup receipt and actual absence/sibling/cache/evidence checks. Tracker preimage remains `5f8be9bd772636d0b8165ccc5d1f151130942b44cb6a7acbd331fe6bdcd4e66c`.

## Exact revised envelope

- The publication controller admission and running stop floor for `MemAvailable` is **8,589,934,592 bytes (8 GiB)**. Keep one heavy job, physical cache directories/TMPDIR,1GiB disk floor, normal hooks and all original stop/invalidation controls. No RAM disk/cache layer, global setting or further cleanup is permitted.
- The envelope says preserve all **remaining** reusable caches and permits no **additional** deletion. It records the separate user-approved four-directory incremental cleanup, with its exact hash-bound receipt. The retained1766-file Runtime cache and evidence are unchanged.
- The exact tracker template retains only the original seven receipt-derived substitutions. Its final sentence replaces the overbroad cache-preservation claim with an explicit account of the approved incremental cleanup and preservation of compiled dependencies, executables, profiles, evidence and the known Runtime cache. Resulting template SHA-256 is `86a6ab9990831e8bdaf445ffec59e263fa891a6776b39260861a9c813a40f411`.
- All named validation commands, exact commit/tree, unchanged-upstream fetch condition, normal nonforce push, four controlled FF operations, main preservation and flock/preimage/readback tracker append remain as reviewed. No task/CLAP/beta closure or validator waiver is added.

This resolves the wording issue concretely without adding repository content or hiding the authorized deletion in a preservation claim. The retained packet's chronology remains historical; the final tracker records the subsequent operation explicitly.

## Controller inspection and binding

Read the actual one-off helpers, without executing them. Retained exact copies:

| Helper | SHA-256 | Assessment |
|---|---|---|
| `run-publication-reviewed.py` | `72252105d8b686e1a7cb2c9380b8f90ad875f911d48b5f5c91532b85eb00a54a` | Admission matches manifest PASS; exact staged tree before commit; normal hooks; physical cache/temp checks;8GiB/1GiB admission and sampled running guard; one owned subprocess group; logs preserved. |
| `post-review-checks-reviewed.py` | `beb7cef377db38d7dc0db19b285e87c7fa12bfb49ac79c4c8a0c65d0f865054a` | Exact tree/path/source checks; named light checks; final drift rejection and retained logs. |
| `finalize-reviewed.py` | `bc2de5a92bbeb75646abff1ac80e55a2fc24cc741d7b3085331911d578ebafbb` | Checks committed parent/tree/upstream and clean integration; preserves main/cache; stages only the listed target-identical known paths before FF; exact seven-field conditional tracker append and readback. |

These helpers are components of root's reviewed sequence, not independent authority to skip its steps. Root still performs the required fetch without integration and verifies the recorded upstream before normal push; that guard is not implemented inside the push helper itself. Any non-null stop reason or failed named validation/hook invalidates admission even if a subprocess races to exit0. Resource snapshots do not guarantee future headroom. No retry, changed source or upstream integration is authorized by this report.

## Handback

Root must admit the **new** manifest hash above, retain the earlier verdicts as history, and execute only the revised finite envelope after rechecking its preconditions. No publication command was started by this reviewer. Only review records were written; no builds/tests/native/LLVM workers, Git/cache/repository/tracker mutations or cleanup occurred. Root retains sole writer/executor authority. Full task5.1/5.2, CLAP and beta completion remain open, and the fractional-rate validator failure remains unwaived.
