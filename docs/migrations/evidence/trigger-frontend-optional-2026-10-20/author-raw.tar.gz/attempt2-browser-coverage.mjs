import {chromium} from '/tmp/dandrum-lanes/frontend/web/trigger/node_modules/playwright/index.mjs';
import {session,yaml} from '/tmp/dandrum-lanes/frontend/web/trigger/tests/native-fixture.mjs';
import {parse,stringify} from '/tmp/dandrum-lanes/frontend/web/trigger/node_modules/yaml/dist/index.js';
import {writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',headless:true});
try{
 const page=await browser.newPage({viewport:{width:1800,height:1200}});
 await page.coverage.startJSCoverage({resetOnNavigation:false});
 await page.addInitScript(initial=>{
 window.nativeCalls=[];window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend:{addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:name=>async(...args)=>{window.nativeCalls.push([name,...args]);if(name==='getSamplerSession')return initial;throw Error('Unexpected '+name);}}};
 },(()=>{const graph=parse(yaml);graph.assets.sample_sources[0].regions[0].loop={mode:'forward',start_frame:0,end_frame:10000,crossfade_ms:0};return session(stringify(graph));})());
 await page.goto('http://127.0.0.1:8323/');await page.getByRole('img',{name:'Waveform unavailable'}).first().waitFor();
 await page.getByRole('tab',{name:/^Slices/}).click();await page.getByRole('img',{name:'Waveform unavailable'}).first().waitFor();
 await page.getByRole('tab',{name:'Routing',exact:true}).click();await page.getByText('Meters unavailable',{exact:true}).last().waitFor();
 assert.deepEqual(await page.evaluate(()=>window.nativeCalls.map(call=>call[0])),['getSamplerSession']);
 const entries=await page.coverage.stopJSCoverage();
 const mock=await browser.newPage();await mock.coverage.startJSCoverage();await mock.goto('http://127.0.0.1:8323/');await mock.getByTestId('trigger-editor').waitFor();
 await mock.getByRole('button',{name:/^Patch/}).click();await mock.getByRole('button',{name:'Load Felt Kit',exact:true}).click();await mock.getByRole('slider',{name:'Region start',exact:true}).waitFor();
 await mock.getByLabel('Import sample files').setInputFiles({name:'coverage.wav',mimeType:'audio/wav',buffer:Buffer.from('mock')});await mock.getByText('Loading coverage.wav',{exact:true}).waitFor();
 entries.push(...await mock.coverage.stopJSCoverage());await mock.close();
 const local=entries.filter(entry=>entry.url.startsWith('http://127.0.0.1:8323/')&&!entry.url.includes('/node_modules/')&&!entry.url.includes('/vendor/'));
 await writeFile('/tmp/dandrum-lanes/evidence-frontend-optional/browser-v8.json',JSON.stringify(local));
 console.log(JSON.stringify({entries:local.length,urls:local.map(entry=>entry.url)}));
}finally{await browser.close();}
