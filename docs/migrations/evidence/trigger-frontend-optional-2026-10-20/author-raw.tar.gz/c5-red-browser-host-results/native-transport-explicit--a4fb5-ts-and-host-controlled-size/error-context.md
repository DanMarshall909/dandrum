# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-transport.spec.mjs >> explicit absent services render accepted controls with unavailable measurements and host-controlled size
- Location: tests/browser/native-transport.spec.mjs:48:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('banner').getByText('Meters unavailable', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('banner').getByText('Meters unavailable', { exact: true }) with timeout 5000ms
  - waiting for getByRole('banner').getByText('Meters unavailable', { exact: true })

```

```yaml
- banner:
  - text: dandrum Trigger
  - button "Nothing to undo" [disabled]
  - button "Nothing to redo" [disabled]
  - button "Patch Advanced Drum Kit"
  - status: Ready 5 zones · 1 samples
  - text: Connected Voices — / 8
  - radiogroup:
    - radio "Min"
    - radio "Default" [checked]
    - radio "Expanded"
  - button "Collapse"
  - button "Log"
  - button "Clip indicator"
- text: Macros
- navigation:
  - tablist:
    - tab "Sample" [selected]
    - tab "Slices 0"
    - tab "Mapping"
    - tab "Layers"
    - tab "Voice"
    - tab "Modulation 0"
    - tab "Routing"
    - tab "Effects"
  - button "Browser"
- complementary:
  - text: Instrument
  - button "Add group"
  - option "Advanced Drum Kit 1 groups"
  - option "kit 5 zones"
  - option "kick 36 C2"
  - option "snare soft 38 D2"
  - option "hat closed 42 F♯2"
  - option "hat open 46 A♯2"
  - text: Sources
  - button "Add source…"
  - button "Imported 1"
  - text: Modulators
  - button "Add modulator"
  - button "Envelopes 0 · 0"
  - button "LFOs 0 · 0"
  - button "Performance 0 · 0"
  - button "Macros 0 · 0"
  - button "Random 0 · 0"
  - text: Click to preview a source. Drag sources onto pads or zones, modulators onto controls. Right-click a control for Modulation.
- main:
  - text: Sample
  - button "advanced-drums.wav"
  - button "Audition (Space)"
  - radiogroup:
    - radio "Once" [checked]
    - radio "Gated"
    - radio "Loop"
    - radio "Ping-pong"
    - radio "Sustain loop"
  - button "Reverse"
  - text: START END
  - radiogroup "Display":
    - button "Wave" [pressed]
    - button "Spectral"
  - text: START END advanced-drums.wav · 1.063 s
  - slider "Region start"
  - slider "Region end"
  - slider "Fade in"
  - slider "Fade out"
  - text: Format 48 kHz · stereo Length 1.063 s Peak Not analysed Loudness Not analysed Pitch Not analysed Source external · cached Region
  - slider "Start"
  - slider "End"
  - slider "Fade in"
  - slider "Fade out"
  - text: Native controls
  - slider "pitch ratio"
  - slider "start offset"
  - slider "level"
  - slider "pan"
  - slider "variation"
  - slider "pitch ratio"
  - slider "start offset"
  - slider "level"
  - slider "pan"
  - slider "pitch ratio"
  - slider "start offset"
  - slider "level"
  - slider "pan"
  - slider "variation"
  - slider "pitch ratio"
  - slider "start offset"
  - slider "level"
  - slider "pan"
  - slider "pitch ratio"
  - slider "start offset"
  - slider "level"
  - slider "pan"
  - slider "variation"
  - text: Root Root note
  - spinbutton "Root note": 36 C2
  - text: Pitch not analysed
- complementary:
  - text: Advanced Drum Kit › kit › kick advanced-drums.wav Sample History 1 of 1
  - button "Add operation…"
  - button "Collapse stack to a new sample" [disabled]
  - button "Source Source advanced-drums.wav":
    - checkbox "Source" [checked] [disabled]
    - text: Source advanced-drums.wav
  - text: Bottom to top. Uncheck to bypass, drag ⋮⋮ to reorder, click to edit. Sample State loaded · cached Format 48 kHz · 0-bit Channels Stereo Used by 1 zone(s) Region Start 0.000 s End 0.250 s Loop Off Root 60 C4 Analysis Pitch Not analysed Loudness Not analysed Zero crossings Ready
  - button "Analyse pitch"
  - button "Analyse loudness"
  - button "Analyse loops"
  - button "Replace…"
- contentinfo: Drag markers to edit · double-click a value to type · Ctrl+wheel zooms · Space auditions 1200 × 800
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {session} from '../native-fixture.mjs';
  3  | 
  4  | test('the production entrypoint uses the versioned host instead of the comparison bridge',async({page})=>{
  5  |   await page.addInitScript(initial=>{
  6  |     window.nativeCalls=[];
  7  |     const backend={addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:name=>async(...args)=>{
  8  |       window.nativeCalls.push([name,...args]);
  9  |       if(name==='getSamplerSession')return initial;
  10 |       if(name==='subscribeMeter'||name==='setMeterVisible')return true;
  11 |       if(name==='requestSourceWaveform')return {status:'accepted',job_id:'1',generation:initial.document.generation};
  12 |       if(name==='getWaveformJobStatus')return {state:'ready',generation:initial.document.generation,result:{buckets:[]}};
  13 |       return null;
  14 |     }};
  15 |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',backend};
  16 |     window.__JUCE__={backend:{getNativeFunction:()=>{throw new Error('Comparison bridge must remain unused');}}};
  17 |   },session());
  18 |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  19 |   await expect(page.getByRole('banner').locator('[data-backend="native"]')).toBeVisible();
  20 |   expect(await page.evaluate(()=>window.nativeCalls.filter(call=>call[0]==='setTriggerWindowTitle'))).toEqual([['setTriggerWindowTitle','Advanced Drum Kit']]);
  21 |   await expect(page.getByRole('alert')).toHaveCount(0);
  22 | });
  23 | 
  24 | test('an incompatible declared native host displays an error and never opens the silent preview',async({page})=>{
  25 |   await page.addInitScript(()=>{window.__DANDRUM__={protocolVersion:2};});
  26 |   await page.goto('/');
  27 |   await expect(page.getByRole('alert')).toHaveText('Native sampler failed: Unsupported native transport protocol version');
  28 |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  29 | });
  30 | 
  31 | test('a rejected native snapshot displays its capability error without simulating an instrument',async({page})=>{
  32 |   await page.addInitScript(()=>{
  33 |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',backend:{addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:()=>async()=>{
  34 |       throw Object.assign(new Error('Session snapshot capability unavailable'),{code:'capabilityUnavailable',method:'getSamplerSession'});
  35 |     }}};
  36 |   });
  37 |   await page.goto('/');await expect(page.getByRole('alert')).toHaveText('Native sampler failed: Session snapshot capability unavailable');
  38 |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  39 | });
  40 | 
  41 | test('an ordinary browser continues to show an explicitly silent preview',async({page})=>{
  42 |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  43 |   await expect(page.getByRole('banner').locator('[data-backend="mock"]')).toContainText(/silent/i);
  44 |   await expect(page.getByRole('alert')).toHaveCount(0);
  45 | });
  46 | 
  47 | 
  48 | test('explicit absent services render accepted controls with unavailable measurements and host-controlled size',async({page},testInfo)=>{
  49 |   const errors=[];page.on('pageerror',error=>errors.push(error.message));
  50 |   await page.addInitScript(initial=>{
  51 |     window.nativeCalls=[];
  52 |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend:{addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:name=>async(...args)=>{
  53 |       window.nativeCalls.push([name,...args]);if(name==='getSamplerSession')return initial;
  54 |       throw Object.assign(new Error('Unsupported '+name),{code:'capabilityUnavailable',method:name});
  55 |     }}};
  56 |   },session());
  57 |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  58 |   const header=page.getByRole('banner');
  59 |   await expect(header.getByTestId('backend-status')).toHaveText('Connected');
  60 |   await expect(header).toContainText('Voices — / 8');
> 61 |   await expect(header.getByText('Meters unavailable',{exact:true})).toBeVisible();
     |                                                                     ^ Error: expect(locator).toBeVisible() failed
  62 |   await expect(header.getByText('Size controlled by host',{exact:true})).toBeVisible();
  63 |   await expect(header.getByRole('radio')).toHaveCount(0);
  64 |   await expect(header.getByRole('button',{name:'Collapse',exact:true})).toHaveCount(0);
  65 |   await expect(page.getByRole('img',{name:'Waveform unavailable'}).first()).toBeVisible();
  66 |   await expect(page.locator('[data-knob="drums.level"]')).toBeVisible();
  67 |   await expect(page.getByRole('alert')).toHaveCount(0);
  68 |   expect(await page.evaluate(()=>window.nativeCalls.map(call=>call[0]))).toEqual(['getSamplerSession']);
  69 |   await page.screenshot({path:testInfo.outputPath('native-optional-unavailable.png'),animations:'disabled'});
  70 |   expect(errors).toEqual([]);
  71 | });
  72 | 
```