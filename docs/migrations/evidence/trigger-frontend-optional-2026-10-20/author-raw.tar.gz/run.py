import subprocess,time,json,pathlib,sys,os
out=pathlib.Path(__file__).parent;name=sys.argv[1];cmd=sys.argv[2:];start=time.monotonic()
env=dict(os.environ);env['NODE_V8_COVERAGE']=str(out/(name+'-v8')) if 'coverage' in name else env.get('NODE_V8_COVERAGE','')
if not env['NODE_V8_COVERAGE']:del env['NODE_V8_COVERAGE']
p=subprocess.run(cmd,cwd='/tmp/dandrum-lanes/frontend/web/trigger',stdout=(out/(name+'.log')).open('w'),stderr=subprocess.STDOUT,env=env)
record={'command':cmd,'cwd':'/tmp/dandrum-lanes/frontend/web/trigger','elapsed':time.monotonic()-start,'exit':p.returncode};(out/(name+'.json')).write_text(json.dumps(record));print(json.dumps(record));print((out/(name+'.log')).read_text()[-2200:])
