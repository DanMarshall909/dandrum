import json,pathlib,hashlib
p=pathlib.Path(__file__).parent;data=json.loads((p/'browser-v8.json').read_text()); report=[]
needles={'/TriggerController.jsx':['model.waveformAvailable ?'], '/components/AppHeader.jsx':['model.meteringAvailable === false','model.hostControlledSize'], '/components/OutputBusPanel.jsx':['model.meteringAvailable === false'], '/components/WaveformPreview.jsx':['if (!available)'], '/components/pages/SamplePage.jsx':['available: model.waveformAvailable'], '/components/pages/SlicesPage.jsx':['available: model.waveformAvailable']}
for suffix,wanted in needles.items():
 entries=[e for e in data if e['url'].endswith(suffix)];src=entries[0]['source'];assert all(e['source']==src for e in entries)
 result={'url':entries[0]['url'],'generatedSourceSha256':hashlib.sha256(src.encode()).hexdigest(),'checks':[]}
 for needle in wanted:
  start=0
  while (at:=src.find(needle,start))>=0:
   counts=[]
   for entry in entries:
    ranges=[r for fn in entry['functions'] for r in fn['ranges'] if r['startOffset']<=at<r['endOffset']]
    counts.append(min(ranges,key=lambda r:r['endOffset']-r['startOffset'])['count'])
   result['checks'].append({'needle':needle,'offset':at,'enclosingExecutionCounts':counts,'sum':sum(counts)});start=at+len(needle)
  assert any(c['needle']==needle for c in result['checks'])
 assert all(c['sum']>0 for c in result['checks']),result
 report.append(result)
(p/'browser-coverage-changed-checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
