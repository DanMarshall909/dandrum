# F1 repair criterion

Independent review found accepted voice-limit refresh was accidentally tied to meter packets. The existing generation-change owner now publishes only accepted non-measured voice-limit metadata through its existing telemetry event path. Unknown active/null and unavailable flag remain; absent meter data stays empty. No meter owner or optional RPC is introduced.

Tests first: owning public NativeEngine+Store regression covers distinct8→12 accepted changes through both parameter-generation refresh and actual prepared voice-policy publication. It asserts real accepted patch, Store telemetry, actual subscription notification, adapter snapshot coherence, unknown active, false availability, empty meters and zero optional RPCs. Existing mapping/undo/note/heartbeat/feedback scenarios remain. A narrow production-renderer browser case additionally delivers real fixture parameterStateChanged and checks actual header8→12, absent meter label and exactly two snapshot requests.

RED: red-store.log contains expected Store max8 instead of12; red-browser.log contains actual stale rendered Voices — /8 instead of12. Both commands capture exactly the same preimplementation16path source/test manifest cfb6d46b72fd9d45fe491e4487fe0d66e1f99f035a31e9f9c03465a4f04b40af with exact source copies. No setup failures impersonate RED.

GREEN: green-store-coverage.log passes both generation/prepared cases; green-browser.log passes actual header update. Both source manifests match18c2c53ddf38c8e2a24383e7e635c25223b3027cb848fbb5cf6d35a941f2fb62. New changed() production statements execute in focused V8 coverage.

Production refactor considered: keep accepted metadata publication in NativeLive.changed(), the existing shared owner called after generation/prepared/session-command acceptance. No new state/cache/subsystem, and no extraction warranted. Test refactor considered: one table preserves independent generation and prepared entry paths using the existing accepted native fixture; one browser regression pins the actual consumer while policy assertions remain at Store boundary. No helper module or test-only production seam. Original author evidence is untouched; repair sources/logs are separate.

Measurements remain unavailable; this is not a new voice-count telemetry service. Fixtures do not prove Rust/Wry/CLAP or audio. Mutation remains excluded.
