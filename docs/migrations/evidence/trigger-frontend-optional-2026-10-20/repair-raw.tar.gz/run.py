import subprocess,time,json,pathlib,sys,os,hashlib,shutil
out=pathlib.Path(__file__).parent;root=pathlib.Path('/tmp/dandrum-lanes/frontend');name=sys.argv[1];cmd=sys.argv[2:];rows=[]
for path in subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines():
 source=root/path;b=source.read_bytes();target=out/(name+'-source')/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target);rows.append({'path':path,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
(out/(name+'-source.json')).write_text(json.dumps(rows,indent=2)+'\n');start=time.monotonic();env=dict(os.environ)
if 'coverage' in name:env['NODE_V8_COVERAGE']=str(out/(name+'-v8'))
p=subprocess.run(cmd,cwd=root/'web/trigger',stdout=(out/(name+'.log')).open('w'),stderr=subprocess.STDOUT,env=env)
record={'command':cmd,'cwd':str(root/'web/trigger'),'elapsed':time.monotonic()-start,'exit':p.returncode,'sourceManifestSha256':hashlib.sha256((out/(name+'-source.json')).read_bytes()).hexdigest()};(out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));print((out/(name+'.log')).read_text()[-2500:])
