import json,pathlib,hashlib,shutil,sys
out=pathlib.Path('/tmp/dandrum-evidence/g3-note-lease');label=sys.argv[1]
records=[]
for line in (out/(label+'.stdout.log')).read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')=='compiler-artifact' and r['target']['name']=='dandrum_clap_adapter' and r['profile']['test'] and r.get('executable'):records.append(r)
assert len(records)==1
source=pathlib.Path(records[0]['executable']);retained=out/'artifacts'/label/'owner-tests';retained.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,retained)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(out/(label+'-binding.json')).write_text(json.dumps({'test':str(retained),'test_sha256':h(retained),'cargo_artifact':str(source),'cargo_artifact_sha256':h(source)},indent=2))
print(retained)
