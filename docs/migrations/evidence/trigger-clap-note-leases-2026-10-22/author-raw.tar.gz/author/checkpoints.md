# Native note lease evidence

Source base 0dc1f7a9814a238edca21c22b67ca81e411d1994; root retains publication.
Sole source/build executor g3_note_lease_tracer; mutation excluded.

## Qualification

- `qualification-native`: setup failure, sandbox X11 denied.
- `qualification-native-x11`: setup failure, observer JavaScript syntax typo. Fixed only the test.
- `qualification-green`: calibration failure, independent positive PCM16 expected values omitted signed-writer quantization. No production behavior RED claimed.
- `qualification-pcm-green`: PASS, actual copied release DSO, unmodified app.js, literal signed stereo onset, -0.125 tail through 30208/480000 rendered frames and real authenticated NoteOff silence.
- Runtime uses real native time; no fake clock, private protocol or product seam. The fixture changes only copied document/WAV and restores both via RAII.
- Direct backend note calls do not populate NativeLive audition desired map. A passive getter observer forwards calls and records exact note traffic; no timer or automatic-heartbeat Promise is replaced. No physical keyboard/pointer proof is claimed.

## N1 planned oracle

Authenticated heartbeat at ~1.1s followed by signed output at ~2.3s. An authenticated NoteOff for unused pitch62 invokes native sweep without releasing or renewing pitch60. This distinguishes heartbeat renewal from an unswept old lease even before periodic expiry service joins. Exact note traffic confirms no automatic heartbeat or hidden release.

## N1 completed checkpoint

Genuine RED: n1-native-red.stdout.log, capabilityUnavailable on real authenticated heartbeat; matching fast dispatch RED n1-owner-red.stdout.log. Immutable Cargo-selected red artifacts and source snapshots retained.
GREEN: n1-native-green (3.87s test, 114688/480000 frames); complete exact 13 adapter owner tests; n1-fmt and n1-clippy PASS. Native LLVM n1-native-llvm passes with one raw profile, immutable instrumented DSO hash e984a894673280c09c8f838df0a8b2115dc0f0b9a0cb6868a7aa3bc4e9d937e8; new shared note dispatch executes. The native criterion does not cover parameter/error/worker branches; owning tests protect admission, malformed heartbeat, duplicate heartbeat, preserved parameters and optional capability error. No blanket GUI/dependency coverage claim.

Production refactor: removed the now-unreachable wildcard after routing the final enum variant into the existing note authority. No additional helper/policy needed. Test refactor: the existing dispatch test absorbed heartbeat settlement/errors; shared HeldSample/HeldAudio helpers support literal output and bounded GLib/audio service, without abstracting the native criterion into a fake. No further extraction is justified at this boundary. Normal DSO restored with SHA receipt before next RED.

## N2 completed checkpoint and final refactor

Genuine RED: `n2-native-red.stdout.log` retained late editor+host output -0.25 after 2.313609577 seconds from renewal, remaining output -0.25, then -0.125 after host release. Only 170496/480000 fixture frames were rendered. Cleanup preceded the final assertion. GREEN: `n2-native-green.stdout.log` observes -0.25 -> -0.125 -> zero at the same public boundary, with no post-renewal note command that could perform the sweep.

Production refactor review: keep the small native-time service borrow separate so expiry does not depend on GUI state/structural work. Reuse the existing controller policy and bounded attachment traversal; no new extraction justified. Test refactor shares bounded GLib service/render progression, verified by the N1 regression before N2 RED. Final N2 oracle additionally performs an authenticated snapshot after capturing expiry output and verifies the same attachment. The real lease requires slow native cases; fast policy checks remain in the core owner.

Final checks: 15 current trigger_parameters native cases; 13 adapter owner tests; 14 core editor-note tests; fmt; strict Clippy for editor, default and plain-trigger feature profiles; OpenSpec strict validation and diff check all PASS. Final native LLVM covers all 3 note cases; owner LLVM covers all 13 owner cases. New periodic service regions: native 4/5, owner 5/5, source-coordinate union 5/5. Normal DSO restored and all 3 native note cases pass again. Mutation deliberately excluded. No next behavior criterion started.
