from pathlib import Path
import subprocess,sys
out=Path('/tmp/dandrum-evidence/g3-note-lease')
cases=[
'note_native::copied_native_gated_sample_outlasts_short_fixture_and_releases',
'note_native::copied_native_heartbeat_renews_held_note_past_original_deadline',
'note_native::copied_native_live_attachment_expires_renewed_note_and_preserves_host_voice',
]
for case in cases:subprocess.run([sys.executable,str(out/'native.py'),'final-product-build',case],check=True)
print('Verified exact restored normal note cases:',len(cases))
