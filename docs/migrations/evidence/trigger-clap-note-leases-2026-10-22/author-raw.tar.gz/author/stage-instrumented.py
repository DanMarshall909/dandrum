from pathlib import Path
import json,sys,hashlib,shutil,time
out=Path('/tmp/dandrum-evidence/g3-note-lease');label=sys.argv[1];base=json.loads((out/(sys.argv[2]+'-binding.json')).read_text())
source=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g3-note-lease')/label/'libdandrum_clap_adapter.so';target=Path(base['copied_library']);shutil.copy2(source,target)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base.update(source_library=str(source),source_sha256=h(source),copy_sha256=h(target),profile_start_ns=time.time_ns(),note='Instrumented owner DSO; normal runtime stack/no preload, same uniquely reported normal native test ELF and unmodified production assets; no dependency/browser coverage claim.')
(out/(label+'-instrumented-binding.json')).write_text(json.dumps(base,indent=2));print(json.dumps(base))
