import gzip,hashlib,io,json,tarfile
from pathlib import Path
root=Path('/tmp/dandrum-evidence/g3-note-native-fixture'); author=Path('/tmp/dandrum-evidence/g3-note-lease'); dest=Path('/tmp/dandrum-lanes/integration/docs/migrations/evidence/trigger-clap-note-leases-2026-10-22');dest.mkdir(parents=True,exist_ok=True)
def sha(d):return hashlib.sha256(d).hexdigest()
def archive(name,entries):
 index={n:dict(sha256=sha(d),bytes=len(d)) for n,d in entries.items()};entries['meta/index.json']=(json.dumps(index,sort_keys=True,indent=2)+'\n').encode();p=dest/name
 assert not p.exists()
 with p.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as t:
  for n,d in sorted(entries.items()):
   i=tarfile.TarInfo(n);i.size=len(d);i.mode=0o644;t.addfile(i,io.BytesIO(d))
 with tarfile.open(p,'r:gz') as t:
  assert set(t.getnames())==set(entries)
  for i in t:assert t.extractfile(i).read()==entries[i.name]
 r=dict(archive=name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size,members=len(entries),every_member_byte_verified=True);(dest/(name.replace('-raw.tar.gz','-archive.json'))).write_text(json.dumps(r,indent=2)+'\n');print(r)
def add(e,p,n):
 d=p.read_bytes();assert not d.startswith(b'\x7fELF') and len(d)<8*1024**2,p;d.decode('utf8');e[n]=d
entries={}
for p in sorted(author.iterdir()):
 if p.is_file():add(entries,p,'author/'+p.name)
for p in sorted((author/'compiler-captures').rglob('*')):
 if p.is_file():add(entries,p,'compiler-captures/'+str(p.relative_to(author/'compiler-captures')))
states={};objects={}
for p in sorted(author.iterdir()):
 if not (p/'source').is_dir():continue
 rows={}
 for s in sorted((p/'source').rglob('*')):
  if not s.is_file():continue
  assert not s.is_symlink();d=s.read_bytes();assert not d.startswith(b'\x7fELF');h=sha(d);objects[h]=d;rows[str(s.relative_to(p/'source'))]=dict(sha256=h,bytes=len(d),mode=oct(s.stat().st_mode&0o777))
 states[p.name]=rows
entries['meta/source-states.json']=(json.dumps(states,sort_keys=True,indent=2)+'\n').encode()
for h,d in objects.items():entries['source-objects/'+h]=d
archive('author-raw.tar.gz',entries)
entries={}
for p in sorted(root.iterdir()):
 if p.is_file() and p.suffix in ('.py','.json','.log','.d'):add(entries,p,'root/'+p.name)
for name in ('registration-test-before','registration-implementation-before'):add(entries,root/name,'root/'+name)
for fixture in ('trigger-clap-native-fixture','trigger-clap-parameters-fixture'):
 for p in sorted((root/'native-build'/fixture/'evidence').iterdir()):
  if p.is_file():add(entries,p,'native-prepare/'+fixture+'/'+p.name)
for name in ('CTestTestfile.cmake','CMakeCache.txt'):add(entries,root/'native-build'/name,'native-configuration/'+name)
qual=Path('/tmp/dandrum-evidence/g3-native-note-readiness')
for name in ('first-heartbeat-red-assessment.json','first-heartbeat-coverage-assessment.json','first-expiry-red-assessment.json','first-expiry-coverage-assessment.json'):
 add(entries,qual/name,'root-independent-checkpoints/'+name)
for name in ('root-clap-build-boundary.json','root-clap-build-boundary.stdout.log','root-clap-build-boundary.stderr.log'):
 p=Path('/tmp/dandrum-evidence/g3-native-fixture')/name
 if p.exists():add(entries,p,'prior-structural-base-build/'+name)
archive('root-raw.tar.gz',entries)
for name in ('root-final-coverage-assessment.json','root-native-result.json','root-actual-cargo-bindings.json','root-build-boundary-reuse.json','root-linkage-audit.json'):(dest/name).write_bytes((root/name).read_bytes())
(dest/'author-handoff.md').write_bytes((author/'handoff.md').read_bytes())
