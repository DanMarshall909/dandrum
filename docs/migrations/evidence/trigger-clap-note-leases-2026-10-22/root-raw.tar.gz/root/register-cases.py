"""One-off registration TDD; refuses edits before author handback admission."""
from pathlib import Path
import sys,json,hashlib
root=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g3-note-native-fixture');kind=sys.argv[1];assert kind in ('test','implementation')
assert (out/'author-release-admitted.json').exists(),'Explicit final source/cache handback must be independently admitted first'
premises=json.loads((out/'registration-preparation.json').read_text());cases=premises['intended_cases']
path='tests/python/test_engine_only_build.py' if kind=='test' else 'CMakeLists.txt';p=root/path;before=p.read_bytes();expected=premises['source_preimages'][path];assert hashlib.sha256(before).hexdigest()==expected
s=before.decode()
if kind=='test':
 old='''            "trigger-clap-native-parameter-structural-session":
                "structural_native::copied_native_mapping_survives_lost_reply_and_view_loss",
'''
 new=old+''.join(f'            "trigger-clap-native-parameter-{name}":\n                "{case}",\n' for name,case in cases.items())
 assert s.count(old)==1;s=s.replace(old,new)
else:
 old='''                source-credits feedback-undo callback-audit invalid-stopped-flush structural-session)'''
 new='''                source-credits feedback-undo callback-audit invalid-stopped-flush structural-session
                note-hold note-heartbeat note-expiry)'''
 assert s.count(old)==1;s=s.replace(old,new)
 old='''                structural_native::copied_native_mapping_survives_lost_reply_and_view_loss)'''
 new='''                structural_native::copied_native_mapping_survives_lost_reply_and_view_loss
'''+''.join('                '+case+('\n' if n<2 else ')') for n,case in enumerate(cases.values()))
 assert s.count(old)==1;s=s.replace(old,new)
assert not (out/('registration-'+kind+'-edit.json')).exists()
(out/('registration-'+kind+'-before')).write_bytes(before);p.write_text(s)
r=dict(kind=kind,path=path,before_sha256=expected,after_sha256=hashlib.sha256(p.read_bytes()).hexdigest());(out/('registration-'+kind+'-edit.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
