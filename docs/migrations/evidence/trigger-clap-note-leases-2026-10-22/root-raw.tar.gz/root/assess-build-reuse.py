from pathlib import Path
import json,hashlib,subprocess
root=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g3-note-native-fixture');old=Path('/tmp/dandrum-evidence/g3-native-fixture')
source=Path(json.loads((old/'root-build-boundary-cache-binding.json').read_text())['source_fixture']).resolve();dep=Path('/tmp/dandrum-lanes/cache-runtime/release/libdandrum_clap_adapter.d');raw=dep.read_bytes();line=raw.decode().splitlines()[0];assert '\\ ' not in line;names=line.partition(': ')[2].split();assert names
rows={};removed={};external=[]
for name in names:
 p=Path(name).resolve()
 if not p.is_relative_to(source):external.append(str(p));continue
 rel=str(p.relative_to(source));current=root/rel;assert current.is_file(),rel
 sha=hashlib.sha256(current.read_bytes()).hexdigest()
 if p.exists():assert hashlib.sha256(p.read_bytes()).hexdigest()==sha,rel;rows[rel]=sha
 else:
  assert rel=='examples/patches/tb303-acid.yaml',rel
  assert subprocess.check_output(['git','show','0dc1f7a9814a238edca21c22b67ca81e411d1994:'+rel],cwd=root)==current.read_bytes()
  removed[rel]=dict(current_and_base_sha256=sha,qualification='Copied fixture asset intentionally removed by installed-runtime test after successful build. Original copied bytes unavailable to rehash; current bytes match published base. Maintained script copies inputs then removes source asset directory.')
assert 'src/clap-adapter/src/trigger.rs' in rows and len(rows)==76
assert not any('/trigger/gui.rs' in p or 'trigger_note_native.rs' in p for p in rows)
manifests={}
for rel in ('src/clap-adapter/Cargo.toml','src/clap-adapter/Cargo.lock','src/clap-adapter/src/trigger.rs'):
 assert (source/rel).read_bytes()==(root/rel).read_bytes();manifests[rel]=hashlib.sha256((root/rel).read_bytes()).hexdigest()
(out/'previous-headless-product.d').write_bytes(raw);prior=json.loads((old/'root-clap-build-boundary.json').read_text())
x=dict(previous_guard_receipt=str(old/'root-clap-build-boundary.json'),previous_guard_exit=prior['exit'],previous_all8_seconds=prior['seconds'],existing_compiled_source_inputs_rehashed=len(rows),compiled_source_sha256=rows,intentionally_removed_asset_inputs=removed,manifest_and_cfg_gate_sha256=manifests,external_paths=external,depinfo_sha256=hashlib.sha256(raw).hexdigest(),scope='Reuse prior8 copied-source build evidence for unchanged headless inputs; current3 affected registration/configuration/development-graph guards rerun. Prior headless-Trigger transitive depinfo excludes GUI/note test changes. Existing76 copied inputs match; one intentionally removed fixture asset limitation explicit. CMake changes add case names inside native-X11 option; disabled/enabled configs rerun. Not a fresh all8 execution, source-free native-editor build, installed beta or final task5.1 closure claim.')
(out/'root-build-boundary-reuse.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items() if k not in ('compiled_source_sha256','external_paths','manifest_and_cfg_gate_sha256')}))
