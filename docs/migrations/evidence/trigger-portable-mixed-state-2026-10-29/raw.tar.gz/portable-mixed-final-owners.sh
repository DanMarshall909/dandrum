#!/usr/bin/env bash
set -euo pipefail
for owner in rust-engine instrument-session trigger-host clap-adapter; do
  cargo fmt --manifest-path "src/$owner/Cargo.toml" --check
done
cargo clippy --manifest-path src/trigger-host/Cargo.toml --all-targets --offline --locked -- -D warnings
cargo clippy --manifest-path src/instrument-session/Cargo.toml --all-targets --offline --locked -- -D warnings
cargo clippy --manifest-path src/clap-adapter/Cargo.toml --features trigger-editor --all-targets --offline --locked -- -D warnings
cargo test --manifest-path src/instrument-session/Cargo.toml --offline --locked
openspec validate add-juce-free-trigger-beta-products --strict
scripts/check-spec-coverage
git diff --check
