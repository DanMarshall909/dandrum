import hashlib,json,re,subprocess,sys,time
from pathlib import Path
out=Path('/tmp/dandrum-lanes/evidence-native-handshake');label=sys.argv[1];tools=Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin');binary=re.search(r'Running unittests src/lib.rs \(([^)]+)\)',(out/(label+'.log')).read_text()).group(1);profiles=sorted(out.glob(label+'-*.profraw'));assert profiles
prof=out/(label+'.profdata');records=[]
for args,name in [([str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in profiles],'-o',str(prof)],label+'-merge.log'),([str(tools/'llvm-cov'),'export',binary,'--instr-profile',str(prof)],label+'-coverage.json'),([str(tools/'llvm-cov'),'show',binary,'--instr-profile',str(prof),'--show-instantiations=false','src/trigger-editor/src/native_x11.rs'],label+'-coverage.txt')]:
 start=time.monotonic()
 with (out/name).open('wb') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.PIPE)
 records.append(dict(command=args,exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,stderr=r.stderr.decode()));assert r.returncode==0,r.stderr
(out/(label+'-export.json')).write_text(json.dumps(dict(binary=binary,binary_sha256=hashlib.sha256(Path(binary).read_bytes()).hexdigest(),profiles=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in profiles],commands=records),indent=2)+'\n')
for f in json.loads((out/(label+'-coverage.json')).read_text())['data'][0]['files']:
 if f['filename'].endswith('/src/native_x11.rs'):print(json.dumps(dict(file=f['filename'],summary=f['summary'])))
