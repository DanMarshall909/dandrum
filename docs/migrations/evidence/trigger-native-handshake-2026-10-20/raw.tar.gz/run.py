"""One-off source-bound native handshake evidence and owned-resource guard."""
import hashlib,json,os,signal,subprocess,sys,time,shutil
from pathlib import Path
out=Path('/tmp/dandrum-lanes/evidence-native-handshake');label=sys.argv[1]
command=sys.argv[2:] or ['/home/dan/.cargo/bin/cargo','test','--locked','--offline','--jobs','2','--manifest-path','src/trigger-editor/Cargo.toml','--features','native-x11','--lib','native_x11::tests::real_child_loads_local_content_and_drops_without_owning_the_host_parent','--','--ignored','--exact','--nocapture','--test-threads=1']
settings=dict(CARGO_TARGET_DIR='/dev/shm/dandrum-beta-20261020/editor-target',DISPLAY=':10.0',GDK_BACKEND='x11',TMPDIR='/tmp',DANDRUM_TRIGGER_EDITOR_BUNDLE_DIR='/dev/shm/dandrum-beta-20261020/editor-cmake/clap/DandrumTrigger.resources/editor',G_DEBUG='fatal-warnings',RUSTC_WORKSPACE_WRAPPER='/tmp/dandrum-lanes/evidence-native-editor/coverage-wrapper',LLVM_PROFILE_FILE=str(out/(label+'-%p-%m.profraw')))
snapshot=out/(label+'-source');snapshot.mkdir();shutil.copytree('src/trigger-editor',snapshot/'src/trigger-editor')
bindings={str(p.relative_to(snapshot)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(snapshot.rglob('*')) if p.is_file()}
(out/(label+'-hashes.json')).write_text(json.dumps(bindings,indent=2)+'\n')
start=time.monotonic();samples=[];stop=None
with (out/(label+'.log')).open('wb') as log:
 proc=subprocess.Popen(command,env=dict(os.environ,**settings),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll() is None:
  disk=os.statvfs('/tmp');ram=os.statvfs('/dev/shm');mem=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
  s=dict(elapsed_seconds=time.monotonic()-start,disk_free_bytes=disk.f_bavail*disk.f_frsize,ram_free_bytes=ram.f_bavail*ram.f_frsize,mem_available_bytes=mem);samples.append(s)
  if s['disk_free_bytes']<1024**3 or s['ram_free_bytes']<256*1024**2 or mem<4*1024**3:
   stop='resource floor: owned process group stopped; caches preserved';os.killpg(proc.pid,signal.SIGINT);break
  time.sleep(.25)
 code=proc.wait()
record=dict(cwd=os.getcwd(),head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),command=command,env=settings,exit_code=code,elapsed_seconds=time.monotonic()-start,pgid=proc.pid,stop_reason=stop,resource_samples=samples,log_sha256=hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest())
(out/(label+'-run.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ('resource_samples','env')}));sys.exit(code if code>=0 else 128-code)
