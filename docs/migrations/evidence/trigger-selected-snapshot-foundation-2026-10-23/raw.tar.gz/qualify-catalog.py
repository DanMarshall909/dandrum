from pathlib import Path
import os,json,subprocess,hashlib,time,shutil,re
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;stage=Path(os.environ['TMPDIR'])/'catalog-probe';(stage/'src').mkdir(parents=True)
shutil.copy2(out/'catalog-probe.rs',stage/'src/main.rs');shutil.copy2(out/'catalog-probe.Cargo.toml',stage/'Cargo.toml');shutil.copy2(root/'src/trigger-host/Cargo.lock',stage/'Cargo.lock')
rows=[]
def run(label,argv):
 start=time.monotonic();p=subprocess.run(argv,cwd=root,capture_output=True)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 rows.append({'label':label,'argv':argv,'exit_code':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'catalog-qualification-phases.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0,label
 return p.stdout.decode()
text=run('compile-catalog-probe',['/home/dan/.cargo/bin/cargo','build','--offline','--jobs','1','--manifest-path',str(stage/'Cargo.toml'),'--message-format=json'])
def packages(text):
 rows=set()
 for block in text.split('[[package]]')[1:]:
  def field(name):
   m=re.search('^'+name+' = "([^"\n]+)"',block,re.M);return m.group(1) if m else None
  rows.add((field('name'),field('version'),field('source')))
 return rows
assert packages((stage/'Cargo.lock').read_text()) <= packages((root/'src/trigger-host/Cargo.lock').read_text()) | {('dandrum-selected-catalog-probe','0.0.0',None)}
shutil.copy2(stage/'Cargo.lock',out/'catalog-probe.Cargo.lock')
records=[json.loads(line) for line in text.splitlines() if line.startswith('{')];artifacts=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='dandrum-selected-catalog-probe'];assert len(artifacts)==1
binary=Path(artifacts[0]['executable']);(out/'catalog-probe-binding.json').write_text(json.dumps({'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'cargo_artifact':artifacts[0],'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'catalog-probe.rs',out/'catalog-probe.Cargo.toml',out/'catalog-probe.Cargo.lock']},'scope':'One-off production SampleCatalog qualification; real bounded files and cross-thread decode, not maintained/native/DAW acceptance. Exact existing dependency versions, no network.'},indent=2)+'\n')
for channels,count in [(1,1),(2,1),(1,4),(2,4)]:
 label=f'catalog-{channels}ch-{count}files';run(label,['/usr/bin/time','-v',str(binary),str(channels),str(count),str(stage/label)])
print('All four production catalog qualification cases pass; generated sources removed after joined workers and retained-byte assertions.',flush=True)
