from pathlib import Path
import subprocess,sys
p=Path(__file__).parent;c='/home/dan/.cargo/bin/cargo'
for phase,mode,argv in [
 ('edge-strict-lints-final','ordinary',['python3','-B',str(p/'verify-edge-lints.py')]),
 ('host-coverage-current','coverage',['python3','-B',str(p/'host-round2/focused-coverage.py'),'host']),
 ('engine-diagnostic-current','ordinary',[c,'clippy','--offline','--locked','--manifest-path','src/rust-engine/Cargo.toml','--all-targets','--no-deps','--message-format=json']),
 ('plan-current','ordinary',['python3','-B',str(p/'verify-plan.py')]),
]:
 code=subprocess.call([sys.executable,'-B',str(p/'run-check.py'),phase,mode,*argv])
 if code:sys.exit(code)
