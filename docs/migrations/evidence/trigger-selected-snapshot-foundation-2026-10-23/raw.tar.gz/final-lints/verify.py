from pathlib import Path
import subprocess,json,time,hashlib,sys
out=Path(__file__).parent;root=Path('/tmp/dandrum-lanes/integration');cargo='/home/dan/.cargo/bin/cargo';rows=[]
checks=[]
for owner,extra in [('instrument-session',[]),('trigger-host',[]),('trigger-editor',['--features','native-x11']),('clap-adapter',['--features','trigger-editor'])]:
 checks.append((owner+'-format',[cargo,'fmt','--manifest-path','src/'+owner+'/Cargo.toml','--','--check'],False))
 checks.append((owner+'-clippy',[cargo,'clippy','--offline','--locked','--manifest-path','src/'+owner+'/Cargo.toml',*extra,'--all-targets','--no-deps','--message-format=json','--','-D','warnings'],owner=='rust-engine'))
for name,argv,baseline in checks:
 start=time.monotonic();p=subprocess.run(argv,cwd=root,capture_output=True);(out/('last-'+name+'.stdout')).write_bytes(p.stdout);(out/('last-'+name+'.stderr')).write_bytes(p.stderr);rows.append({'name':name,'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'last-static-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode and not baseline:sys.exit(p.returncode)
