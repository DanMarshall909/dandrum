from pathlib import Path
import subprocess,json,time,hashlib,sys
out=Path(__file__).parent;rows=[]
for name,argv in [('change',['openspec','validate','add-juce-free-trigger-beta-products','--strict']),('canonical',['openspec','validate','--specs','--strict']),('coverage',['scripts/check-spec-coverage']),('diff',['git','diff','--check']),('registration',['python3','-B','tests/python/test_engine_only_build.py','ClapProofBuildTest.test_private_clap_native_fixture_binds_maintained_product_and_exact_processes'])]:
 start=time.monotonic();p=subprocess.run(argv,cwd='/tmp/dandrum-lanes/integration',capture_output=True);(out/('final-plan-'+name+'.stdout')).write_bytes(p.stdout);(out/('final-plan-'+name+'.stderr')).write_bytes(p.stderr);rows.append({'name':name,'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'final-plan-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
