"""One-off archive and cleanup of old, never-reused EngineBuildFixture snapshots."""
from pathlib import Path
import os,stat,json,hashlib,tarfile,shutil,subprocess,time
root=Path('/tmp/dandrum-lanes/integration/build/engine-only-regression');out=Path('/tmp/dandrum-evidence/legacy-engine-fixture-cleanup-20261023');out.mkdir();inventory=Path('/tmp/dandrum-evidence/trigger-selected-snapshot-foundation/legacy-fixture-inventory.json');expected=json.loads(inventory.read_text());targets=[Path(r['path']) for r in expected];assert len(targets)==33
uid=os.getuid();skip={os.getpid()};pid=os.getppid()
while pid>1:
 skip.add(pid)
 try:pid=int(Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[1])
 except (FileNotFoundError,ProcessLookupError):break
def idle():
 matches=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit() or int(proc.name) in skip:continue
  try:
   if proc.stat().st_uid!=uid:continue
   cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   if 'test_engine_only_build.py' in cmd or str(root)+'/fixture-' in cmd:matches.append({'pid':int(proc.name),'command':cmd})
   cwd=os.readlink(proc/'cwd')
   if any(cwd==str(t) or cwd.startswith(str(t)+'/') for t in targets):matches.append({'pid':int(proc.name),'cwd':cwd})
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
 assert not matches,matches
 return {'matching_fixture_workers':matches,'global_proc_entries':sum(x.name.isdigit() for x in Path('/proc').iterdir())}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
allowed={str(root/'cargo-target'),'/tmp/dandrum-lanes/cache-runtime'};cache_before={p:(Path(p).lstat().st_dev,Path(p).lstat().st_ino) for p in allowed};before=shutil.disk_usage(root).free;initial_idle=idle();entries=[];unique={};identities={}
for t in targets:
 assert t.parent==root and t.is_dir() and not t.is_symlink() and t.stat().st_uid==uid
 assert (t/'source/tests/python/test_engine_only_build.py').is_file();assert (t/'source/CMakeLists.txt').is_file();assert not (t/'source/.git').exists()
 identities[str(t)]=(t.stat().st_dev,t.stat().st_ino)
 for p in [t,*sorted(t.rglob('*'))]:
  s=p.lstat();assert s.st_uid==uid;name=str(p.relative_to(root));row={'path':name,'mode':stat.S_IMODE(s.st_mode),'device':s.st_dev,'inode':s.st_ino}
  if stat.S_ISDIR(s.st_mode):row['kind']='directory'
  elif stat.S_ISLNK(s.st_mode):
   row.update(kind='symlink',target=os.readlink(p));assert row['target'] in allowed
  else:
   assert stat.S_ISREG(s.st_mode),p;digest=sha(p);row.update(kind='file',bytes=s.st_size,allocated_bytes=s.st_blocks*512,sha256=digest);unique.setdefault(digest,p)
  entries.append(row)
index={'authority':'Existing user instruction to clean owned disposable outputs, and EngineBuildFixture.addClassCleanup(shutil.rmtree, fixture_root). These unique tempfile source/configuration copies are not reusable targets. All global fixture workers idle; caches are only links, never followed.','original_inventory_sha256':sha(inventory),'targets':[str(t) for t in targets],'entries':entries,'cache_identities':cache_before,'initial_idle':initial_idle};(out/'index.json').write_text(json.dumps(index,indent=2)+'\n');archive=out/'content.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1) as a:
 for digest,p in sorted(unique.items()):a.add(p,arcname='blobs/'+digest,recursive=False)
with tarfile.open(archive) as a:
 assert len(a.getmembers())==len(unique)
 for m in a:
  assert m.isfile();h=hashlib.sha256();f=a.extractfile(m)
  while b:=f.read(1024*1024):h.update(b)
  assert m.name=='blobs/'+h.hexdigest()
# Reconstruct every file from archived content-addressed blobs and this index.
# Recheck the entire live snapshot before deletion; any drift stops cleanup.
for r in entries:
 p=root/r['path'];s=p.lstat();assert (s.st_dev,s.st_ino)==(r['device'],r['inode'])
 if r['kind']=='file':assert s.st_size==r['bytes'] and sha(p)==r['sha256']
 elif r['kind']=='symlink':assert os.readlink(p)==r['target']
assert {str(p) for p in root.glob('fixture-*')}==set(identities)
final_idle=idle()
for t in targets:
 assert (t.stat().st_dev,t.stat().st_ino)==identities[str(t)];shutil.rmtree(t);assert not t.exists()
assert {p:(Path(p).lstat().st_dev,Path(p).lstat().st_ino) for p in allowed}==cache_before
record={'removed_directories':len(targets),'regular_files':sum(r['kind']=='file' for r in entries),'allocated_file_bytes_removed':sum(r.get('allocated_bytes',0) for r in entries),'unique_blobs':len(unique),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'index_sha256':sha(out/'index.json'),'free_before':before,'free_after':shutil.disk_usage(root).free,'final_idle':final_idle,'cache_identities_preserved':True,'rebuild_cost':'Fresh test runs already create fresh snapshot/configuration directories; shared Cargo binaries/dependencies remain reusable and untouched.'};(out/'cleanup.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
