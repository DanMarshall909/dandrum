"""One-off portable source/evidence packet; large exact replay ELFs stay external."""
from pathlib import Path
import subprocess,json,hashlib,tarfile,stat,shutil
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;base='2ea523c47c3022c4bf72a5500130083bb6d0bc42';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
sha=lambda b:hashlib.sha256(b).hexdigest()
def file_sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
blobs=out/'source-blobs';blobs.mkdir(exist_ok=True);base_hash={};phases=[]
def bind(name,data,mode=0o644):
 digest=sha(data)
 if name not in base_hash:
  p=subprocess.run(['git','show',base+':'+name],cwd=root,capture_output=True);base_hash[name]=sha(p.stdout) if p.returncode==0 else None
 source='base' if base_hash[name]==digest else 'blob'
 if source=='blob':
  path=blobs/digest
  if path.exists():assert path.read_bytes()==data
  else:path.write_bytes(data)
 return {'path':name,'mode':oct(mode),'sha256':digest,'source':source}
for archive in sorted(out.glob('*-source.tar.gz')):
 with tarfile.open(archive) as t:
  rows=[]
  for m in t:
   assert m.isfile();rows.append(bind(m.name,t.extractfile(m).read(),m.mode))
 phases.append({'snapshot':archive.name,'snapshot_sha256':file_sha(archive),'files':rows})
common=[]
for owner in ['rust-engine','instrument-session','trigger-host','trigger-editor','clap-adapter']:
 for name in ['Cargo.toml','Cargo.lock']:
  p=root/'src'/owner/name;common.append(bind(str(p.relative_to(root)),p.read_bytes(),stat.S_IMODE(p.stat().st_mode)))
for name in ['CMakeLists.txt','tests/python/test_engine_only_build.py','scripts/run-owned-verification.py','scripts/prepare-trigger-clap-native.py','openspec/changes/add-juce-free-trigger-beta-products/selected-samples.md']:
 p=root/name;common.append(bind(name,p.read_bytes(),stat.S_IMODE(p.stat().st_mode)))
(out/'portable-source-replay.json').write_text(json.dumps({'base':base,'phases':phases,'common_current_inputs':common,'recipe':'Reconstruct source bytes from immutable Git base plus source-blobs/<sha256>; verify mode and digest. Large binary replay archives are retained externally with exact hashes, not committed as build/cache directories.'},indent=2)+'\n')
external=[]
for p in sorted(out.rglob('*.tar.gz')):
 if p.name.endswith('-source.tar.gz'):continue
 external.append({'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':file_sha(p),'disposition':'Retained external exact product/coverage-ELF replay archive; not included in Git raw packet.'})
(out/'external-replay-artifacts.json').write_text(json.dumps(external,indent=2)+'\n')
# Preserve compact cleanup proof, not another copy of archived historical fixtures.
cleanup=Path('/tmp/dandrum-evidence/legacy-engine-fixture-cleanup-20261023');dest=out/'legacy-cleanup-proof';dest.mkdir(exist_ok=True);shutil.copy2(cleanup/'cleanup.json',dest/'cleanup.json')
packet=root/'docs/migrations/evidence/trigger-selected-snapshot-foundation-2026-10-23';packet.mkdir(exist_ok=True);members=[]
with tarfile.open(packet/'raw.tar.gz','w:gz',compresslevel=1) as t:
 for p in sorted(out.rglob('*')):
  if p.is_dir():continue
  assert stat.S_ISREG(p.lstat().st_mode),str(p)
  if p.suffixes[-2:]==['.tar','.gz']:continue
  data=p.read_bytes();name=str(p.relative_to(out));members.append({'path':name,'bytes':len(data),'sha256':sha(data)});t.add(p,arcname=name,recursive=False)
with tarfile.open(packet/'raw.tar.gz') as t:
 actual={m.name:m for m in t};assert set(actual)=={r['path'] for r in members}
 for r in members:
  h=hashlib.sha256();f=t.extractfile(actual[r['path']]);size=0
  while b:=f.read(1024*1024):size+=len(b);h.update(b)
  assert size==r['bytes'] and h.hexdigest()==r['sha256']
(packet/'raw-index.json').write_text(json.dumps({'archive_sha256':file_sha(packet/'raw.tar.gz'),'members':members},indent=2)+'\n')
current=[]
for line in subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True).splitlines():
 name=line[3:]
 if name.startswith(str(packet.relative_to(root))+'/'):continue
 p=root/name;assert p.is_file() and not p.is_symlink();current.append({'path':name,'status':line[:2],'mode':oct(stat.S_IMODE(p.stat().st_mode)),'sha256':file_sha(p)})
(packet/'binding.json').write_text(json.dumps({'base':base,'scope':'Task 5.1 foundation plus only selected-resource admission/status from 5.2 and trusted chooser ingress from 5.4; no task/scenario closure or beta readiness claim.','current_source':current,'source_replay':'raw.tar.gz:portable-source-replay.json','external_binary_replays':'raw.tar.gz:external-replay-artifacts.json','red':'native-chooser-red-corrected: actual copied prechange CLAP/React returned capabilityUnavailable after literal signed PCM, before production edits. Missing-API compilation and incorrect selector/display setup failures are not RED.','limits':'16 files, 64 MiB encoded/file, 256 MiB encoded + 512 MiB decoded live union, 256 unique resources, one shared worker/chooser, 32 terminal outcomes; explicit failures and immutable real metadata/content identities.','validator':'Current copied release: 34 successes / 10 skips / zero failures; unfiltered official validator and fresh production React bundle.','strict_lint':'Session, host, native editor and GUI adapter strict Clippy PASS. Engine strict Clippy FAIL129 baseline errors; all330 all-target diagnostic occurrences exactly unchanged. No suppression.','coverage':'Snapshot 13/13 functions,75/75 lines,95/95 regions. Final catalog19/19 functions,186/187 lines,223/224 regions; selection27/27 functions,251/258 lines,321/339 regions. Fresh actual native local-owner mappings/assertions retained; no branch coverage claim. Gaps and instrumentation setup failures explicit.','mutation':'Excluded; none run or injected.','resources':'Disk-backed targets, one heavy job,8GiB disk/RAM guards; exact per-run scratch cleanup; all reusable caches/raw profiles preserved. Four max-catalog probes at about834MiB peak debug RSS and640MiB generated WAV cleanup. Old33 never-reused source fixtures archived then cleaned,912MiB removed,about845MiB net recovered; no caches deleted.','pending':'Full-patch publication, production import/mapping/history/Undo, portable state, installed source-hidden/offline proof, physical input/callback acceptance and named DAW remain in active tasks. VST3/standalone deferred.'},indent=2)+'\n')
(packet/'README.md').write_text('''# Selected-sample foundation

This boundary adds immutable selected WAV snapshots, an instance-owned bounded catalog, selected-resource admission/status, and a trusted asynchronous GTK chooser through the existing CLAP/React transport. It advances tasks 5.1, 5.2 and 5.4 without closing their checkboxes or any beta scenario. Full-patch publication, production import/mapping/history and Undo, portable state, installed offline proof, physical input and named-DAW acceptance remain pending. VST3 and standalone remain deferred.

The genuine pre-change behavioral RED uses an actual copied CLAP and production React bundle: packaged MIDI 36 renders literal negative PCM, then `chooseSamplerFiles` returns `capabilityUnavailable`. The later GREEN selects a literal 60-byte PCM16 WAV through the real GTK chooser, checks its independently fixed SHA-256 and decoded metadata, overwrites/removes the original, and recovers the unchanged result after complete editor recreation. Destroying another unadmitted chooser destroys its actual X11 window and reports cancellation in a new editor. Accepted state and signed packaged playback remain unchanged. GTK API-driven selection is native contract evidence; it is not physical input or complete production import acceptance.

Engine, catalog and controller tests cover immutable source identity, filesystem fallback rejection, strict-rate policy, foreign/stale authority, bounded admission/outcomes, shared-worker backpressure, atomic invalid batches, malformed decode, valid retry, worker shutdown and view-independent results. Real selected samples pass through engine preparation and cross-thread runtime handoff, reset and reclamation: literal -0.75 changes to +0.25 while an independent instance retains -0.25. Callback allocation/deallocation counters stay zero, and retired sample bytes remain charged until control-thread destruction. A covered refactor stores the mapping job's context behind one Box rather than boxing jobs at every consumer.

After independent review, two characterization gaps were corrected without changing production code. A real session now prepares and commits 44,100.5 Hz and 1,234.5678 Hz configurations after original-file/root removal, with every rendered frame checked against the existing independent signed PCM/time oracle. Native acquisition tests cover final symlinks, directories, atomic invalid batches and a valid non-UTF-8 OS filename with exact owned content. The FIFO check runs in an owned child with a two-second deadline, kill/wait cleanup and a completion marker; a zero-test child cannot satisfy it. Strict Clippy/formatting and fresh focused LLVM coverage pass. A second independent review found that focused coverage had overwritten four earlier full-owner test streams. Their original exit receipts remain, but those mismatched streams are explicitly not full-owner evidence. Both complete owning suites were rerun successfully into a separate directory with exclusive log creation, and every new stream hash was verified. The old receipts, exact mismatch record and both FAIL reviews remain retained. These are honest GREEN characterizations, not manufactured historical RED.

Final focused LLVM coverage is 13/13 snapshot functions, 75/75 lines and 95/95 regions; 19/19 catalog functions, 186/187 lines and 223/224 regions; and 27/27 selection-controller functions, 251/258 lines and 321/339 regions. Collision, identity-exhaustion and unexpected private worker/routing defenses remain explicit gaps. Fresh native instrumentation verifies mappings for all intended local owners. The first adapter-only run and a cached-dependency setup attempt are kept distinct; neither is presented as full owner coverage. No branch coverage or mutation score is claimed.

The current copied GUI-enabled release, with a freshly built production React bundle, passes the unfiltered official validator: **34 successes, 10 skips, zero failures**. Session, host, editor and adapter strict Clippy pass. Engine strict Clippy still fails on 129 baseline errors; all 330 all-target diagnostic occurrences match the published baseline exactly. The broad adapter invocation without a staged fixture, the X11 sandbox denial, missing-API compiler checks and wrong Python class selectors are retained setup failures, not behavioral RED or product regressions. Normal commit/push hooks and independent exact-candidate review remain publication gates.

Four production catalog probes use real 64 MiB mono/stereo WAVs and worker-thread decoding. Four-file cases retain exactly 256 MiB encoded content and 536,870,560 decoded-capacity bytes, peak at about 834 MiB debug-process RSS, reject a fifth distinct file, reuse duplicate content without another decode, and release charged usage to zero. This is a measured headless debug workload, not a universal RSS or DAW guarantee. All 640 MiB of probe WAVs were removed after workers joined. Runs use physical disk targets, one heavy job and 8 GiB disk/RAM guards. Reusable caches stay; owned scratch is cleaned. Thirty-three historical disposable fixture copies were archived, byte-verified and removed, recovering about 845 MiB net without deleting linked Cargo caches.

`raw.tar.gz` contains commands, logs, source replay blobs, profiles, measurements and cleanup receipts, indexed by SHA-256. Source reconstructs from the recorded Git base and content-addressed blobs; common manifests and wiring are bound explicitly. Large exact ELF/product replay archives remain outside the checkout at the indexed paths and hashes. No build target directory, dependency cache or generated audio payload is committed. Mutation remains explicitly excluded. Main stays at 68dd655.
''')
print(json.dumps({'packet':str(packet),'members':len(members),'source_phases':len(phases),'raw_bytes':(packet/'raw.tar.gz').stat().st_size,'external_replays':len(external)}))
