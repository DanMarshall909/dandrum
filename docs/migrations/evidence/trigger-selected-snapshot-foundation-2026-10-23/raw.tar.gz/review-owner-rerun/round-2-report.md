# Independent selected-snapshot foundation review — round 2

**FAIL.** R1 and R2 are resolved. One packet-integrity correction remains: focused coverage runs overwrote four raw full-owner test streams, leaving their recorded hashes uncheckable. No production defect or additional implementation scope is asserted.

## Identity and full-candidate reconstruction

The complete 31-path candidate independently reconstructs to tree `5365d6a645e0bc56107aae7b56edf6da1d9ceead`. Manifest SHA-256 is `9e4898e0615e070dadb435c4ba634e556b6d8aafe290d03db086faeb8ba1bafa`. Worktree `/tmp/dandrum-lanes/integration`, branch `lane/trigger-integration-20261020`; base, current HEAD, recorded upstream and merge base are all `2ea523c47c3022c4bf72a5500130083bb6d0bc42`. Upstream is `refs/remotes/origin/feat/juce-free-host-adapters`; the integration lane has no configured upstream.

Every path's status, Git mode, staged object, index bytes and worktree SHA matches. The complete index tree was constructed in memory without writing Git. Compared with round 1, all production, original tests, build wiring and specification bytes are unchanged. Only two maintained test-owner paths are added to the candidate, plus the four regenerated evidence packet files. There are no unrelated/excluded paths. `reconstruction.json` contains the entire independent inventory.

Main is clean at `68dd6553a2f07e71e2fe09ee1d7094d518559937`. The current tracker hash matches `35f34484a886d0ca24db7ad8678031928c8458e5b5ae5b00abc72861a94c3158`. The earlier review, packet and failure history remain under `round-1`. Root retains sole mutable ownership; this reviewer wrote only review artifacts and ran the explicitly leased cached test ELFs. No Cargo, build, network, native GUI/service, mutation, source or Git operation occurred.

## Task-to-implementation matrix

| Accepted portion | Implementation and review | Status |
| --- | --- | --- |
| 5.1 immutable bytes, decoder metadata and explicit preparation authority | sample_snapshot, LoadedSample encoded lease and ResourceResolver; unchanged and reassessed against the full original tests/evidence | Sound within foundation scope. |
| 5.1 bounded ownership, deduplication and live-union accounting | SampleCatalog, jobs/completions and actual runtime retained samples; original reservation/rejection/runtime/memory assertions remain applicable | Sound within measured scope. |
| 5.1 selected authority through session reconfiguration | InstrumentSession context preservation, now exercised through actual prepare/commit after source/root loss | R1 resolved. |
| 5.2 selected-resource admission/status only | v1 optional commands, opaque permit, bounded phase/outcome queue and shared worker | Original stale/foreign/retry/backpressure/view-loss evidence remains applicable. |
| 5.4 trusted native ingress only | GTK chooser and native file-open helper; new real filesystem acquisition tests | R2 resolved; physical-input/full import still pending. |
| Maintained verification registration | CMake selected-snapshot case/Python registration; new tests live in existing normal owner suites | No registration regression found. |
| Complete 5.1/5.2/5.4 tasks and beta scenarios | Checkboxes/maps unchanged | No closure; still 5/17 complete. |
| Full-patch/history/import, portable state, installed/physical/DAW acceptance | Explicitly pending | Not earned or implemented by this review. |
| Future products | CLAP-only beta; VST3/standalone deferred with direct coupler-rs/vst3-rs preference/gates | Unchanged and preserved. |

## Criterion-to-test matrix

| Criterion | Assertions/evidence | Assessment |
| --- | --- | --- |
| Owned identity and decoded metadata | Literal WAV/fixed SHA, channel/frame/rate and signed sample oracles | Existing evidence remains valid. |
| Source/root removal and no selected fallback | Engine resolver decoy rejection; copied-native overwrite/removal/recreated Ready | Existing evidence remains valid. |
| Reconfiguration preserves selected content | New `admitted_selected_content_survives_real_session_reconfiguration_after_source_loss` removes the whole original root, prepares and commits 44,100.5 and 1,234.5678 Hz through actual InstrumentSession APIs, asserts unchanged authoring snapshot and every signed PCM frame/end point, plus wrong-note silence | R1 resolved; independently rerun 1/1. |
| Native regular/non-UTF-8/symlink/nonregular acquisition | New `native_acquisition_rejects_nonregular_paths_and_reads_exact_os_bytes` opens the actual helper, decodes through catalog, compares exact encoded bytes and display name, rejects final symlink/directory/mixed batch/count and permits retry | R2 resolved; independently rerun. |
| Native FIFO cannot wait for a writer | New parent launches exact ignored child against a real FIFO with no writer; two-second bound, kill/wait containment, successful result plus post-assertion completion marker | R2 resolved; independently rerun; zero-test exit cannot pass. |
| Bounded catalog, atomic failure and runtime reclamation | Existing six catalog tests, literal -.75 to +.25 and independent -.25, zero callback allocations/deallocations, retired charge until control destruction and max-size debug probes | Strong existing owning-layer evidence, independently exercised in round 1. |
| v1 bounds, stale/foreign/replay authority and session-owned results | Existing protocol test and nine selection-controller cases, actual GTK lifecycle contract | Existing evidence remains valid. |
| Current repair owners' full normal suites | checks.json reports success but four raw streams now belong to later focused coverage runs | R3: retained-output integrity gap. |
| Full production import/mapping/Undo, fresh restore, installed offline/native/DAW | No foundation completion claim | Remain pending. |

## R3 — Coverage overwrote full-owner raw test evidence (P2)

The packet's `review-repair/checks.json` contains hashes for the full instrument-session and CLAP adapter library test stdout/stderr. `verify.py` writes these under `{owner}-test.stdout` and `{owner}-test.stderr`. The later `coverage.py` uses exactly those names for its focused test invocations. All four files now disagree with `checks.json`; all focused coverage log hashes do match `coverage-phases.json`.

The full-owner supervisor stdout preserves only six action/exit lines, not the raw test output. Thus the full-suite claims have exit receipts but lack the matching retained streams required for source-bound review. `owner-log-hash-mismatches.json` preserves each expected/actual hash and a short actual-content excerpt. This is an evidence failure, not a failing product assertion.

Recover the original four streams matching their hashes if available; otherwise rerun full current owner suites into distinct phase-owned names with fresh source-bound receipts. Preserve and disclose the overwritten history, separate ordinary and coverage log namespaces, regenerate the complete packet/index/binding/manifest and resubmit the whole candidate. No source implementation, mutation or fabricated RED is needed.

## Whole-candidate evidence and test effectiveness

All 1,397 indexed raw archive members match their declared sizes/hashes and are regular unique safe paths. All 8,903 source entries across 57 phases reconstruct from the recorded immutable base/content blobs; all 15 common current inputs match. All 15 external binary replay archives, totaling 943,333,215 bytes, match their indexed sizes/hashes. These archive matches cannot cure an inconsistent internal receipt; they establish that the frozen packet faithfully contains the R3 mismatch.

The original genuine copied-native RED remains valid: fixed signed packaged audio precedes actual capabilityUnavailable for chooser admission. Compiler/setup failures are still kept distinct. R1/R2 additions are honest GREEN characterization of unchanged production code, with no invented historical RED and no mutation/fault injection. R1 reuses the established independent linear PCM/time oracle, avoiding a duplicated mapper. R2 uses real kernel filesystem behavior rather than a fake path abstraction. The child-only test writes its marker only after checking FIFO type and rejection; timeout/error handling reaps its exact process.

Fresh LLVM exports map both repair sources canonically (including the adapter #[path] filename containing ../../). The R1 test, both R2 parents and FIFO child each have execution count 1. Original snapshot coverage remains 13/13 functions, 75/75 lines, 95/95 regions; catalog 19/19 functions, 186/187 lines, 223/224 regions; controller 27/27 functions, 251/258 lines, 321/339 regions. Defensive collision/identity/private-routing gaps remain explicit, and no branch or mutation score is claimed.

The retained current release validator remains 34 successes/10 skips/zero failures. Original actual GTK acquisition/source-loss/recreation/destruction evidence is still production-source-valid. Engine strict Clippy remains the disclosed 129-error baseline failure with 330 unchanged diagnostic occurrences. Session/host/editor/adapter strict lint evidence remains; new repair fmt/Clippy raw streams match their receipts. The existing broader adapter suite predates the final context indirection; that limitation remains disclosed rather than converted to a fresh whole-adapter claim.

## Independent runs and cleanup

Executed only the exact newly hash-bound cached test ELFs through the owned supervisor, with review-directory cwd/TMPDIR/LLVM profiles:

- R1: 1 passed; test body 0.03 s, supervisor/digest recheck 0.243 s.
- R2: 2 parents passed (including the bounded actual FIFO child); test body 0.03 s, supervisor/digest recheck 0.239 s.

No rebuild, GUI or native service occurred. Both ELF hashes are unchanged. Guardian proofs report all_children_reaped; cleanup records no remaining workers and both owned scratch directories removed. Root was notified and both read/execute leases returned immediately. `independent-execution.json` retains complete commands, hashes, raw output and cleanup receipts. Round 1 independently passed nine selection-controller and six catalog/runtime cases; those results retain their original source scope.

## Architecture, security, alternatives and publication

The entire unchanged foundation was reassessed alongside its repaired tests. Engine/session remain format-neutral; GTK/CLAP types stay at the edge. The browser cannot supply file paths/bytes/metadata; opaque instance/view permits gate acquisition. The catalog atomically accepts complete batches and pins encoded charges while prepared/active/retired sample consumers remain alive. The shared worker bounds preparation and shutdown; disposable view callbacks use weak Core ownership. Real file flags, regular-file validation and exact native path bytes now have direct tests. All work remains off audio, and native API-driven evidence is not mislabeled physical input.

The Arc-backed immutable owner plus weak accounting remains simpler and safer for these requirements than a global mutable cache or reopened originals. The existing context Box avoids repeated boxing at worker consumers. The repairs add only focused owning tests, reusing the existing waveform oracle and native helper; no new framework or decoder is justified. No additional product change is requested.

Publication helper hashes and updated tracker-template hash match the reviewed envelope. It remains finite: exact strict OpenSpec/spec-coverage/diff validations; exact-tree commit with normal hooks; fetch requiring unchanged upstream; ordinary nonforce push; four known fast-forwards; deterministic guarded tracker append; bounded owned scratch cleanup and verified final archive. Main and reusable targets/profiles/cache/evidence must remain preserved. Mutation remains explicitly excluded. The envelope is recorded exactly in verdict.json but **this FAIL does not authorize publication**.

The earlier R1/R2 findings are closed by evidence. R3 is the sole outstanding correction. No task/scenario or beta closure is earned. The existing raw-evidence retention instructions already cover this issue; separate phase namespaces are a concrete repair to the one-off evidence scripts, not a proposal for additional standing guidance. All reviewer jobs are stopped and all leases returned.
