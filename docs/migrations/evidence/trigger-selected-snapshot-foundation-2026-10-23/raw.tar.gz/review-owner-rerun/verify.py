from pathlib import Path
import subprocess,json,time,hashlib,sys
out=Path(__file__).parent;c='/home/dan/.cargo/bin/cargo';rows=[]
for owner,extra in [('instrument-session',[]),('clap-adapter',['--features','trigger-editor','--lib'])]:
 argv=[c,'test','--manifest-path','src/'+owner+'/Cargo.toml','--offline','--locked',*extra];start=time.monotonic();p=subprocess.run(argv,cwd='/tmp/dandrum-lanes/integration',capture_output=True);name=owner+'-full-owner'
 for suffix,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  dest=out/(name+'.'+suffix)
  with dest.open('xb') as f:f.write(data)
 rows.append({'name':name,'argv':argv,'cwd':'/tmp/dandrum-lanes/integration','exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
