from pathlib import Path
import os,sys,subprocess,json,shlex,time,hashlib,shutil,tarfile
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;owner=sys.argv[1];assert owner in ('engine','host')
cache=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov');profiles=out/(owner+'-profiles');profiles.mkdir();stage=Path(os.environ['TMPDIR'])/(owner+'-objects');stage.mkdir();rows=[]
manifest='src/'+('rust-engine' if owner=='engine' else 'trigger-host')+'/Cargo.toml';cargo='/home/dan/.cargo/bin/cargo';env=dict(os.environ,CARGO_TARGET_DIR=str(cache),CARGO_LLVM_COV_TARGET_DIR=str(cache),CARGO_LLVM_COV_BUILD_DIR=str(cache),CARGO_BUILD_JOBS='1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,argv,childenv=None):
 start=time.monotonic();p=subprocess.run(argv,cwd=root,env=childenv or env,capture_output=True)
 (out/(owner+'-'+label+'.stdout')).write_bytes(p.stdout);(out/(owner+'-'+label+'.stderr')).write_bytes(p.stderr)
 rows.append({'label':label,'argv':argv,'exit_code':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/(owner+'-coverage-phases.json')).write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0,label
 return p.stdout.decode()
text=run('show-env',[cargo,'llvm-cov','show-env','--manifest-path',manifest,'--sh'])
for line in text.split('\n'):
 if not line:continue
 parts=shlex.split(line);assert len(parts)==2 and parts[0]=='export',line
 key,sep,value=parts[1].partition('=');assert sep;env[key]=value
for key in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR'):env[key]=str(cache)
env['LLVM_PROFILE_FILE']=str(profiles/(owner+'-%m-%p.profraw'))
(out/(owner+'-coverage-environment.json')).write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('CARGO','__CARGO','LLVM','RUSTC'))},indent=2)+'\n')
selection=['--test','selected_snapshot'] if owner=='engine' else ['--lib','--test','selected_admission','--test','session_jobs','--test','protocol']
text=run('compile',[cargo,'test','--offline','--locked','--manifest-path',manifest,*selection,'--no-run','--message-format=json'])
records=[json.loads(line) for line in text.splitlines() if line.startswith('{')];tests=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('profile',{}).get('test')];assert len(tests)==(1 if owner=='engine' else 4),len(tests)
objects=[]
for i,r in enumerate(tests):
 source=Path(r['executable']);target=stage/(str(i)+'-'+r['target']['name']);shutil.copy2(source,target);assert sha(source)==sha(target);objects.append({'path':target.name,'sha256':sha(target),'bytes':target.stat().st_size,'cargo_artifact':r})
 run('test-'+str(i),[str(target),'--test-threads=1','--nocapture'])
sysroot=Path(subprocess.check_output(['/home/dan/.cargo/bin/rustc','--print','sysroot'],text=True).strip());tools=sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/bin';raw=sorted(profiles.glob('*.profraw'));assert raw
merged=out/(owner+'-focused.profdata');run('merge',[str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in raw],'-o',str(merged)])
args=[str(stage/objects[0]['path'])]
for obj in objects[1:]:args.extend(['--object',str(stage/obj['path'])])
args.extend(['--instr-profile',str(merged)])
run('export',[str(tools/'llvm-cov'),'export',*args]);run('annotation',[str(tools/'llvm-cov'),'show',*args,'--show-line-counts-or-regions'])
archive=out/(owner+'-coverage-objects.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for obj in objects:t.add(stage/obj['path'],arcname=obj['path'],recursive=False)
with tarfile.open(archive) as t:
 for obj in objects:assert hashlib.sha256(t.extractfile(obj['path']).read()).hexdigest()==obj['sha256']
binding={'owner':owner,'objects':objects,'archive_sha256':sha(archive),'profiles':{p.name:sha(p) for p in raw},'merged_sha256':sha(merged),'llvm_tools':{n:sha(tools/n) for n in ('llvm-cov','llvm-profdata')},'scope':'Fresh isolated raw profiles, local-root-crate instrumentation through cargo-llvm-cov show-env; existing physical target and all old shared raw profiles preserved. No workspace/cache cleaning, mutation, native GUI or full-beta coverage claim.'}
(out/(owner+'-coverage-binding.json')).write_text(json.dumps(binding,indent=2)+'\n');print(owner,'focused coverage complete:',len(tests),'ELFs',len(raw),'profiles',flush=True)
