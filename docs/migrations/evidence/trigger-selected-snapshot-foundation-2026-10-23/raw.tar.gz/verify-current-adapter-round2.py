"""One-off exact-source copied products and dynamic/native owner checks."""
from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,tarfile,sys
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;stage=Path(os.environ['TMPDIR'])/'adapter-products';stage.mkdir();rows=[]
cargo='/home/dan/.cargo/bin/cargo';manifest='src/clap-adapter/Cargo.toml';cache=Path(os.environ['CARGO_TARGET_DIR']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,argv,env=None):
 start=time.monotonic();p=subprocess.run(argv,cwd=root,env=env or os.environ,capture_output=True)
 (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
 rows.append({'name':name,'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'adapter-current-r2-r2-phases.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0,name
 return p.stdout.decode()
run('current-r2-headless-build',[cargo,'build','--offline','--locked','--manifest-path',manifest,'--lib'])
headless=stage/'DandrumHeadlessProof.clap';shutil.copy2(cache/'debug/libdandrum_clap_adapter.so',headless)
run('current-r2-gui-build',[cargo,'build','--offline','--locked','--manifest-path',manifest,'--features','trigger-editor','--lib'])
plugin=stage/'DandrumTrigger.clap';shutil.copy2(cache/'debug/libdandrum_clap_adapter.so',plugin)
prior=Path('/tmp/dandrum-evidence/trigger-clap-precise-clock-repair');frontend=json.loads((prior/'native-release-frontend-source.json').read_text());assert all(sha(root/p)==h for p,h in frontend.items())
expected=json.loads((prior/'native-release-product-binding.json').read_text())['files']
with tarfile.open(prior/'native-release-product.tar.gz') as t:
 for m in t:
  if not m.name.startswith('DandrumTrigger.resources/'):continue
  assert m.isfile() and '..' not in Path(m.name).parts and not Path(m.name).is_absolute();data=t.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==expected[m.name]['sha256'];p=stage/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
for a,b in [('examples/patches/advanced-drum-kit.yaml','instrument/advanced-drum-kit.yaml'),('examples/patches/assets/advanced-drums.wav','instrument/assets/advanced-drums.wav')]:assert sha(root/a)==sha(stage/'DandrumTrigger.resources'/b)
env=dict(os.environ,DANDRUM_CLAP_PLUGIN_PATH=str(headless),DANDRUM_TRIGGER_CLAP_PLUGIN_PATH=str(plugin),DANDRUM_TRIGGER_GUI_PLUGIN_PATH=str(plugin),DISPLAY=':10.0',XAUTHORITY='/home/dan/.Xauthority',GDK_BACKEND='x11')
text=run('current-r2-adapter-compile',[cargo,'test','--offline','--locked','--manifest-path',manifest,'--features','trigger-editor','--no-run','--message-format=json'],env)
artifacts=[json.loads(l) for l in text.splitlines() if l.startswith('{')];tests=[r for r in artifacts if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('profile',{}).get('test')];assert tests
for r in tests:
 name=r['target']['name'];source=Path(r['executable']);dest=stage/(name+'-test');shutil.copy2(source,dest);assert sha(source)==sha(dest)
 listing=run('current-r2-'+name+'-listing',[str(dest),'--list'],env)
 ignored_listing=run('current-r2-'+name+'-ignored-listing',[str(dest),'--list','--ignored'],env)
 cases=[l.removesuffix(': test') for l in listing.splitlines() if l.endswith(': test')]
 ignored={l.removesuffix(': test') for l in ignored_listing.splitlines() if l.endswith(': test')}
 for i,case in enumerate(cases):
  if case.endswith('allocator_audit_child'):continue # Only its calibrated parent may launch this.
  output=run('current-r2-'+name+'-case-'+str(i),[str(dest),case,'--exact','--nocapture','--test-threads=1',*(['--ignored'] if case in ignored else [])],env)
  assert '1 passed; 0 failed' in output,case

files={str(p.relative_to(stage)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(stage.rglob('*')) if p.is_file()}
(out/'adapter-current-r2-r2-product-binding.json').write_text(json.dumps({'files':files,'frontend_source':frontend,'artifacts':tests,'scope':'Current copied debug products and actual GTK API/React native contract checks; physical input, installed source-hidden and named DAW gates remain pending; allocator audit children run only through their calibrated parents.'},indent=2)+'\n')
with tarfile.open(out/'adapter-current-r2-r2-products.tar.gz','w:gz') as t:
 for name in files:t.add(stage/name,arcname=name,recursive=False)
