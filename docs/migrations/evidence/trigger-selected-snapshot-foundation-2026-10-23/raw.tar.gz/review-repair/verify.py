from pathlib import Path
import subprocess,json,time,hashlib,sys
out=Path(__file__).parent;c='/home/dan/.cargo/bin/cargo';rows=[]
for owner,extra in [('instrument-session',[]),('clap-adapter',['--features','trigger-editor','--lib'])]:
 for action,args in [('fmt',['--','--check']),('test',['--offline','--locked',*extra]),('clippy',['--offline','--locked',*extra,'--all-targets','--no-deps','--','-D','warnings'])]:
  argv=[c,action,'--manifest-path','src/'+owner+'/Cargo.toml',*args];start=time.monotonic();p=subprocess.run(argv,cwd='/tmp/dandrum-lanes/integration',capture_output=True);name=owner+'-'+action;(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);rows.append({'name':name,'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
  if p.returncode:sys.exit(p.returncode)
