"""Focused review-repair coverage, exact leased cache ELFs, no cache cleaning."""
from pathlib import Path
import os,json,subprocess,shlex,time,hashlib,tarfile
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;c='/home/dan/.cargo/bin/cargo';cache=Path(os.environ['CARGO_TARGET_DIR']);rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,argv,env):
 start=time.monotonic();p=subprocess.run(argv,cwd=root,env=env,capture_output=True);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);rows.append({'name':name,'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'coverage-phases.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0,name;return p.stdout.decode()
sysroot=Path(subprocess.check_output(['/home/dan/.cargo/bin/rustc','--print','sysroot'],text=True).strip());tools=sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/bin'
for owner,extra,selection in [('instrument-session',['--test','precise_clocks'],['admitted_selected_content_survives_real_session_reconfiguration_after_source_loss','--exact']),('clap-adapter',['--features','trigger-editor','--lib'],['native_acquisition_'])]:
 manifest='src/'+owner+'/Cargo.toml';env=dict(os.environ);shown=run(owner+'-show-env',[c,'llvm-cov','show-env','--manifest-path',manifest,'--sh'],env)
 for line in shown.splitlines():
  parts=shlex.split(line);assert len(parts)==2 and parts[0]=='export';k,sep,v=parts[1].partition('=');assert sep;env[k]=v
 for key in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR'):env[key]=str(cache)
 profiles=out/(owner+'-profiles');profiles.mkdir();env['LLVM_PROFILE_FILE']=str(profiles/'%m-%p.profraw')
 safe={k:v for k,v in env.items() if k in {'CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','LLVM_PROFILE_FILE','RUSTC_WRAPPER','__CARGO_LLVM_COV_RUSTC_WRAPPER','__CARGO_LLVM_COV_RUSTC_WRAPPER_RUSTFLAGS','__CARGO_LLVM_COV_RUSTC_WRAPPER_CRATE_NAMES'}};(out/(owner+'-environment.json')).write_text(json.dumps(safe,indent=2)+'\n')
 text=run(owner+'-compile',[c,'test','--offline','--locked','--manifest-path',manifest,*extra,'--no-run','--message-format=json'],env);records=[json.loads(l) for l in text.splitlines() if l.startswith('{')];artifacts=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('profile',{}).get('test')];assert len(artifacts)==1
 elf=Path(artifacts[0]['executable']);assert elf.resolve().is_relative_to(cache.resolve());digest=sha(elf);run(owner+'-test',[str(elf),*selection,'--nocapture','--test-threads=1'],env)
 raw=sorted(profiles.glob('*.profraw'));assert raw;merged=out/(owner+'.profdata');run(owner+'-merge',[str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in raw],'-o',str(merged)],env)
 args=[str(elf),'--instr-profile',str(merged)];run(owner+'-export',[str(tools/'llvm-cov'),'export',*args],env);run(owner+'-annotation',[str(tools/'llvm-cov'),'show',*args,'--show-line-counts-or-regions'],env)
 archive=out/(owner+'-objects.tar.gz')
 with tarfile.open(archive,'w:gz',compresslevel=1) as t:t.add(elf,arcname=elf.name,recursive=False)
 with tarfile.open(archive) as t:assert hashlib.sha256(t.extractfile(elf.name).read()).hexdigest()==digest
 assert sha(elf)==digest
 (out/(owner+'-binding.json')).write_text(json.dumps({'artifact':artifacts[0],'object_sha256':digest,'archive_sha256':sha(archive),'profiles':{p.name:sha(p) for p in raw},'merged':sha(merged),'llvm_tools':{n:sha(tools/n) for n in ['llvm-cov','llvm-profdata']},'scope':'R1 real selected session prepare+commit precise reconfiguration after complete source/root loss, or R2 actual native regular/symlink/nonregular/OS-byte/FIFO acquisition with bounded owned child. Current behavior characterization; no product edits or invented RED/faults.','lease':'Read exact ELF under exclusive build lease, hash before/after/archive; no duplicate scratch copy or cache cleaning.'},indent=2)+'\n');print(owner,'coverage complete',len(raw),'profiles',flush=True)
