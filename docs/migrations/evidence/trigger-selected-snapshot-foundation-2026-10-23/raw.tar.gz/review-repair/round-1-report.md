# Independent selected-snapshot foundation review

**FAIL.** Two actionable regression-evidence gaps remain in the accepted foundation contract. No source defect is asserted from inspection alone. Both corrections are bounded owning-layer characterization tests; no full-patch, production import, persistence, physical-input, installed or DAW implementation is requested by this verdict.

## Frozen identity and review independence

- Worktree: `/tmp/dandrum-lanes/integration`; branch `lane/trigger-integration-20261020`.
- Base/current/integration base/recorded upstream: `2ea523c47c3022c4bf72a5500130083bb6d0bc42`.
- Upstream: `refs/remotes/origin/feat/juce-free-host-adapters`; no configured upstream for the integration lane.
- Independently reconstructed index tree: `ca9c04c61f741c11351222a07f5a9719e360f9d0`.
- Manifest SHA-256: `c68ca16837138aa56c63c429a13f7d9d83556aaf7b76c8212834c50358845756`.
- All 29 changed paths match their status, canonical Git mode, staged object, worktree SHA-256 and index bytes. No extra or excluded path. The index tree was reconstructed in memory from the complete staged entry list, without writing Git objects.
- Main remains clean at `68dd6553a2f07e71e2fe09ee1d7094d518559937`. Tracker SHA-256 remains `a18fa3e42f321a620a0690265fffd392b2ee47f7602caced1d4a107a7e817d38`.
- Read the project AGENTS, shared AI Rules, completion-review procedure, behavior-first-tdd, coverage-and-mutation, security-by-design and reflect instructions. No delegation, implementation, Git/tracker write, native service, network, Cargo or mutation operation occurred. The online shared-rule preflight was outside the explicit no-network review authorization.

`reconstruction.json` retains the complete independent path reconstruction. `verdict.json` binds the exact reviewed envelope as well as the candidate. The source is frozen; a repair creates a new candidate requiring a whole-candidate review.

## Task-to-implementation matrix

| Accepted task portion | Implementation | Assessment |
| --- | --- | --- |
| 5.1 immutable selected bytes and real decoder metadata | Engine sample_snapshot, LoadedSample encoded lease, ResourceResolver selected authority | Implemented; literal WAV identity/channel assertions and missing-authority decoy rejection are strong. |
| 5.1 bounded catalog, deduplication, live-union accounting | TriggerHost SampleCatalog/SelectionJob/Completion and weak retention | Implemented; reservations, invalid-batch rollback, foreign completion, real selected runtime ownership and measured max workloads evidenced. |
| 5.1 preparation/reconfiguration preservation | PreparationContext selected map; InstrumentSession clones context before changing rate | Code is coherent; **R1 lacks the owning session reconfiguration assertion**. |
| 5.2 selected-resource admission/status only | Existing v1 optional commands, NativeSelectionPermit, Selections phases and shared SessionWorker | Implemented; old envelope bounds remain; once-only chooser dispatch, stale/foreign authority, backpressure, retention and terminal eviction tested. |
| 5.4 trusted chooser ingress only | NativeFileSelection and CLAP GUI callback/service/open boundary | GTK success/source loss/editor recreation and unadmitted chooser X11 destruction evidenced; **R2 lacks native file-open safety/path tests**. |
| Maintained verification registration | CMake selected-snapshot native case and Python inventory | Registered in normal CTest structure; retained corrected registration checks distinguish invalid selectors. |
| Full 5.1/5.2/5.4 checkboxes and all beta scenarios | Remain unchecked/unearned | Correct: tasks remain 5/17 complete. No scenario map or checkbox is changed. |
| Remaining 5.3/5.5/6.x/7.x/8.x beta work | Full-patch/history/import, portable state, installed/native/DAW and release audit | Explicitly pending; this review neither requires implementation now nor grants completion. |
| Later products | future-products.md | CLAP-only first beta preserved; VST3/standalone deferred and direct coupler-rs/vst3-rs preference/gates retained. |

## Criterion-to-test matrix

| Foundation criterion | Executable evidence / assertions | Result |
| --- | --- | --- |
| Truthful immutable bytes, hash, rate, channels, frames and signed samples | `owned_snapshot_metadata_and_channels_come_from_the_retained_bytes`: literal 60-byte WAV and fixed SHA; fixed channel and downmix samples | Proven within engine scope. |
| Original/root loss, selected authority, strict rate and ordinary selected-directory compatibility | `selected_authority_survives_original_and_root_loss_without_filesystem_fallback`; ordinary-directory test; real native overwrite/removal/recreated Ready | Proven at stated layers. |
| Selected authority survives actual session reconfiguration | Context helper test plus ordinary filesystem session clock tests only | **R1: missing composition oracle.** |
| Encoded/decoded/count admission, reservations, atomic invalid batch, live deduplication | Catalog owner tests; production mono/stereo max probes | Proven at stated catalog scope. |
| Prepared/runtime/retired ownership and callback reclamation | `selected_runtime_pins_bytes_until_control_reclamation_without_callback_destruction`: -0.75 to +0.25, independent -0.25, zero callback allocation/deallocation, charge retained until control drop | Strong real-consumer evidence. |
| No browser file authority; v1 bounds/replay | `native_selection_commands_use_existing_bounds_without_browser_file_authority` plus existing protocol suite | Proven at protocol scope. |
| Admitted work survives view loss; unadmitted work revoked | 9 selected_admission tests; recreated Ready and cancelled actual chooser native test | Proven at controller/native-contract scope. |
| Outcome release/eviction, stale/foreign authority, worker busy/shutdown and valid retry | 9 selected_admission tests and catalog foreign-completion tests | Proven at controller scope. |
| FIFO nonblocking, final symlink rejection, exact native OS path bytes | Flags and PathBuf visible in code; tests currently start after open or use ordinary UTF-8 path | **R2: missing actual open-boundary oracle.** |
| Real GTK chooser acquires a supported file and destroys unadmitted window | Copied-native test with production React, fixed content hash and X11 query of destroyed chooser | Proven; GTK API driven, not physical-input acceptance. |
| Production full import/mapping/Undo and fresh selected restore | None claimed for this slice | Pending in full beta tasks. |

## Required corrections

### R1 — Selected ownership through session reconfiguration has no executable oracle (P2)

`src/instrument-session/src/lib.rs:577` / `InstrumentSession::prepare_realtime_render_configuration_owned`.

Requirement: selected-samples.md:74-76; task 5.1 selected-authority lifetime; behavior-first executable evidence.

Evidence: The changed method now clones PreparationContext before changing its rate. selected_snapshot.rs:85 tests that context helper directly, while selected_samples.rs:21 constructs a session and immediately creates a runtime. Neither calls session prepare/commit reconfiguration with selected content. Existing instrument-session precise_clocks/render_configuration fixtures use filesystem WAVs. Root confirmed no retained executable assertion for this selected-resource session boundary.

Consequence: A regression that drops the selected authority when reconfiguring the session can pass the supplied selected-resource tests. Correct-looking code and the existing filesystem-based clock suite do not prove the newly promised selected behavior.

Required outcome: Add an owning-layer behavior test creating a session from an admitted selected snapshot, removing/replacing its original source/root, preparing and committing a changed precise render configuration through the real InstrumentSession APIs, and asserting independently known signed output/timing from the resulting prepared consumer. Keep authority/lifetime assertions at the observable resource boundary. Run the test and owning suite/coverage; characterize current behavior honestly without inventing historical RED or injecting an excluded mutation. Update source-bound packet and resubmit the full frozen candidate.

### R2 — Native file acquisition safety promises are inspected but not tested (P2)

`src/clap-adapter/src/trigger/gui.rs:508` / `native_sample_files`.

Requirement: selected-samples.md:14-17 trusted Linux acquisition promises; task 5.4 trusted ingress subset; security-boundary test effectiveness.

Evidence: The new native acquisition function opens paths with O_NONBLOCK|O_NOFOLLOW|O_CLOEXEC and retains PathBuf for opening. The copied GTK test selects only an ordinary UTF-8 regular path. Catalog rejection tests receive already-opened File handles and therefore cannot exercise these open flags or preservation of non-UTF-8 OS path bytes. No retained test exercises a FIFO or final-component symlink at this function.

Consequence: Removing the nonblocking or no-follow protection, or converting the path through lossy display text before opening, would escape the current supplied assertions. These are reachable native input cases with UI-blocking or wrong-file consequences, not unreachable defensive branches.

Required outcome: Add focused actual-filesystem tests through the real native acquisition boundary for a FIFO without a writer (bounded nonblocking rejection), final-component symlink rejection, nonregular input, and a valid non-UTF-8 Linux filename whose exact content is acquired while only its bounded display basename is exposed. Retain a regular-file success control and atomic invalid-batch/retry evidence at the owning layer. A private helper test in the adapter is sufficient; do not expand to physical-input/full-beta acceptance. Use finite owned-process containment where a broken nonblocking contract could otherwise hang a test. Preserve existing GTK calibration and update the source-bound packet.

## Evidence quality and reconstruction

All 1,305 raw archive members match their indexed byte lengths and SHA-256 values; members are regular, unique and path-safe. All 8,432 source entries across 54 phases reconstruct from the immutable Git base or content-addressed replay blobs; all 15 common current inputs also match current files. All 13 externally retained replay archives, totaling 871,006,472 bytes, match their indexed sizes and hashes. This establishes replay identity, not automatic correctness of every recorded assertion.

The corrected preproduction copied-native RED explicitly logs successful signed packaged PCM, then fails because chooseSamplerFiles returns capabilityUnavailable. Missing-API compiler errors, unavailable X11, unstaged product fixture and incorrect Python class selectors are distinct setup failures and are not credited as behavioral RED. The candidate contains current native GREEN and official release validator evidence (34 successes, 10 skips, zero failures) with an actual production React bundle. The broader 77 adapter cases precede the last context indirection; subsequent owning session/host suites and current native/validator/lints qualify the final refactor scope. This is not a claim that every broader adapter case was rerun after that indirection.

Snapshot coverage is 13/13 functions, 75/75 lines, 95/95 regions; catalog 19/19 functions, 186/187 lines, 223/224 regions; selection controller 27/27 functions, 251/258 lines, 321/339 regions. Native coverage includes current local-owner mappings. Collision equality defenses, finite identity exhaustion, and unexpected private worker/routing defenses remain honest gaps. Branch coverage is unavailable. These diagnostic counts do not resolve R1/R2, which concern useful observable behavior. Mutation was explicitly excluded: none executed, injected or credited.

Session/host/editor/adapter strict Clippy pass. Engine strict Clippy remains a disclosed FAIL with 129 baseline errors; the 330 all-target diagnostic occurrences are unchanged, not a strict pass. The max catalog measurements are actual debug processes, peaking around 834 MiB for four 64 MiB files; they are not a DAW or universal RSS guarantee. The packet retains successful rejection, duplicate reuse, zero final charged usage and generated-WAV cleanup evidence.

## Independent execution

Under the root's explicit read/execute lease, directly ran the exact hash-bound cached ELFs through scripts/run-owned-verification.py from the review directory with review-owned TMPDIR and LLVM profiles. No Cargo invocation or rebuild occurred.

- selected_admission: **9 passed**, 0 failed; test body 0.25 s; owned supervisor plus digest recheck 0.534 s.
- samples::tests: **6 passed**, 0 failed; test body 0.08 s; owned supervisor plus digest recheck 0.372 s.

The resource-owner run includes the signed cross-thread runtime/reclamation oracle. Both ELF hashes are unchanged. Guardian receipts report all_children_reaped, remaining_workers is empty, and both exact owned scratch directories were removed. The read/execute lease was returned to root immediately afterward. `independent-execution.json` retains commands, results, hashes and cleanup receipts. An initial reviewer-side attempt used unavailable Python hashlib.file_digest and stopped before launching a test; the corrected streaming hash is the executed check. No product failure is inferred from that setup error.

## Architecture, security and alternatives

The engine remains independent of CLAP/GTK/Wry. Native code supplies already-opened regular File handles; the browser receives bounded metadata and cannot choose paths or manufacture decoder metadata. Opaque permit identity combines per-record Arc identity, live session attachment and phase checks, preventing equal numeric IDs in another instance from granting admission. Terminal metadata is bounded by 16 files, bounded basename/identity fields and the unchanged wire egress limit. The hash supplies content identity; it is not presented as an authentication credential.

Encoded bytes are pinned by the shared LoadedSample, so a runtime retaining decoded data also keeps the corresponding catalog charge alive. Weak catalog observations do not own buffers. Whole-batch construction commits entries only after successful preparation; rejection drops staged owners away from audio. The single preparation worker is shared with structural work; UI destruction cancels only choosing work, while admitted selection/result ownership survives. Callbacks hold a weak Core and no strong WebView. File operations remain outside audio. Blocking ordinary-file/network-filesystem IO is not claimed cancellable by worker shutdown; FIFO-specific opening is intended bounded but needs R2 evidence.

A global mutable cache or re-reading original paths would be smaller but break isolation/source-loss/lifetime requirements. A single owned materialization would add filesystem cleanup and fallback risks. Immutable Arc-backed decoded/encoded data with weak budget observation is a justified direct design here. The final one-Box MappingJob context indirection is simpler than boxing at every consumer and retains the existing worker/public APIs. No broader framework, decoder, dependency, new product or new infrastructure is needed to correct this review.

## Publication envelope and remaining work

All three frozen publication helper hashes and the tracker template hash match the manifest. The proposed envelope has no semantic source transformation: exact validations (strict owning OpenSpec, strict specs, check-spec-coverage, both diff checks); exact tree commit with normal hooks; unchanged-upstream fetch check at 2ea523c4; ordinary nonforce push to feat/juce-free-host-adapters; four known fast-forwards; deterministic tracker append guarded by the original hash; exact owned scratch cleanup after guardian closure; verified final review/publication archive. Main, reusable targets, profiles, evidence and the 1,766 Runtime cache entries must remain protected. The reviewer independently checked main and the tracker; root supplied the current cache inventory confirmation.

**No publication is authorized by this FAIL.** After R1/R2 characterization and proportionate tests/coverage, regenerate the complete packet/manifest and return the whole candidate for review. Retain all existing gaps and 5/17 task status. Do not broaden this repair into full beta work, manufacture historical RED, introduce mutation, or bypass normal hooks.

No additional standing-guidance change is proposed: the current behavior-first and security-boundary instructions already cover both findings. All reviewer jobs are stopped and all execution leases returned; only review artifacts were written.
