use dandrum_trigger_host::samples::{SampleCatalog, NativeSampleFile, SampleError};
use std::{fs::{File, OpenOptions}, io::{Write, Seek, SeekFrom}, path::{Path, PathBuf}, time::Instant};
const ENCODED: usize = 64 * 1024 * 1024;
fn generate(path: &Path, channels: u16, value: i16) {
    let mut file = File::create(path).unwrap();
    let payload = (ENCODED - 44) as u32;
    file.write_all(b"RIFF").unwrap(); file.write_all(&((ENCODED - 8) as u32).to_le_bytes()).unwrap();
    file.write_all(b"WAVEfmt ").unwrap(); file.write_all(&16_u32.to_le_bytes()).unwrap();
    file.write_all(&1_u16.to_le_bytes()).unwrap(); file.write_all(&channels.to_le_bytes()).unwrap();
    file.write_all(&48000_u32.to_le_bytes()).unwrap(); file.write_all(&(48000_u32 * u32::from(channels) * 2).to_le_bytes()).unwrap();
    file.write_all(&(channels * 2).to_le_bytes()).unwrap(); file.write_all(&16_u16.to_le_bytes()).unwrap();
    file.write_all(b"data").unwrap(); file.write_all(&payload.to_le_bytes()).unwrap();
    let mut block = [0_u8; 65536];
    for pcm in block.chunks_exact_mut(2) { pcm.copy_from_slice(&value.to_le_bytes()); }
    let mut remaining = payload as usize;
    while remaining != 0 { let count = remaining.min(block.len()); file.write_all(&block[..count]).unwrap(); remaining -= count; }
    assert_eq!(file.metadata().unwrap().len(), ENCODED as u64);
}
fn selected(path: &Path) -> NativeSampleFile {
    NativeSampleFile::new(path.file_name().unwrap().to_string_lossy().into_owned(), File::open(path).unwrap()).unwrap()
}
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let channels: u16 = args[1].parse().unwrap(); let count: usize = args[2].parse().unwrap();
    assert!(matches!(channels, 1 | 2) && matches!(count, 1 | 4));
    let root = PathBuf::from(&args[3]); std::fs::create_dir(&root).unwrap();
    let began = Instant::now(); let mut catalog = SampleCatalog::default();
    let mut results = Vec::new(); let mut paths = Vec::new();
    let values = [-24576_i16, -16384, -8192, 8192];
    for (i, value) in values.iter().copied().take(count).enumerate() {
        let path = root.join(format!("sample-{i}.wav")); generate(&path, channels, value);
        let work = catalog.begin(vec![selected(&path)]).unwrap();
        let completed = std::thread::spawn(move || work.prepare()).join().unwrap();
        let files = catalog.accept(completed).unwrap().expect("supported real PCM must decode");
        let sample = &files[0].sample;
        assert_eq!(sample.encoded_bytes().len(), ENCODED);
        assert_eq!(sample.sample().sample_rate_hz(), 48000);
        assert_eq!(sample.sample().source_channel_count(), channels);
        let frames = (ENCODED - 44) / (usize::from(channels) * 2);
        assert_eq!(sample.sample().frame_count(), frames);
        assert_eq!(sample.sample().source_sample(0, 0), Some(f32::from(value) / 32768.0));
        assert_eq!(sample.sample().source_sample(channels - 1, frames - 1), Some(f32::from(value) / 32768.0));
        assert_eq!(sample.sample().frames()[frames - 1], f32::from(value) / 32768.0);
        results.push(files); paths.push(path);
    }
    let usage = catalog.usage();
    assert_eq!(usage.encoded_bytes, count * ENCODED);
    assert_eq!(usage.decoded_bytes, count * 2 * (ENCODED - 44));
    assert_eq!(usage.resource_count, count);
    if count == 4 {
        let mut source = OpenOptions::new().write(true).open(&paths[0]).unwrap();
        source.seek(SeekFrom::Start(44)).unwrap(); source.write_all(&(-4096_i16).to_le_bytes()).unwrap(); drop(source);
        let work = catalog.begin(vec![selected(&paths[0])]).unwrap();
        assert!(matches!(catalog.accept(std::thread::spawn(move || work.prepare()).join().unwrap()), Ok(Err(SampleError::EncodedLimit))));
        assert_eq!(catalog.usage(), usage, "rejected new content preserves the full live union");
        let work = catalog.begin(vec![selected(&paths[1])]).unwrap();
        let duplicate = catalog.accept(std::thread::spawn(move || work.prepare()).join().unwrap()).unwrap().expect("a full catalog reuses admitted bytes");
        assert_eq!(catalog.usage(), usage);
        assert_eq!(duplicate[0].sample.content_sha256(), results[1][0].sample.content_sha256());
        drop(duplicate);
    }
    use std::os::unix::fs::MetadataExt;
    let removed: u64 = paths.iter().map(|p| std::fs::metadata(p).unwrap().blocks() * 512).sum();
    for path in &paths { std::fs::remove_file(path).unwrap(); }
    for (i, files) in results.iter().enumerate() {
        assert_eq!(files[0].sample.sample().source_sample(0, 0), Some(f32::from(values[i]) / 32768.0));
    }
    drop(results); assert_eq!(catalog.usage().encoded_bytes, 0); assert_eq!(catalog.usage().decoded_bytes, 0);
    std::fs::remove_dir(root).unwrap();
    println!("channels={channels} count={count} encoded={} decoded={} resources={} source_allocated_bytes_removed={removed} source_loss_retained=true final_usage=0 elapsed_seconds={:.6}", usage.encoded_bytes, usage.decoded_bytes, usage.resource_count, began.elapsed().as_secs_f64());
}
