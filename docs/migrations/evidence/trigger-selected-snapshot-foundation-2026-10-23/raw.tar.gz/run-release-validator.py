"""One-off source-bound native release build and unfiltered official validation."""
from pathlib import Path
import subprocess,os,json,time,hashlib,shutil,tarfile,sys
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;stage=Path(os.environ['TMPDIR'])/'native-release-product';stage.mkdir();rows=[]
cache=Path('/tmp/dandrum-lanes/cache-editor-guard');assert cache.resolve().stat().st_dev==out.stat().st_dev
source=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');expected=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==expected
frontend={}
for p in (root/'web/trigger').rglob('*'):
 if not p.is_file() or any(n in p.relative_to(root/'web/trigger').parts for n in ('node_modules','dist','dist-native','dist-preview','test-results','playwright-report')):continue
 name=str(p.relative_to(root));q=source/name;digest=hashlib.sha256(p.read_bytes()).hexdigest();assert q.is_file() and hashlib.sha256(q.read_bytes()).hexdigest()==digest,name;frontend[name]=digest

def run(label,argv,env=None,cwd=root):
 start=time.monotonic();p=subprocess.run(argv,cwd=cwd,env=env);rows.append({'label':label,'command':argv,'cwd':str(cwd),'exit':p.returncode,'seconds':time.monotonic()-start});(out/'native-release-phases.json').write_text(json.dumps(rows,indent=2)+'\n');return p.returncode
# Existing dependency installation is reused; frontend output belongs only to owned scratch.
editor=stage/'DandrumTrigger.resources/editor'
assert run('production-react-bundle',['npm','--prefix',str(source/'web/trigger'),'run','build:native','--','--outDir',str(editor),'--emptyOutDir'])==0
assert all(hashlib.sha256((source/n).read_bytes()).hexdigest()==d for n,d in frontend.items())
(out/'native-release-frontend-source.json').write_text(json.dumps(frontend,sort_keys=True,indent=2)+'\n')
env=dict(os.environ,CARGO_TARGET_DIR=str(cache),CARGO_BUILD_JOBS='1');cargo='/home/dan/.cargo/bin/cargo'
assert run('native-release-build',[cargo,'build','--offline','--locked','--jobs','1','--manifest-path','src/clap-adapter/Cargo.toml','--features','trigger-editor','--release','--lib'],env)==0
plugin=stage/'DandrumTrigger.clap';shutil.copy2(cache/'release/libdandrum_clap_adapter.so',plugin)
instrument=stage/'DandrumTrigger.resources/instrument';(instrument/'assets').mkdir(parents=True)
for a,b in [('examples/patches/advanced-drum-kit.yaml','advanced-drum-kit.yaml'),('examples/patches/assets/advanced-drums.wav','assets/advanced-drums.wav')]:shutil.copy2(root/a,instrument/b)
files={str(p.relative_to(stage)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(stage.rglob('*')) if p.is_file()}
validator=Path('/tmp/dandrum-validator-0.4.1-qualified/clap-validator');vhash=hashlib.sha256(validator.read_bytes()).hexdigest();assert vhash=='d9a78bfe781719de450bc5013141496eb13e1d9a538c67de1b8d325628670dbf'
(out/'native-release-product-binding.json').write_text(json.dumps({'base':expected,'features':'trigger-editor','target':str(cache),'files':files,'validator_sha256':vhash,'limits':'Copied GUI-enabled release product, not an installed-source-hidden or named-DAW/native-input acceptance run.'},indent=2)+'\n')
archive=out/'native-release-product.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for name in files:t.add(stage/name,arcname=name,recursive=False)
argv=[str(validator),'validate','--plugin-id','org.dandrum.trigger','--json','--jobs','1',str(plugin)];start=time.monotonic()
with (out/'official-validator.stdout').open('wb') as stdout,(out/'official-validator.stderr').open('wb') as stderr:p=subprocess.run(argv,cwd=stage,stdout=stdout,stderr=stderr,env=dict(os.environ,CARGO_NET_OFFLINE='true'))
rows.append({'label':'unfiltered-official-validator','command':argv,'cwd':str(stage),'exit':p.returncode,'seconds':time.monotonic()-start});(out/'native-release-phases.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Official validator exit',p.returncode,flush=True);sys.exit(p.returncode)
