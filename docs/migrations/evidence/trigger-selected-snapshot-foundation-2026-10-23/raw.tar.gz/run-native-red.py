from pathlib import Path
import os,json,hashlib,tarfile,shutil,subprocess,sys,time
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent
records=[]
for line in (out/'red-compile-run/stdout.log').read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')=='compiler-artifact':records.append(r)
tests=[r for r in records if r.get('target',{}).get('name')=='trigger_parameters' and 'test' in r.get('target',{}).get('kind',[]) and r.get('executable')];assert len(tests)==1
libs=[r for r in records if r.get('target',{}).get('name')=='dandrum_clap_adapter' and 'cdylib' in r.get('target',{}).get('kind',[])];assert len(libs)==1 and 'trigger-editor' in libs[0]['features']
products=[Path(p) for p in libs[0]['filenames'] if p.endswith('.so')];assert len(products)==1
stage=Path(os.environ['TMPDIR'])/'selected-snapshot-red-product';stage.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=Path('/tmp/dandrum-evidence/trigger-clap-precise-clock-repair')
frontend=json.loads((prior/'native-release-frontend-source.json').read_text());assert all(sha(root/p)==h for p,h in frontend.items())
expected=json.loads((prior/'native-release-product-binding.json').read_text())['files']
with tarfile.open(prior/'native-release-product.tar.gz') as t:
 for m in t:
  if not m.name.startswith('DandrumTrigger.resources/'):continue
  assert m.isfile() and '..' not in Path(m.name).parts and not Path(m.name).is_absolute()
  data=t.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==expected[m.name]['sha256']
  p=stage/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
for a,b in [('examples/patches/advanced-drum-kit.yaml','instrument/advanced-drum-kit.yaml'),('examples/patches/assets/advanced-drums.wav','instrument/assets/advanced-drums.wav')]:assert sha(root/a)==sha(stage/'DandrumTrigger.resources'/b)
shutil.copy2(products[0],stage/'DandrumTrigger.clap');test=Path(tests[0]['executable']);shutil.copy2(test,stage/'trigger-parameters-test')
binding={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'library_artifact':libs[0],'test_artifact':tests[0],'files':{str(p.relative_to(stage)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(stage.rglob('*')) if p.is_file()},'frontend_source_identity':frontend,'source_snapshot':'red-compile-source.tar.gz','limits':'Actual copied GUI-enabled CLAP and unchanged production React; no new production feature yet, no physical input/installed/named DAW claim.'}
(out/'red-product-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
with tarfile.open(out/'red-replay-product.tar.gz','w:gz') as t:
 for p in sorted(stage.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(stage)),recursive=False)
argv=[str(stage/'trigger-parameters-test'),'selection_native::copied_native_selection_retains_real_metadata_across_source_and_editor_loss','--ignored','--exact','--nocapture','--test-threads=1']
env=dict(os.environ,GDK_BACKEND='x11',DANDRUM_TRIGGER_GUI_PLUGIN_PATH=str(stage/'DandrumTrigger.clap'));start=time.monotonic();p=subprocess.run(argv,cwd=stage,env=env)
(out/'red-native-phase.json').write_text(json.dumps({'argv':argv,'cwd':str(stage),'exit_code':p.returncode,'seconds':time.monotonic()-start,'plugin_sha256':sha(stage/'DandrumTrigger.clap'),'test_sha256':sha(stage/'trigger-parameters-test'),'replay_archive_sha256':sha(out/'red-replay-product.tar.gz')},indent=2)+'\n');sys.exit(p.returncode)
