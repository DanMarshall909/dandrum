use super::*;
use std::collections::BTreeMap;
use webkit2gtk::{URIRequestExt, URIResponseExt, WebResourceExt, WebViewExt};

pub(super) fn unmodified_bundle_renders_silent_preview_with_all_eight_fonts(parent: u32) {
    let bundle = std::path::PathBuf::from(
        std::env::var_os("DANDRUM_TRIGGER_EDITOR_BUNDLE_DIR")
            .expect("native production bundle input must be configured explicitly"),
    );
    let package = common::Package::new();
    let mut expected = BTreeMap::new();
    for path in common::FILES {
        let bytes = std::fs::read(bundle.join(path))
            .unwrap_or_else(|error| panic!("required production asset {path}: {error}"));
        package.write(path, &bytes);
        assert_eq!(
            std::fs::read(package.root().join("editor").join(path)).unwrap(),
            bytes
        );
        if !path.ends_with(".txt") {
            expected.insert(path.to_string(), bytes);
        }
    }
    let messages = Rc::new(RefCell::new(Vec::new()));
    let sink = messages.clone();
    let owner = NativeEditor::create(
        parent,
        EditorAssets::open(package.root()).unwrap(),
        move |message| sink.borrow_mut().push(message),
    )
    .unwrap();
    let view = owner.view.webview();
    let resources = Rc::new(RefCell::new(BTreeMap::new()));
    let received = resources.clone();
    let resource_handler = view.connect_resource_load_started(move |_, resource, request| {
        let uri = request.uri().unwrap_or_default().to_string();
        let received = received.clone();
        resource.connect_finished(move |resource| {
            let (status, mime) = resource
                .response()
                .map(|response| {
                    (
                        response.status_code(),
                        response.mime_type().unwrap_or_default().to_string(),
                    )
                })
                .unwrap_or_default();
            let received = received.clone();
            let uri = uri.clone();
            resource.data(None::<&gtk::gio::Cancellable>, move |data| {
                received
                    .borrow_mut()
                    .insert(uri, (status, mime, data.map_err(|error| error.to_string())));
            });
        });
    });
    let deadline = Instant::now() + Duration::from_secs(15);
    while (view.uri().as_deref() != Some("dandrum://localhost/index.html") || view.is_loading())
        && Instant::now() < deadline
    {
        NativeEditor::service().unwrap();
        std::thread::sleep(Duration::from_millis(5));
    }
    let paths = expected
        .keys()
        .map(|path| format!("\"{path}\""))
        .collect::<Vec<_>>()
        .join(",");
    owner
        .view
        .evaluate_script(
            &include_str!("../fixtures/production-observer.js")
                .replace("__PRODUCTION_BROWSER_PATHS__", &format!("[{paths}]")),
        )
        .unwrap();
    while Instant::now() < deadline {
        NativeEditor::service().unwrap();
        if messages
            .borrow()
            .iter()
            .any(|message| message.starts_with("production-error|"))
            || (messages
                .borrow()
                .iter()
                .any(|message| message == "production-ready|silent-preview|eight-fonts")
                && expected.keys().all(|path| {
                    resources
                        .borrow()
                        .contains_key(&format!("dandrum://localhost/{path}"))
                }))
        {
            break;
        }
        std::thread::sleep(Duration::from_millis(5));
    }
    eprintln!(
        "production browser receipts: {:?}; consumed resources: {:?}",
        messages.borrow(),
        resources
            .borrow()
            .iter()
            .map(|(uri, (status, mime, bytes))| (uri, status, mime, bytes.as_ref().map(Vec::len)))
            .collect::<Vec<_>>()
    );
    assert!(messages.borrow().iter().any(|message| message
        == "production-preview|silent|mock|1200px|800px|16px|rgb(26, 21, 17)|inline-svg"));
    for (family, weights) in [
        ("Barlow", &[500, 600, 700][..]),
        ("Barlow Semi Condensed", &[500, 600, 700][..]),
        ("JetBrains Mono", &[500, 600][..]),
    ] {
        for weight in weights {
            assert!(
                messages
                    .borrow()
                    .contains(&format!("production-font|{family}|{weight}|loaded")),
                "all eight real font faces load"
            );
        }
    }
    assert!(
        messages
            .borrow()
            .iter()
            .any(|message| message == "production-ready|silent-preview|eight-fonts")
    );
    assert!(
        !messages
            .borrow()
            .iter()
            .any(|message| message.starts_with("production-error|"))
    );
    for (path, bytes) in expected {
        let received = resources.borrow();
        let (status, mime, data) = received
            .get(&format!("dandrum://localhost/{path}"))
            .unwrap_or_else(|| panic!("browser resource {path} was observed"));
        assert_eq!(*status, 200);
        let expected_mime = if path.ends_with(".ttf") {
            "font/ttf"
        } else if path.ends_with(".js") {
            "text/javascript"
        } else if path.ends_with(".css") {
            "text/css"
        } else {
            "text/html"
        };
        assert_eq!(mime, expected_mime);
        assert_eq!(
            data.as_ref().unwrap(),
            &bytes,
            "actual WebKit-consumed bytes for {path}"
        );
    }
    view.disconnect(resource_handler);
    drop(view);
    drop(owner);
}
