import hashlib,json,os,resource,signal,subprocess,time
from pathlib import Path
root=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g3-native-fixture');cache=Path('/tmp/dandrum-lanes/cache-runtime');resource.setrlimit(resource.RLIMIT_CORE,(0,0));tmp=out/'owner-tmp';tmp.mkdir(exist_ok=True)
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_TARGET_DIR=str(cache),CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',TMPDIR=str(tmp))
for k in ('LD_PRELOAD','RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER'):env.pop(k,None)
def resources():
 return {'disk_free_bytes':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'memory_available_bytes':int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024}
def enough(v):return v['disk_free_bytes']>1024**3 and v['memory_available_bytes']>4*1024**3
source=json.loads((out/'source-integration.json').read_text());sources={x['path']:x['sha256'] for x in source['files']}
for p in ('CMakeLists.txt','tests/python/test_engine_only_build.py'):
 sources[p]=hashlib.sha256((root/p).read_bytes()).hexdigest()
for p,h in sources.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,'source drift: '+p
for label,argv in [('root-full-host-tests',['/home/dan/.cargo/bin/cargo','test','--manifest-path','src/trigger-host/Cargo.toml','--locked','--jobs','1']),('root-clap-build-boundary',['python3',str(out/'run-build-boundary-shared-cache.py')])]:
 before=resources();assert enough(before),before;start=time.monotonic();stop=None;samples=[]
 with (out/(label+'.stdout.log')).open('w') as stdout,(out/(label+'.stderr.log')).open('w') as stderr:
  child=subprocess.Popen(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  while child.poll() is None:
   r=resources();samples.append(r)
   if not enough(r) or time.monotonic()-start>2400:
    stop='resource floor' if not enough(r) else 'timeout';os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    break
   time.sleep(.5)
 record={'command':argv,'cwd':str(root),'environment':{k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','TMPDIR')},'source_sha256':sources,'exit':child.returncode,'seconds':time.monotonic()-start,'stop_reason':stop,'resource_before':before,'resource_after':resources(),'minimum_disk_free_bytes':min([before['disk_free_bytes']]+[v['disk_free_bytes'] for v in samples]),'minimum_memory_available_bytes':min([before['memory_available_bytes']]+[v['memory_available_bytes'] for v in samples]),'owned_process_group':child.pid}
 (out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(label,child.returncode,round(record['seconds'],3),flush=True)
 assert child.returncode==0 and stop is None,record
 for p,h in sources.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,'source drift: '+p
