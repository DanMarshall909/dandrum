from pathlib import Path
import subprocess,json,os,time,hashlib,sys
out=Path('/tmp/dandrum-evidence/g3-native-fixture');root=Path('/tmp/dandrum-lanes/integration');phase=sys.argv[1];assert phase in ('red','green');expected=1 if phase=='red' else 0
name='registration-'+phase;assert not (out/(name+'.json')).exists();env=dict(os.environ,PYTHONPATH=str(root/'tests/python'),TMPDIR=str(out/'tmp'),CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='1');Path(env['TMPDIR']).mkdir(exist_ok=True)
cmd=['python3','-m','unittest','-v','test_engine_only_build.ClapProofBuildTest.test_private_clap_native_fixture_uses_reported_artifacts_and_exact_processes'];sources={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['CMakeLists.txt','tests/python/test_engine_only_build.py']};start=time.monotonic()
with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:r=subprocess.run(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=120)
x={'command':cmd,'cwd':str(root),'environment':{k:env[k] for k in ['PYTHONPATH','TMPDIR','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS']},'source_sha256':sources,'exit':r.returncode,'expected_exit':expected,'seconds':time.monotonic()-start};(out/(name+'.json')).write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x));assert r.returncode==expected
