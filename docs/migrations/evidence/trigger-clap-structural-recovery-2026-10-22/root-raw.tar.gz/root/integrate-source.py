"""One-off exact author transfer; root invokes only after explicit handback."""
from pathlib import Path
import subprocess,hashlib,json,shutil
src=Path('/tmp/dandrum-lanes/runtime');dst=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g3-native-fixture');base='072c1af49f3a4cc81117887541c70c5f3c3f5633'
paths=['src/clap-adapter/src/trigger.rs','src/clap-adapter/src/trigger/gui.rs','src/clap-adapter/tests/internal/trigger_gui_dispatch.rs','src/clap-adapter/tests/trigger_parameters.rs','src/clap-adapter/tests/internal/trigger_structural_native.rs']
def g(p,*a):return subprocess.check_output(['git',*a],cwd=p).decode().strip()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (out/'author-release-admitted.json').is_file(),'Root must first record author handback and actual source/cache release'
assert g(src,'rev-parse','HEAD')==g(dst,'rev-parse','HEAD')==g(dst,'rev-parse','origin/feat/juce-free-host-adapters')==base
assert not g(dst,'status','--porcelain=v1','--untracked-files=all') and not g(src,'diff','--cached','--name-only')
changed=g(src,'diff','--name-only').splitlines()+[x for x in g(src,'ls-files','--others','--exclude-standard').splitlines() if not x.startswith('cache-editor-guard/')];assert set(changed)==set(paths)
admission=json.loads((out/'author-release-admitted.json').read_text());assert admission['base']==base and admission['source_cache_released'] is True
assert set(admission['source_sha256'])==set(paths)
for path in paths:assert h(src/path)==admission['source_sha256'][path]
entries=[]
for name in paths:
 s=src/name;d=dst/name;before=h(d) if d.exists() else None
 if d.exists():
  backup=out/'integration-before'/name;backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(d,backup)
 d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,d);assert s.read_bytes()==d.read_bytes()
 entries.append({'path':name,'before_sha256':before,'sha256':h(d),'mode':oct(d.stat().st_mode&0o777)})
x={'source':str(src),'destination':str(dst),'base':base,'files':entries,'excluded':['Runtime accidental cache-editor-guard and all other targets/caches','main checkout','Git index and refs','author evidence before curation']};(out/'source-integration.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
