from pathlib import Path
import hashlib,json
p=Path('/tmp/dandrum-evidence/g3-structural-service');out=Path('/tmp/dandrum-evidence/g3-native-fixture');aggregate={};runs={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label in ['final-native','final-owner']:
 b=json.loads((p/(label+'-coverage-binding.json')).read_text());export=p/(label+'-raw-export.json');assert sha(export)==b['export_sha256'];assert sha(Path(b['elf']))==b['elf_sha256']
 for name,h in b['profiles'].items():assert sha(Path(name))==h
 r=json.loads((p/(label+'-llvm.json')).read_text());assert r['exit']==0;assert r['source_sha256']['src/clap-adapter/src/trigger/gui.rs']=='54ff95fa89be316409c9eeee658162af197c05d2e3e37f58bff1d2f4ba123dcd'
 data=json.loads(export.read_text())
 for d in data['data']:
  for f in d['functions']:
   if not any(name.endswith('/trigger/gui.rs') for name in f['filenames']):continue
   main=next((k for k,token in [('start_worker','12start_worker'),('worker_wake','15request_service'),('structural_service','23service_structural_jobs'),('command_error','13command_error')] if token in f['name']),None)
   for reg in f['regions']:
    if len(reg)!=8 or reg[7]!=0:continue
    key=main
    if '8dispatch' in f['name']:
     if 351<=reg[0] and reg[2]<=356:key='status_arm'
     elif 357<=reg[0] and reg[2]<=362:key='structural_admission_arm'
    if reg[0]==reg[2]==423:key='worker_shutdown'
    if key:aggregate.setdefault(key,{}).setdefault(tuple(reg[:4]),[]).append(reg[4])
 runs[label]={'elf_sha256':b['elf_sha256'],'export_sha256':b['export_sha256'],'profile_files':len(b['profiles'])}
summary={k:{'distinct_source_regions':len(v),'positive_source_regions':sum(any(c>0 for c in counts) for counts in v.values()),'zero_source_ranges':[list(r) for r,counts in v.items() if not any(c>0 for c in counts)]} for k,v in aggregate.items()}
expected={'start_worker':(7,6),'worker_wake':(5,5),'structural_service':(24,24),'command_error':(5,5),'status_arm':(6,6),'structural_admission_arm':(6,6),'worker_shutdown':(1,1)};assert set(summary)==set(expected)
for k,(all_count,hit) in expected.items():assert (summary[k]['distinct_source_regions'],summary[k]['positive_source_regions'])==(all_count,hit)
x={'source_gui_sha256':'54ff95fa89be316409c9eeee658162af197c05d2e3e37f58bff1d2f4ba123dcd','runs':runs,'aggregate':summary,'qualification':'Independently reconstructed code-region execution across exact final native/owner copies. No branch/every-instantiation/whole-GUI claim. Startup OS thread-launch error translation unforced; existing Core Drop attachment fallback not exercised by final selected runs. Behavioral outcomes come from signed routing/history, actual header action, and owner rejection/borrow assertions.'};(out/'root-final-coverage-assessment.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
