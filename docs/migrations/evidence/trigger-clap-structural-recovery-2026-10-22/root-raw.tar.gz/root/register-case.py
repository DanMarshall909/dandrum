"""One-off sequential TDD edits, applied only after author source handback."""
from pathlib import Path
import sys,hashlib,json
r=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g3-native-fixture');kind=sys.argv[1];assert kind in ('test','implementation')
if kind=='test':
 p=r/'tests/python/test_engine_only_build.py';expected='a0fe6ecbd16031a331faab65c682f5af8ba3d1194db23f1d11c361fcf137d60a';old='''            "trigger-clap-native-parameter-invalid-stopped-flush":
                "copied_native_invalid_stopped_flush_preserves_uncollected_automation_ownership",
''';new=old+'''            "trigger-clap-native-parameter-structural-session":
                "structural_native::copied_native_mapping_survives_lost_reply_and_view_loss",
'''
else:
 p=r/'CMakeLists.txt';expected='afa8bc44620a30639c7f70f03534ba1b968cff746a1f1fe0d2c6cbbf7998fc3d';old='''                source-credits feedback-undo callback-audit invalid-stopped-flush)''';new='''                source-credits feedback-undo callback-audit invalid-stopped-flush structural-session)'''
before=p.read_bytes();assert hashlib.sha256(before).hexdigest()==expected
text=before.decode();assert text.count(old)==1;text=text.replace(old,new)
if kind=='implementation':
 old='''                copied_native_invalid_stopped_flush_preserves_uncollected_automation_ownership)''';new='''                copied_native_invalid_stopped_flush_preserves_uncollected_automation_ownership
                structural_native::copied_native_mapping_survives_lost_reply_and_view_loss)''';assert text.count(old)==1;text=text.replace(old,new)
(out/('registration-'+kind+'-before')).write_bytes(before);p.write_text(text)
x={'kind':kind,'path':str(p.relative_to(r)),'before_sha256':expected,'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()};(out/('registration-'+kind+'-edit.json')).write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
