"""One-off lossless text/check/source deduplication; never archives build caches."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
base=Path('/tmp/dandrum-evidence/g3-structural-service');dest=Path('/tmp/dandrum-lanes/integration/docs/migrations/evidence/trigger-clap-structural-recovery-2026-10-22');dest.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
entries={};index={};objects={};states={}
for p in sorted(base.iterdir()):
 if p.is_file():
  data=p.read_bytes();assert not data.startswith(b'\x7fELF') and len(data)<2*1024**2,p
  data.decode('utf-8');name='author/'+p.name;entries[name]=data;index[name]={'sha256':sha(data),'bytes':len(data)}
roots=[(p.name,p/'source') for p in sorted(base.iterdir()) if (p/'source').is_dir()]+[('final-source',base/'final-source')]
for label,root in roots:
 rows={}
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink(),p
  rel=p.relative_to(root);assert not any(v in ('target','build','.git','cache-editor-guard') for v in rel.parts),p
  data=p.read_bytes();assert not data.startswith(b'\x7fELF') and len(data)<2*1024**2,p
  h=sha(data);objects[h]=data;rows[str(rel)]={'sha256':h,'bytes':len(data),'mode':oct(p.stat().st_mode&0o777)}
 states[label]=rows
for h,data in objects.items():entries['source-objects/'+h]=data
meta={'schema_version':1,'base':'072c1af49f3a4cc81117887541c70c5f3c3f5633','scope':'All final author top-level text receipts/raw logs/scripts/exports and exact source-state snapshots deduplicated by content. No installed ELF, raw profiles, cache, accidental target or repeated source copies. Early snapshots retain their actual capture scope; missing host sources are not filled retrospectively.','raw_files':index,'source_states':states,'unique_source_objects':len(objects)}
entries['meta/source-states-and-raw-index.json']=(json.dumps(meta,indent=2,sort_keys=True)+'\n').encode()
archive=dest/'author-raw.tar.gz'
assert not archive.exists()
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for name,data in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(entries)
 for member in tar:
  assert tar.extractfile(member).read()==entries[member.name]
for name in ('final-handoff-manifest.json','final-coverage-assessment.json'):(dest/('author-'+name)).write_bytes((base/name).read_bytes())
receipt={'archive':str(archive.relative_to(dest)),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'raw_text_files':len(index),'source_states':len(states),'unique_source_objects':len(objects),'members':len(entries),'roundtrip':'Every member read back and byte-compared; no extraction into repository source.','exclusions':['installed ELF and probe libraries','raw coverage profiles and compiler caches','accidental Runtime/cache-editor-guard','repeated source snapshots (deduplicated objects retained instead)']};(dest/'author-archive.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
