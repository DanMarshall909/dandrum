import pathlib,os,sys,json,hashlib,subprocess,re
assert 'RUST_MIN_STACK' not in os.environ and 'LD_PRELOAD' not in os.environ, 'normal native proof forbids runtime stack/preload override'
out=pathlib.Path('/tmp/dandrum-evidence/g3-structural-service');binding=json.loads((out/(sys.argv[1]+'-binding.json')).read_text())
h=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert h(binding['test'])==binding['test_sha256'];assert h(binding['copied_library'])==binding['copy_sha256']
from exact import run_exact
sys.exit(run_exact(binding['test'],sys.argv[2],True))
