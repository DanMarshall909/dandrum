#!/usr/bin/python3
import os,sys,pathlib,json
if '--crate-name' in sys.argv:
 name=sys.argv[sys.argv.index('--crate-name')+1]
 if name in ('dandrum_clap_adapter','dandrum_trigger_host','trigger_parameters'):
  kind='test' if '--test' in sys.argv else 'lib'
  keys=[k for k in os.environ if (k.startswith('CARGO_') and k!='CARGO_MAKEFLAGS') or k in ('RUST_MIN_STACK','LD_LIBRARY_PATH','TMPDIR')]
  pathlib.Path('/tmp/dandrum-evidence/g3-structural-service/'+name+'-'+kind+'-rustc.json').write_text(json.dumps({'cwd':os.getcwd(),'command':sys.argv[1:],'environment':{k:os.environ[k] for k in sorted(keys)}},indent=2))
os.execv(sys.argv[1],sys.argv[1:])
