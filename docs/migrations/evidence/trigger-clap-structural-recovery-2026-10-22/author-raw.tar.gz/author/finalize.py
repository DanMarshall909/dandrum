from pathlib import Path
import json,hashlib,shutil,subprocess,os
out=Path('/tmp/dandrum-evidence/g3-structural-service');root=Path('/tmp/dandrum-lanes/runtime');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
selectors={'start_worker':lambda n,r:'12start_worker' in n,'structural_service':lambda n,r:'23service_structural_jobs' in n,'worker_wake':lambda n,r:'10WorkerWake' in n,'command_error':lambda n,r:'13command_error' in n,'status_arm':lambda n,r:'8dispatch' in n and 352<=r[0]<=354,'structural_admission_arm':lambda n,r:'8dispatch' in n and 358<=r[0]<=360,'worker_shutdown':lambda n,r:'4Core' in n and '4drop' in n and r[0]==423}
regions={k:{} for k in selectors};runs={}
for tag in ('final-native','final-owner'):
 binding=json.loads((out/(tag+'-coverage-binding.json')).read_text());data=json.loads((out/(tag+'-raw-export.json')).read_text());runs[tag]={'elf_sha256':binding['elf_sha256'],'export_sha256':binding['export_sha256'],'profile_files':len(binding['profiles'])}
 for block in data['data']:
  for f in block['functions']:
   if not any(p.endswith('/trigger/gui.rs') for p in f['filenames']):continue
   for r in f['regions']:
    if r[7]!=0:continue
    for k,predicate in selectors.items():
     if predicate(f['name'],r):regions[k][tuple(r[:4])]=regions[k].get(tuple(r[:4]),0)+r[4]
assessment={'runs':runs,'aggregate':{k:{'distinct_source_regions':len(v),'positive_source_regions':sum(c>0 for c in v.values()),'zero_source_ranges':[list(r) for r,c in v.items() if not c]} for k,v in regions.items()},'qualification':'Source-region execution union for identical final source, native release DSO and debug owner test ELF. Not branch/every-instantiation/whole-GUI coverage. Startup OS thread-launch error closure is unforced. Native assertions independently prove signed routing/history/identity; owner assertions cover borrow deferral and rejection. Existing Core Drop attachment fallback is not exercised by these final selected runs.'}
(out/'final-coverage-assessment.json').write_text(json.dumps(assessment,indent=2));print(json.dumps(assessment['aggregate']))
# Preserve exact final artifacts outside reusable caches; retain original binding paths too.
artifacts={}
for tag,key in [('final-native-build','test'),('final-native-build','source_library'),('final-owner','test'),('final-owner-instrumented','test'),('final-native-instrumented','source_library')]:
 b=json.loads((out/(tag+'-binding.json')).read_text());src=Path(b[key]);dest=out/'artifacts'/tag/src.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);artifacts[str(dest)]={'original':str(src),'sha256':h(dest)}
for tag in ('final-native','final-owner'):
 b=json.loads((out/(tag+'-coverage-binding.json')).read_text())
 for name in b['profiles']:
  src=Path(name);dest=out/'artifacts'/tag/'profiles'/src.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);artifacts[str(dest)]={'original':str(src),'sha256':h(dest)}
 src=Path(b['elf']);dest=out/'artifacts'/tag/src.name;shutil.copy2(src,dest);artifacts[str(dest)]={'original':str(src),'sha256':h(dest)}
shutil.copy2(out/'artifacts/final-normal/DandrumTrigger.clap',out/'installed/DandrumTrigger.clap')
paths=['src/clap-adapter/src/trigger.rs','src/clap-adapter/src/trigger/gui.rs','src/clap-adapter/tests/internal/trigger_gui_dispatch.rs','src/clap-adapter/tests/trigger_parameters.rs','src/clap-adapter/tests/internal/trigger_structural_native.rs'];sources={}
for name in paths:
 p=root/name;dest=out/'final-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);sources[name]=h(p)
labels=['mapping-native-red-x11','mapping-native-green','recovery-native-red','recovery-calibrated-native-green','undo-native-red','undo-native-green','final-native-build','final-native-regression','final-owner-build','final-owner-green','final-native-instrument-build','final-native-llvm','final-owner-instrument-build','final-owner-llvm','final-rustfmt','final-editor-clippy','final-default-clippy','final-plain-trigger-clippy'];receipts={}
for label in labels:
 p=out/(label+'.json');d=json.loads(p.read_text());receipts[label]={'path':str(p),'sha256':h(p),'exit':d['exit'],'seconds':d['seconds']}
cache={}
for p in map(Path,['/tmp/dandrum-lanes/cache-editor-guard','/tmp/dandrum-lanes/cache-host-snapshot-cov','/tmp/dandrum-lanes/runtime/cache-editor-guard']):
 st=p.stat();cache[str(p)]={'device':st.st_dev,'inode':st.st_ino,'apparent_bytes':int(subprocess.check_output(['du','-sb',str(p)],text=True).split()[0]),'preserved':True}
manifest={'base_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':sources,'artifacts':artifacts,'receipts':receipts,'cache_identity':cache,'test_name':'structural_native::copied_native_mapping_survives_lost_reply_and_view_loss','normal_installed_dso_sha256':h(out/'installed/DandrumTrigger.clap'),'production_app_sha256':json.loads((out/'final-native-build-binding.json').read_text())['app_sha256'],'final_binding_files':{str(p):h(p) for p in out.glob('final-*-binding.json')},'coverage_assessment_sha256':h(out/'final-coverage-assessment.json'),'ownership_release':'All assigned source paths and both loaned absolute cache roots handed back to root; accidental relative cache unchanged/excluded. No further child writes/builds planned. Root owns Git/registration/tracker/spec/docs/integration.','process_state':'All launched exec sessions/drivers reaped; no pending child builder or native fixture. Namespace-local process check and root actual-host confirmation separate.'}
(out/'final-handoff-manifest.json').write_text(json.dumps(manifest,indent=2));print('manifest',h(out/'final-handoff-manifest.json'))
