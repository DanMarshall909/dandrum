from pathlib import Path
import json,hashlib,shutil,sys
out=Path('/tmp/dandrum-evidence/g3-structural-service');root=Path('/tmp/dandrum-lanes/runtime');label,origin=sys.argv[1:]
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
for line in (out/(label+'.stdout.log')).read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')=='compiler-artifact':records.append(r)
libs=[f for r in records if r['target']['name']=='dandrum_clap_adapter' and not r['profile']['test'] for f in r['filenames'] if f.endswith('.so')];assert len(libs)==1
old=json.loads((out/(origin+'-binding.json')).read_text());recipe=json.loads((out/'trigger_parameters-test-rustc.json').read_text());preimage=json.loads((out/(origin+'.json')).read_text())
for name,sha in preimage['source_sha256'].items():
 if name.startswith('src/clap-adapter/tests/') or name.endswith(('Cargo.toml','Cargo.lock')):assert h(root/name)==sha,name
assert h(old['test'])==old['test_sha256']
artifacts=out/'artifacts'/label;artifacts.mkdir(parents=True)
source=Path(libs[0]);retained=artifacts/source.name;shutil.copy2(source,retained)
retained_test=artifacts/'native-host';shutil.copy2(old['test'],retained_test)
copy=out/'installed/DandrumTrigger.clap';shutil.copy2(source,copy)
new={**old,'source_library':str(source),'source_sha256':h(source),'copied_library':str(copy),'copy_sha256':h(copy),'source_gui_sha256':h(root/'src/clap-adapter/src/trigger/gui.rs'),'test':str(retained_test),'test_sha256':h(retained_test),'retained_library':str(retained),'test_origin':origin,'test_recipe':recipe,'current_existing_test_externs':{arg:h(arg.split('=',1)[1]) for i,arg in enumerate(recipe['command']) if i and recipe['command'][i-1]=='--extern'},'provenance':'DSO from this Cargo build JSON. Unchanged actual native host ELF from separate originating Cargo test build; all fixture sources and manifests match origin. Native fixture dynamically loads copied Entry and does not call the implicitly supplied dandrum_clap_adapter rlib; other dependency artifacts remain in assigned cache. No claim of same Cargo invocation.'}
(out/(label+'-binding.json')).write_text(json.dumps(new,indent=2));print(json.dumps({k:new[k] for k in ['source_sha256','test_sha256','test_origin','test']}))
