import json,pathlib,sys,hashlib,shutil
out=pathlib.Path('/tmp/dandrum-evidence/g3-structural-service')
label=sys.argv[1]; records=[]
for l in (out/(label+'.stdout.log')).read_text().splitlines():
 try:d=json.loads(l)
 except:continue
 if d.get('reason')=='compiler-artifact':records.append(d)
libs=[(d,f) for d in records if d['target']['name']=='dandrum_clap_adapter' and not d['profile']['test'] for f in d['filenames'] if f.endswith('.so')]
tests=[d for d in records if d['target']['name']=='trigger_parameters' and d.get('executable')]
assert len(libs)==len(tests)==1,(libs,tests)
fixture=out/'installed';fixture.mkdir(exist_ok=True)
source=pathlib.Path(libs[0][1]);target=fixture/'DandrumTrigger.clap'
shutil.copy2(source,target)
resources=fixture/'DandrumTrigger.resources'
if not resources.exists():shutil.copytree('/tmp/dandrum-lanes/evidence-trigger-native-gui/installed/DandrumTrigger.resources',resources)
h=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
receipt={'source_library':str(source),'source_sha256':h(source),'copied_library':str(target),'copy_sha256':h(target),'test':tests[0]['executable'],'test_sha256':h(tests[0]['executable']),'source_gui_sha256':h('/tmp/dandrum-lanes/runtime/src/clap-adapter/src/trigger/gui.rs'),'app_sha256':h(resources/'editor/app.js'),'note':'Production assets unmodified; test invokes public WebKit JS API against actual live view.'}
assert receipt['source_sha256']==receipt['copy_sha256']
(out/(label+'-binding.json')).write_text(json.dumps(receipt,indent=2));(out/'native-test-path').write_text(tests[0]['executable']);print(json.dumps(receipt))

unit=[d for d in records if d['target']['name']=='dandrum_clap_adapter' and d['profile']['test'] and d.get('executable')]
if unit:
 assert len(unit)==1
 elf=unit[0]['executable'];(out/(label+'-libtest-binding.json')).write_text(json.dumps({'test':elf,'test_sha256':h(elf),'selection':'unique Cargo compiler-artifact target dandrum_clap_adapter profile.test true executable'},indent=2))
