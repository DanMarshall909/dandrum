from pathlib import Path
import json,hashlib,os,subprocess,time
R=Path('/tmp/dandrum-evidence/maintained-gui-product-root');ROOT=Path('/tmp/dandrum-lanes/integration');OUT=R/'dynamic-scope-coverage';OUT.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=ROOT/'src/clap-adapter/tests/trigger_dynamic.rs';before=sha(source)
def run(label,command,env=None):
 start=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True);(OUT/(label+'.stdout')).write_bytes(p.stdout);(OUT/(label+'.stderr')).write_bytes(p.stderr);row={'command':command,'cwd':str(ROOT),'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':sha(OUT/(label+'.stdout')),'stderr_sha256':sha(OUT/(label+'.stderr'))};(OUT/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');assert p.returncode==0,(label,p.stderr[-3000:]);return p
p=run('compile',['/home/dan/.cargo/bin/cargo','rustc','--offline','--locked','--release','--jobs','1','--manifest-path','src/clap-adapter/Cargo.toml','--features','trigger','--test','trigger_dynamic','--message-format=json','--','-C','instrument-coverage'])
records=[json.loads(x) for x in p.stdout.decode().splitlines() if x.startswith('{')];tests=[Path(x['executable']) for x in records if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='trigger_dynamic' and x.get('executable')];assert len(tests)==1;test=tests[0]
products={'headless':R/'scope-headless-product/DandrumTrigger.clap','gui':R/'sourcefree-production/installed/DandrumTrigger.clap'}
for mode,product in products.items():
 env=dict(os.environ,LLVM_PROFILE_FILE=str(OUT/(mode+'-%m-%p.profraw')),DANDRUM_TRIGGER_CLAP_PLUGIN_PATH=str(product),DANDRUM_TRIGGER_CLAP_AUDIT_EVIDENCE_DIR=str(OUT/(mode+'-audit-fixtures')))
 p=run('run-'+mode,[str(test),'--exact','dynamic_callback_allocator_audit_observes_plugin_and_framework_dso','--nocapture','--test-threads=1'],env)
 assert b'1 passed; 0 failed' in p.stdout and ('main-thread service: gui='+str(mode=='gui').lower()).encode() in p.stdout,p.stdout[-2000:]
sysroot=Path(subprocess.check_output(['/home/dan/.cargo/bin/rustc','--print','sysroot'],text=True).strip());bindir=sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/bin';profdata=OUT/'merged.profdata';profiles=sorted(OUT.glob('*.profraw'));assert len(profiles)>=4
run('merge',[str(bindir/'llvm-profdata'),'merge','-sparse',*[str(p) for p in profiles],'-o',str(profdata)])
run('export',[str(bindir/'llvm-cov'),'export',str(test),'--instr-profile',str(profdata),str(source)])
p=run('show',[str(bindir/'llvm-cov'),'show',str(test),'--instr-profile',str(profdata),str(source),'--show-line-counts-or-regions'])
assert before==sha(source)
(OUT/'binding.json').write_text(json.dumps({'source':str(source),'source_sha256':before,'test':str(test),'test_sha256':sha(test),'products':{m:{'path':str(p),'sha256':sha(p)} for m,p in products.items()},'profiles':{p.name:sha(p) for p in profiles},'merged_profile_sha256':sha(profdata),'scope':'Instrumented maintained dynamic test target only, both actual plain-trigger and fresh installed GUI products; new main-thread capability distinction, unchanged DSO callback sentinels. Not production/whole-owner coverage.'},indent=2)+'\n')
print('Both exact instrumented dynamic allocator audit variants PASS',flush=True)
