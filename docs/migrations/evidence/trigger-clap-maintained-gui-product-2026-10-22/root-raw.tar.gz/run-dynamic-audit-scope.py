import subprocess,json,sys
from pathlib import Path
r=Path('/tmp/dandrum-evidence/maintained-gui-product-root')
s=Path(json.loads((r/'root-build-boundary-cache-binding.json').read_text())['source_fixture'])
for mode in ('trigger-product-enabled','trigger-editor'):
 p=subprocess.run(['ctest','--test-dir',str(s/'build'/mode),'--verbose','-R','^trigger-clap-dynamic-host$'])
 assert p.returncode==0,(mode,p.returncode)
