"""One-off final build/runtime proof; never runs before explicit cache handback."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

ROOT = Path('/tmp/dandrum-lanes/integration')
OUT = Path('/tmp/dandrum-evidence/maintained-gui-product-root')
assert (OUT / 'author-release-admitted.json').is_file()
WORK = OUT / 'sourcefree-production'
WORK.mkdir(exist_ok=False)
SOURCE = WORK / 'source'
SOURCE.mkdir()
CACHE = Path('/tmp/dandrum-lanes/cache-runtime')
BUNDLE = Path('/tmp/dandrum-lanes/evidence-trigger-native-gui/current-native-build')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
planned = json.loads((OUT / 'planned-production-bundle.json').read_text())
assert all(sha(BUNDLE / n) == v['sha256'] for n, v in planned.items())
shutil.copy2(ROOT / 'CMakeLists.txt', SOURCE / 'CMakeLists.txt')
for name in ('src', 'tests', 'examples', 'schema', 'scripts', 'spikes'):
    shutil.copytree(ROOT / name, SOURCE / name,
                    ignore=shutil.ignore_patterns('target', 'build', '__pycache__'))
assert not any((SOURCE / n).exists() for n in ('third_party', 'web', 'ui'))
INPUT = WORK / 'editor-input'
shutil.copytree(BUNDLE, INPUT)
BUILD = SOURCE / 'build' / 'graphical-product'
BUILD.mkdir(parents=True)
(BUILD / 'rust-target').symlink_to(CACHE, target_is_directory=True)
TMP = WORK / 'runtime-tmp'
TMP.mkdir(mode=0o700)
environment = dict(os.environ, CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='1',
                   TMPDIR=str(TMP))
for key in ('LD_PRELOAD', 'RUSTFLAGS', 'RUSTC_WRAPPER', 'LLVM_PROFILE_FILE',
            'CARGO_ENCODED_RUSTFLAGS', 'RUST_MIN_STACK'):
    environment.pop(key, None)


def resources():
    return dict(disk_free_bytes=shutil.disk_usage('/tmp').free,
                mem_available_bytes=int(next(l.split()[1] for l in
                    Path('/proc/meminfo').read_text().splitlines()
                    if l.startswith('MemAvailable:'))) * 1024)


def enough(sample):
    return sample['disk_free_bytes'] > 1024**3 and sample['mem_available_bytes'] > 4*1024**3


def run(name, command, env=environment, timeout=1500, pass_fds=()):
    before = resources()
    assert enough(before), before
    start = time.monotonic()
    samples = []
    stopped = None
    with (WORK / (name + '.stdout')).open('wb') as a, (WORK / (name + '.stderr')).open('wb') as b:
        p = subprocess.Popen(command, cwd=ROOT, env=env, stdout=a, stderr=b,
                             start_new_session=True, pass_fds=pass_fds)
        while p.poll() is None:
            current = resources()
            current['seconds'] = time.monotonic() - start
            samples.append(current)
            if not enough(current) or current['seconds'] > timeout:
                stopped = 'resource floor' if not enough(current) else 'outer deadline'
                os.killpg(p.pid, signal.SIGTERM)
                try:
                    p.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(p.pid, signal.SIGKILL)
                    p.wait()
                break
            time.sleep(.25)
    row = dict(command=command, cwd=str(ROOT), exit=p.returncode,
               seconds=time.monotonic()-start, owned_controller_pid_and_pgid=p.pid,
               resource_before=before, samples=samples, stop_reason=stopped,
               stdout_sha256=sha(WORK / (name + '.stdout')),
               stderr_sha256=sha(WORK / (name + '.stderr')))
    (WORK / (name + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    print(name, row['exit'], round(row['seconds'], 3), flush=True)
    assert row['exit'] == 0 and stopped is None, row
    return row


source_hashes = {str(p.relative_to(SOURCE)): sha(p)
                 for p in sorted(SOURCE.rglob('*')) if p.is_file()}
(WORK / 'source-inputs.json').write_text(json.dumps(source_hashes, indent=2) + '\n')
run('configure', ['cmake', '-S', str(SOURCE), '-B', str(BUILD),
    '-DCMAKE_BUILD_TYPE=Release', '-DDANDRUM_ENGINE_ONLY=ON', '-DDANDRUM_CLAP_PROOF=ON',
    '-DDANDRUM_TRIGGER_CLAP_EDITOR=ON', '-DDANDRUM_TRIGGER_EDITOR_BUNDLE_DIR=' + str(INPUT)])
cache_text = (BUILD / 'CMakeCache.txt').read_text()
assert 'DANDRUM_NODE_EXECUTABLE:' not in cache_text
run('build', ['cmake', '--build', str(BUILD), '--target',
    'dandrum-trigger-clap-product', '--parallel', '1', '--verbose'])
assert '--features trigger-editor --lib' in (WORK / 'build.stdout').read_text()
PRODUCT = BUILD / 'clap' / 'DandrumTrigger.clap'
RESOURCES = BUILD / 'clap' / 'DandrumTrigger.resources'
for n, item in planned.items():
    assert sha(INPUT / n) == item['sha256'] == sha(RESOURCES / 'editor' / n)
for name in ('advanced-drum-kit.yaml', 'assets/advanced-drums.wav'):
    assert sha(SOURCE / 'examples/patches' / name) == sha(RESOURCES / 'instrument' / name)
installed = WORK / 'installed'
installed.mkdir()
shutil.copy2(PRODUCT, installed / PRODUCT.name)
shutil.copytree(RESOURCES, installed / RESOURCES.name)
installed_hashes = {str(p.relative_to(installed)): sha(p)
                    for p in sorted(installed.rglob('*')) if p.is_file()}
dep = CACHE / 'release/libdandrum_clap_adapter.d'
(WORK / 'product-depinfo.d').write_bytes(dep.read_bytes())
fixture = Path('/tmp/dandrum-evidence/g3-lost-ack-native-fixture/native-build/trigger-clap-parameters-fixture')
binding = json.loads((fixture / 'binding.json').read_text())
host = fixture / binding['artifacts']['test']['copy']
assert sha(host) == binding['artifacts']['test']['copy_sha256']
(WORK / 'build-installed-binding.json').write_text(json.dumps(dict(
    product_path=str(PRODUCT), product_sha256=sha(PRODUCT),
    installed_directory=str(installed), installed_sha256=installed_hashes,
    ordinary_test_path=str(host), ordinary_test_sha256=sha(host),
    ordinary_test_binding=binding['artifacts']['test'], production_bundle=planned,
    source_inputs_sha256=sha(WORK / 'source-inputs.json'),
    producing_build_receipt_sha256=sha(WORK / 'build.json'),
    scope='Build/copy checkpoint only; native source-exclusion proof still pending.'),
    indent=2) + '\n')
native_env = dict(environment, DISPLAY=':10.0', GDK_BACKEND='x11',
    XAUTHORITY='/home/dan/.Xauthority', TMPDIR='/tmp',
    XDG_CACHE_HOME='/tmp/xdg-cache', XDG_DATA_HOME='/tmp/xdg-data',
    XDG_CONFIG_HOME='/tmp/xdg-config', XDG_RUNTIME_DIR='/tmp/xdg-runtime',
    DANDRUM_TRIGGER_GUI_PLUGIN_PATH='/mnt/DandrumTrigger.clap')
(TMP / 'xdg-runtime').mkdir(mode=0o700)
host_net = os.readlink('/proc/self/ns/net')
for label, case in [
    ('feedback', 'copied_native_host_feedback_updates_rendered_control_without_polling_or_undo_pollution'),
    ('structural', 'structural_native::copied_native_mapping_survives_lost_reply_and_view_loss'),
]:
    absent = [str(ROOT), '/home/dan/code/dandrum', '/tmp/dandrum-lanes/runtime',
              str(SOURCE), str(INPUT), str(BUNDLE)]
    probe = ('from pathlib import Path; import os,sys; '
        + 'assert all(not Path(p).exists() for p in ' + repr(absent) + '); '
        + 'assert os.readlink("/proc/self/ns/net") != ' + repr(host_net) + '; '
        + 'print("SOURCE_PATHS_ABSENT_NETWORK_NAMESPACE_ISOLATED", flush=True); '
        + 'os.execv("/tmp/proof-host", ["/tmp/proof-host","--ignored","--exact",'
        + repr(case) + ',"--nocapture","--test-threads=1"])')
    with (WORK / (label + '-namespace-info.json')).open('wb') as info:
        command = ['bwrap', '--die-with-parent', '--ro-bind', '/', '/',
            '--unshare-net', '--unshare-pid', '--proc', '/proc',
            '--dev-bind', '/dev', '/dev', '--tmpfs', '/home/dan/code',
            '--bind', str(TMP), '/tmp', '--ro-bind', '/tmp/.X11-unix', '/tmp/.X11-unix',
            '--ro-bind', str(installed), '/mnt', '--ro-bind', str(host), '/tmp/proof-host',
            '--chdir', '/mnt', '--info-fd', str(info.fileno()), '--',
            '/usr/bin/python3', '-c', probe]
        run('native-' + label, command, env=native_env, timeout=90, pass_fds=(info.fileno(),))
    text = (WORK / ('native-' + label + '.stdout')).read_text()
    assert 'SOURCE_PATHS_ABSENT_NETWORK_NAMESPACE_ISOLATED' in text
    assert 'running 1 test' in text and '1 passed; 0 failed' in text
assert installed_hashes == {str(p.relative_to(installed)): sha(p)
    for p in sorted(installed.rglob('*')) if p.is_file()}
assert all(sha(ROOT / p) == h for p, h in source_hashes.items())
result = dict(product_sha256=sha(PRODUCT), installed_sha256=installed_hashes,
    ordinary_test_sha256=sha(host), ordinary_test_binding=binding['artifacts']['test'],
    source_inputs_sha256=sha(WORK / 'source-inputs.json'), production_bundle=planned,
    cache=str(CACHE), compile_absent=['third_party', 'web', 'ui', 'Node discovery'],
    namespace_hidden=absent, network_namespace_unshared=True,
    scope='Fresh maintained GUI product from copied source without JUCE/web/ui, real external production bundle, exact copied installed artifact. Two native synthetic-host cases with conventional source paths unavailable and network namespace isolated. Not a physical device/DAW/release-package or whole-beta claim.')
(WORK / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'product_sha256':result['product_sha256'],'native_cases':2}), flush=True)
