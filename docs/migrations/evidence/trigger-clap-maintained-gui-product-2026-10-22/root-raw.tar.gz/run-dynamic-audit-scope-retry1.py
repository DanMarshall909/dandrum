import subprocess,json,os,shutil,hashlib
from pathlib import Path
r=Path('/tmp/dandrum-evidence/maintained-gui-product-root');s=Path(json.loads((r/'root-build-boundary-cache-binding.json').read_text())['source_fixture']);cargo='/home/dan/.cargo/bin/cargo'
p=subprocess.run(['ctest','--test-dir',str(s/'build/trigger-editor'),'--verbose','-R','^trigger-clap-dynamic-host$']);assert p.returncode==0,('graphical',p.returncode)
def cargo_records(label,args):
 p=subprocess.run([cargo,*args,'--manifest-path',str(s/'src/clap-adapter/Cargo.toml'),'--message-format=json'],capture_output=True,text=True);(r/(label+'.stdout')).write_text(p.stdout);(r/(label+'.stderr')).write_text(p.stderr);assert p.returncode==0,p.stderr
 return [json.loads(x) for x in p.stdout.splitlines() if x.startswith('{')]
records=cargo_records('scope-headless-build',['build','--locked','--offline','--release','--features','trigger','--lib','--jobs','1'])
libs=[Path(n) for x in records if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='dandrum_clap_adapter' for n in x.get('filenames',[]) if n.endswith('.so')];assert len(libs)==1,libs
out=r/'scope-headless-product';out.mkdir(exist_ok=False);shutil.copy2(libs[0],out/'DandrumTrigger.clap');shutil.copytree(s/'build/trigger-editor/clap/DandrumTrigger.resources',out/'DandrumTrigger.resources')
records=cargo_records('scope-headless-test',['test','--locked','--offline','--features','trigger','--test','trigger_dynamic','--no-run','--jobs','1'])
tests=[Path(x['executable']) for x in records if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='trigger_dynamic' and x.get('executable')];assert len(tests)==1
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(r/'scope-headless-binding.json').write_text(json.dumps({'library':str(libs[0]),'copy':str(out/'DandrumTrigger.clap'),'sha256':sha(out/'DandrumTrigger.clap'),'test':str(tests[0]),'test_sha256':sha(tests[0]),'scope':'Explicit plain-trigger Cargo build, not maintained CMake GUI product.'},indent=2)+'\n')
p=subprocess.run([str(tests[0]),'--nocapture','--test-threads=1'],env=dict(os.environ,DANDRUM_TRIGGER_CLAP_PLUGIN_PATH=str(out/'DandrumTrigger.clap')));assert p.returncode==0,('headless',p.returncode)
