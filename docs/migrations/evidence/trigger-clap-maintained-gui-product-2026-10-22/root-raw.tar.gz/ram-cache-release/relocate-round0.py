from pathlib import Path
import os, stat, hashlib, json, shutil, subprocess, time
OUT=Path('/tmp/dandrum-evidence/ram-cache-release-20261022')
PAIRS=[(Path('/dev/shm/dandrum-beta-20261020'),Path('/tmp/dandrum-lanes/ram-cache-preserved-20261022')),(Path('/dev/shm/dnb'),Path('/tmp/dandrum-lanes/ram-bootstrap-preserved-20261022'))]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def manifest(root):
 rows={};links={}
 for base,dirs,files in os.walk(root,followlinks=False):
  for p in [Path(base),*(Path(base)/n for n in dirs+files)]:
   rel=p.relative_to(root).as_posix()
   if rel in rows:continue
   s=p.lstat();row={'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns}
   if p.is_symlink():row.update(type='symlink',target=os.readlink(p))
   elif p.is_file():
    row.update(type='file',size=s.st_size,sha256=digest(p));links.setdefault((s.st_dev,s.st_ino),[]).append(rel)
   elif p.is_dir():row.update(type='directory')
   else:raise AssertionError(('special file',str(p)))
   rows[rel]=row
 return {'entries':dict(sorted(rows.items())),'hardlink_groups':sorted(sorted(v) for v in links.values() if len(v)>1)}
def consumers(root):
 hits=[];key=str(root).encode()
 for p in Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name)==os.getpid():continue
  for name in ('cmdline','environ','maps'):
   try:
    if key in (p/name).read_bytes():hits.append([p.name,name])
   except (OSError,PermissionError):pass
  for path in [p/'cwd',p/'root',*list((p/'fd').glob('*'))]:
   try:
    if str(root) in os.readlink(path):hits.append([p.name,str(path)])
   except OSError:pass
 return hits
records=[]
for source,dest in PAIRS:
 start=time.monotonic();assert source.is_dir() and not source.is_symlink() and not dest.exists()
 hits=consumers(source);assert not hits,hits
 before=manifest(source);logical=sum(x.get('size',0) for x in before['entries'].values());assert shutil.disk_usage('/tmp').free>logical+4*1024**3
 (OUT/(source.name+'-before.json')).write_text(json.dumps(before,sort_keys=True)+'\n')
 cp=subprocess.run(['cp','-a','--reflink=auto','--',str(source),str(dest)],capture_output=True)
 assert cp.returncode==0,cp.stderr
 copied=manifest(dest);assert copied==before,'copy bytes, metadata, symlinks or hardlinks differ'
 assert manifest(source)==before,'source drift during copy'
 hits=consumers(source);assert not hits,hits
 free_before=shutil.disk_usage('/dev/shm').free
 shutil.rmtree(source);source.symlink_to(dest,target_is_directory=True)
 assert source.resolve()==dest and manifest(source)==before
 row={'source':str(source),'preserved':str(dest),'logical_file_bytes':logical,'entries':len(before['entries']),'manifest_sha256':digest(OUT/(source.name+'-before.json')),'hardlink_groups':len(before['hardlink_groups']),'seconds':time.monotonic()-start,'shm_available_before_release':free_before,'shm_available_after_release':shutil.disk_usage('/dev/shm').free,'verified':'Full content/type/mode/uid/gid/mtime/symlink/hardlink equality before original removal; logical alias retained; no live consumers.'}
 records.append(row);(OUT/'result.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
