import datetime,json,os,pathlib,shutil,signal,subprocess,sys,time
r=pathlib.Path('/tmp/dandrum-evidence/maintained-gui-product-root');label=sys.argv[1];command=sys.argv[2:];env=dict(os.environ,CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR='/tmp/dandrum-lanes/cache-runtime',CARGO_BUILD_JOBS='1',TMPDIR=str(r/'owner-tmp'),DISPLAY=':10.0',GDK_BACKEND='x11',XAUTHORITY='/home/dan/.Xauthority');records=[]
(r/'owner-tmp').mkdir(exist_ok=True)
assert (r/'author-release-admitted.json').is_file()
def sample():
 disk=shutil.disk_usage('/tmp').free;mem=int(next(s.split()[1] for s in pathlib.Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024;records.append({'elapsed_seconds':time.monotonic()-t,'disk_free_bytes':disk,'mem_available_bytes':mem});return disk>=1024**3 and mem>=4*1024**3
t=time.monotonic();assert sample(),records[-1]
with (r/(label+'.stdout')).open('wb') as out,(r/(label+'.stderr')).open('wb') as err:
 p=subprocess.Popen(command,cwd='/tmp/dandrum-lanes/integration',env=env,stdout=out,stderr=err,start_new_session=True);reason=None
 while p.poll() is None:
  if not sample() or time.monotonic()-t>1200:
   reason='resource-floor-or-timeout';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(1)
 code=p.wait()
try:os.killpg(p.pid,0);idle=False
except ProcessLookupError:idle=True
summary={'command':command,'cwd':'/tmp/dandrum-lanes/integration','environment':{k:env[k] for k in ('CARGO_NET_OFFLINE','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','TMPDIR','DISPLAY','GDK_BACKEND','XAUTHORITY')},'exit':code,'elapsed_seconds':time.monotonic()-t,'owned_pgid':p.pid,'owned_group_idle':idle,'termination_reason':reason,'samples':records,'utc_end':datetime.datetime.now(datetime.timezone.utc).isoformat()};(r/(label+'.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='samples'}));sys.exit(code or int(not idle))
