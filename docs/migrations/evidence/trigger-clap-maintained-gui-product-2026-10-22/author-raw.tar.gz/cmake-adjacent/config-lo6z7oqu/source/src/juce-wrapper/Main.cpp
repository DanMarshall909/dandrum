#include <juce_audio_devices/juce_audio_devices.h>

#include "Cli.h"
#include "DefaultPatch.h"
#include "DrumLoop.h"
#include "MidiToRustEngine.h"
#include "RustEngineSource.h"

#include <atomic>
#include <csignal>
#include <iostream>
#include <memory>

namespace
{
std::atomic<bool> shouldQuit { false };

void handleSignal (int)
{
    shouldQuit.store (true);
}

int runDrumLoopDemo (RustEngineSource& engineSource, const juce::File& patchPath)
{
    if (! engineSource.loadPatch (patchPath.getFullPathName()))
    {
        std::cerr << "Failed to load drum container patch: " << patchPath.getFullPathName() << '\n';
        return 1;
    }

    std::cout << "Loaded drum container patch: " << patchPath.getFullPathName() << '\n';

    MidiToRustEngine syntheticMidi (engineSource);
    std::cout << "Playing simple drum loop. Press Ctrl+C to quit.\n";

    auto noteOn = [&](int note, int velocity) { syntheticMidi.handleIncomingMidiMessage (nullptr, juce::MidiMessage::noteOn (1, note, static_cast<juce::uint8> (velocity))); };
    auto noteOff = [&](int note) { syntheticMidi.handleIncomingMidiMessage (nullptr, juce::MidiMessage::noteOff (1, note)); };

    while (! shouldQuit.load())
    {
        dandrum::playSimpleDrumLoopOnce (shouldQuit, noteOn, noteOff);
        if (shouldQuit.load())
            break;
    }

    return 0;
}
} // namespace

int main (int argc, char* argv[])
{
    std::signal (SIGINT, handleSignal);
    std::signal (SIGTERM, handleSignal);

    const juce::StringArray args (argv + 1, argc - 1);

    if (args.contains ("--list-midi-inputs"))
    {
        printMidiInputs();
        return 0;
    }

    const auto drumLoopMode = args.contains ("--drum-loop");

    juce::AudioDeviceManager deviceManager;
    const auto error = deviceManager.initialiseWithDefaultDevices (0, 2);

    if (error.isNotEmpty())
    {
        std::cerr << "Failed to initialize audio device: " << error << '\n';
        return 1;
    }

    printAudioDeviceInfo (deviceManager);

    RustEngineSource engineSource;
    juce::AudioSourcePlayer player;
    player.setSource (&engineSource);

    const auto resolvedDefaultPatch = juce::File (drumLoopMode ? dandrum::defaultDrumContainerPath().string()
                                                               : dandrum::defaultPatchPath().string());
    if (! resolvedDefaultPatch.existsAsFile())
    {
        std::cerr << (drumLoopMode ? "Failed to locate default drum container patch: examples/patches/drum-kit.yaml\n"
                                   : "Failed to locate default patch: examples/patches/polyphonic-pad.yaml\n");
        return 1;
    }

    const auto patchArgIndex = args.indexOf ("--patch");
    const auto useExplicitPatch = patchArgIndex >= 0 && patchArgIndex + 1 < args.size();
    const auto patchPath = useExplicitPatch ? juce::File (args[patchArgIndex + 1]) : resolvedDefaultPatch;

    if (drumLoopMode)
    {
        if (! patchPath.existsAsFile())
        {
            std::cerr << "Patch path is not a file: " << patchPath.getFullPathName() << '\n';
            player.setSource (nullptr);
            return 1;
        }

        deviceManager.addAudioCallback (&player);
        const auto exitCode = runDrumLoopDemo (engineSource, patchPath);
        deviceManager.removeAudioCallback (&player);
        player.setSource (nullptr);
        return exitCode;
    }

    // Patch loading stays off the audio callback; the callback only renders
    // the already-prepared engine state.
    if (! patchPath.existsAsFile())
    {
        std::cerr << "Patch path is not a file: " << patchPath.getFullPathName() << '\n';
        player.setSource (nullptr);
        return 1;
    }

    if (! engineSource.loadPatch (patchPath.getFullPathName()))
    {
        std::cerr << (useExplicitPatch ? "Failed to load patch: " : "Failed to load default patch: ")
                  << patchPath.getFullPathName() << '\n';
        player.setSource (nullptr);
        return 1;
    }

    std::cout << (useExplicitPatch ? "Loaded patch: " : "Loaded default patch: ")
              << patchPath.getFullPathName() << '\n';

    deviceManager.addAudioCallback (&player);

    const auto exitCode = [&]() -> int {
        const auto testMidiNoteArgIndex = args.indexOf ("--test-midi-note");
        if (testMidiNoteArgIndex >= 0 && testMidiNoteArgIndex + 1 < args.size())
        {
            const auto note = juce::jlimit (0, 127, args[testMidiNoteArgIndex + 1].getIntValue());
            MidiToRustEngine syntheticMidi (engineSource);

            std::cout << "Synthetic MIDI test note: " << note << '\n';
            syntheticMidi.handleIncomingMidiMessage (nullptr, juce::MidiMessage::noteOn (1, note, static_cast<juce::uint8> (110)));
            juce::Thread::sleep (180);
            syntheticMidi.handleIncomingMidiMessage (nullptr, juce::MidiMessage::noteOff (1, note));
            return 0;
        }

        if (args.contains ("--test-midi-scale"))
        {
            MidiToRustEngine syntheticMidi (engineSource);
            const int cMajor[] { 60, 62, 64, 65, 67, 69, 71, 72 };

            std::cout << "Synthetic MIDI C major scale\n";
            for (const auto note : cMajor)
            {
                std::cout << "Scale note: " << note << '\n';
                syntheticMidi.handleIncomingMidiMessage (nullptr, juce::MidiMessage::noteOn (1, note, static_cast<juce::uint8> (110)));
                juce::Thread::sleep (180);
                syntheticMidi.handleIncomingMidiMessage (nullptr, juce::MidiMessage::noteOff (1, note));
                juce::Thread::sleep (40);
            }

            return 0;
        }

        const auto midiArgIndex = args.indexOf ("--midi-input");
        if (midiArgIndex >= 0 && midiArgIndex + 1 < args.size())
        {
            const auto devices = juce::MidiInput::getAvailableDevices();
            const auto requestedIndex = args[midiArgIndex + 1].getIntValue();

            if (requestedIndex < 0 || requestedIndex >= devices.size())
            {
                std::cerr << "Invalid MIDI input index: " << requestedIndex << "\n";
                printMidiInputs();
                return 1;
            }

            MidiToRustEngine midiCallback (engineSource);
            const auto midiIdentifier = devices[requestedIndex].identifier;
            deviceManager.setMidiInputDeviceEnabled (midiIdentifier, true);
            deviceManager.addMidiInputDeviceCallback (midiIdentifier, &midiCallback);

            std::cout << "Opened MIDI input: " << devices[requestedIndex].name << '\n';
            std::cout << "Play MIDI notes. Press Ctrl+C to quit.\n";

            while (! shouldQuit.load())
                juce::Thread::sleep (50);

            deviceManager.removeMidiInputDeviceCallback (midiIdentifier, &midiCallback);
            return 0;
        }

        std::cout << "Rust engine test note. Use --test-midi-note <note>, --test-midi-scale, --list-midi-inputs, or --midi-input <index>.\n";
        engineSource.noteOn (60, 110);
        return 0;
    }();

    deviceManager.removeAudioCallback (&player);
    player.setSource (nullptr);
    return exitCode;
}
