#pragma once

#include <array>
#include <atomic>
#include <cstdint>
#include <deque>
#include <future>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include <juce_audio_processors/juce_audio_processors.h>

#include "InstrumentFileWatcher.h"
#include "InstrumentDemoConfiguration.h"
#include "InstrumentUiCommands.h"
#include "InstrumentUiDocument.h"
#include "InstrumentUiMeterCapture.h"
#include "InstrumentUiMeterDelivery.h"
#include "InstrumentUiParameterState.h"
#include "InstrumentUiWaveformService.h"
#include "InstrumentUiSpectralService.h"
#include "InstrumentUiLiveService.h"
#include "RustEngineBindings.h"
#include "InstrumentSessionBindings.h"

class SoundLabController;

class DandrumAudioProcessor final : public juce::AudioProcessor, private InstrumentUiCommandHost
{
public:
    struct PublicParameterSnapshotEntry
    {
        juce::String id;
        juce::String displayName;
        float normalisedValue = 0.0f;
    };

    explicit DandrumAudioProcessor (
        InstrumentDemoConfiguration configuration = InstrumentDemoConfiguration::tb303());
    // Optional off-audio worker observation; must honor stop and not throw.
    DandrumAudioProcessor (InstrumentDemoConfiguration,
                          InstrumentUiLiveService::BeforeBatch observeLiveWorker,
                          std::function<void()> beforeReloadPreparation = {});
    ~DandrumAudioProcessor() override;

    using juce::AudioProcessor::processBlock;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    const juce::String getName() const override;
    bool acceptsMidi() const override;
    bool producesMidi() const override;
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // Off-audio configuration queries return owned values under reloadMutex.
    // A caller must not retain references into a replaceable configuration.
    bool isInstrumentLoaded() const;
    juce::String getLastLoadError() const;
    juce::String getLastPresetError() const;
    const InstrumentDemoConfiguration& demoConfiguration() const noexcept;
    bool hasPublicParameter (juce::StringRef parameterId) const;
    juce::RangedAudioParameter* getParameterForPublicId (juce::StringRef parameterId) const;
    juce::String getPublicParameterDisplayName (juce::StringRef parameterId) const;
    juce::StringArray getActivePublicParameterIds() const;
    std::vector<PublicParameterSnapshotEntry> getPublicParameterSnapshot() const;
    std::optional<InstrumentUiDocument> getPreparedUiDocument() const;
    InstrumentUiParameterState getUiParameterState() const;
    /// Message-thread request for a prepared, read-only region. Reduction and
    /// cache work run on a worker holding its own retained source lifetime.
    std::optional<std::uint64_t> requestPreparedWaveform (
        std::uint32_t expectedGeneration, const std::string& sourceId,
        const std::string& regionId, std::uint16_t channel, std::size_t bucketCount,
        std::uint64_t sessionId = 0, bool wholeSource = false);
    std::optional<InstrumentUiWaveformService::Snapshot>
        getPreparedWaveformJobStatus (std::uint64_t jobId) const;
    bool cancelPreparedWaveformJob (std::uint64_t jobId);
    void cancelPreparedWaveformSession (std::uint64_t sessionId);
    std::optional<std::uint64_t> requestPreparedSpectrum (
        std::uint32_t expectedGeneration, const std::string& sourceId,
        const std::string& regionId, std::uint16_t channel, std::uint64_t sessionId = 0);
    std::optional<InstrumentUiSpectralService::Snapshot>
        getPreparedSpectrumJobStatus (std::uint64_t jobId) const;
    bool cancelPreparedSpectrumJob (std::uint64_t jobId);
    void cancelPreparedSpectrumSession (std::uint64_t sessionId);
    std::uint32_t getParameterSurfaceGeneration() const noexcept;
    InstrumentUiCommandService& uiCommands() noexcept;
    SoundLabController* getSoundLabController() noexcept;
    juce::File& getSoundLabReferenceFile() noexcept;

    enum class UiJobState { running, completed, failed, stale };
    struct UiJobStatus
    {
        std::uint64_t id = 0;
        UiJobState state = UiJobState::running;
        std::uint32_t generation = 0;
        juce::String error;
    };

    struct InstrumentSessionSnapshot
    {
        std::uint64_t revision = 0;
        std::string yaml;
        std::size_t undoCount = 0;
        std::size_t redoCount = 0;

        bool operator== (const InstrumentSessionSnapshot&) const = default;
    };

    struct InstrumentSessionConnectionSnapshot
    {
        std::uint32_t contractVersion = 0;
        std::uint64_t instanceId = 0;
        std::uint64_t attachmentId = 0;
        std::uint64_t revision = 0;
        std::uint64_t nextRequestId = 0;
        std::string yaml;
        std::size_t undoCount = 0;
        std::size_t redoCount = 0;
        std::size_t attachmentLimit = 0;
        std::size_t historyLimit = 0;
        std::size_t outcomeLimit = 0;
        std::size_t activeRequestLimit = 0;
    };

    struct InstrumentSessionJobStatus
    {
        std::uint64_t id = 0;
        UiJobState state = UiJobState::running;
        std::uint64_t revision = 0;
        std::size_t undoCount = 0;
        std::size_t redoCount = 0;
        juce::String error;
    };

    /// Admits one native mapping command. The Rust-owned job prepares without
    /// an editor and publishes through the same gate used by processBlock.
    std::optional<std::uint64_t> requestInstrumentSessionMappingJob (
        std::uint64_t requestId, std::uint64_t expectedRevision,
        const std::string& mapId, const std::string& zoneId,
        std::uint8_t keyLow, std::uint8_t keyHigh);
    std::optional<InstrumentSessionConnectionSnapshot> openInstrumentSessionConnection();
    bool closeInstrumentSessionConnection (std::uint64_t instanceId,
                                           std::uint64_t attachmentId);
    std::optional<InstrumentSessionConnectionSnapshot> getInstrumentSessionConnectionSnapshot (
        std::uint64_t instanceId, std::uint64_t attachmentId) const;
    std::optional<std::uint64_t> requestInstrumentSessionMappingJobForConnection (
        std::uint64_t instanceId, std::uint64_t attachmentId,
        std::uint64_t requestId, std::uint64_t expectedRevision,
        const std::string& mapId, const std::string& zoneId,
        std::uint8_t keyLow, std::uint8_t keyHigh);
    std::optional<std::uint64_t> requestInstrumentSessionUndoJob (
        std::uint64_t instanceId, std::uint64_t attachmentId,
        std::uint64_t requestId, std::uint64_t expectedRevision);
    std::optional<InstrumentSessionJobStatus> getInstrumentSessionJobStatus (
        std::uint64_t requestId) const;
    std::optional<InstrumentSessionSnapshot> getInstrumentSessionSnapshot() const;

    /// Admit one off-audio instrument reload without waiting for preparation.
    /// Admission closes audio access immediately. The processor worker prepares,
    /// activates or recovers without an editor/status query driving completion.
    /// Terminal records outlive editor sessions for this processor instance.
    std::optional<std::uint64_t> requestInstrumentReloadJob (
        const juce::File& yamlFile, std::uint32_t expectedGeneration,
        std::optional<juce::String> yamlSnapshot = std::nullopt);
    std::optional<UiJobStatus> getInstrumentUiJobStatus (std::uint64_t jobId);

    /// Publishes bounded, per-note editor intent for delivery by processBlock.
    /// The message thread never calls the Rust engine directly. Session 0 is
    /// reserved for existing direct callers; each Web editor uses its own ID.
    bool enqueueEditorNoteOn (int noteNumber, float velocity, std::uint64_t sessionId = 0) noexcept;
    bool enqueueEditorNoteOff (int noteNumber, std::uint64_t sessionId = 0) noexcept;
    void closeEditorNoteSession (std::uint64_t sessionId) noexcept;

    /// Silences audio output during an explicit instrument-replacement
    /// transaction. Safe to call from any thread; processBlock reads this
    /// atomically each block.
    void setMuted (bool shouldMute) noexcept;
    bool isMuted() const noexcept;

    /// Loads a replacement instrument from a YAML file as an explicit,
    /// off-audio-thread replacement transaction: a candidate engine is built
    /// and validated first, and the active engine is only swapped once the
    /// candidate is fully prepared. On failure the previously active
    /// instrument keeps running unchanged and getLastLoadError() reports why.
    /// Fails if the host has not yet called prepareToPlay (the sample rate is
    /// not yet known). Safe to call from multiple threads: concurrent calls
    /// are serialized so one reload's engine can never be destroyed while
    /// another is still building on it. Must not be called from processBlock.
    bool reloadInstrumentFromFile (const juce::File& yamlFile);

    /// Loads an owned YAML snapshot while retaining sourceHint as the
    /// instrument's provenance and relative-asset root. The snapshot is staged
    /// beside sourceHint for Rust's path-based loader, then removed after the
    /// replacement transaction. Must not be called from processBlock.
    bool reloadInstrumentFromYaml (const juce::String& yamlText,
                                   const juce::File& sourceHint);

    /// Enables/disables watching the loaded instrument file for external
    /// edits. While disabled, external edits do not trigger a reload and the
    /// running instrument is left unchanged until watching is re-enabled or a
    /// manual reload is requested. Safe to call from the message thread.
    void setFileWatchEnabled (bool shouldWatch);
    bool isFileWatchEnabled() const noexcept;

    /// The instrument file currently being watched for external edits, if any.
    juce::File watchedInstrumentFile() const;

    /// Polls the watched instrument file once for a stable external change,
    /// reloading through the standard replacement transaction if one is found.
    /// The plugin drives this from a low-frequency background timer; it is
    /// exposed so tests can drive polling deterministically. Never called from
    /// processBlock.
    void pollInstrumentFileForChanges();

    /// Applies a compatible preset as mutable public-parameter state for the
    /// currently loaded immutable instrument. This never reparses, rewrites, or
    /// replaces the loaded instrument YAML.
    bool loadPresetFromFile (const juce::File& presetFile);

    /// The currently loaded instrument's source file, if loaded from one. This
    /// is only a restore hint; plugin state embeds the YAML content too.
    juce::File currentInstrumentFile() const;
    bool isSoundLabInstrumentCompatible() const;

    /// The currently loaded instrument's YAML content, captured at load time
    /// so it can be embedded in plugin state without depending on the source
    /// file still existing at the original path.
    juce::String currentInstrumentYaml() const;

    juce::String currentPresetName() const;
    juce::String currentPresetYaml() const;

    /// Non-empty after a reload that dropped previously-live public parameters
    /// or exceeded the fixed host slot budget.
    juce::String getLastReloadWarning() const;

    /// Current explicit replacement transaction phase for the editor/status
    /// surface. Audio acquires a bounded reader guard before engine access.
    juce::String replacementTransactionState() const;

    /// Number of web-editor MIDI events rejected because the fixed-capacity
    /// message-thread-to-audio-thread queue was full.
    std::size_t getDroppedMidiEventCount() const noexcept;

    /// One processor-owned, stereo master capture stream. The UI aggregation
    /// service is its sole off-audio consumer; editors never own queue storage.
    std::uint64_t getDroppedMeterFrameCount() const noexcept;
    InstrumentUiMeterCapture::ClipSnapshot getMeterClipSnapshot() const noexcept;
    bool acknowledgeMeterClip (std::size_t channel, std::uint32_t generation,
                               std::uint64_t ticket) noexcept;
    /// Message-thread only. Capture storage remains processor-owned when an
    /// editor closes; the fixed session table gates unnecessary visual work.
    bool subscribeMeter (std::uint64_t sessionId, std::uint32_t generation) noexcept;
    bool unsubscribeMeter (std::uint64_t sessionId) noexcept;
    bool setMeterSessionVisible (std::uint64_t sessionId, bool visible) noexcept;
    void pollMeterDelivery() noexcept;
    std::optional<InstrumentUiMeterDelivery::Packet> takeMeterPacket (
        std::uint64_t sessionId) noexcept;
    bool acknowledgeMeterPacket (std::uint64_t sessionId, std::uint32_t generation,
                                 std::uint64_t sequence) noexcept;

    // Off-audio live-analysis sessions. PCM and worker storage belong to this
    // processor; editors receive only owned numeric packet values.
    bool subscribeLiveAnalysis (std::uint64_t, std::uint32_t, std::uint8_t);
    bool unsubscribeLiveAnalysis (std::uint64_t);
    bool setLiveAnalysisVisible (std::uint64_t, bool);
    std::optional<InstrumentUiLiveService::Packet> takeLiveAnalysisPacket (std::uint64_t);
    bool acknowledgeLiveAnalysisPacket (std::uint64_t, std::uint32_t, std::uint64_t);
    InstrumentUiLiveService::Statistics getLiveAnalysisStatistics() const;

private:
    static constexpr std::uint32_t engineAccessClosed = 1U << 31;
    static_assert (std::atomic<std::uint32_t>::is_always_lock_free);
    // A successful bounded acquisition pins engine and slot storage for the
    // whole callback. Releasing this guard only decrements an atomic count.
    struct EngineReaderGuard final
    {
        explicit EngineReaderGuard (std::atomic<std::uint32_t>&);
        ~EngineReaderGuard();
        EngineReaderGuard (const EngineReaderGuard&) = delete;
        EngineReaderGuard& operator= (const EngineReaderGuard&) = delete;
        std::atomic<std::uint32_t>& access;
        bool acquired = false;
    };
    // Off audio and under reloadMutex. Nested pauses cannot reopen an outer
    // pause; only its owner publishes access again after mutation/cleanup.
    struct EngineAccessPause final
    {
        explicit EngineAccessPause (DandrumAudioProcessor&);
        ~EngineAccessPause();
        EngineAccessPause (const EngineAccessPause&) = delete;
        EngineAccessPause& operator= (const EngineAccessPause&) = delete;
        DandrumAudioProcessor& owner;
        bool ownsGate = false, previousMute = false;
    };
    void waitForEngineReaders() const;
    friend struct PluginConstructionTestProbe;
    friend struct PluginInstrumentSessionTestProbe;
    /// Test-only direct inspection; subscription delivery is the production
    /// queue consumer and excludes this diagnostic path while active.
    void setMeterCaptureEnabled (bool enabled) noexcept;
    bool popMeterFrame (InstrumentUiMeterCapture::Frame& frame) noexcept;
    std::uint32_t uiCommandGeneration() const noexcept override;
    InstrumentUiCommandStatus applyUiParameter (
        std::uint32_t generation, const std::string& id, float normalisedValue,
        bool withinGesture) override;
    InstrumentUiGestureAdmission beginUiGesture (
        std::uint32_t generation, const std::string& id) override;
    void endUiGesture (std::size_t hostSlot) override;

    static constexpr std::intptr_t kNoEngineSlot = -1;
    static constexpr int kPublicParameterSlotCount = 64;
    static constexpr int kPluginStateSchemaVersion = 1;

    enum class ReplacementState : int
    {
        Running = 0,
        Muted,
        Failed,
    };

    struct PublicParameterDescriptor
    {
        juce::String id;
        juce::String name;
        float defaultValue = 0.0f;
        float minValue = 0.0f;
        float maxValue = 1.0f;
    };

    struct ParameterSlot
    {
        juce::String slotParameterId;
        bool active = false;
        PublicParameterDescriptor descriptor;
        const std::atomic<float>* rawValue = nullptr;
        std::intptr_t kernelSlotIndex = kNoEngineSlot;
        float lastAppliedNormalisedValue = 0.0f;
    };
    struct CandidateParameterBindings
    {
        DandrumKernelInstrument* kernel;
        std::vector<ParameterSlot> slots;
    };

    /// The plugin's explicit concept of "the currently loaded immutable
    /// instrument definition" — distinct from the mutable public parameter
    /// values held in the fixed APVTS slots.
    struct LoadedInstrument
    {
        juce::File sourceFile;   // restore hint only, per design.md
        juce::String yamlContent;
        juce::String instrumentId;
        int presetSchemaVersion = 0;
        bool reprepareFromEmbeddedYaml = false;
    };

    struct LoadedPreset
    {
        juce::File sourceFile;
        juce::String name;
        juce::String yamlContent;
    };

    struct ParsedPreset
    {
        juce::String name;
        juce::String instrumentId;
        int presetSchemaVersion = 0;
        std::map<juce::String, double> values;
        juce::String yamlContent;
        juce::String error;
    };

    struct PreparedUiReload
    {
        juce::String yaml;
        std::vector<PublicParameterDescriptor> descriptors;
        std::unique_ptr<DandrumKernelInstrument, decltype (&dandrum_kernel_destroy)> candidate {
            nullptr, &dandrum_kernel_destroy };
        juce::String error;
    };

    class SessionActivation;

    static juce::String publicSlotParameterId (int slotIndex);
    static std::vector<PublicParameterDescriptor> loadPublicParameterDescriptors (const std::string& patchPath);
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout (
        const InstrumentDemoConfiguration& initialConfiguration);
    static bool readInstrumentIdentity (const juce::String& yaml, juce::String& instrumentId, int& schemaVersion);
    static ParsedPreset parsePresetFile (const juce::File& presetFile);
    static float clampToDescriptorRange (const PublicParameterDescriptor& descriptor, float value) noexcept;
    static float normalisePublicValue (const PublicParameterDescriptor& descriptor, float value) noexcept;
    static float denormalisePublicValue (const PublicParameterDescriptor& descriptor, float normalisedValue) noexcept;

    bool loadDefaultInstrument();
    bool replaceActiveEngineFromFile (const juce::File& yamlFile,
                                      const juce::File& sourceHint,
                                      const juce::String& yamlText,
                                      bool requirePreparedHost,
                                      bool preferCurrentSlotValues,
                                      juce::String* reloadWarning);
    void installPreparedEngine (DandrumKernelInstrument* candidateKernel,
                                const juce::File& sourceHint,
                                const juce::String& yamlText,
                                const std::vector<PublicParameterDescriptor>& descriptors,
                                bool preferCurrentSlotValues,
                                juce::String* reloadWarning);
    void runInstrumentReloadJob (std::uint64_t, const juce::File&,
                                 std::uint32_t generation, std::uint32_t sampleRate,
                                 std::size_t preparedBlockSize, bool previousMute,
                                 const std::optional<juce::String>& yamlSnapshot);
    void finishInstrumentReloadJob (UiJobStatus, bool previousMute);
    bool createInstrumentSession (std::uint32_t sampleRate, std::size_t blockSize);
    DandrumInstrumentSession* prepareInstrumentSession (
        const LoadedInstrument&, const juce::File& preparationFile,
        std::uint32_t sampleRate, std::size_t blockSize);
    void runInstrumentSessionJob (std::uint64_t, DandrumInstrumentSessionJob*);
    std::optional<std::uint64_t> requestInstrumentSessionMappingJobInternal (
        std::optional<std::pair<std::uint64_t, std::uint64_t>> connection,
        std::uint64_t requestId, std::uint64_t expectedRevision,
        const std::string& mapId, const std::string& zoneId,
        std::uint8_t keyLow, std::uint8_t keyHigh);
    std::optional<InstrumentSessionConnectionSnapshot> copyInstrumentSessionConnectionSnapshot (
        const DandrumInstrumentSessionSnapshot&) const;
    static void* beginInstrumentSessionActivation (
        void*, DandrumKernelInstrument*, const std::uint8_t*, std::size_t,
        std::uint64_t, std::size_t, std::size_t) noexcept;
    static void publishInstrumentSessionActivation (
        void*, void*, std::uint64_t, std::size_t, std::size_t) noexcept;
    static void abortInstrumentSessionActivation (void*, void*) noexcept;
    static const DandrumInstrumentSessionHostCallbacks instrumentSessionHostCallbacks;
    void renderSilence (juce::AudioBuffer<float>& buffer) const;
    void preparePublicParameterSlots (const juce::File& instrumentFile,
                                      juce::String* droppedParametersWarning,
                                      bool preferCurrentSlotValues);
    void preparePublicParameterSlots (const std::vector<PublicParameterDescriptor>& descriptors,
                                      juce::String* droppedParametersWarning,
                                      bool preferCurrentSlotValues,
                                      CandidateParameterBindings* candidate = nullptr);
    void publishParameterSurface();
    void applyChangedParameters (DandrumKernelInstrument* activeKernel) noexcept;
    void applySlotToKernel (ParameterSlot& slot, float normalisedValue, DandrumKernelInstrument* activeKernel) noexcept;
    void setSlotNormalisedValue (int slotIndex, float normalisedValue);
    void publishEditorNoteIntent (std::uint8_t note, std::uint8_t velocity) noexcept;
    void deliverEditorNoteIntent (
        DandrumKernelInstrument* activeKernel,
        const std::array<bool, 128>& hostTouchedNotes) noexcept;
    void clearEditorNoteIntentForReload() noexcept;

    const InstrumentDemoConfiguration configuration;
    // The supported main output remains stereo; input negotiation cannot change
    // it. Capture once before host use so UI readers never access JUCE bus storage.
    const std::vector<InstrumentUiDocument::OutputBus> hostOutputBuses;
    juce::AudioProcessorValueTreeState parameters;
    std::atomic<DandrumKernelInstrument*> kernel { nullptr };
    std::unique_ptr<DandrumInstrumentSession, decltype (&dandrum_instrument_session_destroy)>
        instrumentSession { nullptr, &dandrum_instrument_session_destroy };
    std::atomic<std::uint32_t> engineAccess { 0 };
    bool instrumentLoaded = false;
    juce::String lastLoadError;
    juce::String lastPresetError;
    juce::String lastReloadWarning;
    LoadedInstrument loadedInstrument;
    LoadedPreset loadedPreset;
    std::vector<ParameterSlot> parameterSlots;
    std::atomic<bool> muted { false };
    std::atomic<int> replacementState { static_cast<int> (ReplacementState::Running) };
    std::atomic<std::uint32_t> parameterSurfaceGeneration { 0 };
    std::atomic<std::size_t> droppedMidiEventCount { 0 };
    // One admission writer and one audio reader. The upper 48 bits count note
    // onsets, then one byte retains their velocity and the low byte is desired
    // gate velocity. An on/off pair between callbacks still carries an onset.
    static_assert (std::atomic<std::uint64_t>::is_always_lock_free);
    // Reload may run off the message thread; only admission/teardown takes
    // this lock. The audio callback reads atomic intent without locking.
    std::mutex editorNoteCommandMutex;
    std::array<std::atomic<std::uint64_t>, 128> editorNoteIntent {};
    std::array<std::optional<std::uint64_t>, 128> editorNoteOwner {};
    std::array<std::uint64_t, 128> lastAudioEditorOnSequence {};
    std::array<bool, 128> audioEditorNoteHeld {};
    std::array<bool, 128> audioEditorTransientRelease {};
    std::array<bool, 128> audioHostNoteHeld {};
    std::array<bool, 128> audioHostReleasePending {};
    DandrumKernelInstrument* lastAudioKernel = nullptr;
    DandrumKernelInstrument* lastMeterKernel = nullptr;
    InstrumentUiMeterCapture meterCapture;
    InstrumentUiMeterAggregation meterAggregation;
    InstrumentUiMeterDisplay meterDisplay;
    InstrumentUiMeterDelivery meterDelivery;
    InstrumentUiLiveService liveService;

    void refreshMeterCaptureSubscription (bool wasInactive) noexcept;
    // Serializes engine replacement, reprepare, and UI metadata snapshots.
    // Readers copy retained metadata before a previous engine is destroyed.
    // Host notifications may re-enter snapshot readers on the same thread.
    mutable std::recursive_mutex reloadMutex;
    bool engineActivationInProgress = false; // protected by reloadMutex, including recursive notifications
    InstrumentUiWaveformService waveformService;
    InstrumentUiSpectralService spectralService;
    InstrumentUiCommandService uiCommandService { *this };
    std::unique_ptr<SoundLabController> soundLabController;
    juce::File soundLabReferenceFile;
    // Admission/status use reloadMutex; this processor-owned worker also
    // serializes activation there. Its completion is independent of editors.
    std::future<void> pendingUiReload;
    std::future<void> pendingInstrumentSessionJob;
    // Optional off-audio observation barrier, owned until the worker is joined.
    // This is also the pre-validation boundary used by lifecycle tests.
    std::function<void()> beforeUiReloadPreparation;
    bool uiReloadActive = false;
    bool uiReloadShuttingDown = false;
    bool instrumentSessionJobActive = false;
    bool instrumentSessionReconfigurationPending = false;
    std::thread::id instrumentSessionLifecycleOwner;
    std::atomic<bool> instrumentSessionLeasePublishing { false };
    std::atomic<std::size_t> instrumentSessionLeasePublicationThread { 0 };
    bool failNextSessionActivationForTest = false;
    std::deque<InstrumentSessionJobStatus> instrumentSessionJobHistory;
    std::uint64_t nextUiJobId = 1;
    std::deque<UiJobStatus> uiJobHistory;
    // Watches the loaded instrument file for external edits and reloads it
    // through the standard replacement transaction. Declared last so it is
    // destroyed (and its timer stopped) before the members its callback uses.
    InstrumentFileWatcher instrumentFileWatcher;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DandrumAudioProcessor)
};
