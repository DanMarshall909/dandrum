#pragma once

namespace Tb303WebUi
{
inline constexpr auto indexHtml = R"HTML(<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dandrum TB-303</title>
<style>
:root{font-family:"Arial Narrow",Arial,sans-serif;color:#171717;background:#111}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 50% 15%,#555,#222 45%,#0d0d0d);overflow:auto}.stage{min-height:100vh;display:grid;place-items:center;padding:18px}.machine{width:min(1180px,96vw);padding:22px 25px;border-radius:13px;background:linear-gradient(#d2d0c7,#a5a49b 55%,#8d8d85);border:1px solid #555;box-shadow:0 26px 60px #000b,inset 0 1px #fff,0 0 0 6px #202020}.brand{display:flex;justify-content:space-between;align-items:end;border-bottom:2px solid #222;padding:2px 5px 12px;font-weight:900}.brand .roland{font-size:24px}.brand .model{font-size:29px;color:#d22922}.synth{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:14px;padding:20px 4px;border-bottom:2px solid #282828}.control{display:grid;place-items:center;gap:8px}.empty-controls{grid-column:1/-1;padding:35px;text-align:center;font-size:12px;font-weight:900}.label{font-size:10px;font-weight:900;letter-spacing:.7px;text-align:center}.knob-wrap{position:relative;width:98px;height:98px;display:grid;place-items:center}.knob-wrap:before{content:"";position:absolute;inset:3px;border-radius:50%;background:repeating-conic-gradient(from -135deg,#222 0 1deg,transparent 1deg 27deg);clip-path:polygon(0 0,100% 0,100% 80%,50% 50%,0 80%)}.knob{position:relative;width:69px;height:69px;border-radius:50%;background:radial-gradient(circle at 34% 28%,#777,#2b2b2b 35%,#080808 78%);border:2px solid #050505;box-shadow:inset 2px 2px 4px #fff2,inset -4px -5px 7px #000,0 4px 6px #0008;cursor:ns-resize;touch-action:none}.knob i{position:absolute;left:50%;top:5px;width:3px;height:28px;background:#eee;border-radius:2px;transform-origin:50% 30px}.mode button,.step,.fn{border:1px solid #111;border-radius:3px;background:linear-gradient(#555,#151515);color:#eee;box-shadow:inset 0 1px #fff4,0 3px 4px #0007;font-weight:900;cursor:pointer}.mode button.on,.step.on,.fn.on{color:#ff493f;transform:translateY(2px);box-shadow:inset 0 3px 6px #000}/*sound-lab-style*/.middle{display:grid;grid-template-columns:210px 1fr;border-top:2px solid #282828;border-bottom:2px solid #282828}.left{padding:18px;border-right:2px solid #282828}.mode{display:grid;gap:10px}.mode button{height:38px}.status{margin-top:16px;background:#171c18;border:4px solid #30312d;color:#ff543e;font:700 20px monospace;padding:8px;text-align:center;text-shadow:0 0 7px #f31}.seq{padding:18px}.steps{display:grid;grid-template-columns:repeat(8,1fr);gap:7px}.step{height:43px}.step span{display:inline-block;width:8px;height:8px;border-radius:50%;background:#421714;margin-right:6px}.step.on span{background:#ff3b2e;box-shadow:0 0 8px #ff3b2e}.functions{display:grid;grid-template-columns:repeat(6,1fr);gap:7px;margin-top:12px}.fn{height:36px;font-size:9px}.keys{display:grid;grid-template-columns:repeat(19,1fr);gap:4px;padding-top:17px}.key{height:96px;border:1px solid #111;border-radius:2px 2px 5px 5px;background:linear-gradient(90deg,#efeee7,#aaa89f);font-weight:900;cursor:pointer}.key.black{height:70px;color:#eee;background:linear-gradient(90deg,#555,#111)}.key.on{transform:translateY(3px);box-shadow:inset 0 4px 9px #0008}.footer{display:flex;justify-content:space-between;padding-top:12px;font-size:9px;font-weight:900}.error{position:fixed;left:24px;right:24px;bottom:8px;color:#ff786f;font-size:11px;text-align:center;pointer-events:none}@media(max-width:900px){.machine{padding:15px}.stage{padding:8px}.lab-body{grid-template-columns:1fr}.middle{grid-template-columns:160px 1fr}}
</style>
</head>
<body>
<main class="stage">
  <section class="machine">
    <header class="brand"><span class="roland">ROLAND <small>COMPUTER CONTROLLED</small></span><span>BASS LINE <span class="model">TB-303</span></span></header>
    <section class="synth" id="controls"></section>
    <!--sound-lab-panel-->
    <section class="middle"><div class="left"><div class="mode"><button class="on">PATTERN</button><button>TRACK</button></div><div class="status" id="status">01</div></div><div class="seq"><div class="steps" id="steps"></div><div class="functions" id="functions"></div></div></section>
    <section class="keys" id="keys"></section>
    <footer class="footer"><span>DIN SYNC &nbsp; 12V DC</span><span>MADE IN JAPAN &nbsp; TB-303</span><span>POWER &nbsp; OUTPUT</span></footer>
  </section>
  <div class="error" id="error"></div>
</main>
<script src="/shared-instrument-ui.js"></script>
<!--sound-lab-script-->
<script>
const steps=document.getElementById('steps');for(let n=0;n<16;n++){const b=document.createElement('button');b.className='step'+(n===0?' on':'');b.innerHTML=`<span></span>${n+1}`;b.onclick=()=>{document.querySelectorAll('.step').forEach(x=>x.classList.remove('on'));b.classList.add('on');document.getElementById('status').textContent=String(n+1).padStart(2,'0')};steps.appendChild(b)}
for(const name of ['TRANSPOSE DOWN','TRANSPOSE UP','ACCENT','SLIDE','REST','TIE']){const b=document.createElement('button');b.className='fn';b.textContent=name;b.onclick=()=>b.classList.toggle('on');document.getElementById('functions').appendChild(b)}
</script>
</body>
</html>)HTML";
}
