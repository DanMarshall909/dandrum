cmake_minimum_required(VERSION 3.22)

if (NOT DEFINED SOURCE_ROOT)
    message(FATAL_ERROR "SOURCE_ROOT must point to the repository root")
endif()

function(read_source_relative out_var relative_path)
    file(READ "${SOURCE_ROOT}/${relative_path}" source_text)
    set(${out_var} "${source_text}" PARENT_SCOPE)
endfunction()

function(strip_trailing_rust_test_module out_var source_text)
    string(FIND "${source_text}" "\n#[cfg(test)]\nmod tests" test_module_pos)
    if (NOT test_module_pos EQUAL -1)
        string(SUBSTRING "${source_text}" 0 ${test_module_pos} source_text)
    endif()
    set(${out_var} "${source_text}" PARENT_SCOPE)
endfunction()

function(extract_function_body out_var source_text signature)
    string(FIND "${source_text}" "${signature}" signature_pos)
    if (signature_pos EQUAL -1)
        message(FATAL_ERROR "Could not find function signature: ${signature}")
    endif()

    string(SUBSTRING "${source_text}" ${signature_pos} -1 after_signature)
    string(FIND "${after_signature}" "{" open_offset)
    if (open_offset EQUAL -1)
        message(FATAL_ERROR "Could not find function body for: ${signature}")
    endif()

    string(SUBSTRING "${after_signature}" ${open_offset} -1 body_and_rest)
    string(FIND "${body_and_rest}" "\n}" close_offset)
    if (close_offset EQUAL -1)
        message(FATAL_ERROR "Could not find end of function body for: ${signature}")
    endif()

    string(SUBSTRING "${body_and_rest}" 0 ${close_offset} body)
    set(${out_var} "${body}" PARENT_SCOPE)
endfunction()

read_source_relative(rust_engine_source "src/juce-wrapper/RustEngineSource.cpp")
extract_function_body(
    get_next_audio_block_body
    "${rust_engine_source}"
    "void RustEngineSource::getNextAudioBlock")

if (get_next_audio_block_body MATCHES "ScopedLock|CriticalSection|std::cout|std::cerr|dandrum_engine_load_patch|dandrum_engine_prepare")
    message(FATAL_ERROR "RustEngineSource::getNextAudioBlock contains callback-unsafe locking, console IO, or engine preparation")
endif()

extract_function_body(
    note_on_body
    "${rust_engine_source}"
    "bool RustEngineSource::noteOn")

if (note_on_body MATCHES "ScopedLock|CriticalSection|dandrum_engine_note_on")
    message(FATAL_ERROR "RustEngineSource::noteOn must enqueue without locking or directly mutating the engine")
endif()

extract_function_body(
    note_off_body
    "${rust_engine_source}"
    "bool RustEngineSource::noteOff")

if (note_off_body MATCHES "ScopedLock|CriticalSection|dandrum_engine_note_off")
    message(FATAL_ERROR "RustEngineSource::noteOff must enqueue without locking or directly mutating the engine")
endif()

read_source_relative(midi_to_rust_engine "src/juce-wrapper/MidiToRustEngine.cpp")
extract_function_body(
    handle_incoming_midi_body
    "${midi_to_rust_engine}"
    "void MidiToRustEngine::handleIncomingMidiMessage")

if (handle_incoming_midi_body MATCHES "std::cout|std::cerr")
    message(FATAL_ERROR "MidiToRustEngine::handleIncomingMidiMessage contains callback-unsafe console IO")
endif()

read_source_relative(plugin_processor_source "src/juce-plugin/PluginProcessor.cpp")
extract_function_body(
    plugin_process_block_body
    "${plugin_processor_source}"
    "void DandrumAudioProcessor::processBlock")

if (plugin_process_block_body MATCHES "ScopedLock|CriticalSection|std::cout|std::cerr|new |malloc|dandrum_engine_load_patch|dandrum_engine_prepare|dandrum_engine_create|dandrum_engine_destroy|SoundLab|sound_fixture|sound_workbench|sound_match|reference|Sha256|optimizer|graph_proposal|provider|codex|std::process|write_wav|fft|waveformService|InstrumentUiWaveformService|requestPreparedWaveform|cancelPreparedWaveformJob|std::jthread|\\.join\\(")
    message(FATAL_ERROR "DandrumAudioProcessor::processBlock contains callback-unsafe locking, allocation, console IO, engine lifecycle/loading, matching, provider, or offline Sound Lab work")
endif()

foreach(capture_path
        "src/juce-plugin/InstrumentUiMeterCapture.h"
        "src/juce-plugin/InstrumentUiLiveCapture.h")
    read_source_relative(capture_source "${capture_path}")
    string(REGEX REPLACE "//[^\n]*" "" capture_code "${capture_source}")
    if (capture_code MATCHES "std::vector|std::mutex|condition_variable|new |malloc|make_unique|make_shared|WaitableEvent|callAsync|triggerAsyncUpdate|MessageManager|std::thread|std::future")
        message(FATAL_ERROR "${capture_path} contains allocation, locking, message posting or worker execution")
    endif()
endforeach()

set(rust_offline_operation_pattern
    "codex_cli_provider|graph_proposal|sound_matching|sound_workbench|match_sound_fixture|std::process|Command::new|std::fs|fs::(read|write|File|OpenOptions)|File::(open|create)|sha2|Sha256|rustfft|FftPlanner|deterministic_bounded_search|optimizer|reference_wav|load_pcm_wav|decode_pcm_wav|write_wav|fft")

foreach(forbidden_rust_example
        "use std::fs"
        "std::fs::read"
        "File::open"
        "sha2::Sha256"
        "rustfft::FftPlanner"
        "deterministic_bounded_search"
        "load_pcm_wav"
        "write_wav_stereo_i16"
        "codex_cli_provider"
        "Command::new")
    if (NOT forbidden_rust_example MATCHES "${rust_offline_operation_pattern}")
        message(FATAL_ERROR "Realtime Rust guard calibration missed: ${forbidden_rust_example}")
    endif()
endforeach()

foreach(realtime_rust_source
        "src/rust-engine/src/realtime.rs"
        "src/rust-engine/src/graph_processor/mod.rs"
        "src/rust-engine/src/graph_processor/realtime_graph_processor.rs"
        "src/rust-engine/src/graph_processor/processing.rs"
        "src/rust-engine/src/graph_processor/block.rs"
        "src/rust-engine/src/graph_processor/audio_arena.rs"
        "src/rust-engine/src/graph_processor/event_queue.rs"
        "src/rust-engine/src/synth.rs"
        "src/rust-engine/src/ffi.rs")
    read_source_relative(realtime_source_text "${realtime_rust_source}")
    strip_trailing_rust_test_module(realtime_production_source "${realtime_source_text}")
    if (realtime_production_source MATCHES "${rust_offline_operation_pattern}")
        message(FATAL_ERROR "${realtime_rust_source} imports file IO, FFT, hashing, optimization, matching, proposal, WAV, or child-process work")
    endif()
endforeach()

read_source_relative(main_source "src/juce-wrapper/Main.cpp")
string(FIND "${main_source}" "defaultPatchPath(" default_patch_pos)
if (default_patch_pos EQUAL -1)
    message(FATAL_ERROR "Main.cpp must load the bundled default patch when no explicit patch is provided")
endif()

string(FIND "${main_source}" "engineSource.loadPatch" load_patch_pos)
string(FIND "${main_source}" "deviceManager.addAudioCallback" add_audio_callback_pos)

if (load_patch_pos EQUAL -1 OR add_audio_callback_pos EQUAL -1)
    message(FATAL_ERROR "Main.cpp must load a patch and attach the audio callback")
endif()

if (add_audio_callback_pos LESS load_patch_pos)
    message(FATAL_ERROR "Main.cpp must load the patch before attaching the audio callback")
endif()
