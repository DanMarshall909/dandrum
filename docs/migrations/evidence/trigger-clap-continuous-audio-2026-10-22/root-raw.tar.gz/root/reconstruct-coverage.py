from pathlib import Path
import hashlib,json,subprocess,time
out=Path('/tmp/dandrum-evidence/g3-continuous-native-fixture');author=Path('/tmp/dandrum-evidence/g3-continuous-native-audio');root=Path('/tmp/dandrum-lanes/integration');assert (out/'author-release-admitted.json').is_file();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binding=author/'refactor-coverage-binding.json';assert sha(binding)=='96de778be65af9b068ecd6840c9f6c3172fd97040331e846820e7d5176c915c1';b=json.loads(binding.read_text())
for p,h in b['objects'].items():assert sha(Path(p))==h
for p,h in b['profiles'].items():assert sha(Path(p))==h
for i,t in enumerate(('llvm-profdata','llvm-cov')):assert sha(Path(b['commands'][i][0]))==b['tool_sha256'][t]
merge=list(b['commands'][0]);merge[merge.index('-o')+1]=str(out/'root-final.profdata');export=list(b['commands'][1]);export[-1]='--instr-profile='+str(out/'root-final.profdata');start=time.monotonic()
for label,cmd in [('merge',merge),('export',export)]:
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);(out/f'root-final-{label}.stderr.log').write_bytes(p.stderr);assert p.returncode==0
 if label=='export':(out/'root-final-raw-export.json').write_bytes(p.stdout)
original=author/'coverage-final/export.json';assert sha(original)==b['export_sha256'];assert json.loads(original.read_text())==json.loads((out/'root-final-raw-export.json').read_text())
rows=[]
for f in json.loads(original.read_text())['data'][0]['functions']:
 name=f['name'];suffix='src/clap-adapter/tests/internal/trigger_note_native.rs';wanted=('continuous_' in name or 'Continuous' in name) and any(x.endswith('/'+suffix) for x in f['filenames'])
 if not wanted:
  suffix='src/clap-adapter/tests/trigger_parameters.rs';wanted=any(v in name for v in ('calibrated_callback_audit','run_allocator_audit_child')) or ('5Audit' in name and '7measure' in name);wanted=wanted and any(x.endswith('/'+suffix) for x in f['filenames'])
 if not wanted:continue
 regions=[r for r in f['regions'] if r[7]==0 and f['filenames'][r[5]].endswith('/'+suffix)]
 rows.append(dict(name=name,source=suffix,source_sha256=sha(root/suffix),function_count=f['count'],source_regions=len(regions),positive_source_regions=sum(r[4]>0 for r in regions),zero_hit_spans=[r[:4] for r in regions if r[4]==0]))
assert any('run_allocator_audit_child' in r['name'] and r['source_regions']==r['positive_source_regions']==116 for r in rows)
assert any('calibrated_callback_audit' in r['name'] and r['source_regions']==r['positive_source_regions']==49 for r in rows)
x=dict(binding_sha256=sha(binding),objects=b['objects'],profiles=b['profiles'],raw_profile_count=len(b['profiles']),original_export_sha256=sha(original),regenerated_export_sha256=sha(out/'root-final-raw-export.json'),commands=[merge,export],exit=[0,0],seconds=time.monotonic()-start,functions=rows,scope='Fresh independent merge/export from verified tools,2 actual ELFs and13 raw profiles; parsed data equality. Profiles include exact --list invocations plus3 outer tests and2 parent-owned allocator children, not13 executions. Both lists and parent-only runs may emit host profiles without a DSO. File-identified code-region accounting, not branch/whole-owner completeness; fixture error/timeout/ownership defenses remain disclosed. No physical-device or narrow destroy-call-overlap claim.')
(out/'root-final-coverage-assessment.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(dict(profiles=len(b['profiles']),functions=len(rows),fully_positive=sum(r['source_regions']==r['positive_source_regions'] for r in rows),stderr_bytes=sum((out/f'root-final-{n}.stderr.log').stat().st_size for n in ('merge','export')))))
