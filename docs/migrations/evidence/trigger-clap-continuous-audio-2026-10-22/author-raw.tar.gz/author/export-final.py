from pathlib import Path
import json,hashlib,subprocess,shutil
out=Path('/tmp/dandrum-evidence/g3-continuous-native-audio');binding=json.loads((out/'final-coverage-execution-binding.json').read_text());tools=Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin');dest=out/'coverage';dest.mkdir(exist_ok=True);h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
profiles=[]
for p,digest in binding['profiles'].items():
 assert h(p)==digest;q=dest/Path(p).name;shutil.copy2(p,q);profiles.append(q)
dso=Path(binding['instrumented_dso']);test=Path(binding['test']);assert h(dso)==binding['dso_sha256'] and h(test)==binding['test_sha256'];merged=dest/'coverage.profdata'
commands=[[str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in profiles],'-o',str(merged)],[str(tools/'llvm-cov'),'export',str(dso),'--object='+str(test),'--instr-profile='+str(merged)]]
receipt={'tool_versions':{n:subprocess.check_output([str(tools/n),'--version'],text=True) for n in ('llvm-profdata','llvm-cov')},'tool_sha256':{n:h(tools/n) for n in ('llvm-profdata','llvm-cov')},'commands':commands,'objects':{str(dso):h(dso),str(test):h(test)},'profiles':{str(p):h(p) for p in profiles},'commands_exit':[]}
for i,c in enumerate(commands):
 with (dest/(str(i)+'.stdout.log' if i==0 else 'export.json')).open('w') as stdout,(dest/(str(i)+'.stderr.log')).open('w') as stderr:r=subprocess.run(c,stdout=stdout,stderr=stderr)
 receipt['commands_exit'].append(r.returncode);assert r.returncode==0
files=['src/trigger-editor/src/native_x11.rs','src/clap-adapter/src/trigger/gui.rs','src/clap-adapter/tests/internal/trigger_note_native.rs','src/clap-adapter/tests/trigger_parameters.rs']
show=[str(tools/'llvm-cov'),'show',str(dso),'--object='+str(test),'--instr-profile='+str(merged),'--show-line-counts-or-regions','--show-instantiations',*[str(Path('/tmp/dandrum-lanes/runtime')/p) for p in files]]
with (dest/'focused-show.txt').open('w') as stdout,(dest/'show.stderr.log').open('w') as stderr:r=subprocess.run(show,stdout=stdout,stderr=stderr)
receipt['show_command']=show;receipt['show_exit']=r.returncode;assert r.returncode==0
for obj in (dso,test):
 for option,name in [('-n','notes'),('-S','sections')]:
  with (dest/(obj.name+'.'+name+'.txt')).open('w') as f:subprocess.run(['readelf',option,str(obj)],stdout=f,check=True)
data=json.loads((dest/'export.json').read_text());selected=[]
for d in data['data']:
 for f in d['functions']:
  joined='\n'.join(f['filenames'])
  if any(s in joined for s in ('trigger_note_native.rs','trigger_parameters.rs','native_x11.rs')) or ('/trigger/gui.rs' in joined and ('set_parent' in f['name'] or 'cleanup_attachment' in f['name'])):
   selected.append(f)
receipt['focused_functions']=selected;receipt['export_sha256']=h(dest/'export.json');receipt['merged_sha256']=h(merged);(out/'final-coverage-binding.json').write_text(json.dumps(receipt,indent=2));print(json.dumps([{'name':f['name'],'count':f['count']} for f in selected if f['count']]))
