import subprocess,sys

def run_exact(elf,name,ignored):
 listing=subprocess.check_output([elf,'--list'],text=True)
 assert name+': test' in listing.splitlines(),'exact test not found'
 args=[elf,name,'--exact','--show-output','--test-threads=1']
 if ignored:args.append('--ignored')
 result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 sys.stdout.buffer.write(result.stdout);sys.stderr.buffer.write(result.stderr)
 output=result.stdout.decode(errors='replace')
 assert 'running 1 test' in output,'expected exactly one executed test'
 assert any('test '+name+' ... '+status in output.splitlines() for status in ('ok','FAILED')),'exact test result missing'
 assert any(summary in output for summary in ('test result: ok. 1 passed; 0 failed;','test result: FAILED. 0 passed; 1 failed;')),'exact one-test summary missing'
 return result.returncode
