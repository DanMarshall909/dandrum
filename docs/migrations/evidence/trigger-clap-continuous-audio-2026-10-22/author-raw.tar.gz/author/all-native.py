from pathlib import Path
import json,sys,time,subprocess,os,hashlib
from exact import run_exact
out=Path('/tmp/dandrum-evidence/g3-continuous-native-audio');elf=str(out/'trigger_parameters')
assert 'RUST_MIN_STACK' not in os.environ and 'LD_PRELOAD' not in os.environ
listing=subprocess.check_output([elf,'--list','--ignored'],text=True)
names=[s[:-6] for s in listing.splitlines() if s.endswith(': test')];assert len(names)==21,(len(names),names)
# This helper executes under LD_PRELOAD only from its calibrated parent case.
names.remove('native_parameter_callback_allocator_audit_child');names.remove('note_native::continuous_audio_allocator_audit_child');assert len(names)==19
receipts=[];logs=out/'native-cases';logs.mkdir(exist_ok=True)
for name in names:
 start=time.monotonic()
 with (logs/(name+'.stdout.log')).open('w') as stdout,(logs/(name+'.stderr.log')).open('w') as stderr:
  result=subprocess.run([sys.executable,'-c','from exact import run_exact; import sys; sys.exit(run_exact(sys.argv[1],sys.argv[2],True))',elf,name],cwd=out,stdout=stdout,stderr=stderr,timeout=60)
 receipts.append({'case':name,'exit':result.returncode,'seconds':time.monotonic()-start})
 (out/'native-cases.json').write_text(json.dumps(receipts,indent=2));print(receipts[-1],flush=True)
 if result.returncode:sys.exit(result.returncode)
