import subprocess,sys,json,time
from pathlib import Path
from exact import run_exact
out=Path('/tmp/dandrum-evidence/g3-continuous-native-audio');elf=str(out/'trigger_gui');listing=subprocess.check_output([elf,'--list','--ignored'],text=True);cases=[s[:-6] for s in listing.splitlines() if s.endswith(': test')];assert len(cases)==5,cases
results=[]
for name in cases:
 start=time.monotonic();code=run_exact(elf,name,True);results.append({'case':name,'exit':code,'seconds':time.monotonic()-start});(out/'gui-cases.json').write_text(json.dumps(results,indent=2))
 if code:sys.exit(code)
