from pathlib import Path
import json,hashlib,subprocess,shutil
out=Path('/tmp/dandrum-evidence/g3-continuous-native-audio');root=Path('/tmp/dandrum-lanes/runtime');old=Path('/tmp/dandrum-evidence/g3-creation-failure')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
run=lambda args,cwd=root:subprocess.check_output(args,cwd=cwd,text=True).strip()
files=['src/clap-adapter/tests/internal/trigger_note_native.rs','src/clap-adapter/tests/trigger_parameters.rs'];sources={p:h(root/p) for p in files}
normal=json.loads((out/'refactor-ordinary-product-build-binding.json').read_text())['library'];assert h(normal['source'])==h(normal['copy'])==normal['sha256']
resources=json.loads((out/'resources-baseline.json').read_text());installed=out/'installed/DandrumTrigger.resources';assert {str(p.relative_to(installed)):h(p) for p in installed.rglob('*') if p.is_file()}==resources
cache=json.loads((old/'runtime-untracked-cache-baseline.json').read_text());cache_root=root/'cache-editor-guard';current={str(p.relative_to(cache_root)):{'size':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in cache_root.rglob('*') if p.is_file()};assert current==cache
tracked=run(['git','ls-files','src/clap-adapter/src','src/trigger-editor/src','src/clap-adapter/Cargo.toml','src/clap-adapter/Cargo.lock','src/trigger-editor/Cargo.toml']).splitlines();production={}
for name in tracked:
 published=subprocess.check_output(['git','show','HEAD:'+name],cwd=root);assert hashlib.sha256(published).hexdigest()==h(root/name),name;production[name]=h(root/name)
assert set(run(['git','diff','--name-only']).splitlines())==set(files)
assert subprocess.run(['git','diff','--check'],cwd=root).returncode==0
previous=json.loads((old/'final-restoration-audit.json').read_text())['metadata_restored'];stat=Path(previous['path']).stat();assert stat.st_mtime_ns==previous['mtime_ns'] and stat.st_mode==previous['mode']
receipts=[];groups=set();minimum_disk=None;minimum_mem=None
for p in out.glob('*.json'):
 try:r=json.loads(p.read_text())
 except json.JSONDecodeError:continue
 if isinstance(r,dict) and 'owned_process_group' in r:
  receipts.append(p.name);groups.add(r['owned_process_group'])
  for sample in json.loads((out/(p.stem+'.samples.json')).read_text()):
   minimum_disk=min(minimum_disk or sample['disk_free_bytes'],sample['disk_free_bytes']);minimum_mem=min(minimum_mem or sample['MemAvailable'],sample['MemAvailable'])
rows=run(['ps','-eo','pid,ppid,pgid,comm']).splitlines()[1:];owned=[];builders=[]
for row in rows:
 pid,ppid,pgid,comm=row.split(maxsplit=3)
 if int(pgid) in groups:owned.append(row)
 if comm in ('cargo','rustc','rust-lld','ld','cc','clang','cc1'):builders.append(row)
assert not owned,owned;assert not builders,builders
main=Path('/home/dan/code/dandrum');main_head=run(['git','rev-parse','HEAD'],main);main_status=run(['git','status','--short'],main);assert main_head=='68dd6553a2f07e71e2fe09ee1d7094d518559937' and not main_status
body={'final_source_sha256':sources,'normal_plugin':normal,'restored_resources_sha256':resources,'production_sha256':production,'production_unchanged_from_published_HEAD':True,'runtime_head':run(['git','rev-parse','HEAD']),'known_runtime_cache_files':len(current),'known_runtime_cache_size_mtime_unchanged':True,'native_editor_mtime_and_mode_unchanged':True,'no_source_timestamp_refresh_performed':True,'owned_process_groups':sorted(groups),'owned_processes_remaining':owned,'host_builders_remaining':builders,'guarded_receipts':sorted(receipts),'minimum_sampled_disk_free_bytes':minimum_disk,'minimum_sampled_MemAvailable_bytes':minimum_mem,'disk_free_bytes':shutil.disk_usage('/tmp').free,'cache_sizes':run(['du','-sb','/tmp/dandrum-lanes/cache-editor-guard','/tmp/dandrum-lanes/cache-host-snapshot-cov']),'git_status':run(['git','status','--short']),'main_head':main_head,'main_status':main_status,'compiler_environment_verification':{'cc':run(['cc','--version']),'rustc':run(['rustc','-Vv'])}}
(out/'final-restoration-audit.json').write_text(json.dumps(body,indent=2));print(json.dumps({k:v for k,v in body.items() if k in ('final_source_sha256','known_runtime_cache_files','owned_processes_remaining','host_builders_remaining','minimum_sampled_disk_free_bytes','minimum_sampled_MemAvailable_bytes','disk_free_bytes','git_status','main_head','main_status')}))
