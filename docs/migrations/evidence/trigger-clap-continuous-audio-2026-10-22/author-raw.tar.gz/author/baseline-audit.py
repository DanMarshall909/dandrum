from exact import run_exact
raise SystemExit(run_exact('/tmp/dandrum-evidence/g3-continuous-native-audio/baseline-trigger_parameters','copied_native_parameter_callbacks_allocate_and_destroy_nothing_while_gui_services',True))
