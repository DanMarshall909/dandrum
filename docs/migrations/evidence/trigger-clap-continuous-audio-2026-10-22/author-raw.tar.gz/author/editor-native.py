from exact import run_exact
raise SystemExit(run_exact('/tmp/dandrum-evidence/g3-continuous-native-audio/dandrum_trigger_editor','native_x11::tests::destroy_releases_application_handlers_while_framework_context_remains',True))
