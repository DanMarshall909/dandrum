import sys
from exact import run_exact
raise SystemExit(run_exact('/tmp/dandrum-evidence/g3-continuous-native-audio/trigger_parameters',sys.argv[1],True))
