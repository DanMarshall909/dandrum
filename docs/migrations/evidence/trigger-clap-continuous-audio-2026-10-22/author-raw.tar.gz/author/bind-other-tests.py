import json,hashlib,shutil,sys
from pathlib import Path
out=Path('/tmp/dandrum-evidence/g3-continuous-native-audio');label=sys.argv[1]
records=[json.loads(s) for s in (out/(label+'.stdout.log')).read_text().splitlines() if s.startswith('{')];selected={}
for r in records:
 if r.get('reason')=='compiler-artifact' and r.get('executable'):
  name=r['target']['name'];p=Path(r['executable']);dest=out/name;shutil.copy2(p,dest)
  selected[name]={'source':str(p),'copy':str(dest),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
assert selected
(out/(label+'-tests-binding.json')).write_text(json.dumps(selected,indent=2));print(json.dumps(selected))
