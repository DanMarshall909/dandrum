import subprocess,sys
root='/tmp/dandrum-evidence/g3-continuous-native-audio';target='/tmp/dandrum-lanes/cache-editor-guard'
checks=[('refactor-formatting',['/home/dan/.cargo/bin/cargo','fmt','--manifest-path','src/clap-adapter/Cargo.toml','--check']),('refactor-strict-clippy',['/home/dan/.cargo/bin/cargo','clippy','--manifest-path','src/clap-adapter/Cargo.toml','--features','trigger-editor','--all-targets','--offline','--locked','--','-D','warnings']),('refactor-normal-restoration',['timeout','60s','python3',root+'/new-exact.py','note_native::copied_native_continuous_audio_survives_view_replacement'])]
for label,command in checks:
 result=subprocess.run(['python3',root+'/run.py',label,target,*command])
 if result.returncode:sys.exit(result.returncode)
