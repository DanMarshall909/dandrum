from pathlib import Path
import json,sys,os,shutil,subprocess,hashlib,time
out=Path('/tmp/dandrum-evidence/g3-continuous-native-audio');root=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g3-continuous-native-audio');dest=out/'installed/DandrumTrigger.clap';dso=root/'dso-final/libdandrum_clap_adapter.so';tests=[p for p in (root/'test-final').glob('trigger_parameters-*') if p.is_file() and not p.suffix];assert len(tests)==1
profiles=root/'final-profiles';profiles.mkdir(exist_ok=False)
normal=json.loads((out/'ordinary-product-build-binding.json').read_text())['library'];h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert h(normal['source'])==normal['sha256'];env=dict(os.environ,LLVM_PROFILE_FILE=str(profiles/'%m-%p.profraw'));assert 'RUST_MIN_STACK' not in env and 'LD_PRELOAD' not in env
names=['note_native::copied_native_continuous_audio_survives_view_replacement','note_native::copied_native_continuous_audio_callbacks_allocate_and_deallocate_nothing','copied_native_parameter_callbacks_allocate_and_destroy_nothing_while_gui_services']
receipt={'profile_pattern':env['LLVM_PROFILE_FILE'],'test':str(tests[0]),'test_sha256':h(tests[0]),'instrumented_dso':str(dso),'dso_sha256':h(dso),'ordinary_dso':normal,'cases':[]};code=1
try:
 shutil.copy2(dso,dest);receipt['copy_sha256']=h(dest)
 for name in names:
  command=[sys.executable,'-c','from exact import run_exact; import sys; sys.exit(run_exact(sys.argv[1],sys.argv[2],True))',str(tests[0]),name];start=time.monotonic()
  r=subprocess.run(command,env=env,cwd=out,timeout=60);receipt['cases'].append({'command':command,'exit':r.returncode,'seconds':time.monotonic()-start})
  if r.returncode:break
 code=r.returncode
finally:
 shutil.copy2(normal['source'],dest);receipt['restored_sha256']=h(dest);receipt['profiles']={str(p):h(p) for p in profiles.glob('*.profraw')};(out/'final-coverage-execution-binding.json').write_text(json.dumps(receipt,indent=2));assert h(dest)==normal['sha256']
sys.exit(code)
