from pathlib import Path
import os,sys,json,subprocess,hashlib
out=Path('/tmp/dandrum-evidence/g3-continuous-native-audio');kind=sys.argv[1]
recipe={'editor':'ordinary-editor-rustc.json','dso':'ordinary-dso-rustc.json','test':'trigger_parameters-test-rustc.json'}[kind]
capture=json.loads((out/recipe).read_text());dest=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g3-continuous-native-audio')/(kind+'-final');dest.mkdir(parents=True,exist_ok=False)
command=list(capture['command']);command[command.index('--out-dir')+1]=str(dest);command+=['-C','instrument-coverage']
replaced=None
if kind=='dso':
 choices=list(dest.parent.joinpath('editor-final').glob('libdandrum_trigger_editor-*.rlib'));assert len(choices)==1
 for i,arg in enumerate(command):
  if i and command[i-1]=='--extern' and arg.startswith('dandrum_trigger_editor='):
   replaced=arg;command[i]='dandrum_trigger_editor='+str(choices[0])
 assert replaced
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
env=dict(os.environ,**capture['environment'])
for k in ('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS','RUSTC_WRAPPER','LD_PRELOAD','LLVM_PROFILE_FILE'):env.pop(k,None)
env['RUST_MIN_STACK']='16777216';env['TMPDIR']=str(out/'tmp')
receipt={'recipe':recipe,'capture':capture,'command':command,'cwd':capture['cwd'],'environment':{k:env[k] for k in capture['environment'] if k in env},'changes':['out-dir redirected to exclusive LLVM cache','instrument-coverage enabled','16MiB compiler stack only','TMPDIR task-owned evidence path'],'replaced_editor_extern':replaced,'compiler':subprocess.check_output([command[0],'-Vv'],text=True),'compiler_sha256':h(command[0]),'source_sha256':{str(p):h(p) for crate in ('clap-adapter','trigger-editor') for p in Path('/tmp/dandrum-lanes/runtime/src',crate).rglob('*.rs')},'extern_sha256':{arg:h(arg.split('=',1)[1]) for i,arg in enumerate(command) if i and command[i-1]=='--extern'}}
(out/(kind+'-final-instrument.json')).write_text(json.dumps(receipt,indent=2));r=subprocess.run(command,cwd=capture['cwd'],env=env);receipt['exit']=r.returncode;(out/(kind+'-final-instrument.json')).write_text(json.dumps(receipt,indent=2));sys.exit(r.returncode)
