from pathlib import Path
import os,json,subprocess,shutil,hashlib,tarfile,time,sys
out=Path(__file__).parent;scratch=Path(os.environ['DANDRUM_VERIFICATION_SCRATCH']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((out/'native-historical-red-source.json').read_text());root=Path(source['source_root'])
for name,digest in source['snapshot']['files'].items():assert sha(root/name)==digest
records=[json.loads(s) for s in (out/'native-historical-product-build-run/stdout.log').read_text().splitlines() if s.startswith('{')]
reported=[r for r in records if r.get('reason')=='compiler-artifact' and r['target']['name']=='dandrum_clap_adapter'];assert len(reported)==1
paths=[Path(p) for p in reported[0]['filenames'] if p.endswith('.so')];assert len(paths)==1;product=paths[0]
current=json.loads((out/'native-current-result.json').read_text());fixture=Path(current['fixture']);test=fixture/current['binding']['artifacts']['test']['copy'];assert sha(test)==current['binding']['artifacts']['test']['copy_sha256']
plugin=scratch/'DandrumTrigger.clap';shutil.copy2(product,plugin);assert sha(plugin)==sha(product)
shutil.copytree(fixture/'DandrumTrigger.resources',scratch/'DandrumTrigger.resources')
with tarfile.open(out/'native-historical-product.tar.gz','x:gz',compresslevel=1) as t:t.add(plugin,arcname=plugin.name)
argv=[str(test),'structural_native::copied_native_mapping_survives_lost_reply_and_view_loss','--ignored','--exact','--nocapture','--test-threads=1'];env=dict(os.environ,GDK_BACKEND='x11',DANDRUM_TRIGGER_GUI_PLUGIN_PATH=str(plugin));start=time.monotonic();p=subprocess.run(argv,env=env,capture_output=True,timeout=45)
for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:
 with (out/('native-historical-red.'+stream)).open('xb') as f:f.write(data)
result={'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'source':'native-historical-red-source.json','product_sha256':sha(plugin),'test_sha256':sha(test),'product_compiler_artifact':reported[0],'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'scope':'Recovered actual pre-fix product with unchanged native test body; private headless authenticated X11. Inspect failure oracle before classifying RED.'};(out/'native-historical-red-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'exit':p.returncode,'seconds':result['seconds']}),flush=True);sys.exit(p.returncode)
