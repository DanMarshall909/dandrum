from pathlib import Path
import os,json,subprocess,hashlib,time,sys
root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');out=Path(__file__).parent;cargo='/home/dan/.cargo/bin/cargo';rows=[]
checks=[('adapter-fmt',[cargo,'fmt','--manifest-path','src/clap-adapter/Cargo.toml','--','--check'],0),('adapter-clippy',[cargo,'clippy','--manifest-path','src/clap-adapter/Cargo.toml','--offline','--locked','--features','trigger-editor','--all-targets','--no-deps','--','-D','warnings'],0),('active-spec',['openspec','validate','add-juce-free-trigger-beta-products','--strict'],0),('canonical-specs',['openspec','validate','--specs','--strict'],0),('spec-map',['scripts/check-spec-coverage'],0),('dependency-tree',[cargo,'tree','--manifest-path','src/clap-adapter/Cargo.toml','--offline','--locked','--features','trigger-editor','-e','normal'],0),('release-linkage',['ldd','build/engine-only/clap/DandrumTrigger.clap'],0),('engine-clippy',[cargo,'clippy','--manifest-path','src/rust-engine/Cargo.toml','--offline','--locked','--all-targets','--no-deps','--message-format=json','--','-D','warnings'],101)]
for label,argv,expected in checks:
 start=time.monotonic();p=subprocess.run(argv,cwd=root,capture_output=True)
 for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  with (out/(label+'.'+stream)).open('xb') as f:f.write(data)
 rows.append({'name':label,'argv':argv,'exit':p.returncode,'expected_exit':expected,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode!=expected:sys.exit(p.returncode or 1)
