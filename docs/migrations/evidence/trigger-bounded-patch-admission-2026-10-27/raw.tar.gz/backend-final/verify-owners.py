from pathlib import Path
import subprocess,json,time,hashlib,resource,sys
out=Path(__file__).parent;root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');cargo='/home/dan/.cargo/bin/cargo';rows=[]
for owner,features in [('trigger-host',[]),('clap-adapter',['--features','trigger-editor'])]:
 for action,args in [('fmt',['--','--check']),('test',['--offline','--locked',*features,*(['--lib'] if owner=='clap-adapter' else [])]),('clippy',['--offline','--locked',*features,'--all-targets','--no-deps','--','-D','warnings'])]:
  argv=[cargo,action,'--manifest-path','src/'+owner+'/Cargo.toml',*args];start=time.monotonic();p=subprocess.run(argv,cwd=root,capture_output=True);name=owner+'-'+action
  for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:
   with (out/(name+'.'+stream)).open('xb') as f:f.write(data)
  rows.append({'name':name,'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'maximum_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss});(out/'owner-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
  if p.returncode:sys.exit(p.returncode)
