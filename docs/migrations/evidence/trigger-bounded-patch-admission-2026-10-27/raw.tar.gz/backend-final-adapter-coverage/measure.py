from pathlib import Path
import os,subprocess,shlex,json,time,hashlib,tarfile
root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');out=Path(__file__).parent;cargo='/home/dan/.cargo/bin/cargo';cache=Path('/home/dan/.cache/dandrum-trigger-beta/llvm');base_env=dict(os.environ);env=dict(os.environ);phases=[];objects=[];names=set();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(p.relative_to(root)):sha(p) for p in (root/'src').rglob('*.rs')}
for owner in ['rust-engine','instrument-session','trigger-host','trigger-editor','clap-adapter']:
 for name in ['Cargo.toml','Cargo.lock']:
  p=root/'src'/owner/name;inputs[str(p.relative_to(root))]=sha(p)
inputs['schema/patch.schema.yaml']=sha(root/'schema/patch.schema.yaml')
(out/'source.json').write_text(json.dumps(inputs,indent=2)+'\n')
with tarfile.open(out/'source.tar.gz','x:gz') as archive:
 for name in sorted(inputs):archive.add(root/name,arcname=name,recursive=False)
def run(name,argv,child_env=None):
 start=time.monotonic();p=subprocess.run(argv,cwd=root,env=child_env or env,capture_output=True)
 for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  with (out/(name+'.'+stream)).open('xb') as f:f.write(data)
 phases.append({'name':name,'argv':argv,'exit':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()});(out/'phases.json').write_text(json.dumps(phases,indent=2)+'\n');print(name,p.returncode,flush=True)
 assert p.returncode==0,name
 return p.stdout.decode()
for owner in ['clap-adapter','trigger-host','instrument-session','rust-engine','trigger-editor']:
 shown=run(owner+'-environment',[cargo,'llvm-cov','show-env','--manifest-path','src/'+owner+'/Cargo.toml','--sh'],base_env)
 for line in shown.splitlines():
  parts=shlex.split(line);assert len(parts)==2 and parts[0]=='export';key,sep,value=parts[1].partition('=');assert sep
  if key=='__CARGO_LLVM_COV_RUSTC_WRAPPER_CRATE_NAMES':names.update(value.split(','))
  else:env[key]=value
for key in ['CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR']:env[key]=str(cache)
env['__CARGO_LLVM_COV_RUSTC_WRAPPER_CRATE_NAMES']=','.join(sorted(names));assert env.get('__CARGO_LLVM_COV_RUSTC_WRAPPER_PRE_EXISTING')!=env.get('RUSTC_WRAPPER')
profiles=out/'profiles';profiles.mkdir();env['LLVM_PROFILE_FILE']=str(profiles/'%m-%p.profraw');(out/'environment.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('CARGO','__CARGO','LLVM','RUSTC','RUSTFLAGS','RUSTDOCFLAGS'))},indent=2)+'\n')
for label,owner,selection in [('adapter','clap-adapter',['--features','trigger-editor','--lib'])]:
 text=run(label+'-compile',[cargo,'test','--manifest-path','src/'+owner+'/Cargo.toml','--offline','--locked',*selection,'--no-run','--message-format=json']);records=[]
 for line in text.splitlines():
  if line.startswith('{'):records.append(json.loads(line))
 artifacts=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('profile',{}).get('test')];assert artifacts
 for index,artifact in enumerate(artifacts):
  elf=Path(artifact['executable']);assert elf.resolve().is_relative_to(cache.resolve());objects.append({'path':str(elf),'sha256':sha(elf),'artifact':artifact,'owner':owner});run(label+'-execute-'+str(index),[str(elf),'--nocapture','--test-threads=1'])
tools=Path(subprocess.check_output(['/home/dan/.cargo/bin/rustc','--print','sysroot'],text=True).strip())/'lib/rustlib/x86_64-unknown-linux-gnu/bin';raw=sorted(profiles.glob('*.profraw'));assert raw
merged=out/'merged.profdata';run('merge',[str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in raw],'-o',str(merged)])
args=[objects[0]['path'],*[a for o in objects[1:] for a in ['--object',o['path']]],'--instr-profile',str(merged)]
for index,obj in enumerate(objects):
 individual=json.loads(run('object-'+str(index)+'-export',[str(tools/'llvm-cov'),'export',obj['path'],'--instr-profile',str(merged)]));mapped={f['filename'] for d in individual['data'] for f in d['files']};assert any(p.endswith('/rust-engine/src/preparation.rs') for p in mapped),'missing actual engine instrumentation';assert sha(Path(obj['path']))==obj['sha256']
export=json.loads(run('export',[str(tools/'llvm-cov'),'export',*args]));run('annotation',[str(tools/'llvm-cov'),'show',*args,'--show-line-counts-or-regions']);summary={f['filename']:f['summary'] for d in export['data'] for f in d['files'] if '/src/trigger-host/src/' in f['filename'] or f['filename'].endswith('/clap-adapter/src/trigger/gui.rs')};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert all(sha(root/name)==digest for name,digest in inputs.items()),'source changed during coverage'
binding={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'objects':objects,'profiles':{p.name:sha(p) for p in raw},'merged_sha256':sha(merged),'tools':{n:sha(tools/n) for n in ['llvm-cov','llvm-profdata']},'source_sha256':sha(out/'source.json'),'replay_objects_pending':True,'scope':'Current complete editor-adapter library suite after table-driven Undo/Redo retry test refactoring. Production sources equal chooser-retry-coverage; that run also retains complete host coverage. Actual native Core/GTK/physical input, official release validator, portable restoration, installed and named DAW gates remain separate; full engine owner coverage is not this scope.'};(out/'binding.json').write_text(json.dumps(binding,indent=2)+'\n');print('Complete:',len(objects),'executables',len(raw),'profiles',flush=True)
