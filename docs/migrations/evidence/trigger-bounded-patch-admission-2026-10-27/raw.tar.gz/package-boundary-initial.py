from pathlib import Path
import os,json,hashlib,tarfile,subprocess
out=Path(__file__).parent;root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');dest=root/'docs/migrations/evidence/trigger-bounded-patch-admission-2026-10-27';dest.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();members={}
def add(p,name=None):
 p=Path(p);assert p.is_file() and not p.is_symlink();name=name or str(p.relative_to(out));assert name not in members or members[name]==p;members[name]=p
for p in sorted(out.iterdir()):
 if p.is_dir() and not p.is_symlink() and ('-run' in p.name) and (p/'owner.json').exists():
  cleanup=json.loads((p/'cleanup.json').read_text());assert cleanup['scratch_removed'] and not cleanup['remaining_workers'],p.name
  for f in p.iterdir():
   if f.is_file() and not f.is_symlink():add(f)
for folder in ['backend-final','backend-wide','source-free-command-logs','official-current']:
 for p in (out/folder).rglob('*'):
  if p.is_file():add(p)
coverage=['chooser-retry-coverage','backend-final-adapter-coverage','native-final-coverage']
for folder in coverage:
 for p in (out/folder).iterdir():
  if p.is_file() and (p.suffix in ['.json','.py'] or p.name in ['export.stdout','annotation.stdout','source.tar.gz','merged.profdata']):add(p)
 for p in (out/folder/'profiles').glob('*.profraw'):add(p)
# Earlier exact replay map is shared by final native scopes, not copied binaries.
for name in ['native-core-coverage/binding.json','native-core-coverage/phases.json','native-core-coverage/measure.py','native-core-coverage/environment.json']:
 p=out/name
 if p.exists():add(p)
for p in out.glob('.trigger-clap-native-fixture-*/evidence/*'):
 if p.is_file():add(p,'diagnostic-prepare/'+p.parent.parent.name+'/'+p.name)
for pattern in ['*-result.json','*-source.json','*-assessment.json','*-completion.json','*storage*.json','*-time.txt','*tooling.json','tool-versions.json','engine-clippy-comparison.json','resumed-profile.json','restoration.json','checkpoint-digest-comparison.json','native-*.log','native-historical-red.stdout','native-historical-red.stderr','creation-failure-diagnostic-source*.rs','native-current-cache-refresh.json','native-current-LastTest.log','native-full-final-LastTest.log','replay-steps.json','chooser-retry-red-source.tar.gz']:
 for p in out.glob(pattern):
  if p.is_file():add(p)
# Portable historical overlays use immutable Git0856 plus content-addressed blobs.
phases=[]
for filename in ['projection-red-replay-source.json','parse-budget-red-replay-source.json','native-historical-red-source.json','legacy-save-historical-red-source.json','native-redo-historical-red-source.json']:
 p=out/filename;doc=json.loads(p.read_text());files=doc['source'] if 'source' in doc else doc['snapshot']['files'];phases.append({'name':filename,'base':'0856dee556f5cafcb118c88be2d78283b39d1cb0','files':files,'absent':doc.get('absent_owned_source_paths',[])})
 for name,digest in files.items():
  blob=out/'recovered-source-blobs'/digest;assert sha(blob)==digest;add(blob,'source-blobs/'+digest)
 add(p)
recipe=out/'portable-boundary-source-replay.json';recipe.write_text(json.dumps({'phases':phases,'instructions':'Start a fresh isolated checkout/archive of each immutable base; overlay source-blobs by each phase map and remove explicit absent paths. Current production is Git35a79fba; current tests are the two source_delta files in binding.json. Historical reruns are actual recovered predecessors, not mutation/fault injection. Original post-core /tmp raw evidence was lost on restart; fresh reruns replace it. Published core raw packet preserves original initial full-patch capabilityUnavailable RED.'},indent=2)+'\n');add(recipe)
external=[]
archives=['chooser-retry-coverage/replay-objects.tar.gz','backend-final-adapter-coverage/replay-objects.tar.gz','native-core-coverage/replay-product.tar.gz','projection-historical-red-artifact.tar.gz','parse-budget-historical-red-artifact.tar.gz','chooser-retry-red-executable.tar.gz','legacy-save-historical-red-executable.tar.gz','native-redo-historical-red-executable.tar.gz','native-historical-product.tar.gz','native-current-fixture.tar.gz']
for name in archives:
 p=out/name;assert p.is_file();external.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
external_path=out/'boundary-external-artifacts.json';external_path.write_text(json.dumps({'artifacts':external,'scope':'Large exact or LLVM-equivalent replay binaries remain outside Git at bound paths/hashes. Current and historical sources/tool recipes/profiles/logs retained in raw packet. Cached originals are mutable and not an immutable evidence authority.'},indent=2)+'\n');add(external_path)
index=[];archive=dest/'raw.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=1) as t:
 for name,p in sorted(members.items()):
  index.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)});t.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(index)
 for row in index:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
(dest/'raw-index.json').write_text(json.dumps({'archive_sha256':sha(archive),'members':index},indent=2)+'\n')
paths=['src/clap-adapter/tests/internal/trigger_structural_native.rs','src/clap-adapter/tests/internal/trigger_creation_failure_native.rs'];binding={'base':'0856dee556f5cafcb118c88be2d78283b39d1cb0','production_commit':'35a79fba3de32407e81610661253d17d65491177','production_tree':'779a671c7223105cbbe701008d49e25b7c5061ef','source_delta':[{'path':n,'sha256':sha(root/n)} for n in paths],'tested_staged_source_tree':json.loads((out/'native-final-coverage/binding.json').read_text())['staged_tree'],'scope':'Bounded native editor wire v2/full-patch publication/Redo/reply budget/legacy-save refusal, plus test-only native framing and exact editor-owned lifecycle proofs. Tasks5.1–5.3 advance; no checkbox or scenario closure.','raw_archive_sha256':sha(archive),'external_replay':'raw.tar.gz:boundary-external-artifacts.json','source_replay':'raw.tar.gz:portable-boundary-source-replay.json','current_release_sha256':'33af9b9041165b6736a19829b53dcb6c15974f4e76129ec201e9d9f1c6749572','checks':'193host/23adapter unit tests, fmt/strict host+adapterClippy,1091engine tests/strictcoverage,30nativeCLAP checks,9source-free checks,packaged assets/dynamic host,52canonical+active strict specs/631scenarios392mapped239ratchet, current official34success10skip0fail.','explicit_failure':'Strict engineClippy FAIL129 preserved baseline diagnostics, translated through published8-line getter. No new diagnostic after source-line mapping. Not a waiver or passing lint gate.','limits':'Headless authenticated X11/WebKitGTK2.50.4; physical desktop/device/named-DAW/installed/portable-state and production frontend v2/import/Empty remain separate. Mutation excluded. No full-GUI/branch/MCDC/instantiation100% claim.'}
(dest/'binding.json').write_text(json.dumps(binding,indent=2)+'\n');print('packet',len(index),'members',archive.stat().st_size,'bytes',sha(archive),flush=True)
