from pathlib import Path
import json,hashlib,tarfile,shutil,io,gzip
root=Path('/tmp/dandrum-lanes/integration');out=Path('/tmp/dandrum-evidence/g1-native-registration');author=Path('/tmp/dandrum-lanes/evidence-trigger-native-gui');dest=root/'docs/migrations/evidence/trigger-clap-native-g1-2026-10-21';dest.mkdir(parents=True,exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((author/'165-portable-archive-receipt.json').read_text());archive=Path(receipt['archive']);assert h(archive)==receipt['sha256'];shutil.copy2(archive,dest/'author.tar.gz');shutil.copy2(author/'165-portable-manifest.json',dest/'author-artifacts.json');shutil.copy2(author/'162-g1-verified-checkpoint.json',dest/'author-checkpoint.json');shutil.copy2(author/'164-frontend-and-allocator-scope-addendum.json',dest/'scope-qualifications.json')
fixtures=sorted((root/'build/engine-only-regression').glob('fixture-*/source/CMakeLists.txt'),key=lambda p:p.stat().st_mtime_ns);fixture=fixtures[-1].parent
assert (fixture/'CMakeLists.txt').read_bytes()==(root/'CMakeLists.txt').read_bytes();assert (fixture/'tests/python/test_engine_only_build.py').read_bytes()==(root/'tests/python/test_engine_only_build.py').read_bytes()
inputs={str(p.relative_to(fixture)):h(p) for p in fixture.rglob('*') if p.is_file() and 'build' not in p.relative_to(fixture).parts and '__pycache__' not in p.parts};(out/'source-free-inputs.json').write_text(json.dumps({'fixture':str(fixture),'excluded_trees':['third_party','web','ui'],'sha256':inputs},indent=2)+'\n')
files={'root/'+p.name:p for p in out.iterdir() if p.is_file()}
for p in Path('/tmp/dandrum-evidence/native-fixture-driver').rglob('*'):
 if p.is_file():files['driver/'+str(p.relative_to('/tmp/dandrum-evidence/native-fixture-driver'))]=p
for p in (root/'build/engine-only-regression').glob('*.log'):files['source-free/'+p.name]=p
for label in ('g1-precompletion-assessment.md','g1-precompletion-inputhashes.json'):
 p=Path('/tmp/dandrum-evidence/trigger-native-gui-next/lifetime-assessment')/label;files['preassessment/'+label]=p
with (dest/'root.tar.gz').open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,p in sorted(files.items()):
  data=p.read_bytes();assert not data.startswith(b'\x7fELF');info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
rootmanifest={n:{'bytes':p.stat().st_size,'sha256':h(p)} for n,p in sorted(files.items())}
with tarfile.open(dest/'root.tar.gz','r:gz') as tar:
 for name,entry in rootmanifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==entry['sha256']
(dest/'root-artifacts.json').write_text(json.dumps({'sha256':h(dest/'root.tar.gz'),'members':rootmanifest},indent=2)+'\n')
checks={k:json.loads((out/(k+'.json')).read_text()) for k in ['root-checkpoint','native-maintained-runtime','actual-cargo-binding','native-zero-test-rejected','native-guard-calibration','source-free','spec-checks']};(dest/'root-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'destination':str(dest),'author_archive_sha256':h(dest/'author.tar.gz'),'root_archive_sha256':h(dest/'root.tar.gz'),'root_archive_bytes':(dest/'root.tar.gz').stat().st_size,'root_members':len(files),'sourcefree_inputs':len(inputs)}))
