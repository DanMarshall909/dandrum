import os,pathlib,subprocess,json,time,hashlib,resource,shutil
root=pathlib.Path('/tmp/dandrum-lanes/runtime'); out=pathlib.Path('/tmp/dandrum-evidence/g1-native-registration'); build=out/'native-build'
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
build.mkdir(exist_ok=True)
target=build/'rust-target'
if not target.exists(): target.symlink_to('/tmp/dandrum-lanes/cache-editor-guard',target_is_directory=True)
assert target.resolve()==pathlib.Path('/tmp/dandrum-lanes/cache-editor-guard')
env=dict(os.environ,DISPLAY=':10.0',GDK_BACKEND='x11',XAUTHORITY='/home/dan/.Xauthority',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='1')
for k in ('LD_PRELOAD','RUST_MIN_STACK','RUSTFLAGS','LLVM_PROFILE_FILE'): env.pop(k,None)
def run(name,args,expected=0):
 assert shutil.disk_usage('/tmp').free>1073741824
 t=time.monotonic()
 with (out/(name+'.stdout.log')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:
  p=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=1200)
 r=dict(command=args,cwd=str(root),exit=p.returncode,seconds=time.monotonic()-t,source_sha256={x:hashlib.sha256((root/x).read_bytes()).hexdigest() for x in ('CMakeLists.txt','README.md','tests/python/test_engine_only_build.py','scripts/prepare-trigger-clap-native.py','tests/python/test_trigger_native_fixture.py','src/clap-adapter/src/trigger.rs','src/clap-adapter/src/trigger/gui.rs','src/clap-adapter/tests/trigger_gui.rs')})
 (out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n'); print(name,p.returncode,round(r['seconds'],2),flush=True)
 assert p.returncode==expected,r
 return r
run('native-configure',['cmake','-S',str(root),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DDANDRUM_ENGINE_ONLY=ON','-DDANDRUM_CLAP_PROOF=ON','-DDANDRUM_TRIGGER_CLAP_EDITOR=ON','-DDANDRUM_TRIGGER_EDITOR_NATIVE_X11=ON','-DDANDRUM_TRIGGER_EDITOR_BUNDLE_DIR=/tmp/dandrum-lanes/evidence-trigger-native-gui/current-native-build'])
run('native-stage',['cmake','--build',str(build),'--target','dandrum-trigger-resources','--parallel','2'])
run('native-maintained-runtime',['ctest','--test-dir',str(build),'--verbose','-R','^trigger-clap-native-'])
text=(out/'native-maintained-runtime.stdout.log').read_text()
assert text.count('running 1 test')==5 and '100% tests passed' in text
binding=json.loads((build/'trigger-clap-native-fixture/binding.json').read_text())
for name,entry in binding['artifacts'].items():
 source=pathlib.Path(entry['source']);copied=build/'trigger-clap-native-fixture'/entry['copy']
 assert hashlib.sha256(source.read_bytes()).hexdigest()==entry['source_sha256']==entry['copy_sha256']==hashlib.sha256(copied.read_bytes()).hexdigest()
(out/'actual-cargo-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
p=build/'CTestTestfile.cmake';original=p.read_bytes();needle=b'copied_editor_failed_native_parent_attempt_retains_only_code_and_preserves_audio';assert original.count(needle)==1
try:
 p.write_bytes(original.replace(needle,b'deliberately_missing_native_lifecycle_calibration'))
 # Skip only preparation already proved above, preserving its exact bound fixture.
 run('native-zero-test-rejected',['ctest','--test-dir',str(build),'--verbose','-FA','trigger-clap-native-compiled','-R','^trigger-clap-native-failed-parent$'],8)
 negative=(out/'native-zero-test-rejected.stdout.log').read_text()
 assert 'running 0 tests' in negative and 'Error regular expression found in output. Regex=[running 0 tests]' in negative
finally:p.write_bytes(original)
assert p.read_bytes()==original
(out/'native-guard-calibration.json').write_text(json.dumps({'positive':'private driver actual Cargo JSON reported artifacts independently hash matched; five exact native process cases plus seven driver fast tests pass','negative':'exact missing Rust test exits zero; CTest fails its zero-test diagnostic','restored_generated_ctest_sha256':hashlib.sha256(original).hexdigest()},indent=2)+'\n')
