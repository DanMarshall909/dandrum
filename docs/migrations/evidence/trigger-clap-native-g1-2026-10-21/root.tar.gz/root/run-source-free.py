import os,subprocess,pathlib,time,json,shutil,resource
out=pathlib.Path('/tmp/dandrum-evidence/g1-native-registration');root=pathlib.Path('/tmp/dandrum-lanes/integration');assert shutil.disk_usage('/tmp').free>1073741824
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2')
args=['python3','tests/python/test_engine_only_build.py','ClapProofBuildTest'];start=time.monotonic()
with (out/'source-free.stdout.log').open('w') as stdout,(out/'source-free.stderr.log').open('w') as stderr:
 p=subprocess.Popen(args,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 samples=[]
 while p.poll() is None:
  mem=int(next(l.split()[1] for l in pathlib.Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
  sample={'seconds':time.monotonic()-start,'disk_free':shutil.disk_usage('/tmp').free,'mem_available':mem};samples.append(sample)
  if sample['disk_free']<1073741824 or mem<4294967296:
   import signal;os.killpg(p.pid,signal.SIGTERM);p.wait();raise RuntimeError('resource floor crossed')
  time.sleep(1)
r={'command':args,'cwd':str(root),'environment':{k:env[k] for k in ('CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_INCREMENTAL','CARGO_BUILD_JOBS')},'exit':p.returncode,'seconds':time.monotonic()-start,'disk_min_bytes':min(s['disk_free'] for s in samples),'mem_min_bytes':min(s['mem_available'] for s in samples)}
(out/'source-free.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));assert p.returncode==0
