# GUI DSO unload readiness

Read-only, 2026-10-21. Test25 body passed in1.89s, then SIGSEGV; this is **not green**. Author-owned trace26 reports background TID1357896 PC0x70126b8b00ef inside libwebkit2gtk-4.1.so.0.19.7 after main TID1357513 unmapped its complete89924680-byte mapping. Thus the observed fault is native WebKit code after dependency unload, not a demonstrated Rust-plugin trampoline fault. Trace scheduling/sandbox qualification remains in the author's report. No debug/build/native run or mutation was performed here.

## Source facts

Current Main::drop calls core.destroy_editor; that invalidates GUI state, detaches attachment, takes/drops its Rc<NativeEditor>. Core::drop repeats ownership cleanup as a fallback (trigger/gui.rs:39–50,189–203). NativeEditor::drop disconnects its script-message signal; Wry then destroys the WebView; OwnedWindow synchronously destroys the GTK container and display.syncs (native_x11.rs:26–54,236–243). X11 synchronization proves ordering of window requests, not completion of WebKit workers or all asynchronous callbacks.

Wry0.57 does **not** use a TLS/default-global Rust WebContext here: new_gtk constructs a scoped context when none is supplied (webkitgtk/mod.rs:256–271; web_context.rs Default creates a new context). Dropping that Rust owner does not prove native context finalization while native WebView/requests retain references. Wry InnerWebView::drop calls widget destroy, not a process-global engine shutdown (:100–103).

Additional delayed **plugin-code** hazards are source-supported, though not the trace26 PC:

- Wry registers custom-scheme handler on native WebContext (webkitgtk/web_context.rs:143); webkit2gtk boxes the closure and installs both a monomorphized request callback and destroy notifier (auto/web_context.rs:531–558). Native context/request lifetime controls when either runs. No unregister-scheme API was found.
- The scheme responder may call MainContext::default().invoke with an owned URISchemeRequest (:218–245). glib's queued source stores Rust trampoline/destroy functions (main_context.rs:115–138). The synchronous response path can invoke inline on the owner, so queued execution is conditional, not established for this test.
- NativeEditor.evaluate_script uses Wry eval, which always calls run_javascript with cancellable=None and a Rust completion closure, even without a user result callback (mod.rs:781–807). webkit2gtk boxes ThreadGuard<P> and supplies its Rust async trampoline (auto/web_view.rs:1470–1516). IPC disconnection does not cancel/account for those completions.
- Wry also sets String qdata on the WebView (:334); glib installs a Rust drop_value callback for native finalization (object.rs:2400–2413). Wry load/navigation/close signals are other native-held Rust closures; NativeEditor currently explicitly disconnects only its IPC signal.

No process-global/TLS WebContext or atexit registration was identified in the inspected Rust paths. gtk0.18.2 rt.rs has TLS Cell<bool>/static initialization flags and acquires the default context during init; these are not evidence that the observed crash is a Rust TLS destructor. Native WebKit worker/global shutdown implementation source was unavailable locally; no exit-hook cause is asserted.

## Safe teardown obligations and limits

Available primary headers/bindings expose per-view stop_loading, try_close and terminate_web_process, not an identified global shutdown/join/unload-safe API. Terminating a web-content process does not establish shutdown of local UI-process WebKit threads. Current Drop therefore provides per-instance window/IPC cleanup, not a complete DSO/dependency-unload proof.

A complete repair must account for all outstanding Rust callbacks/native objects while their code remains valid, and separately establish native engine worker lifetime before unloading its dependency. Cancellation/completion tracking could strengthen per-view cleanup but does not by itself resolve trace26's native worker. Bounded host-owned dispatch must not become an unbounded wait or plugin-owned nested loop; source absence is not permission to assume a successful drain.

NODELETE, leaking/pinning libraries or process-lifetime dependency ownership are **not accepted by this review**. No implementation is chosen. If no supported global quiescence guarantee exists, root must explicitly resolve that boundary; do not mask the exit crash or mark GUI acceptance complete. Both source findings and trace26 were sent directly to the author, who owns reproduction/repair.

Source/evidence SHA256:
- src/clap-adapter/src/trigger/gui.rs: `79560e80fa9f4236c4817fc0ac69dcc0c83c31ab99378425ac31a8acb0f1fda6`
- src/trigger-editor/src/native_x11.rs: `7ee8ccda4f8ab61fe2cf6f2dc3bdb46761e7ee73fbd2ae6d2c15c9ccdc8ed2bf`
- wry-0.57.0/src/webkitgtk/mod.rs: `20a4064b352747b46d7e15ae6962922dfa85017660e109e87e255219c6ee2017`
- wry-0.57.0/src/webkitgtk/web_context.rs: `ef43edb59e19e60743c7858be846cac23ce8e7a188f77b12ac7e0a82a907628f`
- webkit2gtk-2.0.2/src/auto/web_context.rs: `2782277daa63a68d61fc3c4c5ed7d74b9ece31ed18e1a02d8a36138308c4a3b7`
- webkit2gtk-2.0.2/src/auto/web_view.rs: `d69acf9837d12be9021383254bb06dea3cb0450af1d8fae4e1dfaeee33b3b776`
- glib-0.18.5/src/main_context.rs: `a1dc45489f318659f0c4a94d3143807270e6cce6a8d127afa25944838ce66b25`
- glib-0.18.5/src/object.rs: `61304201fc2dd2ec7d0e8db7343bc62db6e9c81be07b2b16ad3f530a8972f017`
- gtk-0.18.2/src/rt.rs: `192a109c1f733550aad37a46ef714da0a38897db4087dae198fdc4907c923e77`
- /usr/include/webkitgtk-4.1/webkit/WebKitWebView.h: `699d477c3206f68da48759194d0e3b3d215fbc3e5ee6fd7754ca3d410f130607`
- /tmp/dandrum-lanes/evidence-trigger-native-gui/26-fault-map-summary.json: `01e8fb625f79b6c9c1ac621c253ac52e604a7640795e9d6aef3a46468aa8d0d3`
