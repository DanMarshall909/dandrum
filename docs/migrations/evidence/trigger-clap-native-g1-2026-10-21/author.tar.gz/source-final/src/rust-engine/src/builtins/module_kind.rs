use super::module_types;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ModuleKind {
    MidiInput,
    #[cfg(test)]
    AudioOutput,
    Oscillator,
    Gain,
    AudioMixer,
    ControlMixer,
    Adsr,
    Lfo,
    Filter,
    AudioDelayOneSample,
    BlockDelay,
    ControlDelay,
    Script,
    Sampler,
    SamplePlayer,
    SampleSlicer,
    SampleMapPlayer,
    NoteToRate,
    DynamicsProcessor,
    Saturator,
    Convolution,
    Echo,
    Reverb,
    FrequencySplitter,
    SpectralProcessor,
    Noise,
    Impulse,
    Multiply,
    NoteToControl,
    EventFilter,
    EnvelopeFollower,
    CurveMapper,
    Slew,
    Decay,
    /// Compiler-generated control→audio promotion (see `unify-graph-kernel` §2.5).
    ControlToAudio,
    CompensationDelay,
    FeedbackDelay,
    Poly,
    VoiceIntrinsics,
}

impl ModuleKind {
    pub fn from_str(s: &str) -> Option<Self> {
        match s {
            module_types::MIDI_INPUT => Some(Self::MidiInput),
            #[cfg(test)]
            module_types::AUDIO_OUTPUT => Some(Self::AudioOutput),
            module_types::OSCILLATOR => Some(Self::Oscillator),
            module_types::GAIN => Some(Self::Gain),
            module_types::AUDIO_MIXER => Some(Self::AudioMixer),
            module_types::CONTROL_MIXER => Some(Self::ControlMixer),
            module_types::ADSR => Some(Self::Adsr),
            module_types::LFO => Some(Self::Lfo),
            module_types::FILTER => Some(Self::Filter),
            module_types::AUDIO_DELAY_ONE_SAMPLE => Some(Self::AudioDelayOneSample),
            module_types::BLOCK_DELAY => Some(Self::BlockDelay),
            module_types::CONTROL_DELAY => Some(Self::ControlDelay),
            module_types::SCRIPT => Some(Self::Script),
            module_types::SAMPLER => Some(Self::Sampler),
            module_types::SAMPLE_PLAYER => Some(Self::SamplePlayer),
            module_types::SAMPLE_SLICER => Some(Self::SampleSlicer),
            module_types::SAMPLE_MAP_PLAYER => Some(Self::SampleMapPlayer),
            module_types::NOTE_TO_RATE => Some(Self::NoteToRate),
            module_types::DYNAMICS_PROCESSOR => Some(Self::DynamicsProcessor),
            module_types::SATURATOR => Some(Self::Saturator),
            module_types::CONVOLUTION => Some(Self::Convolution),
            module_types::ECHO => Some(Self::Echo),
            module_types::REVERB => Some(Self::Reverb),
            module_types::FREQUENCY_SPLITTER => Some(Self::FrequencySplitter),
            module_types::SPECTRAL_PROCESSOR => Some(Self::SpectralProcessor),
            module_types::NOISE => Some(Self::Noise),
            module_types::IMPULSE => Some(Self::Impulse),
            module_types::MULTIPLY => Some(Self::Multiply),
            module_types::NOTE_TO_CONTROL => Some(Self::NoteToControl),
            module_types::EVENT_FILTER => Some(Self::EventFilter),
            module_types::ENVELOPE_FOLLOWER => Some(Self::EnvelopeFollower),
            module_types::CURVE_MAPPER => Some(Self::CurveMapper),
            module_types::SLEW => Some(Self::Slew),
            module_types::DECAY => Some(Self::Decay),
            module_types::CONTROL_TO_AUDIO => Some(Self::ControlToAudio),
            module_types::COMPENSATION_DELAY => Some(Self::CompensationDelay),
            module_types::FEEDBACK_DELAY => Some(Self::FeedbackDelay),
            module_types::POLY => Some(Self::Poly),
            module_types::VOICE_INTRINSICS => Some(Self::VoiceIntrinsics),
            _ => None,
        }
    }

    pub fn is_render_supported(self) -> bool {
        #[cfg(test)]
        if self == Self::AudioOutput {
            return true;
        }
        matches!(
            self,
            Self::MidiInput
                | Self::Oscillator
                | Self::Gain
                | Self::AudioMixer
                | Self::ControlMixer
                | Self::Adsr
                | Self::Lfo
                | Self::Filter
                | Self::Sampler
                | Self::SamplePlayer
                | Self::SampleSlicer
                | Self::SampleMapPlayer
                | Self::NoteToRate
                | Self::DynamicsProcessor
                | Self::Saturator
                | Self::Convolution
                | Self::Echo
                | Self::Reverb
                | Self::FrequencySplitter
                | Self::SpectralProcessor
                | Self::Noise
                | Self::Impulse
                | Self::Multiply
                | Self::NoteToControl
                | Self::EventFilter
                | Self::EnvelopeFollower
                | Self::CurveMapper
                | Self::Slew
                | Self::Script
                | Self::Decay
                | Self::ControlToAudio
                | Self::CompensationDelay
                | Self::FeedbackDelay
                | Self::Poly
                | Self::VoiceIntrinsics
        )
    }
}
