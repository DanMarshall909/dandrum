//! Acceptance tests for the `add-drum-voice-authoring` change.
//!
//! These prove that the seeded 808/909-style drum instruments load, expose
//! their declared public parameters, and render non-silent audio from a MIDI
//! trigger, and that the primitive gaps closed for drum authoring (oscillator
//! waveform selection and runtime-updatable decay) behave as specified.

use std::collections::BTreeMap;
use std::fs;
use std::path::PathBuf;

use crate::core::TimedInputEvent;
use crate::graph_processor::{
    render_kernel_offline_named, render_kernel_offline_named_with_inputs,
};
use crate::kernel::document::load_kernel_patch_file;
use crate::kernel::{ResourceKind, StaticArg, StaticValue};
use crate::patch::{self, RenderSettings, validate_patch_schema};
use crate::preparation::{
    HostBuses, PreparationContext, PreparedKernelInstrument, prepare_kernel_graph_with_buses,
    prepare_kernel_patch_with_context,
};
use crate::sample::PreparedSamplerAssets;
use crate::script::ScriptEvent;
use crate::synth::DandrumEngine;

const SAMPLE_RATE_HZ: f32 = 48_000.0;
const TRIGGER_NOTE: u8 = 40;
const TRIGGER_VELOCITY: u8 = 110;

fn drums_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .join("examples")
        .join("patches")
        .join("drums")
}

fn drum_patch_paths() -> Vec<PathBuf> {
    let mut paths: Vec<PathBuf> = fs::read_dir(drums_dir())
        .expect("drums example directory should exist")
        .map(|entry| entry.expect("directory entry should be readable").path())
        .filter(|path| path.extension().is_some_and(|ext| ext == "yaml"))
        .collect();
    paths.sort();
    assert!(
        !paths.is_empty(),
        "expected at least one authored drum instrument in {}",
        drums_dir().display()
    );
    paths
}

fn note_on_at_start() -> Vec<TimedInputEvent> {
    vec![TimedInputEvent::new(
        0,
        ScriptEvent::NoteOn {
            note: TRIGGER_NOTE,
            velocity: TRIGGER_VELOCITY,
        },
    )]
}

fn peak(samples: &[f32]) -> f32 {
    samples
        .iter()
        .fold(0.0_f32, |acc, sample| acc.max(sample.abs()))
}

#[test]
fn every_drum_voice_loads_validates_and_declares_public_parameters() {
    for path in drum_patch_paths() {
        if let Ok(kernel) = load_kernel_patch_file(&path) {
            assert!(
                kernel.instrument().is_some(),
                "{} should declare an instrument identity so presets can target it",
                path.display()
            );
            assert!(
                !kernel.preset_surface().parameters().is_empty(),
                "{} should expose at least one public parameter through preset_surface",
                path.display()
            );
            continue;
        }
        let patch = patch::load_patch_file(&path)
            .unwrap_or_else(|error| panic!("{} should parse: {error}", path.display()));

        validate_patch_schema(&patch)
            .unwrap_or_else(|error| panic!("{} should validate: {error}", path.display()));

        assert!(
            patch.instrument.is_some(),
            "{} should declare an instrument identity so presets can target it",
            path.display()
        );
        assert!(
            !patch.preset_surface.parameters.is_empty(),
            "{} should expose at least one public parameter through preset_surface",
            path.display()
        );
    }
}

#[test]
fn every_drum_voice_renders_non_silent_audio_from_a_midi_trigger() {
    for path in drum_patch_paths() {
        if let Ok(kernel) = load_kernel_patch_file(&path) {
            let settings = RenderSettings {
                sample_rate_hz: SAMPLE_RATE_HZ as u32,
                block_size_frames: 128,
                duration_frames: 2_048,
            };
            let context = PreparationContext::new(
                path.parent().expect("drum patch has a parent directory"),
                settings.sample_rate_hz,
            );
            let prepared = prepare_kernel_patch_with_context(&kernel, &settings, &context)
                .unwrap_or_else(|error| panic!("{} should prepare: {error}", path.display()));
            let buses = render_kernel_offline_named(
                &prepared,
                note_on_at_start(),
                &PreparedSamplerAssets::empty(),
            )
            .unwrap_or_else(|error| panic!("{} should render: {error}", path.display()));
            let stereo_bus = buses.iter().any(|(_, channels)| {
                channels.len() == 2 && peak(&channels[0]) > 0.0 && peak(&channels[1]) > 0.0
            });
            let mono_output = |name: &str| {
                buses
                    .iter()
                    .find(|(bus, _)| bus == name)
                    .is_some_and(|(_, channels)| channels.len() == 1 && peak(&channels[0]) > 0.0)
            };
            assert!(
                stereo_bus || (mono_output("left") && mono_output("right")),
                "{} should render non-silent stereo audio from a MIDI trigger",
                path.display()
            );
            continue;
        }
        let mut engine = DandrumEngine::new();
        engine.prepare(SAMPLE_RATE_HZ);
        let render = engine
            .render_patch_file_offline(&path, note_on_at_start())
            .unwrap_or_else(|error| panic!("{} should render: {error}", path.display()));

        assert!(
            peak(&render.left) > 0.0 && peak(&render.right) > 0.0,
            "{} should render non-silent stereo audio from a MIDI trigger",
            path.display()
        );
    }
}

#[test]
fn sampler_backed_909_metallic_voices_reference_placeholder_assets() {
    // Task 3.2/4.3: 909 hats/crash/ride are sampler-backed, and the repository
    // ships only self-authored placeholder samples, never proprietary content.
    for path in drum_patch_paths() {
        let name = path.file_name().unwrap().to_string_lossy().to_string();
        let is_metallic = ["hat", "crash", "ride"]
            .iter()
            .any(|voice| name.contains(voice));
        if !is_metallic {
            continue;
        }

        if let Ok(kernel) = load_kernel_patch_file(&path) {
            let voice = kernel
                .registry()
                .get("metallic_voice")
                .expect("metallic voice definition");
            let sampler = voice
                .nodes()
                .iter()
                .find(|node| node.id().as_str() == "sampler")
                .expect("metallic voice sampler");
            assert!(
                matches!(
                    sampler.static_args().get("sample"),
                    Some(StaticArg::Literal(StaticValue::Resource(resource)))
                        if resource.kind() == ResourceKind::Sample
                            && resource.path().starts_with("assets/drums/909")
                ),
                "{name} should reference a typed self-authored placeholder sample under assets/drums/909",
            );
        } else {
            let patch = patch::load_patch_file(&path).expect("metallic voice should parse");
            assert!(
                patch
                    .assets
                    .iter()
                    .any(|asset| { asset.path.contains("assets/drums/909") }),
                "{name} should reference a self-authored placeholder sample under assets/drums/909",
            );
        }
    }
}

fn render_tom_with_runtime_decay(prepared: &PreparedKernelInstrument, decay: Vec<f32>) -> Vec<f32> {
    let inputs = BTreeMap::from([("decay_ms".to_string(), vec![decay])]);
    let buses = render_kernel_offline_named_with_inputs(
        prepared,
        note_on_at_start(),
        &PreparedSamplerAssets::empty(),
        &inputs,
    )
    .expect("808 tom renders with a live root decay control");
    assert_eq!(buses[0].0, "master");
    assert_eq!(buses[0].1[0], buses[0].1[1]);
    buses[0].1[0].clone()
}

#[test]
fn decay_public_parameter_updates_mapped_target_at_runtime_without_reloading_yaml() {
    // Task 1.3: the public decay control is a root input bus. It can change
    // during a note while the prepared graph and voice state stay in place.
    let patch = load_kernel_patch_file(drums_dir().join("drum-808-tom.yaml"))
        .expect("808 tom loads as a kernel patch");
    let frames = SAMPLE_RATE_HZ as usize / 2;
    let settings = RenderSettings {
        sample_rate_hz: SAMPLE_RATE_HZ as u32,
        block_size_frames: 128,
        duration_frames: frames as u64,
    };
    let host = HostBuses::new()
        .with_input("decay_ms", 1)
        .with_output("master", 2);
    let prepared =
        prepare_kernel_graph_with_buses(patch.root(), patch.registry(), &settings, &host)
            .expect("808 tom binds its public decay control to a host input");
    let short = render_tom_with_runtime_decay(&prepared, vec![60.0; frames]);
    let long = render_tom_with_runtime_decay(&prepared, vec![900.0; frames]);
    let switch_frame = frames / 4;
    let mut changing = vec![60.0; frames];
    changing[switch_frame..].fill(900.0);
    let changing = render_tom_with_runtime_decay(&prepared, changing);

    let tail = |samples: &[f32]| -> f32 {
        let start = samples.len() * 3 / 4;
        samples[start..].iter().map(|sample| sample.abs()).sum()
    };

    assert!(
        tail(&long) > tail(&short) * 2.0,
        "a longer runtime decay should leave more energy in the tail \
         (short={}, long={})",
        tail(&short),
        tail(&long)
    );
    assert_eq!(
        &changing[switch_frame..],
        &long[switch_frame..],
        "the running voice should use the new decay value from the first changed frame"
    );
}

#[test]
fn oscillator_waveform_selection_changes_rendered_output() {
    // Task 1.2: waveform selection is honoured by the render path, not just the
    // metadata surface. A sine and a saw body at the same pitch differ.
    fn render_waveform(waveform: &str) -> Vec<f32> {
        let yaml = format!(
            r#"
metadata:
  name: Waveform Probe
render:
  sample_rate_hz: 48000
  block_size_frames: 128
  duration_frames: 512
modules:
  - id: midi
    type: midi_input
  - id: osc
    type: oscillator
    parameters:
      waveform: {waveform}
      pitch: 1
  - id: mixer
    type: audio_mixer
  - id: out
    type: audio_output
connections:
  - from: osc.audio
    to: mixer.inputs
  - from: mixer.mix
    to: out.left
  - from: mixer.mix
    to: out.right
"#
        );
        let patch = patch::load_patch_str(&yaml).expect("waveform probe patch should parse");
        let graph = crate::graph::Graph::from_patch_declarations(&patch);
        graph
            .validate()
            .expect("waveform probe graph should validate");
        let (left, _) = crate::graph_processor::render_offline(&graph, &patch.render, Vec::new());
        left
    }

    let saw = render_waveform("saw");
    let sine = render_waveform("sine");

    assert_eq!(
        saw.len(),
        sine.len(),
        "both waveforms render the same length"
    );
    assert!(
        saw.iter().zip(&sine).any(|(a, b)| (a - b).abs() > 1e-3),
        "saw and sine oscillators at the same pitch should produce different samples"
    );
    // The default (saw) rises from -1, while sine starts near zero.
    assert_approx_eq!(sine[0], 0.0, 1e-3, "a sine oscillator starts near zero");
}
