use crate::builtins::module_kind::ModuleKind;
use crate::compiled_patch::{CompiledPatch, ControlSlotId};
use crate::graph::SignalType;
#[cfg(test)]
use crate::graph::builtin_ports;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub(super) struct BufferId(pub(super) usize);

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub(super) struct EventQueueId(pub(super) usize);

#[derive(Clone, Copy, Debug, PartialEq)]
pub(super) struct CompiledEdge {
    pub(super) source: BufferId,
    pub(super) destination: BufferId,
    pub(super) signal_type: SignalType,
    pub(super) gain: f32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct CompiledEventEdge {
    pub(super) source: EventQueueId,
    pub(super) destination: EventQueueId,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub(super) struct ControlDefault {
    pub(super) buffer: BufferId,
    pub(super) slot: ControlSlotId,
}

#[derive(Clone, Debug)]
pub(super) struct RenderStep {
    pub(super) module_index: usize,
    pub(super) module_kind: ModuleKind,
    pub(super) processor: super::realtime_graph_processor::PreparedStepProcessor,
    pub(super) poly_region_index: Option<usize>,
    pub(super) input_buffers: Box<[BufferId]>,
    pub(super) output_buffers: Box<[BufferId]>,
    pub(super) incoming_edges: Box<[CompiledEdge]>,
    pub(super) incoming_event_edges: Box<[CompiledEventEdge]>,
    pub(super) control_defaults: Box<[ControlDefault]>,
    pub(super) event_inputs: Box<[EventQueueId]>,
    pub(super) event_outputs: Box<[EventQueueId]>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct AudioBufferPlan {
    pub(super) buffer_count: usize,
    pub(super) max_block_frames: usize,
    pub(super) max_voices: usize,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct EventQueuePlan {
    pub(super) queue_count: usize,
    pub(super) queue_capacity: usize,
}

#[cfg(test)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct AudioOutputBinding {
    pub(super) left: BufferId,
    pub(super) right: BufferId,
}

#[derive(Clone, Debug)]
pub(super) struct RenderPlan {
    #[cfg(test)]
    pub(super) voice_steps: Box<[RenderStep]>,
    pub(super) global_steps: Box<[RenderStep]>,
    pub(super) feedback_step_indices: Box<[usize]>,
    pub(super) audio_buffers: AudioBufferPlan,
    pub(super) event_queues: EventQueuePlan,
    pub(super) midi_input: Option<EventQueueId>,
    #[cfg(test)]
    pub(super) audio_output: Option<AudioOutputBinding>,
}

struct RenderPlanBuilder<'a> {
    compiled: &'a CompiledPatch,
    input_buffer_starts: Vec<usize>,
    input_buffer_count: usize,
    event_queue_starts: Vec<usize>,
    event_queue_count: usize,
}

impl RenderPlan {
    #[cfg(test)]
    pub(super) fn empty(max_block_frames: usize, max_voices: usize) -> Self {
        Self {
            voice_steps: Box::new([]),
            global_steps: Box::new([]),
            feedback_step_indices: Box::new([]),
            audio_buffers: AudioBufferPlan {
                buffer_count: 0,
                max_block_frames,
                max_voices,
            },
            event_queues: EventQueuePlan {
                queue_count: 0,
                queue_capacity: 0,
            },
            midi_input: None,
            audio_output: None,
        }
    }

    pub(super) fn from_compiled_patch(
        compiled: &CompiledPatch,
        max_block_frames: usize,
        max_voices: usize,
        event_queue_capacity: usize,
    ) -> Self {
        let builder = RenderPlanBuilder::new(compiled);
        #[cfg(test)]
        let voice_steps = compiled
            .voice_node_indices()
            .iter()
            .copied()
            .map(|module_index| builder.step(module_index))
            .collect::<Vec<_>>()
            .into_boxed_slice();
        #[cfg(test)]
        let global_indices = compiled.global_node_indices();
        #[cfg(not(test))]
        let global_indices = compiled.execution_order();
        let global_steps = global_indices
            .iter()
            .copied()
            .map(|module_index| builder.step(module_index))
            .collect::<Vec<_>>()
            .into_boxed_slice();
        let feedback_step_indices = global_steps
            .iter()
            .enumerate()
            .filter_map(|(index, step)| {
                (step.module_kind == ModuleKind::FeedbackDelay).then_some(index)
            })
            .collect::<Vec<_>>()
            .into_boxed_slice();

        Self {
            #[cfg(test)]
            voice_steps,
            global_steps,
            feedback_step_indices,
            audio_buffers: AudioBufferPlan {
                buffer_count: compiled.total_output_buffer_count() + builder.input_buffer_count,
                max_block_frames,
                max_voices,
            },
            event_queues: EventQueuePlan {
                queue_count: builder.event_queue_count,
                queue_capacity: event_queue_capacity,
            },
            midi_input: compiled
                .midi_input_index()
                .and_then(|module_index| builder.first_event_output_queue(module_index)),
            #[cfg(test)]
            audio_output: compiled
                .audio_output_index()
                .and_then(|module_index| builder.audio_output_binding(module_index)),
        }
    }
}

impl RenderPlanBuilder<'_> {
    fn new(compiled: &CompiledPatch) -> RenderPlanBuilder<'_> {
        let mut next_input_buffer = compiled.total_output_buffer_count();
        let mut input_buffer_starts = Vec::with_capacity(compiled.nodes().len());
        let mut next_event_queue = 0;
        let mut event_queue_starts = Vec::with_capacity(compiled.nodes().len());

        for node in compiled.nodes() {
            input_buffer_starts.push(next_input_buffer);
            next_input_buffer += node
                .input_port_spans
                .iter()
                .filter(|span| span.channel_count > 0)
                .map(|span| span.channel_count)
                .sum::<usize>();

            event_queue_starts.push(next_event_queue);
            next_event_queue += node
                .input_port_types
                .iter()
                .chain(node.output_port_types.iter())
                .filter(|signal_type| **signal_type == SignalType::Event)
                .count();
        }

        RenderPlanBuilder {
            compiled,
            input_buffer_starts,
            input_buffer_count: next_input_buffer - compiled.total_output_buffer_count(),
            event_queue_starts,
            event_queue_count: next_event_queue,
        }
    }

    fn step(&self, module_index: usize) -> RenderStep {
        let node = &self.compiled.nodes()[module_index];
        let input_buffer_count = node
            .input_port_spans
            .iter()
            .map(|span| span.channel_count)
            .sum::<usize>();
        let input_buffers = (0..input_buffer_count)
            .map(|channel| BufferId(self.input_buffer_starts[module_index] + channel))
            .collect::<Vec<_>>()
            .into_boxed_slice();
        let output_buffers = node
            .output_port_map
            .iter()
            .copied()
            .map(BufferId)
            .collect::<Vec<_>>()
            .into_boxed_slice();
        let incoming_edges = self.incoming_edges(module_index).into_boxed_slice();
        let incoming_event_edges = self.incoming_event_edges(module_index).into_boxed_slice();
        let control_defaults = self.control_defaults(module_index).into_boxed_slice();
        let event_inputs = self.event_queues_for_ports(module_index, &node.input_port_types, 0);
        let event_outputs = self.event_queues_for_ports(
            module_index,
            &node.output_port_types,
            node.input_port_types.len(),
        );

        RenderStep {
            module_index,
            module_kind: node.module_kind,
            processor: super::realtime_graph_processor::resolve_step_processor(node.module_kind),
            poly_region_index: (node.module_kind == ModuleKind::Poly).then(|| {
                self.compiled
                    .poly_regions()
                    .iter()
                    .position(|region| region.node_id() == node.id.as_str())
                    .expect("compiled poly step has a prepared region")
            }),
            input_buffers,
            output_buffers,
            incoming_edges,
            incoming_event_edges,
            control_defaults,
            event_inputs,
            event_outputs,
        }
    }

    fn incoming_edges(&self, module_index: usize) -> Vec<CompiledEdge> {
        let node = &self.compiled.nodes()[module_index];
        let mut edges = Vec::new();

        for (destination_port_index, sources) in node.input_routes.iter().enumerate() {
            let signal_type = node.input_port_types[destination_port_index];
            if signal_type == SignalType::Event {
                continue;
            }

            let destination_span = node.input_port_spans[destination_port_index];
            for (route_index, source) in sources.iter().enumerate() {
                edges.push(CompiledEdge {
                    source: BufferId(source.output_buffer_id),
                    destination: self.input_buffer_channel(
                        module_index,
                        destination_port_index,
                        route_index % destination_span.channel_count,
                    ),
                    signal_type,
                    gain: 1.0,
                });
            }
        }

        edges
    }

    fn incoming_event_edges(&self, module_index: usize) -> Vec<CompiledEventEdge> {
        let node = &self.compiled.nodes()[module_index];
        let mut edges = Vec::new();

        for (destination_port_index, sources) in node.input_port_map.iter().enumerate() {
            if node.input_port_types[destination_port_index] != SignalType::Event {
                continue;
            }

            for source in sources {
                let source_node = &self.compiled.nodes()[source.module_index];
                let source_combined_port_index =
                    source_node.input_port_types.len() + source.port_index;
                if let (Some(source_queue), Some(destination_queue)) = (
                    self.event_queue(source.module_index, source_combined_port_index),
                    self.event_queue(module_index, destination_port_index),
                ) {
                    edges.push(CompiledEventEdge {
                        source: source_queue,
                        destination: destination_queue,
                    });
                }
            }
        }

        edges
    }

    fn control_defaults(&self, module_index: usize) -> Vec<ControlDefault> {
        let node = &self.compiled.nodes()[module_index];
        node.control_defaults
            .iter()
            .filter_map(|default| {
                if !node.input_routes[default.input_port_index].is_empty() {
                    return None;
                }
                Some(ControlDefault {
                    buffer: self.input_buffer(module_index, default.input_port_index),
                    slot: default.slot,
                })
            })
            .collect()
    }

    fn input_buffer(&self, module_index: usize, port_index: usize) -> BufferId {
        self.input_buffer_channel(module_index, port_index, 0)
    }

    fn input_buffer_channel(
        &self,
        module_index: usize,
        port_index: usize,
        channel: usize,
    ) -> BufferId {
        let node = &self.compiled.nodes()[module_index];
        let offset = node.input_port_spans[..port_index]
            .iter()
            .map(|span| span.channel_count)
            .sum::<usize>();
        BufferId(self.input_buffer_starts[module_index] + offset + channel)
    }

    fn first_event_output_queue(&self, module_index: usize) -> Option<EventQueueId> {
        let node = &self.compiled.nodes()[module_index];
        let output_offset = node.input_port_types.len();
        node.output_port_types
            .iter()
            .position(|signal_type| *signal_type == SignalType::Event)
            .and_then(|port_index| self.event_queue(module_index, output_offset + port_index))
    }

    #[cfg(test)]
    fn audio_output_binding(&self, module_index: usize) -> Option<AudioOutputBinding> {
        let node = &self.compiled.nodes()[module_index];
        let left_index = node
            .input_port_names
            .iter()
            .position(|name| name == builtin_ports::LEFT)?;
        let right_index = node
            .input_port_names
            .iter()
            .position(|name| name == builtin_ports::RIGHT)?;

        Some(AudioOutputBinding {
            left: self.input_buffer(module_index, left_index),
            right: self.input_buffer(module_index, right_index),
        })
    }

    fn event_queues_for_ports(
        &self,
        module_index: usize,
        port_types: &[SignalType],
        local_offset: usize,
    ) -> Box<[EventQueueId]> {
        port_types
            .iter()
            .enumerate()
            .filter_map(|(port_index, signal_type)| {
                if *signal_type == SignalType::Event {
                    self.event_queue(module_index, local_offset + port_index)
                } else {
                    None
                }
            })
            .collect::<Vec<_>>()
            .into_boxed_slice()
    }

    fn event_queue(&self, module_index: usize, combined_port_index: usize) -> Option<EventQueueId> {
        let node = &self.compiled.nodes()[module_index];
        let event_ordinal = node
            .input_port_types
            .iter()
            .chain(node.output_port_types.iter())
            .take(combined_port_index + 1)
            .filter(|signal_type| **signal_type == SignalType::Event)
            .count()
            .checked_sub(1)?;

        Some(EventQueueId(
            self.event_queue_starts[module_index] + event_ordinal,
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::{Cable, ExecutionScope, Graph, ModuleId, ModuleNode, PortRef};
    use crate::patch::RenderSettings;

    #[test]
    fn empty_render_plan_records_prepared_size_without_runtime_storage() {
        let plan = RenderPlan::empty(128, 4);

        assert_eq!(plan.audio_buffers.max_block_frames, 128);
        assert_eq!(plan.audio_buffers.max_voices, 4);
        assert_eq!(plan.audio_buffers.buffer_count, 0);
        assert_eq!(plan.event_queues.queue_count, 0);
        assert_eq!(plan.voice_steps.len(), 0);
        assert_eq!(plan.global_steps.len(), 0);
    }

    #[test]
    fn render_plan_resolves_audio_edges_to_buffer_ids() {
        let graph = Graph::new(
            vec![
                ModuleNode::new(ModuleId::new("osc"), "oscillator")
                    .with_execution_scope(ExecutionScope::Voice)
                    .with_output(builtin_ports::AUDIO, SignalType::Audio),
                ModuleNode::new(ModuleId::new("out"), "audio_output")
                    .with_input(builtin_ports::LEFT, SignalType::Audio)
                    .with_input(builtin_ports::RIGHT, SignalType::Audio),
            ],
            vec![Cable::new(
                PortRef::new(ModuleId::new("osc"), builtin_ports::AUDIO),
                PortRef::new(ModuleId::new("out"), builtin_ports::LEFT),
            )],
        );
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 64,
            duration_frames: 64,
        };
        let compiled =
            crate::compiled_patch::compile(&graph, &settings).expect("graph should compile");
        let plan = RenderPlan::from_compiled_patch(&compiled, 64, 4, 32);

        assert_eq!(plan.voice_steps.len(), 1);
        assert_eq!(plan.global_steps.len(), 1);
        assert_eq!(plan.global_steps[0].incoming_edges.len(), 1);
        assert_eq!(plan.global_steps[0].incoming_edges[0].source, BufferId(0));
        assert_eq!(plan.audio_buffers.max_block_frames, 64);
        assert_eq!(plan.audio_buffers.max_voices, 4);
        assert!(plan.audio_output.is_some());
    }

    #[test]
    fn render_plan_resolves_event_edges_to_event_queue_ids() {
        let graph = Graph::new(
            vec![
                ModuleNode::new(ModuleId::new("midi"), "midi_input")
                    .with_output(builtin_ports::EVENTS, SignalType::Event),
                ModuleNode::new(ModuleId::new("sampler"), "sampler")
                    .with_input(builtin_ports::TRIGGER, SignalType::Event)
                    .with_input(builtin_ports::RATE, SignalType::Control)
                    .with_input(builtin_ports::START, SignalType::Control)
                    .with_input(builtin_ports::LOOP_ENABLED, SignalType::Control)
                    .with_input(builtin_ports::LOOP_START, SignalType::Control)
                    .with_input(builtin_ports::LOOP_END, SignalType::Control)
                    .with_output(builtin_ports::AUDIO, SignalType::Audio),
            ],
            vec![Cable::new(
                PortRef::new(ModuleId::new("midi"), builtin_ports::EVENTS),
                PortRef::new(ModuleId::new("sampler"), builtin_ports::TRIGGER),
            )],
        );
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 64,
            duration_frames: 64,
        };
        let compiled =
            crate::compiled_patch::compile(&graph, &settings).expect("graph should compile");
        let plan = RenderPlan::from_compiled_patch(&compiled, 64, 1, 32);

        let sampler_step = plan
            .global_steps
            .iter()
            .find(|step| step.module_kind == ModuleKind::Sampler)
            .expect("sampler step should be planned");

        assert_eq!(plan.midi_input, Some(EventQueueId(0)));
        assert_eq!(sampler_step.event_inputs.as_ref(), &[EventQueueId(1)]);
        assert_eq!(sampler_step.incoming_event_edges.len(), 1);
        assert_eq!(
            sampler_step.incoming_event_edges[0],
            CompiledEventEdge {
                source: EventQueueId(0),
                destination: EventQueueId(1),
            }
        );
    }

    #[test]
    fn render_plan_binds_sibling_poly_steps_to_numeric_region_indices() {
        let patch = crate::kernel::document::load_kernel_patch_str(
            "ports:\n  - { name: left, direction: output, signal: audio, channels: 1, maps_from: left_voices.audio }\n  - { name: right, direction: output, signal: audio, channels: 1, maps_from: right_voices.audio }\nmodule_definitions:\n  - type: voice\n    ports:\n      - { name: audio, direction: output, signal: audio, channels: 1, maps_from: source.out }\n    modules:\n      - { id: source, type: control_to_audio, defaults: { in: 0.25 } }\n    connections: []\nmodules:\n  - { id: right_voices, type: poly, static: { definition: voice, max_voices: 1, allocation: reject-new } }\n  - { id: left_voices, type: poly, static: { definition: voice, max_voices: 1, allocation: reject-new } }\nconnections: []\n",
        )
        .expect("sibling poly patch loads");
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 8,
            duration_frames: 8,
        };
        let prepared = crate::preparation::prepare_kernel_patch(&patch, &settings)
            .expect("sibling pools prepare");
        let plan = RenderPlan::from_compiled_patch(prepared.compiled_patch(), 8, 1, 8);
        let indices = plan
            .global_steps
            .iter()
            .filter(|step| step.module_kind == ModuleKind::Poly)
            .map(|step| step.poly_region_index)
            .collect::<Vec<_>>();
        assert_eq!(indices, [Some(0), Some(1)]);
        assert_ne!(
            prepared.compiled_patch().poly_regions()[0].node_id(),
            prepared.compiled_patch().poly_regions()[1].node_id()
        );
    }

    #[test]
    fn render_plan_records_default_control_values_for_unconnected_inputs() {
        let graph = Graph::new(
            vec![
                ModuleNode::new(ModuleId::new("osc"), "oscillator")
                    .with_input(builtin_ports::PITCH, SignalType::Control)
                    .with_output(builtin_ports::AUDIO, SignalType::Audio),
            ],
            Vec::new(),
        );
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 64,
            duration_frames: 64,
        };
        let compiled =
            crate::compiled_patch::compile(&graph, &settings).expect("graph should compile");
        let plan = RenderPlan::from_compiled_patch(&compiled, 64, 1, 32);

        assert_eq!(plan.global_steps.len(), 1);
        assert_eq!(
            plan.global_steps[0].control_defaults.as_ref(),
            &[ControlDefault {
                buffer: BufferId(1),
                slot: ControlSlotId::from_index(0),
            }]
        );
        assert_eq!(compiled.parameter_slot_value(0), Some(1.0));
    }

    #[test]
    fn render_plan_omits_default_control_values_for_connected_inputs() {
        let graph = Graph::new(
            vec![
                ModuleNode::new(ModuleId::new("rate"), "note_to_rate")
                    .with_output(builtin_ports::RATE, SignalType::Control),
                ModuleNode::new(ModuleId::new("osc"), "oscillator")
                    .with_input(builtin_ports::PITCH, SignalType::Control)
                    .with_output(builtin_ports::AUDIO, SignalType::Audio),
            ],
            vec![Cable::new(
                PortRef::new(ModuleId::new("rate"), builtin_ports::RATE),
                PortRef::new(ModuleId::new("osc"), builtin_ports::PITCH),
            )],
        );
        let settings = RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 64,
            duration_frames: 64,
        };
        let compiled =
            crate::compiled_patch::compile(&graph, &settings).expect("graph should compile");
        let plan = RenderPlan::from_compiled_patch(&compiled, 64, 1, 32);

        let oscillator_step = plan
            .global_steps
            .iter()
            .find(|step| step.module_kind == ModuleKind::Oscillator)
            .expect("oscillator step should be planned");
        assert!(oscillator_step.control_defaults.is_empty());
    }
}
