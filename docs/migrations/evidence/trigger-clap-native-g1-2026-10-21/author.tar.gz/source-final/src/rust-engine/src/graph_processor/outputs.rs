use std::collections::HashMap;

use crate::script::ScriptEvent;

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct BlockEvent {
    pub(crate) frame_offset: u32,
    pub(crate) event: ScriptEvent,
}

pub(super) struct ModuleOutputs {
    #[cfg(test)]
    pub(super) audio: HashMap<String, Vec<f32>>,
    pub(super) control: HashMap<String, Vec<f32>>,
    pub(super) events: Vec<BlockEvent>,
    pub(super) event_ports: HashMap<String, Vec<BlockEvent>>,
}

impl ModuleOutputs {
    pub(super) fn empty() -> Self {
        Self {
            #[cfg(test)]
            audio: HashMap::new(),
            control: HashMap::new(),
            events: Vec::new(),
            event_ports: HashMap::new(),
        }
    }
}
