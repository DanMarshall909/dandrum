pub const MIDI_INPUT: &str = "midi_input";
pub const AUDIO_OUTPUT: &str = "audio_output";
pub const OSCILLATOR: &str = "oscillator";
pub const GAIN: &str = "gain";
pub const AUDIO_MIXER: &str = "audio_mixer";
pub const CONTROL_MIXER: &str = "control_mixer";
pub const ADSR: &str = "adsr";
pub const LFO: &str = "lfo";
pub const FILTER: &str = "filter";
pub const AUDIO_DELAY_ONE_SAMPLE: &str = "audio_delay_one_sample";
pub const BLOCK_DELAY: &str = "block_delay";
pub const CONTROL_DELAY: &str = "control_delay";
pub const SCRIPT: &str = "script";
pub const SAMPLER: &str = "sampler";
pub const SAMPLE_PLAYER: &str = "sample_player";
pub const SAMPLE_ZONE_SELECTOR: &str = "sample_zone_selector";
pub const SAMPLE_SLICER: &str = "sample_slicer";
pub const SAMPLE_MAP_PLAYER: &str = "sample_map_player";
pub const SAMPLE_MAP_CONTROL_GROUPS: usize = 8;
pub const SAMPLE_MAP_CONTROLS_PER_GROUP: usize = 5;
pub const SAMPLE_MAP_CONTROL_INPUTS: usize =
    SAMPLE_MAP_CONTROLS_PER_GROUP * (1 + SAMPLE_MAP_CONTROL_GROUPS);
pub const NOTE_TO_RATE: &str = "note_to_rate";
pub const DYNAMICS_PROCESSOR: &str = "dynamics-processor";
pub const SATURATOR: &str = "saturator";
pub const CONVOLUTION: &str = "convolution";
pub const ECHO: &str = "echo";
pub const REVERB: &str = "reverb";
pub const FREQUENCY_SPLITTER: &str = "frequency_splitter";
pub const SPECTRAL_PROCESSOR: &str = "spectral_processor";

pub const NOISE: &str = "noise";
pub const IMPULSE: &str = "impulse";
pub const MULTIPLY: &str = "multiply";
pub const NOTE_TO_CONTROL: &str = "note_to_control";
pub const EVENT_FILTER: &str = "event_filter";
pub const ENVELOPE_FOLLOWER: &str = "envelope_follower";
pub const CURVE_MAPPER: &str = "curve_mapper";
pub const SLEW: &str = "slew";
pub const DECAY: &str = "decay";
pub const POLY: &str = "poly";
/// Compiler-injected source for `voice.note`, `voice.velocity`, and
/// `voice.gate` inside a definition wrapped by `poly`.
pub const VOICE_INTRINSICS: &str = "voice_intrinsics";

/// Compiler-generated node promoting a `control` signal to `audio` where a
/// control output feeds an audio input (see `unify-graph-kernel` §2.5).
pub const CONTROL_TO_AUDIO: &str = "control_to_audio";

/// Compiler-generated fixed delay used to align converging signal paths.
pub const COMPENSATION_DELAY: &str = "compensation_delay";
/// Explicit block-or-longer boundary for audio and control feedback cycles.
pub const FEEDBACK_DELAY: &str = "feedback_delay";
