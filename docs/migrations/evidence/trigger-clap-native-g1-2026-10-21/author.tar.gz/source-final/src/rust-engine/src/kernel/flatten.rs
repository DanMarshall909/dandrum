//! Recursive flattening of a kernel graph definition into a flat graph of
//! atomic (Rust primitive) nodes (see `unify-graph-kernel` §2.1, §2.2).
//!
//! Defined modules are expanded until only atomic nodes remain. Public ports of
//! a defined module forward to/gather from internal ports via each port's
//! `maps_to`/`maps_from`, so the flattened connections join atomic ports
//! directly. Node identities are namespaced by their defined-module instance path,
//! making expansion deterministic.
//!
//! Expansion is cached: a definition is structurally expanded once per distinct
//! `(definition, resolved static arguments)` key, producing a [`Template`] with
//! ids relative to the definition's own frame. Each instantiation re-namespaces
//! the template under its instance path — so repeated instances share one
//! expansion structure while, at runtime, each receives disjoint state.
//! Per-instance control-default overrides are applied after instantiation
//! through the resolved boundary interface, so they never contaminate the
//! cached structure.

use std::collections::{BTreeMap, BTreeSet};

use crate::builtins::module_types;
use crate::diagnostics::{Diagnostic, Diagnostics, Severity, error_codes};
use crate::graph::{PortDirection, SignalType};

use super::{
    CONTROL_TO_AUDIO_DEFINITION, Connection, DefinitionImplementation, DefinitionRegistry,
    GraphDefinition, Multiplicity, NAMESPACE_SEPARATOR, Node, NodeId, POLY_ALLOCATION_OLDEST_STEAL,
    POLY_ALLOCATION_PARAM, POLY_ALLOCATION_QUIETEST_STEAL, POLY_ALLOCATION_REJECT_NEW,
    POLY_DEFINITION, POLY_MAX_VOICES_PARAM, POLY_NOTE_EVENTS_INPUT, POLY_WRAPPED_DEFINITION_PARAM,
    PROMOTION_INPUT_PORT, PROMOTION_NODE_PREFIX, PROMOTION_OUTPUT_PORT, PolyAllocationPolicy, Port,
    PortRef, PromotionStep, ResolvedPort, StaticArg, StaticValue, VOICE_GATE_OUTPUT,
    VOICE_INTRINSIC_NODE,
};

/// Maximum defined-module nesting depth before flattening bails out. Guards against
/// pathologically deep (non-recursive) definition chains.
pub const MAX_FLATTEN_DEPTH: usize = 64;

/// An atomic node in the flattened graph: a resolved instance of a Rust
/// primitive with a namespaced identity, resolved ports, effective control
/// defaults, and processing latency.
#[derive(Clone, Debug, PartialEq)]
pub struct AtomicNode {
    id: NodeId,
    definition: String,
    static_args: BTreeMap<String, StaticValue>,
    port_defaults: BTreeMap<String, f64>,
    ports: Vec<ResolvedPort>,
    latency: u32,
}

impl AtomicNode {
    pub fn id(&self) -> &NodeId {
        &self.id
    }

    pub fn definition(&self) -> &str {
        &self.definition
    }

    pub fn static_args(&self) -> &BTreeMap<String, StaticValue> {
        &self.static_args
    }

    pub fn port_defaults(&self) -> &BTreeMap<String, f64> {
        &self.port_defaults
    }

    pub fn ports(&self) -> &[ResolvedPort] {
        &self.ports
    }

    pub fn latency(&self) -> u32 {
        self.latency
    }
}

/// The result of flattening: a flat list of atomic nodes, the connections
/// between their ports, and the resolved public ports of the root definition.
#[derive(Clone, Debug, PartialEq)]
pub struct FlattenedGraph {
    nodes: Vec<AtomicNode>,
    poly_regions: Vec<FlattenedPolyRegion>,
    connections: Vec<Connection>,
    root_ports: Vec<ResolvedPort>,
    /// Each root output port name mapped to the atomic port(s) it gathers from.
    /// This is what makes root latency (and any output-driven analysis)
    /// computable from the graph's actual outputs rather than from terminal
    /// nodes, so a dead latency-bearing branch cannot inflate reported latency.
    root_output_sources: BTreeMap<String, Vec<PortRef>>,
    root_input_destinations: BTreeMap<String, Vec<PortRef>>,
    /// The control→audio promotions the compiler inserted, in insertion order.
    promotions: Vec<PromotionStep>,
    expansion_count: usize,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FlattenedPolyRegion {
    node_id: NodeId,
    wrapped_definition: String,
    max_voices: usize,
    allocation_policy: PolyAllocationPolicy,
    sample_map_choke: Option<(String, u32)>,
}

impl FlattenedPolyRegion {
    pub fn node_id(&self) -> &NodeId {
        &self.node_id
    }

    pub fn wrapped_definition(&self) -> &str {
        &self.wrapped_definition
    }

    pub fn max_voices(&self) -> usize {
        self.max_voices
    }

    pub fn allocation_policy(&self) -> PolyAllocationPolicy {
        self.allocation_policy
    }

    pub fn sample_map_choke(&self) -> Option<(&str, u32)> {
        self.sample_map_choke
            .as_ref()
            .map(|(mode, fade_ms)| (mode.as_str(), *fade_ms))
    }
}

impl FlattenedGraph {
    /// Turn a prepared map player's voice count into the existing structural
    /// `poly` region. Its child remains a one-voice map player; voice allocation
    /// and summing therefore use the same path as authored poly instruments.
    pub(crate) fn expand_sample_map_poly_regions(
        &mut self,
        registry: &mut DefinitionRegistry,
    ) -> Result<(), Diagnostics> {
        for node in &mut self.nodes {
            if node.definition != module_types::SAMPLE_MAP_PLAYER {
                continue;
            }
            let max_voices = match node.static_args.get("max_voices") {
                Some(StaticValue::Int(value)) => *value,
                _ => unreachable!("validated map player has an integer max_voices default"),
            };
            if !(1..=128).contains(&max_voices) {
                return Err(Diagnostics::from(
                    Diagnostic::new(
                        error_codes::KERNEL_SAMPLE_INVALID_VOICE_LIMIT,
                        Severity::Error,
                        format!(
                            "sample_map_player '{}' max_voices must be 1..=128",
                            node.id.as_str()
                        ),
                    )
                    .with_module_id(node.id.as_str()),
                ));
            }
            let choke_mode = match node.static_args.get("choke_mode") {
                Some(StaticValue::Enum(value)) => value.as_str(),
                _ => "cut",
            };
            let choke_fade_ms = match node.static_args.get("choke_fade_ms") {
                Some(StaticValue::Int(value)) => *value,
                _ => 5,
            };
            if !(1..=1_000).contains(&choke_fade_ms) || (max_voices == 1 && choke_mode != "cut") {
                return Err(Diagnostics::from(
                    Diagnostic::new(
                        error_codes::KERNEL_SAMPLE_UNSUPPORTED_MODE,
                        Severity::Error,
                        format!("sample_map_player '{}' requires a 1..=1000 ms choke fade and at least two voices for fade or release", node.id.as_str()),
                    )
                    .with_module_id(node.id.as_str()),
                ));
            }
            if max_voices <= 1 {
                continue;
            }
            let mut index = registry.definitions().count();
            let wrapped_name = loop {
                let name = format!("__prepared_sample_map_voice_{index}");
                if registry.get(&name).is_none() {
                    break name;
                }
                index += 1;
            };
            let voice_steal = match node.static_args.get("voice_steal") {
                Some(StaticValue::Enum(value)) if value == "reject_new" => {
                    (POLY_ALLOCATION_REJECT_NEW, PolyAllocationPolicy::RejectNew)
                }
                Some(StaticValue::Enum(value)) if value == "quietest" => (
                    POLY_ALLOCATION_QUIETEST_STEAL,
                    PolyAllocationPolicy::QuietestSteal,
                ),
                _ => (
                    POLY_ALLOCATION_OLDEST_STEAL,
                    PolyAllocationPolicy::OldestSteal,
                ),
            };
            let mut player = Node::new(NodeId::new("player"), module_types::SAMPLE_MAP_PLAYER);
            for (name, value) in &node.static_args {
                player = player.with_static_arg(
                    name,
                    StaticArg::Literal(match name.as_str() {
                        "max_voices" => StaticValue::Int(1),
                        "choke_mode" => StaticValue::Enum("cut".to_string()),
                        _ => value.clone(),
                    }),
                );
            }
            let mut voice = GraphDefinition::new(&wrapped_name).with_node(player);
            for resolved in &node.ports {
                if resolved.name() == "note" {
                    continue;
                }
                let target = PortRef::new(NodeId::new("player"), resolved.name());
                let mut port = match resolved.direction() {
                    PortDirection::Input => {
                        Port::input(resolved.name(), resolved.signal_type(), resolved.channels())
                            .maps_to(target)
                    }
                    PortDirection::Output => {
                        Port::output(resolved.name(), resolved.signal_type(), resolved.channels())
                            .maps_from(target)
                    }
                };
                if let Some(default) = resolved.control_default() {
                    port = port.with_control_default(default.clone());
                }
                voice = voice.with_port(port.with_multiplicity(resolved.multiplicity()));
            }
            voice = voice.with_connection(Connection::new(
                PortRef::new(NodeId::new(VOICE_INTRINSIC_NODE), VOICE_GATE_OUTPUT),
                PortRef::new(NodeId::new("player"), "note"),
            ));
            *registry = std::mem::take(registry).with_definition(voice);
            let id = node.id.clone();
            self.poly_regions.push(FlattenedPolyRegion {
                node_id: id.clone(),
                wrapped_definition: wrapped_name.clone(),
                max_voices: max_voices as usize,
                allocation_policy: voice_steal.1,
                sample_map_choke: Some((choke_mode.to_string(), choke_fade_ms as u32)),
            });
            node.definition = POLY_DEFINITION.to_string();
            node.static_args = BTreeMap::from([
                (
                    POLY_WRAPPED_DEFINITION_PARAM.to_string(),
                    StaticValue::String(wrapped_name),
                ),
                (
                    POLY_MAX_VOICES_PARAM.to_string(),
                    StaticValue::Int(max_voices),
                ),
                (
                    POLY_ALLOCATION_PARAM.to_string(),
                    StaticValue::Enum(voice_steal.0.to_string()),
                ),
            ]);
            let note = node
                .ports
                .iter_mut()
                .find(|port| port.name == "note")
                .expect("map player has a note port");
            note.name = POLY_NOTE_EVENTS_INPUT.to_string();
            for connection in &mut self.connections {
                if connection.destination().node() == &id
                    && connection.destination().port() == "note"
                {
                    *connection = Connection::new(
                        connection.source().clone(),
                        PortRef::new(id.clone(), POLY_NOTE_EVENTS_INPUT),
                    );
                }
            }
            for destinations in self.root_input_destinations.values_mut() {
                for destination in destinations {
                    if destination.node() == &id && destination.port() == "note" {
                        *destination = PortRef::new(id.clone(), POLY_NOTE_EVENTS_INPUT);
                    }
                }
            }
        }
        Ok(())
    }

    pub fn nodes(&self) -> &[AtomicNode] {
        &self.nodes
    }

    pub fn poly_regions(&self) -> &[FlattenedPolyRegion] {
        &self.poly_regions
    }

    pub fn connections(&self) -> &[Connection] {
        &self.connections
    }

    pub fn root_ports(&self) -> &[ResolvedPort] {
        &self.root_ports
    }

    /// Each root output port name mapped to the atomic port refs it gathers
    /// from. Empty for a root that declares no output ports.
    pub fn root_output_sources(&self) -> &BTreeMap<String, Vec<PortRef>> {
        &self.root_output_sources
    }

    pub fn root_input_destinations(&self) -> &BTreeMap<String, Vec<PortRef>> {
        &self.root_input_destinations
    }

    /// The control→audio promotions the compiler inserted as visible nodes.
    pub fn promotions(&self) -> &[PromotionStep] {
        &self.promotions
    }

    pub fn node(&self, id: &NodeId) -> Option<&AtomicNode> {
        self.nodes.iter().find(|node| node.id() == id)
    }

    /// Record the audio latency of a prepared poly child before its parent is
    /// balanced. The region and structural node are created together by flattening.
    pub(crate) fn set_poly_region_latency(&mut self, id: &NodeId, samples: u32) {
        let node = self
            .nodes
            .iter_mut()
            .find(|node| node.id == *id && node.definition == POLY_DEFINITION)
            .expect("flattened poly region has a structural node");
        node.latency = samples;
    }

    /// The number of distinct `(definition, static arguments)` keys structurally
    /// expanded — i.e. cache misses. Repeated identical instances do not
    /// increase this count.
    pub fn expansion_count(&self) -> usize {
        self.expansion_count
    }
}

/// The externally visible ports of an expanded subtree: each public port name
/// resolved to the atomic port(s) it forwards to (inputs) or gathers from
/// (outputs), with ids relative to the subtree's own frame.
#[derive(Clone, Debug, Default)]
struct Interface {
    inputs: BTreeMap<String, Vec<PortRef>>,
    outputs: BTreeMap<String, Vec<PortRef>>,
}

/// A cached structural expansion of one definition, with node ids and port
/// references relative to the definition's own frame (no instance prefix).
#[derive(Clone, Debug)]
struct Template {
    nodes: Vec<AtomicNode>,
    poly_regions: Vec<FlattenedPolyRegion>,
    connections: Vec<Connection>,
    interface: Interface,
}

/// Compilation state threaded through the recursive expansion.
struct Compiler<'a> {
    registry: &'a DefinitionRegistry,
    diagnostics: Diagnostics,
    cache: BTreeMap<String, Template>,
    expansions: usize,
    /// Definition names currently on the expansion stack, for recursion checks.
    path: Vec<String>,
    /// Definition names whose static references have been checked already.
    checked: BTreeSet<String>,
}

impl GraphDefinition {
    /// Recursively flatten this definition (as the root) into a graph of atomic
    /// nodes, or return the accumulated diagnostics on failure.
    pub fn flatten(&self, registry: &DefinitionRegistry) -> Result<FlattenedGraph, Diagnostics> {
        let context = self.enclosing_context();
        let mut compiler = Compiler {
            registry,
            diagnostics: Diagnostics::new(),
            cache: BTreeMap::new(),
            expansions: 0,
            path: Vec::new(),
            checked: BTreeSet::new(),
        };

        let template = compiler.resolve_expansion(self, &context, 0);

        if compiler.diagnostics.has_errors() {
            return Err(compiler.diagnostics);
        }

        let template = template.expect("no errors implies a template");
        let (mut nodes, poly_regions, connections, interface) = instantiate(&template, "");
        for port in self.ports() {
            let Some(default) = port.control_default() else {
                continue;
            };
            let Some(targets) = interface.inputs.get(port.name()) else {
                continue;
            };
            for target in targets {
                let atomic = nodes
                    .iter_mut()
                    .find(|atomic| atomic.id == *target.node())
                    .expect("a root interface reference names a flattened node");
                atomic
                    .port_defaults
                    .insert(target.port().to_string(), default.default());
            }
        }
        let (nodes, connections, promotions) = insert_promotions(nodes, connections);
        let root_ports = GraphDefinition::resolve_ports(self, &context);
        Ok(FlattenedGraph {
            nodes,
            poly_regions,
            connections,
            root_ports,
            root_output_sources: interface.outputs,
            root_input_destinations: interface.inputs,
            promotions,
            expansion_count: compiler.expansions,
        })
    }
}

impl Compiler<'_> {
    /// Expand `definition` with the given resolved static context into a cached
    /// template. Returns `None` when a guard (recursion, depth) fires.
    fn resolve_expansion(
        &mut self,
        definition: &GraphDefinition,
        static_context: &BTreeMap<String, StaticValue>,
        depth: usize,
    ) -> Option<Template> {
        let key = cache_key(definition.name(), static_context);
        if let Some(template) = self.cache.get(&key) {
            return Some(template.clone());
        }

        // Reject dangling channel/latency static references loudly, before any
        // resolution can silently fall back to a default value.
        if self.checked.insert(definition.name().to_string()) {
            definition.validate_static_references(&mut self.diagnostics);
            definition.validate_definition_structure(&mut self.diagnostics);
        }

        // Reject out-of-range resolved values for this instance's static
        // arguments before port/latency resolution can observe a fallback.
        // Runs per distinct (definition, static args) key, unlike the
        // declaration check above.
        if !definition.validate_resolved_static_references(static_context, &mut self.diagnostics) {
            return None;
        }

        // A definition with no internal nodes is an atomic primitive.
        if definition.implementation() == DefinitionImplementation::Script
            || definition.nodes().is_empty()
        {
            self.expansions += 1;
            let template = definition.atomic_template(static_context);
            self.cache.insert(key, template.clone());
            return Some(template);
        }

        if depth > MAX_FLATTEN_DEPTH {
            self.diagnostics.push(Diagnostic::new(
                error_codes::KERNEL_MAX_DEPTH_EXCEEDED,
                Severity::Error,
                format!(
                    "definition '{}' exceeds the maximum defined module nesting depth of {MAX_FLATTEN_DEPTH}",
                    definition.name()
                ),
            ));
            return None;
        }

        if self.path.iter().any(|name| name == definition.name()) {
            self.diagnostics.push(Diagnostic::new(
                error_codes::KERNEL_RECURSIVE_DEFINITION,
                Severity::Error,
                format!(
                    "definition '{}' is recursive: it instantiates itself directly or transitively",
                    definition.name()
                ),
            ));
            return None;
        }

        self.expansions += 1;
        self.path.push(definition.name().to_string());
        let template = self.expand_body(definition, static_context, depth);
        self.path.pop();

        self.cache.insert(key, template.clone());
        Some(template)
    }

    /// Expand a definition's internal nodes and connections into a relative-frame
    /// template. A node that fails to expand is reported and skipped, so this
    /// always yields a template; `flatten` discards it once diagnostics carry an
    /// error.
    fn expand_body(
        &mut self,
        definition: &GraphDefinition,
        static_context: &BTreeMap<String, StaticValue>,
        depth: usize,
    ) -> Template {
        let mut nodes = Vec::new();
        let mut poly_regions = Vec::new();
        let mut connections = Vec::new();
        let mut child_interfaces: BTreeMap<NodeId, Interface> = BTreeMap::new();

        for node in definition.nodes() {
            if node.definition_ref() == crate::builtins::module_types::AUDIO_OUTPUT {
                self.diagnostics
                    .push(super::retired_audio_output_diagnostic(definition, node));
                continue;
            }
            let Some(referenced) = self.registry.get(node.definition_ref()) else {
                self.diagnostics.push(
                    Diagnostic::new(
                        error_codes::KERNEL_UNKNOWN_DEFINITION,
                        Severity::Error,
                        format!(
                            "node '{}' references unknown definition '{}'",
                            node.id().as_str(),
                            node.definition_ref()
                        ),
                    )
                    .with_module_id(node.id().as_str()),
                );
                continue;
            };

            let Some(child_args) = definition.resolve_static_args(
                node,
                referenced,
                static_context,
                &mut self.diagnostics,
            ) else {
                continue;
            };

            if referenced.name() == POLY_DEFINITION {
                let Some(ports) = definition.resolve_node_ports(
                    node,
                    referenced,
                    &child_args,
                    self.registry,
                    &mut self.diagnostics,
                ) else {
                    continue;
                };
                let wrapped_definition = match child_args.get(POLY_WRAPPED_DEFINITION_PARAM) {
                    Some(StaticValue::String(value)) => value.clone(),
                    _ => continue,
                };
                let max_voices = match child_args.get(POLY_MAX_VOICES_PARAM) {
                    Some(StaticValue::Int(value)) => match usize::try_from(*value) {
                        Ok(value) => value,
                        Err(_) => continue,
                    },
                    _ => continue,
                };
                let Some(allocation_policy) = child_args
                    .get(POLY_ALLOCATION_PARAM)
                    .and_then(PolyAllocationPolicy::from_static_value)
                else {
                    continue;
                };
                let mut port_defaults = declared_control_defaults(&ports);
                port_defaults.extend(node.port_default_overrides().clone());
                nodes.push(AtomicNode {
                    id: node.id().clone(),
                    definition: POLY_DEFINITION.to_string(),
                    static_args: child_args,
                    port_defaults,
                    ports: ports.clone(),
                    latency: 0,
                });
                poly_regions.push(FlattenedPolyRegion {
                    node_id: node.id().clone(),
                    wrapped_definition,
                    max_voices,
                    allocation_policy,
                    sample_map_choke: None,
                });
                child_interfaces.insert(node.id().clone(), atomic_interface(node.id(), &ports));
                continue;
            }

            let Some(child_template) = self.resolve_expansion(referenced, &child_args, depth + 1)
            else {
                continue;
            };

            let (mut child_nodes, mut child_poly_regions, child_connections, child_interface) =
                instantiate(&child_template, node.id().as_str());
            apply_overrides(node, &child_interface, &mut child_nodes);

            nodes.extend(child_nodes);
            poly_regions.append(&mut child_poly_regions);
            connections.extend(child_connections);
            child_interfaces.insert(node.id().clone(), child_interface);
        }

        for connection in definition.connections() {
            let sources = child_interfaces
                .get(connection.source().node())
                .and_then(|interface| interface.outputs.get(connection.source().port()));
            let destinations = child_interfaces
                .get(connection.destination().node())
                .and_then(|interface| interface.inputs.get(connection.destination().port()));

            if let (Some(sources), Some(destinations)) = (sources, destinations) {
                for source in sources {
                    for destination in destinations {
                        connections.push(Connection::new(source.clone(), destination.clone()));
                    }
                }
            }
        }

        let interface = compose_interface(definition, &child_interfaces);
        Template {
            nodes,
            poly_regions,
            connections,
            interface,
        }
    }
}

/// Insert a visible control→audio promotion node on every connection whose
/// source is a `control` port and whose destination is an `audio` port,
/// rewiring the connection through it. The promotion becomes an inspectable
/// atomic node (definition [`CONTROL_TO_AUDIO_DEFINITION`]) in the flattened
/// graph rather than an implicit conversion, and each is recorded as a
/// [`PromotionStep`] for discovery.
fn insert_promotions(
    mut nodes: Vec<AtomicNode>,
    connections: Vec<Connection>,
) -> (Vec<AtomicNode>, Vec<Connection>, Vec<PromotionStep>) {
    let mut port_signal: BTreeMap<(NodeId, String), (SignalType, u32)> = BTreeMap::new();
    for node in &nodes {
        for port in node.ports() {
            port_signal.insert(
                (node.id().clone(), port.name().to_string()),
                (port.signal_type(), port.channels()),
            );
        }
    }
    let signal_of = |reference: &PortRef| {
        port_signal
            .get(&(reference.node().clone(), reference.port().to_string()))
            .copied()
    };

    let mut rewired = Vec::with_capacity(connections.len());
    let mut promotion_nodes = Vec::new();
    let mut promotions = Vec::new();
    for connection in connections {
        match (
            signal_of(connection.source()),
            signal_of(connection.destination()),
        ) {
            (
                Some((SignalType::Control, source_channels)),
                Some((SignalType::Audio, destination_channels)),
            ) => {
                let id = NodeId::new(format!(
                    "{PROMOTION_NODE_PREFIX}{NAMESPACE_SEPARATOR}{}",
                    promotions.len()
                ));
                promotion_nodes.push(promotion_node(&id, source_channels, destination_channels));
                rewired.push(Connection::new(
                    connection.source().clone(),
                    PortRef::new(id.clone(), PROMOTION_INPUT_PORT),
                ));
                rewired.push(Connection::new(
                    PortRef::new(id.clone(), PROMOTION_OUTPUT_PORT),
                    connection.destination().clone(),
                ));
                promotions.push(PromotionStep {
                    source: connection.source().clone(),
                    destination: connection.destination().clone(),
                    channels: destination_channels,
                });
            }
            _ => rewired.push(connection),
        }
    }

    nodes.extend(promotion_nodes);
    (nodes, rewired, promotions)
}

/// Build the atomic node for a control→audio promotion: a control input of the
/// source width and an audio output of the destination width, zero latency.
fn promotion_node(id: &NodeId, input_channels: u32, output_channels: u32) -> AtomicNode {
    AtomicNode {
        id: id.clone(),
        definition: CONTROL_TO_AUDIO_DEFINITION.to_string(),
        static_args: BTreeMap::new(),
        port_defaults: BTreeMap::new(),
        ports: vec![
            ResolvedPort {
                name: PROMOTION_INPUT_PORT.to_string(),
                direction: PortDirection::Input,
                signal_type: SignalType::Control,
                channels: input_channels,
                multiplicity: Multiplicity::default(),
                control_default: None,
            },
            ResolvedPort {
                name: PROMOTION_OUTPUT_PORT.to_string(),
                direction: PortDirection::Output,
                signal_type: SignalType::Audio,
                channels: output_channels,
                multiplicity: Multiplicity::default(),
                control_default: None,
            },
        ],
        latency: 0,
    }
}

/// Re-namespace a template under an instance `prefix`, yielding the concrete
/// atomic nodes, connections, and boundary interface for that instance.
fn instantiate(
    template: &Template,
    prefix: &str,
) -> (
    Vec<AtomicNode>,
    Vec<FlattenedPolyRegion>,
    Vec<Connection>,
    Interface,
) {
    let nodes = template
        .nodes
        .iter()
        .map(|node| AtomicNode {
            id: NodeId::new(namespaced(prefix, node.id.as_str())),
            definition: node.definition.clone(),
            static_args: node.static_args.clone(),
            port_defaults: node.port_defaults.clone(),
            ports: node.ports.clone(),
            latency: node.latency,
        })
        .collect();

    let connections = template
        .connections
        .iter()
        .map(|connection| {
            Connection::new(
                renamespace(connection.source(), prefix),
                renamespace(connection.destination(), prefix),
            )
        })
        .collect();

    let poly_regions = template
        .poly_regions
        .iter()
        .map(|region| FlattenedPolyRegion {
            node_id: NodeId::new(namespaced(prefix, region.node_id.as_str())),
            wrapped_definition: region.wrapped_definition.clone(),
            max_voices: region.max_voices,
            allocation_policy: region.allocation_policy,
            sample_map_choke: region.sample_map_choke.clone(),
        })
        .collect();

    let interface = Interface {
        inputs: renamespace_map(&template.interface.inputs, prefix),
        outputs: renamespace_map(&template.interface.outputs, prefix),
    };

    (nodes, poly_regions, connections, interface)
}

/// Apply a node instance's control-default overrides onto the atomic nodes its
/// public input ports resolve to. Overrides of unknown ports are ignored here
/// (validation reports them separately).
fn apply_overrides(node: &Node, interface: &Interface, nodes: &mut [AtomicNode]) {
    for (port_name, value) in node.port_default_overrides() {
        let Some(targets) = interface.inputs.get(port_name) else {
            continue;
        };
        for target in targets {
            let atomic = nodes
                .iter_mut()
                .find(|atomic| atomic.id == *target.node())
                .expect("a boundary interface reference names a node of the same instance");
            atomic
                .port_defaults
                .insert(target.port().to_string(), *value);
        }
    }
}

fn compose_interface(
    definition: &GraphDefinition,
    child_interfaces: &BTreeMap<NodeId, Interface>,
) -> Interface {
    let mut interface = Interface::default();
    for port in definition.ports() {
        match port.direction() {
            PortDirection::Input => {
                let mut targets = Vec::new();
                for internal in port.internal_targets() {
                    if let Some(child) = child_interfaces.get(internal.node()) {
                        if let Some(refs) = child.inputs.get(internal.port()) {
                            targets.extend(refs.iter().cloned());
                        }
                    }
                }
                interface.inputs.insert(port.name().to_string(), targets);
            }
            PortDirection::Output => {
                let mut sources = Vec::new();
                for internal in port.internal_sources() {
                    if let Some(child) = child_interfaces.get(internal.node()) {
                        if let Some(refs) = child.outputs.get(internal.port()) {
                            sources.extend(refs.iter().cloned());
                        }
                    }
                }
                interface.outputs.insert(port.name().to_string(), sources);
            }
        }
    }
    interface
}

impl GraphDefinition {
    /// Build the template for a single atomic (primitive) definition: one node
    /// whose id is empty relative to its own instance frame, carrying declared
    /// control defaults only.
    fn atomic_template(&self, static_args: &BTreeMap<String, StaticValue>) -> Template {
        let ports = GraphDefinition::resolve_ports(self, static_args);
        let id = NodeId::new("");
        let interface = atomic_interface(&id, &ports);
        Template {
            nodes: vec![AtomicNode {
                id,
                definition: match self.implementation() {
                    DefinitionImplementation::Graph => self.name().to_string(),
                    DefinitionImplementation::Script => {
                        crate::builtins::module_types::SCRIPT.to_string()
                    }
                },
                static_args: static_args
                    .iter()
                    .map(|(name, value)| (name.clone(), value.without_definition_scope()))
                    .collect(),
                port_defaults: declared_control_defaults(&ports),
                ports,
                latency: self.latency().resolve(static_args),
            }],
            poly_regions: Vec::new(),
            connections: Vec::new(),
            interface,
        }
    }
}

fn namespaced(prefix: &str, relative: &str) -> String {
    match (prefix.is_empty(), relative.is_empty()) {
        (_, true) => prefix.to_string(),
        (true, false) => relative.to_string(),
        (false, false) => format!("{prefix}{NAMESPACE_SEPARATOR}{relative}"),
    }
}

fn renamespace(reference: &PortRef, prefix: &str) -> PortRef {
    PortRef::new(
        NodeId::new(namespaced(prefix, reference.node().as_str())),
        reference.port(),
    )
}

fn renamespace_map(
    map: &BTreeMap<String, Vec<PortRef>>,
    prefix: &str,
) -> BTreeMap<String, Vec<PortRef>> {
    map.iter()
        .map(|(name, refs)| {
            (
                name.clone(),
                refs.iter().map(|r| renamespace(r, prefix)).collect(),
            )
        })
        .collect()
}

fn atomic_interface(node_id: &NodeId, ports: &[ResolvedPort]) -> Interface {
    let mut interface = Interface::default();
    for port in ports {
        let reference = vec![PortRef::new(node_id.clone(), port.name())];
        match port.direction() {
            PortDirection::Input => {
                interface.inputs.insert(port.name().to_string(), reference);
            }
            PortDirection::Output => {
                interface.outputs.insert(port.name().to_string(), reference);
            }
        }
    }
    interface
}

fn declared_control_defaults(ports: &[ResolvedPort]) -> BTreeMap<String, f64> {
    ports
        .iter()
        .filter(|port| {
            port.direction() == PortDirection::Input && port.signal_type() == SignalType::Control
        })
        .filter_map(|port| {
            port.control_default()
                .map(|control| (port.name().to_string(), control.default()))
        })
        .collect()
}

fn cache_key(name: &str, static_args: &BTreeMap<String, StaticValue>) -> String {
    let mut key = name.to_string();
    for (parameter, value) in static_args {
        key.push('|');
        key.push_str(parameter);
        key.push('=');
        match value {
            StaticValue::Int(number) => key.push_str(&number.to_string()),
            StaticValue::Enum(text) => {
                key.push_str("enum:");
                key.push_str(text);
            }
            StaticValue::String(authored) | StaticValue::ScopedString { authored, .. } => {
                key.push_str("string:");
                key.push_str(&authored.len().to_string());
                key.push(':');
                key.push_str(authored);
                if let StaticValue::ScopedString { resolved, .. } = value {
                    key.push_str("->");
                    key.push_str(&resolved.len().to_string());
                    key.push(':');
                    key.push_str(resolved);
                }
            }
            StaticValue::Resource(reference) => {
                key.push_str("res:");
                key.push_str(reference.kind().as_str());
                key.push(':');
                key.push_str(&reference.path().to_string_lossy());
                key.push(':');
                match reference.origin() {
                    super::ResourceOrigin::Document => key.push_str("document"),
                    super::ResourceOrigin::Package(root) => {
                        key.push_str("package:");
                        key.push_str(&root.to_string_lossy());
                    }
                }
            }
        }
    }
    key
}

#[cfg(test)]
mod tests;
