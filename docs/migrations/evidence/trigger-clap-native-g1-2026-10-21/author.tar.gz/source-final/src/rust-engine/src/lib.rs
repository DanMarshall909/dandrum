#![deny(dead_code)]

#[macro_use]
mod test_support;

#[cfg(test)]
mod test_allocator;

#[cfg(test)]
mod drum_voice_authoring_tests;

#[cfg(test)]
extern crate self as dandrum_engine;

#[cfg(test)]
#[path = "legacy_tests/declarative_parameters_red_tests.rs"]
mod legacy_declarative_parameters_red_tests;
#[cfg(test)]
#[path = "legacy_tests/declarative_parameters_remaining_red_tests.rs"]
mod legacy_declarative_parameters_remaining_red_tests;
#[cfg(test)]
#[path = "legacy_tests/engine_patch_behaviour_tests.rs"]
mod legacy_engine_patch_behaviour_tests;

pub mod core;

pub mod compiled_patch;

pub mod preparation;

pub mod graph_processor;

pub(crate) mod builtins;

pub mod cli;
pub mod codex_cli_provider;
pub mod graph;
pub mod graph_proposal;
#[cfg(test)]
pub mod instrument_state;
pub mod kernel;
pub mod module_library;
pub mod module_package;
pub mod module_reference;
pub mod patch;
pub(crate) mod sample;
pub use sample::PreparedSamplerAssets;
pub mod script;

pub mod sound_analysis;
pub mod sound_matching;
pub mod sound_workbench;
pub mod sound_workbench_ffi;

#[cfg(test)]
pub(crate) mod synth;

pub mod wav;

#[cfg(test)]
pub(crate) mod voice_allocator;

pub(crate) mod fft;

pub(crate) mod delay_line;
pub(crate) mod echo;
pub(crate) mod filter;
pub(crate) mod reverb;

pub(crate) mod realtime;

pub(crate) mod crossover;

pub(crate) mod spectral;

pub(crate) mod curve_mapper;
pub(crate) mod decay;
pub(crate) mod envelope_follower;
pub(crate) mod oscillator;

pub(crate) mod audio_loading;

pub(crate) mod convolution;
pub(crate) mod dynamics_processor;
pub(crate) mod saturator;

pub mod ffi;

pub mod diagnostics;
