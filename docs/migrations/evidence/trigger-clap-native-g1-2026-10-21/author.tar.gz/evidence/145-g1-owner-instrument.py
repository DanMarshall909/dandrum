from pathlib import Path
import os,json,hashlib,subprocess,sys
out=Path('/tmp/dandrum-lanes/evidence-trigger-native-gui');capture_name=sys.argv[1];capture=json.loads((out/capture_name).read_text());directory=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/trigger-g1-adapter-owner-20261021');directory.mkdir(exist_ok=False);command=list(capture['command']);command[command.index('--out-dir')+1]=str(directory);command+=['-C','instrument-coverage'];env=os.environ.copy();env.update(capture['environment'])
for k in ('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS','RUSTC_WRAPPER','LD_PRELOAD','LLVM_PROFILE_FILE'):env.pop(k,None)
env['RUST_MIN_STACK']='16777216'
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
externs={capture['command'][i+1].split('=',1)[0]:{'path':capture['command'][i+1].split('=',1)[1],'sha256':h(capture['command'][i+1].split('=',1)[1])} for i,x in enumerate(capture['command']) if x=='--extern'}
r={'capture':capture_name,'base_command':capture['command'],'instrumented_command':command,'cwd':capture['cwd'],'environment':{k:env[k] for k in capture['environment'] if k in env},'only_difference':'-C instrument-coverage plus output redirect into existing physical DISK coverage cache bounded subdirectory; original opt/codegen/LTO flags unchanged. Compiler-only RUST_MIN_STACK16MiB, not runtime.','direct_externs':externs,'compiler':subprocess.check_output([command[0],'-Vv'],text=True),'scope':'Adapter owner DSO only; no transitive core/controller/editor/browser/allocator/performance coverage','source_sha256':{str(p):h(p) for p in Path(capture['cwd']).joinpath('src').rglob('*.rs')}}
(out/'g1-owner-instrument-binding.json').write_text(json.dumps(r,indent=2));run=subprocess.run(command,cwd=capture['cwd'],env=env);r['exit']=run.returncode
if run.returncode==0:
 elf=directory/'libdandrum_clap_adapter.so';assert elf.is_file();r.update(instrumented_dso=str(elf),instrumented_dso_sha256=h(elf),ELF_notes=subprocess.check_output(['readelf','-n',str(elf)],text=True))
(out/'g1-owner-instrument-binding.json').write_text(json.dumps(r,indent=2));raise SystemExit(run.returncode)
