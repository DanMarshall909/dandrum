#!/usr/bin/python3
import os,sys,pathlib,json
if '--crate-name' in sys.argv:
 name=sys.argv[sys.argv.index('--crate-name')+1]
 if name in ('dandrum_clap_adapter','trigger_gui'):
  keys=[k for k in os.environ if (k.startswith('CARGO_') and k!='CARGO_MAKEFLAGS') or k in ('RUST_MIN_STACK','LD_LIBRARY_PATH','TMPDIR')]
  prefix=os.environ.get('DANDRUM_RUSTC_CAPTURE_PREFIX','100')
  pathlib.Path('/tmp/dandrum-lanes/evidence-trigger-native-gui/'+prefix+'-'+name+'-rustc.json').write_text(json.dumps({'cwd':os.getcwd(),'command':sys.argv[1:],'environment':{k:os.environ[k] for k in sorted(keys)},'omitted_session_keys':['CARGO_MAKEFLAGS']},indent=2))
os.execv(sys.argv[1],sys.argv[1:])
