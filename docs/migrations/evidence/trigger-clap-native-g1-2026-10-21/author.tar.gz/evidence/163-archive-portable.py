from pathlib import Path
import json,hashlib,tarfile,subprocess
out=Path('/tmp/dandrum-lanes/evidence-trigger-native-gui');root=Path('/tmp/dandrum-lanes/runtime');selected={};add=lambda p,n:selected.setdefault(n,p)
for p in out.iterdir():
 if not p.is_file():continue
 prefix=p.name.split('-',1)[0]
 if prefix.isdigit() and (100<=int(prefix)<=162 or int(prefix) in (26,41,51,52)) and (p.suffix in ('.json','.log','.py','.txt','.diff') or p.name.startswith('52-') and '-loader.' in p.name):add(p,'evidence/'+p.name)
for name in ('run.py','g1-owner-instrument-binding.json','current-native-build-inputs.json'):
 p=out/name;assert p.is_file();add(p,'evidence/'+name)
for p in (out/'150-final-native-release-build/source').rglob('*'):
 if p.is_file():add(p,'source-final/'+str(p.relative_to(out/'150-final-native-release-build/source')))
for label in ('41-wrong-loader-identity-red','51-revised-strengthened-native-red'):
 for relative in ('src/clap-adapter/src/trigger/gui.rs','src/clap-adapter/tests/trigger_gui.rs','src/clap-adapter/tests/fixtures/trigger-gui-native-observer.js'):
  p=out/label/'source'/relative
  if p.is_file():add(p,'historical-qualified-source/'+label+'/'+relative)
for relative in ('src/clap-adapter/Cargo.toml','src/clap-adapter/Cargo.lock','src/clap-adapter/src/trigger.rs','src/clap-adapter/src/trigger/gui.rs'):
 p=out/'114-retrospective-current9f4-prepin-build/source'/relative;assert p.is_file();add(p,'retrospective-prepin-source/'+relative)
for p in (out/'installed/DandrumTrigger.resources').rglob('*'):
 if p.is_file():add(p,'actual-original-resources/DandrumTrigger.resources/'+str(p.relative_to(out/'installed/DandrumTrigger.resources')))
for relative in ('src/clap-adapter/fixtures/signed-gain.yaml','examples/patches/tb303-acid.yaml'):add(root/relative,'embedded-fixtures/'+relative)
cov=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/trigger-g1-adapter-owner-20261021');raw=sorted((cov/'profiles').glob('156-g1-*.profraw'));assert len(raw)==5
for p in raw:add(p,'llvm/profiles/'+p.name)
add(cov/'158-g1-owner-coverage.profdata','llvm/158-g1-owner-coverage.profdata')
for name in ('g1-artifact-binding-correction.json','recovered-prepin-artifact-independent-check.json','recovered-pin-artifact-independent-check.json','gnu-loader-boundary-adoption.json','lifetime-policy-adoption.json','combined-lock-license-summary.json','lifetime-assessment/assessment.md'):
 p=Path('/tmp/dandrum-evidence/trigger-native-gui-next')/name;assert p.is_file();add(p,'root-authority/'+name)
add(Path('/tmp/dandrum-evidence/trigger-gui-dso-unload-readiness.md'),'root-authority/trigger-gui-dso-unload-readiness.md')
for p in selected.values():assert p.is_file() and not p.read_bytes().startswith(b'\x7fELF')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest={'purpose':'Portable source-bound G1 developer-only evidence. No ELF, rlib, buildcache or complete cache copy. One final effective-source snapshot only; four distinct retrospective-prepin files and narrow qualified historical sources retained. Original React/resources separate from observerfixture. Raw only exactfive newlyexecuted ownerprofiles+matchingmergeddata; actualELFs remain retained at originalpaths/hashbound, not distributed.','chronology':'162-g1-verified-checkpoint.json and root-authority/g1-artifact-binding-correction.json govern corrected sourcebinding.116-119RETROSPECTIVE afterfirstpinwrite; never presentedas beforecode.51/41timing/failurevalid buthistoricalexactdepsbindingqualified.','source_checkout_HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'root_developer_cut_design_SHA256':'f4999d24c3903c6e46cd9c591f22e66354e2dca9e1ff2911a03513c9a44fcd53','earlier_author_design_SHA256':'744ace5e0f73e76bacc8d004ce7d3adb20e2365da230f19678a203a8f72bc413','entries':{n:{'original_path':str(p),'bytes':p.stat().st_size,'sha256':h(p)} for n,p in sorted(selected.items())},'excluded':'AllELFs/rlibs/dependencycachetrees/redundantsourcesnapshots; rootpublishedNativeEditor9f4portableproof alreadyseparate; old wholeG1workinglogs remainretainedlocally. No completenessclaim for allhistoricalsetupattempts.'}
mp=out/'163-portable-manifest.json';mp.write_text(json.dumps(manifest,indent=2));archive=out/'163-trigger-g1-developer-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for n,p in sorted(selected.items()):tar.add(p,arcname=n,recursive=False)
 tar.add(mp,arcname='manifest.json',recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members={m.name:m for m in tar.getmembers()};assert len(members)==len(selected)+1
 for name,record in manifest['entries'].items():
  f=tar.extractfile(members[name]);assert f is not None;assert hashlib.sha256(f.read()).hexdigest()==record['sha256']
r={'archive':str(archive),'sha256':h(archive),'compressed_bytes':archive.stat().st_size,'entry_count':len(selected)+1,'uncompressed_entry_bytes':sum(p.stat().st_size for p in selected.values())+mp.stat().st_size,'manifest':str(mp),'archive_reread_all_entry_hashes':True,'no_ELF_or_dependency_cache_copy':True};(out/'163-portable-archive-receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
