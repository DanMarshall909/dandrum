import os,json,pathlib,subprocess,hashlib,time
out=pathlib.Path('/tmp/dandrum-lanes/evidence-trigger-native-gui')
elf=pathlib.Path('/tmp/dandrum-lanes/cache-editor-guard/release/deps/trigger_gui-825ed2de539899e1')
results=[]
for name,plugin,baseline in [('gui-no-native',out/'installed/DandrumTrigger.clap',False),('plain73af',out/'baseline73af/DandrumTrigger.clap',True)]:
 env=os.environ.copy();env.pop('LD_PRELOAD',None);env.pop('RUST_MIN_STACK',None)
 env['DANDRUM_TRIGGER_GUI_PLUGIN_PATH']=str(plugin);env['LD_DEBUG']='files';env['LD_DEBUG_OUTPUT']=str(out/('52-'+name+'-loader'))
 if baseline:env['DANDRUM_G1_EXPECT_HEADLESS_BASELINE']='1'
 else:env.pop('DANDRUM_G1_EXPECT_HEADLESS_BASELINE',None)
 command=[str(elf),'--ignored','--exact','copied_editor_scan_and_configuration_only_do_not_make_code_resident','--nocapture']
 start=time.monotonic()
 with open(out/('52-'+name+'.stdout.log'),'wb') as so,open(out/('52-'+name+'.stderr.log'),'wb') as se:
  run=subprocess.run(command,env=env,stdout=so,stderr=se,timeout=25)
 results.append({'control':name,'command':command,'exit':run.returncode,'seconds':time.monotonic()-start,'plugin_path':str(plugin),'plugin_sha256':hashlib.sha256(plugin.read_bytes()).hexdigest(),'test_elf_sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'headless_baseline':baseline})
(out/'52-loader-control-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
raise SystemExit(0 if all(r['exit']==0 for r in results) else 1)
