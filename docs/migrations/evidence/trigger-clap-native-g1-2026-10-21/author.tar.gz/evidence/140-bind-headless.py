from pathlib import Path
import sys,json,hashlib,shutil,subprocess
out=Path('/tmp/dandrum-lanes/evidence-trigger-native-gui');root=Path('/tmp/dandrum-lanes/runtime');label,kind=sys.argv[1:];log=out/(label+'.stdout.log');records=[]
for line in log.read_text().splitlines():
 try:records.append(json.loads(line))
 except json.JSONDecodeError:pass
assert any(r.get('reason')=='build-finished' and r.get('success') for r in records)
owner=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('manifest_path')==str(root/'src/clap-adapter/Cargo.toml')]
prod=[r for r in owner if r['target']['name']=='dandrum_clap_adapter' and set(r['target']['crate_types'])=={'cdylib','rlib'} and any(p.endswith('.so') for p in r['filenames'])];assert len(prod)==1
so=[Path(p) for p in prod[0]['filenames'] if p.endswith('.so')];assert len(so)==1
stage=out/('current-'+kind);stage.mkdir(exist_ok=True);copy=stage/'DandrumTrigger.clap';shutil.copy2(so[0],copy)
if kind=='plain-trigger':shutil.copytree(out/'installed/DandrumTrigger.resources/instrument',stage/'DandrumTrigger.resources/instrument',dirs_exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert h(so[0])==h(copy)
tests={r['target']['name']:{'path':r['executable'],'sha256':h(Path(r['executable'])),'record':r} for r in owner if r.get('executable')}
r={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'log':str(log),'log_sha256':h(log),'production_record':prod[0],'source_path':str(so[0]),'copy_path':str(copy),'source_sha256':h(so[0]),'copy_sha256':h(copy),'tests':tests,'resources':{str(p.relative_to(stage)):h(p) for p in stage.rglob('*') if p.is_file()}}
(out/(label+'-artifact-binding.json')).write_text(json.dumps(r,indent=2));print(json.dumps({'source':str(so[0]),'copy':str(copy),'sha256':h(copy),'tests':{k:v['path'] for k,v in tests.items()}},indent=2))
