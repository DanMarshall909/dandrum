from pathlib import Path
import json,sys,os,subprocess,hashlib
out=Path('/tmp/dandrum-lanes/evidence-trigger-native-gui');build,kind=sys.argv[1:];binding=json.loads((out/(build+'-artifact-binding.json')).read_text());env=os.environ.copy();env.pop('RUST_MIN_STACK',None);env.pop('LD_PRELOAD',None)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert h(binding['copy_path'])==binding['copy_sha256']
env['DANDRUM_CLAP_PLUGIN_PATH']=str(out/'current-default/DandrumTrigger.clap');env['DANDRUM_TRIGGER_CLAP_PLUGIN_PATH']=binding['copy_path'];env['DANDRUM_TRIGGER_CLAP_AUDIT_EVIDENCE_DIR']=str(out/'current-plain-trigger/allocator-audit')
selected=['clap_dynamic','public_engine_baseline'] if kind=='default' else ['trigger_dynamic','public_engine_baseline'];results=[]
for name in selected:
 t=binding['tests'][name];assert h(t['path'])==t['sha256'];command=[t['path'],'--test-threads=1','--nocapture'];r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120);(out/(build+'-'+name+'.stdout.log')).write_bytes(r.stdout);(out/(build+'-'+name+'.stderr.log')).write_bytes(r.stderr);print(name,r.returncode,r.stdout.decode(errors='replace')[-700:]);results.append({'name':name,'command':command,'ELF_sha256':t['sha256'],'exit':r.returncode});assert r.returncode==0;assert b'0 passed;' not in r.stdout
(out/(build+'-executed-regressions.json')).write_text(json.dumps({'binding':build+'-artifact-binding.json','results':results,'environment':{k:env[k] for k in ('DANDRUM_CLAP_PLUGIN_PATH','DANDRUM_TRIGGER_CLAP_PLUGIN_PATH','DANDRUM_TRIGGER_CLAP_AUDIT_EVIDENCE_DIR')},'runtime_RUST_MIN_STACK':env.get('RUST_MIN_STACK'),'runtime_LD_PRELOAD':env.get('LD_PRELOAD')},indent=2))
