from pathlib import Path
import sys,json,hashlib,shutil,subprocess
out=Path('/tmp/dandrum-lanes/evidence-trigger-native-gui');root=Path('/tmp/dandrum-lanes/runtime');label,receipt_label=sys.argv[1:];log=out/(label+'.stdout.log');records=[]
for line in log.read_text().splitlines():
 try:records.append(json.loads(line))
 except json.JSONDecodeError:pass
assert any(r.get('reason')=='build-finished' and r.get('success') for r in records)
production=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('manifest_path')==str(root/'src/clap-adapter/Cargo.toml') and r['target']['name']=='dandrum_clap_adapter' and set(r['target']['crate_types'])=={'cdylib','rlib'}]
assert len(production)==1,production
artifacts=[Path(p) for p in production[0]['filenames'] if p.endswith('.so')];assert len(artifacts)==1,artifacts
actual=artifacts[0];assert actual.is_file()
tests=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('manifest_path')==str(root/'src/clap-adapter/Cargo.toml') and r['target']['name']=='trigger_gui' and r.get('executable')];assert len(tests)==1,tests
elf=Path(tests[0]['executable']);assert elf.is_file();obs=(root/'src/clap-adapter/tests/fixtures/trigger-gui-native-observer.js').read_bytes();raw=elf.read_bytes();offset=raw.find(obs);assert offset>=0
copied=out/'installed/DandrumTrigger.clap';shutil.copy2(actual,copied)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert h(actual)==h(copied)
needed=subprocess.check_output(['readelf','-d',str(elf)],text=True);assert 'libwebkit' not in needed
r={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'Cargo_JSON_log':str(log),'Cargo_JSON_sha256':h(log),'exact_selected_production_record':production[0],'source_elf':str(actual),'source_elf_sha256':h(actual),'copied_elf':str(copied),'copied_elf_sha256':h(copied),'source_copy_hash_equal':True,'ELF_dynamic_symbols':subprocess.check_output(['readelf','--wide','--dyn-syms',str(copied)],text=True),'ELF_notes':subprocess.check_output(['readelf','-n',str(copied)],text=True),'exact_selected_test_record':tests[0],'test_elf':str(elf),'test_elf_sha256':h(elf),'test_DT_NEEDED':needed,'observer_sha256':hashlib.sha256(obs).hexdigest(),'observer_bytes':len(obs),'observer_exact_ELF_offset':offset,'effective_build_source_receipt':str(out/(label+'.json')),'current_owned_source_sha256':{p:h(root/p) for p in ('src/clap-adapter/Cargo.toml','src/clap-adapter/Cargo.lock','src/clap-adapter/src/trigger.rs','src/clap-adapter/src/trigger/gui.rs','src/clap-adapter/tests/trigger_gui.rs')},'embedded_unchanged_fixture_sha256':{p:h(root/p) for p in ('src/clap-adapter/fixtures/signed-gain.yaml','examples/patches/tb303-acid.yaml')},'production_original_app_sha256':h(out/'installed/DandrumTrigger.resources/editor/app.js'),'artifact_selection':'Only matching exactCargo compiler-artifact target.filenames unique.so; never top-level fallback or mtime inference.'};(out/(receipt_label+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps({k:r[k] for k in ('source_elf','source_elf_sha256','copied_elf_sha256','test_elf','test_elf_sha256','observer_exact_ELF_offset','Cargo_JSON_log')},indent=2))
