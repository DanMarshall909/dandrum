from pathlib import Path
import json,subprocess,hashlib,sys
out=Path('/tmp/dandrum-lanes/evidence-trigger-native-gui');directory=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/trigger-g1-adapter-owner-20261021');elf=out/'instrumented-g1/DandrumTrigger.clap';tools=Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin');label=sys.argv[1];prefixes=sys.argv[2:];raw=sorted(p for p in (directory/'profiles').iterdir() if p.suffix=='.profraw' and any(p.name.startswith(prefix) for prefix in prefixes));assert len(raw)==5
binding=json.loads((out/'156-instrumented-native-binding.json').read_text());assert hashlib.sha256(elf.read_bytes()).hexdigest()==binding['copied_elf_sha256'];assert all(p.stat().st_mtime_ns>=binding['profile_start_time_ns'] for p in raw)
merged=directory/(label+'.profdata');export=out/(label+'-raw-export.json');commands=[[str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in raw],'-o',str(merged)],[str(tools/'llvm-cov'),'export',str(elf),'--instr-profile='+str(merged)]]
receipt={'raw_profiles':{str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in raw},'matching_elf':str(elf),'elf_sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'commands':commands,'tool_versions':{n:subprocess.check_output([str(tools/n),'--version'],text=True) for n in ('llvm-profdata','llvm-cov')},'tool_sha256':{n:hashlib.sha256((tools/n).read_bytes()).hexdigest() for n in ('llvm-profdata','llvm-cov')}}
for i,command in enumerate(commands):
 stderr=out/(label+('-merge' if i==0 else '-export')+'.stderr.log')
 with open(stderr,'wb') as se:
  if i==1:
   with open(export,'wb') as so:run=subprocess.run(command,stdout=so,stderr=se)
  else:run=subprocess.run(command,stdout=subprocess.DEVNULL,stderr=se)
 receipt['exit_'+str(i)]=run.returncode;receipt['stderr_bytes_'+str(i)]=stderr.stat().st_size
 if run.returncode!=0 or stderr.stat().st_size:
  (out/(label+'-binding.json')).write_text(json.dumps(receipt,indent=2));raise SystemExit('coverage merge/export error or nonempty stderr; retain qualification, no flag changes')
data=json.loads(export.read_text());receipt['export_sha256']=hashlib.sha256(export.read_bytes()).hexdigest();receipt['files']=[{'filename':f['filename'],'summary':f['summary']} for d in data['data'] for f in d['files']];receipt['function_instantiations']=sum(len(d['functions']) for d in data['data']);receipt['branch_entries']=sum(len(f['branches']) for d in data['data'] for f in d['files']);(out/(label+'-binding.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps({'profiles':len(raw),'instantiations':receipt['function_instantiations'],'branch_entries':receipt['branch_entries'],'adapter':[f for f in receipt['files'] if '/clap-adapter/' in f['filename']]},indent=2))
