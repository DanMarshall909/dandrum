# Lost-ack second-instance follow-up evidence

The assigned structural native case now keeps instance B live through A's existing lost-reply, editor-loss, recovery, recreation, and real header Undo path. At five checkpoints it asserts B's exact accepted snapshot, composite authority, full feedback DTO, exact saved bytes, live attached WebView, and literal signed MIDI 36 `[-0.5,-0.5]` / MIDI 60 `[0.0,0.0]`. Each B audio probe owns a real returned CLAP endpoint and returns/deactivates it before the next host transition. A's existing acceptance/recovery/history/Undo oracles remain intact. Cleanup tracks both optional views and A's active endpoint; on a panic it returns A audio, then destroys both views and asserts empty parent children before unwinding the original failure.

Final source SHA-256: `ef7ef8211b53bc386ec43ccc9d6be4e0035d93fe8120ab412f2affc145c95204`. Only `src/clap-adapter/tests/internal/trigger_structural_native.rs` is modified in Runtime; the excluded Runtime `cache-editor-guard/` remains untouched.

Checks: exact registered structural case passed (one test, zero failures); maintained native CLAP lane passed `28/28` in 45.14 seconds; Rustfmt check and strict all-target Clippy passed. The native lane's first run had two allocator subprocess setup failures because the task TMPDIR had not been created; its retry with the existing task-specific TMPDIR directory passed all tests. The CMake fixture invokes its preparer with `--jobs 2` regardless of `CARGO_BUILD_JOBS=1`.

The focused `cargo llvm-cov` native run executed and passed the exact ignored test under X11. Its generated report has no test source file and all reported library totals are zero, so it is not evidence of changed-test coverage. The instrumented test ELF and raw profiles remain in the leased LLVM cache and are bound in `final-evidence-manifest.json` for root diagnosis.

Raw CTest logs, strict Clippy/Rustfmt logs, LLVM stdout/stderr/report, final source copy/diff, copied production DSO and resource hashes, and command/environment receipts are listed in `final-evidence-manifest.json`.
