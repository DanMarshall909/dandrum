import gzip,hashlib,io,json,tarfile
from pathlib import Path
root=Path('/tmp/dandrum-evidence/g3-lost-ack-native-fixture');author=Path('/tmp/dandrum-evidence/g3-lost-ack-second-instance');dest=Path('/tmp/dandrum-lanes/integration/docs/migrations/evidence/trigger-clap-lost-ack-independence-2026-10-22');dest.mkdir(parents=True,exist_ok=False)
sha=lambda d:hashlib.sha256(d).hexdigest()
def add(e,p,n):
 assert p.is_file() and not p.is_symlink();d=p.read_bytes();assert not d.startswith(b'\x7fELF') and p.suffix not in ('.profraw','.profdata') and len(d)<64*1024**2;d.decode('utf8');e[n]=d

def archive(name,e):
 e['meta/index.json']=(json.dumps({n:dict(sha256=sha(d),bytes=len(d)) for n,d in e.items()},sort_keys=True,indent=2)+'\n').encode();p=dest/name
 with p.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as z,tarfile.open(fileobj=z,mode='w') as t:
  for n,d in sorted(e.items()):
   i=tarfile.TarInfo(n);i.size=len(d);i.mode=0o644;t.addfile(i,io.BytesIO(d))
 with tarfile.open(p,'r:gz') as t:
  assert set(t.getnames())==set(e)
  for i in t:assert t.extractfile(i).read()==e[i.name]
 r=dict(archive=name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size,members=len(e),every_member_byte_verified=True);(dest/name.replace('-raw.tar.gz','-archive.json')).write_text(json.dumps(r,indent=2)+'\n');print(r)
e={}
for p in sorted(author.iterdir()):
 if p.is_file():add(e,p,'author/'+p.name)
archive('author-raw.tar.gz',e)
e={}
for p in sorted(root.iterdir()):
 if p.is_file() and p.suffix in ('.py','.json','.log','.stdout','.stderr','.d'):add(e,p,'root/'+p.name)
for p in sorted((root/'integration-before').rglob('*')):
 if p.is_file():add(e,p,'integration-before/'+str(p.relative_to(root/'integration-before')))
for fixture in ('trigger-clap-native-fixture','trigger-clap-parameters-fixture'):
 for p in sorted((root/'native-build'/fixture/'evidence').iterdir()):
  if p.is_file():add(e,p,'native-prepare/'+fixture+'/'+p.name)
for n in ('CTestTestfile.cmake','CMakeCache.txt'):add(e,root/'native-build'/n,'native-configuration/'+n)
for n in ('assignment.md','assignment-preflight.json','assignment-fetch.log','next-status.json','next-apply.json','resource-addendum.json'):add(e,Path('/tmp/dandrum-evidence/lost-ack-second-instance-readiness')/n,'assignment/'+n)
add(e,Path('/tmp/dandrum-evidence/g3-two-native-instances/final-test-instrument-binding.json'),'prior-reviewed-capture/final-test-instrument-binding.json')
for n in ('root-clap-build-boundary.json','root-clap-build-boundary.stdout.log','root-clap-build-boundary.stderr.log'):add(e,Path('/tmp/dandrum-evidence/g3-native-fixture')/n,'prior-headless-build/'+n)
archive('root-raw.tar.gz',e)
for n in ('root-final-coverage-assessment.json','root-native-result.json','root-actual-cargo-bindings.json','root-build-boundary-reuse.json','root-linkage-audit.json','root-fast-regressions.json'):(dest/n).write_bytes((root/n).read_bytes())
(dest/'author-handoff.json').write_bytes((author/'final-evidence-manifest.json').read_bytes())
