from pathlib import Path
import json,hashlib,subprocess
out=Path('/tmp/dandrum-evidence/g3-lost-ack-native-fixture');author=Path('/tmp/dandrum-evidence/g3-lost-ack-second-instance');runtime=Path('/tmp/dandrum-lanes/runtime');root=Path('/tmp/dandrum-lanes/integration');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((author/'final-evidence-manifest.json').read_text());path='src/clap-adapter/tests/internal/trigger_structural_native.rs';expected='ef7ef8211b53bc386ec43ccc9d6be4e0035d93fe8120ab412f2affc145c95204';base='95d06dff1640206551413a8c736ef6580e81e8fc'
assert sha(runtime/path)==sha(author/'final-source.rs')==m['source_sha256_at_handoff']==expected
for p,h in m['evidence_logs'].items():assert sha(author/p)==h,p
for p in [m['llvm_attempt']['test_elf'],m['llvm_attempt']['normal_copied_dso'],*m['llvm_attempt']['profiles'],*m['llvm_attempt']['llvm_tools'].values()]:assert sha(Path(p['path']))==p['sha256'],p['path']
for p,h in m['copied_resources']['sha256'].items():assert sha(Path(m['copied_resources']['directory'])/p)==h,p
rows=[];cache=runtime/'cache-editor-guard'
for p in sorted(cache.rglob('*')):
 if p.is_symlink():rows.append(dict(path=str(p.relative_to(cache)),symlink=str(p.readlink())))
 elif p.is_file():rows.append(dict(path=str(p.relative_to(cache)),mode=p.stat().st_mode&0o777,size=p.stat().st_size,sha256=sha(p)))
assert rows==json.loads(Path('/tmp/dandrum-evidence/g3-two-publication/runtime-preserved-cache-baseline.json').read_text())
git=lambda p,*a:subprocess.check_output(['git',*a],cwd=p,text=True).strip()
for lane in (root,runtime):assert git(lane,'rev-parse','HEAD')==base and not git(lane,'diff','--cached','--name-only')
assert not git(root,'status','--porcelain')
status=subprocess.check_output(['git','status','--porcelain'],cwd=runtime,text=True)
assert {x[3:] for x in status.splitlines()}=={path,'cache-editor-guard/'},repr(status)
ps=subprocess.check_output(['ps','-eo','pid,ppid,pgid,comm,args'],text=True);active=[l for l in ps.splitlines() if l.split()[3] in ('cargo','rustc','cmake','ctest') or l.split()[3].startswith('trigger_paramet')];assert not active,active
files={str(p.relative_to(author)):dict(size=p.stat().st_size,sha256=sha(p)) for p in sorted(author.rglob('*')) if p.is_file()};(out/'author-file-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
backup=out/'integration-before'/path;backup.parent.mkdir(parents=True,exist_ok=True);assert not backup.exists();backup.write_bytes((root/path).read_bytes());assert sha(backup)==m['source_before_sha256'];(root/path).write_bytes((runtime/path).read_bytes());assert sha(root/path)==expected
r=dict(source_sha256={path:expected},author_manifest_sha256=sha(author/'final-evidence-manifest.json'),evidence_files=len(files),evidence_bytes=sum(v['size'] for v in files.values()),evidence_file_manifest_sha256=sha(out/'author-file-manifest.json'),cache_files_preserved=len(rows),actual_idle_builders=active,explicit_handback='Author explicitly released single source and both caches; root acknowledges sole ownership',coverage_status='Author exact run passed but report excludes test source; root will diagnose before coverage claim',admission_setup='First external preflight stripped porcelain leading space, rejected path-set comparison before integration; driver ownership guard prevented following native launch. Corrected by parsing raw porcelain. No source/cache changes occurred on rejected setup.')
(out/'author-release-admitted.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
