from pathlib import Path
import hashlib,json,os,subprocess,time,signal,shutil
out=Path('/tmp/dandrum-evidence/g3-lost-ack-native-fixture');prior=Path('/tmp/dandrum-evidence/g3-two-native-instances/final-test-instrument-binding.json');old=json.loads(prior.read_text());capture=old['capture'];root=Path('/tmp/dandrum-lanes/runtime');dest=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g3-lost-ack-root-final-test');dest.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(prior)==json.loads(Path('/tmp/dandrum-evidence/g3-two-native-fixture/author-file-manifest.json').read_text())['final-test-instrument-binding.json']
for arg,h in old['extern_sha256'].items():assert sha(arg.split('=',1)[1])==h,arg
assert sha(capture['command'][0])==old['compiler_sha256']
command=list(capture['command']);command[command.index('--out-dir')+1]=str(dest);command+=['-C','instrument-coverage']
env=dict(os.environ,**capture['environment']);env['TMPDIR']=str(out/'tmp');env['RUST_MIN_STACK']='16777216';Path(env['TMPDIR']).mkdir(exist_ok=True)
for k in ('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS','RUSTC_WRAPPER','LD_PRELOAD','LLVM_PROFILE_FILE'):env.pop(k,None)
def sources():return {str(p.relative_to(root)):sha(p) for p in sorted((root/'src/clap-adapter').rglob('*.rs'))}
def resource():return dict(disk_free_bytes=shutil.disk_usage('/tmp').free,mem_available_bytes=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024)
def sufficient(s):return s['disk_free_bytes']>1024**3 and s['mem_available_bytes']>4*1024**3
r=dict(command=command,cwd=capture['cwd'],compiler_sha256=sha(command[0]),source_sha256=sources(),extern_sha256=old['extern_sha256'],prior_binding_sha256=sha(prior),environment={k:env[k] for k in capture['environment'] if k in env},changes=['New exclusive LLVM output directory','instrument-coverage','compiler-only16MiB stack','physical task TMPDIR'],resource_before=resource());assert sufficient(r['resource_before']);start=time.monotonic();samples=[]
(out/'root-final-instrument-binding.json').write_text(json.dumps(r,indent=2)+'\n')
with (out/'root-final-instrument.stdout').open('wb') as a,(out/'root-final-instrument.stderr').open('wb') as b:
 child=subprocess.Popen(command,cwd=capture['cwd'],env=env,stdout=a,stderr=b,start_new_session=True)
 while child.poll() is None:
  s=resource();s['seconds']=time.monotonic()-start;samples.append(s)
  if not sufficient(s) or s['seconds']>600:
   os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=10);break
  time.sleep(.5)
r.update(exit=child.returncode,seconds=time.monotonic()-start,owned_pid_and_pgid=child.pid,resource_samples=samples,artifacts={str(p):sha(p) for p in dest.iterdir() if p.is_file()},source_after=sources());(out/'root-final-instrument-binding.json').write_text(json.dumps(r,indent=2)+'\n');assert r['exit']==0 and r['source_sha256']==r['source_after'];print(json.dumps({k:r[k] for k in ('exit','seconds','owned_pid_and_pgid','artifacts')}))
