from pathlib import Path
import hashlib,json,os,subprocess,signal,time,shutil
out=Path('/tmp/dandrum-evidence/g3-lost-ack-native-fixture');root=Path('/tmp/dandrum-lanes/runtime');bind=json.loads((out/'root-final-instrument-binding.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();elf=next(Path(p) for p in bind['artifacts'] if not p.endswith('.d'));assert sha(elf)==bind['artifacts'][str(elf)]
for p,h in bind['source_sha256'].items():assert sha(root/p)==h
fixture=out/'native-build/trigger-clap-parameters-fixture';plugin=fixture/'DandrumTrigger.clap';assert sha(plugin)=='e9200fbb0bdc714e6f6d3950aefea03b1025302a328374b31310a45e745b0741'
profiles=out/'root-final-profiles';profiles.mkdir(exist_ok=False);env=dict(os.environ,DISPLAY=':10.0',GDK_BACKEND='x11',XAUTHORITY='/home/dan/.Xauthority',TMPDIR=str(out/'tmp'),DANDRUM_TRIGGER_GUI_PLUGIN_PATH=str(plugin),LLVM_PROFILE_FILE=str(profiles/'%p-%m.profraw'))
for k in ('LD_PRELOAD','RUSTC_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUST_MIN_STACK'):env.pop(k,None)
cmd=[str(elf),'--ignored','--exact','structural_native::copied_native_mapping_survives_lost_reply_and_view_loss','--nocapture','--test-threads=1'];r=dict(command=cmd,cwd=str(root),environment={k:env[k] for k in ('DISPLAY','GDK_BACKEND','XAUTHORITY','TMPDIR','DANDRUM_TRIGGER_GUI_PLUGIN_PATH','LLVM_PROFILE_FILE')},test_elf_sha256=sha(elf),plugin_sha256=sha(plugin),source_sha256=bind['source_sha256'],resources={str(p.relative_to(fixture/'DandrumTrigger.resources')):sha(p) for p in sorted((fixture/'DandrumTrigger.resources').rglob('*')) if p.is_file()},source_binding_sha256=sha(out/'root-final-instrument-binding.json'))
start=time.monotonic();samples=[];stopped=None
with (out/'root-final-native.stdout').open('wb') as a,(out/'root-final-native.stderr').open('wb') as b:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=a,stderr=b,start_new_session=True)
 while p.poll() is None:
  s=dict(seconds=time.monotonic()-start,disk_free_bytes=shutil.disk_usage('/tmp').free,mem_available_bytes=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024);samples.append(s)
  if s['seconds']>60 or s['disk_free_bytes']<1024**3 or s['mem_available_bytes']<4*1024**3:
   stopped='bound exceeded';os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10);break
  time.sleep(.1)
r.update(exit=p.returncode,seconds=time.monotonic()-start,owned_actual_pid_and_pgid=p.pid,resource_samples=samples,stop_reason=stopped,profiles={str(p):dict(sha256=sha(p),size=p.stat().st_size) for p in sorted(profiles.glob('*.profraw'))});(out/'root-final-native-binding.json').write_text(json.dumps(r,indent=2)+'\n');assert r['exit']==0 and not stopped
text=(out/'root-final-native.stdout').read_text();assert '1 passed; 0 failed' in text and 'running 1 test' in text
for p,h in bind['source_sha256'].items():assert sha(root/p)==h
print(json.dumps({k:r[k] for k in ('exit','seconds','owned_actual_pid_and_pgid','profiles')}))
