from pathlib import Path
import sys,tarfile,json,hashlib
out=Path(__file__).parent;cache=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov');label=sys.argv[1];archive=out/(label+'-raw-profiles.tar.gz');index=out/(label+'-raw-profiles-index.json');assert not archive.exists() and not index.exists();rows=[]
with tarfile.open(archive,'w:gz') as t:
 for p in sorted([*cache.rglob('*.profraw'),*cache.rglob('*.profdata')]):
  assert p.is_file() and not p.is_symlink();name=str(p.relative_to(cache));rows.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});t.add(p,arcname=name,recursive=False)
index.write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':rows},indent=2)+'\n');print('Preserved profiles:',label,len(rows))
