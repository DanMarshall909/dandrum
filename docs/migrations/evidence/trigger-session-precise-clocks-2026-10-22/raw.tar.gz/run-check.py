"""One-off recorded checks over one owned run and an existing physical target."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time,tarfile
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent
phase,mode=sys.argv[1:3];argv=sys.argv[3:];assert mode in ('ordinary','coverage');assert argv
run=out/(phase+'-run');receipt=out/(phase+'.json');assert not run.exists() and not receipt.exists()
cache=Path('/tmp/dandrum-lanes/cache-runtime' if mode=='ordinary' else '/tmp/dandrum-lanes/cache-host-snapshot-cov');assert cache.resolve().stat().st_dev==out.stat().st_dev
assert not cache.resolve().is_relative_to(Path('/dev/shm'))
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_TARGET_DIR=str(cache),CARGO_BUILD_JOBS='1')
if mode=='coverage':env.update(CARGO_LLVM_COV_TARGET_DIR=str(cache),CARGO_LLVM_COV_BUILD_DIR=str(cache))
start=time.monotonic()
def resources():
 fs=os.statvfs(out);mem=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 return {'seconds':time.monotonic()-start,'disk_free_bytes':fs.f_bavail*fs.f_frsize,'mem_available_bytes':mem}
def low(x):return min(x['disk_free_bytes'],x['mem_available_bytes'])<8*1024**3
samples=[resources()];assert not low(samples[0]),'8GiB disk/RAM admission floor; preserve reusable caches'
sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'src').rglob('*.rs')}
snapshot=out/(phase+'-source.tar.gz')
with tarfile.open(snapshot,'w:gz') as archive:
 for name in sorted(sources):archive.add(root/name,arcname=name,recursive=False)
 for name in ('src/rust-engine/Cargo.toml','src/rust-engine/Cargo.lock'):archive.add(root/name,arcname=name,recursive=False)
cmd=['python3','-B',str(root/'scripts/run-owned-verification.py'),'run','--directory',str(run),'--',*argv];stopped=None
with (out/(phase+'-controller.log')).open('wb') as output:
 process=subprocess.Popen(cmd,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 while process.poll() is None:
  sample=resources();samples.append(sample)
  if low(sample):
   stopped='Resource floor reached; cancel exact supervisor and retain caches';process.send_signal(signal.SIGINT);break
  time.sleep(1)
 code=process.wait(timeout=30) if stopped else process.wait()
for name,digest in sources.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,'Source changed during recorded check'
record={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'command':cmd,'cwd':str(root),'exit':code,'seconds':time.monotonic()-start,'target':str(cache),'source_sha256':sources,'resource_samples':samples,'stopped':stopped,'stdout_sha256':hashlib.sha256((run/'stdout.log').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((run/'stderr.log').read_bytes()).hexdigest(),'cleanup':json.loads((run/'cleanup.json').read_text()) if (run/'cleanup.json').is_file() else None}
receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ('source_sha256','resource_samples','cleanup')}),flush=True)
if stopped:sys.exit(75)
sys.exit(code if code>=0 else 128-code)
