from pathlib import Path
import subprocess,re,time,json,hashlib,statistics
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;binary=Path('/tmp/dandrum-lanes/cache-runtime/debug/deps/precise_clocks-40f6bb8001338b64');names=re.findall(r'#\[test\]\nfn (\w+)\(', (root/'src/instrument-session/tests/precise_clocks.rs').read_text());rows=[]
for repeat in range(2):
 for name in names:
  argv=[str(binary),'--exact',name,'--test-threads=1'];start=time.monotonic();p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);elapsed=time.monotonic()-start;assert p.returncode==0 and b'1 passed;' in p.stdout,(name,p.stdout);rows.append({'repeat':repeat,'name':name,'command':argv,'seconds':elapsed,'exit':p.returncode,'output':p.stdout.decode()})
report={'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'attempts':rows,'median_seconds':{name:statistics.median(r['seconds'] for r in rows if r['name']==name) for name in names},'lane':'Fast, slow selection empty for these three new cases. Full owner/native/DAW checkpoints remain separate.'};(out/'new-test-timings.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'binary_sha256':report['binary_sha256'],'median_seconds':report['median_seconds']}))
