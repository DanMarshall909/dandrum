from pathlib import Path
import subprocess,json,hashlib,tarfile,stat
root=Path('/tmp/dandrum-lanes/integration');out=Path(__file__).parent;base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert base=='35137fa64659eed41fcf4e53c746fb9b09a0c4c0';sha=lambda b:hashlib.sha256(b).hexdigest();blobs=out/'source-blobs';blobs.mkdir(exist_ok=True);cache={};phases=[]
for archive in sorted(out.glob('*-source.tar.gz')):
 rows=[]
 with tarfile.open(archive) as t:
  for member in t:
   assert member.isfile();data=t.extractfile(member).read();digest=sha(data);path=member.name
   if path not in cache:
    p=subprocess.run(['git','show',base+':'+path],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL);cache[path]=sha(p.stdout) if p.returncode==0 else None
   row={'path':path,'sha256':digest}
   if cache[path]==digest:row['source']='base'
   else:
    row['source']='blob';p=blobs/digest
    if p.exists():assert p.read_bytes()==data
    else:p.write_bytes(data)
   rows.append(row)
 phases.append({'snapshot':archive.name,'snapshot_sha256':sha(archive.read_bytes()),'files':rows})
(out/'portable-source-replay.json').write_text(json.dumps({'base':base,'phases':phases,'recipe':'Use git base contents for source=base and source-blobs/<sha256> for source=blob. Verify every reconstructed file hash. Snapshots contain Rust sources plus engine Cargo metadata, no build target.'},indent=2)+'\n')
packet=root/'docs/migrations/evidence/trigger-session-precise-clocks-2026-10-22';packet.mkdir(exist_ok=True);members=[]
with tarfile.open(packet/'raw.tar.gz','w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_dir():continue
  assert stat.S_ISREG(p.lstat().st_mode),str(p)
  if p.name.endswith('-source.tar.gz'):continue
  rel=str(p.relative_to(out));data=p.read_bytes();members.append({'path':rel,'bytes':len(data),'sha256':sha(data)});t.add(p,arcname=rel,recursive=False)
with tarfile.open(packet/'raw.tar.gz') as t:
 actual={m.name:m for m in t};assert set(actual)=={r['path'] for r in members}
 for r in members:
  data=t.extractfile(actual[r['path']]).read();assert len(data)==r['bytes'] and sha(data)==r['sha256']
(packet/'raw-index.json').write_text(json.dumps({'archive_sha256':sha((packet/'raw.tar.gz').read_bytes()),'members':members},indent=2)+'\n')
paths=['src/instrument-session/src/lib.rs','src/instrument-session/tests/precise_clocks.rs','src/rust-engine/src/preparation.rs','src/rust-engine/src/kernel/document/tests.rs']
binding={'base':base,'scope':'Precise persistent-session/planar preparation foundation supporting tasks2.1/2.2; both remain unchecked. No fractional TriggerHost/controller/CLAP acceptance or runtime handoff/native/DAW/release completion claim.','sources':{p:sha((root/p).read_bytes()) for p in paths},'checks':{'session':'36 tests pass; strict warnings-denied Clippy PASS.','engine':'1090 unit + maintained integration/doc targets pass (1097 positive cases total). Strict Clippy FAIL129 baseline library diagnostics; complete diagnostics reconciled in clippy-assessment.json, seven bin messages duplicated under --all-targets, no new identities.','host':'159 tests including compile-fail docs pass; strict warnings-denied Clippy PASS.','coverage':'New planar path and session behavior measured separately. All49 annotated added production lines execute; sessionlib69/69functions702/706lines856/863regions. No branch/full callback/concurrency claim; native FFI old gaps retained.','specs':'Selected/all52strict and631scenario/392mapped/239backlog map pass unchanged.','official_CLAP_validator':'Existing33success/10skip/1FAIL1234.5678Hz unchanged and unwaived.','mutation':'Excluded, no job.'},'tdd_limits':'New constructor/planar/reconfiguration API absence is retained compiler contract evidence, not executed behavioral RED. Initial wrong test-only import is setup failure. Zero/BUSY case characterizes retained rejection policy. All test/source preimages and numerical GREEN assertions are retained.','source_replay':'portable-source-replay.json + base + content-addressed blobs; complete raw source snapshots remain external.','refactor':'Common realtime settings own session/candidates/jobs; thin integer adapters preserve legacy inputs/C ABI. Covered fixture extracted in same test file. No new dependencies/module/framework.'}
(packet/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
(packet/'README.md').write_text('''# Precise clocks in persistent sessions

This is a supporting material boundary within beta tasks 2.1/2.2; both remain open. The first beta is CLAP-only. No TriggerHost fractional handoff, controller/CLAP activation, official-validator fix, native/DAW acceptance or release completion is claimed.

The engine now offers precise planar preparation using its existing common validated configuration. The session stores that same configuration in accepted settings, render candidates and owned mapping jobs. Integer constructors, reconfiguration and C ABI remain input adapters. New precise session construction/reconfiguration delegates to the existing preparation and atomic publication machinery; no optional competing clock is introduced.

Three new fast cases use a real negative PCM16 ramp and independently derived complete waveform/cutoff at 1234.5678, 48000.5 and 48000.000001 Hz. They prove detached cross-thread mapping jobs, native undo, precise reconfiguration with retained history, failed activation rollback and a separate session, and preserved zero-rate/BUSY rejection with later usable publication. The extended engine table renders all three sample owners through both preparation APIs. The session publication stand-ins exercise domain acceptance/rejection only; concrete runtime callback/reclamation and CLAP behavior remain separate required proof.

New API absence is compiler contract evidence, not executed numerical RED. A corrected test-only import setup failure is retained separately. The zero/BUSY test characterizes preserved behavior. Full source preimages, raw commands/results, timing, coverage and resource/cleanup receipts are portable through the source replay index and content-addressed blobs.

All 36 session tests, 1090 engine unit tests plus integration/doc targets (1097 positive cases), and 159 host tests pass. Session and host strict Clippy pass. Engine strict Clippy still FAILS with 129 baseline library diagnostics. Its complete library/test diagnostic identities are unchanged; the all-targets run emits seven unchanged stepseq warnings twice, versus once in the previous lib/tests selection. No lint is suppressed. The official CLAP result remains 33 successes / 10 skips / 1 FAIL at 1234.5678 Hz, unwaived.

Separate current-source LLVM reports execute all 49 annotated added production lines. Session lib measures 69/69 functions, 702/706 lines and 856/863 regions; older aggregate/native-FFI gaps are not hidden and no branch or full-callback claim is made. Comparable medians for the three new cases are 0.026–0.065 seconds, all fast. The covered WAV/session fixture was extracted within the same test file; the common settings owner and thin legacy adapters need no wider refactor.

Selected and all 52 canonical OpenSpec validations pass; the map remains 631 scenarios / 392 mapped / 239 backlog. No task/scenario is prematurely closed. Builds use existing disk-backed targets with one heavy job and 8 GiB disk/MemAvailable guards. Owned scratch is cleaned after verified worker closure; reusable targets, raw profiles and evidence remain. Mutation is excluded. Independent review and normal-hook publication are subsequent exact-candidate gates.
''')
print(json.dumps({'packet':str(packet),'members':len(members),'bytes':(packet/'raw.tar.gz').stat().st_size,'source_phases':len(phases),'source_blobs':len(list(blobs.iterdir()))}))
