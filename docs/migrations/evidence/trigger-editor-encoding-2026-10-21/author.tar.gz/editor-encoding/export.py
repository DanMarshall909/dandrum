import sys,pathlib,json,hashlib,subprocess,tarfile,re,shlex,shutil
base=pathlib.Path('/tmp/dandrum-lanes/evidence-editor-encoding'); phase=base/sys.argv[1]; receipt=json.loads((phase/'receipt.json').read_text()); assert receipt['exit']==0
llvm=pathlib.Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin')
log=(phase/'stderr.log').read_text(); exes=[]
for line in log.splitlines():
 m=re.match(r'\s+Running `(/tmp/dandrum-lanes/cache-host-snapshot-cov/debug/deps/[^` ]+)',line)
 if m:exes.append(pathlib.Path(m[1]))
raws=[pathlib.Path(p) for p in receipt['new_profiles']];assert len(exes)==len(raws),(exes,raws)
def identity(p):
 s=p.stat();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=s.st_size,mode=oct(s.st_mode),mtime_ns=s.st_mtime_ns)
binaries=[]
for p in exes:
 r=subprocess.run(['readelf','-n',str(p)],check=True,capture_output=True); build=re.findall(r'Build ID: (\w+)',r.stdout.decode()); assert len(build)==1
 binaries.append(dict(**identity(p),elf_build_id=build[0]))
profiles=[identity(p) for p in raws]
with tarfile.open(phase/'raw-profiles.tar.gz','w:gz') as tf:
 for p in raws:tf.add(p,arcname=p.name)
merge=[str(llvm/'llvm-profdata'),'merge','-sparse',*[str(p) for p in raws],'-o',str(phase/'exact.profdata')]
r=subprocess.run(merge,capture_output=True);(phase/'merge.stderr').write_bytes(r.stderr);assert r.returncode==0
cmd=[str(llvm/'llvm-cov'),'export','-format=text','-instr-profile='+str(phase/'exact.profdata')]
for p in exes:cmd+=['-object',str(p)]
r=subprocess.run(cmd,capture_output=True);(phase/'exact-export.json').write_bytes(r.stdout);(phase/'export.stderr').write_bytes(r.stderr);assert r.returncode==0
proof=dict(actual_executed_binaries=binaries,raw_profiles=profiles,merge_command=merge,export_command=cmd,source_hashes=receipt['source_hashes'],aggregate_report='NOT evidence: --no-clean includes retained profiles and unexecuted binaries; exact-export uses only this run',exact_profdata=identity(phase/'exact.profdata'))
(phase/'binding.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'binaries':len(exes),'profiles':len(raws),'export_stderr':r.stderr.decode()}))
