import pathlib,subprocess,sys,os,json,hashlib,shlex,re,time,shutil,signal
base=pathlib.Path('/tmp/dandrum-evidence/automation-pending-iterator');root=pathlib.Path('/tmp/dandrum-lanes/runtime');crate=root/'src/trigger-host';out=base/'direct-output';out.mkdir(exist_ok=True)
phase=base/sys.argv[1];phase.mkdir();kind=sys.argv[2];name=sys.argv[3] if len(sys.argv)>3 else 'parameters'
rustc='/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc';log=pathlib.Path('/tmp/dandrum-lanes/evidence-editor-encoding/00-baseline-cov-supported/stderr.log').read_text()
def original(crate_name):
 for line in log.splitlines():
  if 'rustc --crate-name '+crate_name+' ' in line:return shlex.split(line.split('`',1)[1].rsplit('`',1)[0])[1:]
 raise Exception(crate_name)
def args_for(lib=False,metadata=False):
 args=original('dandrum_trigger_host' if lib else 'parameters')[1:];new=[];i=0
 while i<len(args):
  a=args[i]
  if a=='--out-dir':i+=2;continue
  if a=='-C' and (args[i+1].startswith('incremental=') or (not lib and args[i+1].startswith('extra-filename='))):i+=2;continue
  if a=='--extern' and args[i+1].startswith('dandrum_trigger_host=') and kind!='red':new+=['--extern','dandrum_trigger_host='+str(out/'libdandrum_trigger_host-58f679460fc00ba1.rlib')];i+=2;continue
  if not lib and a=='parameters':a=name
  if not lib and a=='tests/parameters.rs':a='tests/'+name+'.rs'
  if metadata and a.startswith('--emit='):a='--emit=metadata'
  new.append(a);i+=1
 if lib:new+=['--out-dir',str(out)]
 else:new+=['-o',str(out/('scratch.rmeta' if metadata else 'scratch-test'))]
 return new
if kind in ['red','test-compile']:cmd=[rustc,*args_for()]
elif kind in ['lib','lib-cov']:cmd=[rustc,*args_for(True)]+(['-C','instrument-coverage','--cfg=coverage'] if kind=='lib-cov' else [])
elif kind=='test-cov-compile':
 cmd=[rustc,*args_for()];cmd[cmd.index('-o')+1]=str(out/'parameters-final');cmd+=['-C','instrument-coverage','--cfg=coverage']
elif kind=='clippy-lib':cmd=[str(pathlib.Path(rustc).with_name('clippy-driver')),*args_for(True,True),'-D','warnings']
elif kind=='clippy-test':cmd=[str(pathlib.Path(rustc).with_name('clippy-driver')),*args_for(False,True),'-D','warnings']
elif kind=='run':cmd=[str(out/'scratch-test'),*sys.argv[3:]]
elif kind=='run-cov':cmd=[str(out/'parameters-final'),*sys.argv[3:]]
else:raise Exception(kind)
env=os.environ.copy()
for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LLVM_PROFILE_FILE']:env.pop(k,None)
env.update(CARGO_MANIFEST_DIR=str(crate),CARGO_PKG_NAME='dandrum-trigger-host',CARGO_PKG_VERSION='0.1.0',CARGO_PKG_VERSION_MAJOR='0',CARGO_PKG_VERSION_MINOR='1',CARGO_PKG_VERSION_PATCH='0',CARGO_PKG_VERSION_PRE='',CARGO_CRATE_NAME=name,TMPDIR=str(base/'tmp'),PATH='/home/dan/.cargo/bin:/usr/bin:/bin')
if kind=='run-cov':env['LLVM_PROFILE_FILE']=str(phase/'iterator-%p-%m.profraw')
def identity(p):
 p=pathlib.Path(p);return {'path':str(p),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
inputs=[identity(a.split('=',1)[1]) for a in cmd if re.match(r'\w+=/tmp/dandrum-lanes/.+\.(rlib|rmeta)$',a)]
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for d in ['src/trigger-host','src/instrument-session','src/rust-engine'] for p in (root/d).rglob('*') if p.is_file() and 'target' not in p.parts and p.suffix in ['.rs','.toml','.lock']}
for n in ['src/trigger-host/src/parameters.rs','src/trigger-host/tests/parameters.rs']:
 dest=phase/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/n,dest)
def sample():
 m={s.split(':')[0]:int(s.split()[1])*1024 for s in pathlib.Path('/proc/meminfo').read_text().splitlines()};return {'disk':shutil.disk_usage('/tmp').free,'memory':m['MemAvailable']}
def low(s):return s['disk']<1024**3 or s['memory']<4*1024**3
samples=[sample()];assert not low(samples[0]);start=time.monotonic();stop=None
with (phase/'stdout.log').open('w') as stdout,(phase/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(cmd,cwd=crate,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 while p.poll() is None:
  time.sleep(.25);s=sample();samples.append(s)
  if low(s):
   stop='original resource floor';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
r={'command':cmd,'cwd':str(crate),'exit':p.returncode,'duration_seconds':time.monotonic()-start,'pid_and_pgid':p.pid,'stop_reason':stop,'resource_min':{k:min(x[k] for x in samples) for k in samples[0]},'input_artifacts':inputs,'source_hashes':hashes,'environment':{k:env[k] for k in ['CARGO_MANIFEST_DIR','CARGO_PKG_VERSION','TMPDIR']},'adaptations':'Retained direct debug2/unoptimized compiler args/dependencies; no Cargo dependency rebuild or shared incremental writes; task-owned output only. Coverage injection explicit when selected.'}
if kind=='run-cov':r['environment']['LLVM_PROFILE_FILE']=env['LLVM_PROFILE_FILE']
r['outputs']=[identity(f) for f in out.iterdir() if f.is_file()]
(phase/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['exit','duration_seconds','resource_min','stop_reason']}));print((phase/'stdout.log').read_text()[-1500:]);print((phase/'stderr.log').read_text()[-2500:]);sys.exit(p.returncode)
