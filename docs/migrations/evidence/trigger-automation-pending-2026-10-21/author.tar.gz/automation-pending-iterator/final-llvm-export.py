from pathlib import Path
import json,hashlib,subprocess,re,gzip
base=Path('/tmp/dandrum-evidence/automation-pending-iterator');p=base/'16-refactor-llvm-parameter-tests';llvm=Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin');exe=base/'direct-output/parameters-final';rlib=base/'direct-output/libdandrum_trigger_host-58f679460fc00ba1.rlib';raws=list(p.glob('*.profraw'));assert len(raws)==1
receipt=json.loads((p/'receipt.json').read_text());assert receipt['exit']==0 and receipt['command']==[str(exe)]
def identity(f):return {'path':str(f),'size':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
merge=[str(llvm/'llvm-profdata'),'merge','-sparse',*[str(x) for x in raws],'-o',str(p/'exact.profdata')];r=subprocess.run(merge,capture_output=True);(p/'merge.stderr').write_bytes(r.stderr);assert r.returncode==0
cmd=[str(llvm/'llvm-cov'),'export','-format=text','-instr-profile='+str(p/'exact.profdata'),'-object',str(exe)];r=subprocess.run(cmd,capture_output=True);(p/'export.stderr').write_bytes(r.stderr);assert r.returncode==0
with gzip.open(p/'exact-export.json.gz','wb') as out:out.write(r.stdout)
report=json.loads(r.stdout);fs=[f for d in report['data'] for f in d['functions'] if 'pending_automation' in f['name']];print(json.dumps({'exported_functions':len(fs),'source_method_counts':[f['count'] for f in fs if any(n.endswith('/src/trigger-host/src/parameters.rs') for n in f['filenames'])]}))
notes=subprocess.check_output(['readelf','-n',str(exe)],text=True)
bind={'actual_executed_elf':{**identity(exe),'elf_build_id':re.findall(r'Build ID: (\w+)',notes)},'instrumented_owner_rlib':identity(rlib),'raw_profiles':[identity(f) for f in raws],'merged_profile':identity(p/'exact.profdata'),'full_raw_export':identity(p/'exact-export.json.gz'),'merge_command':merge,'export_command':cmd,'source_hashes':receipt['source_hashes'],'no_old_profiles':True,'no_exclusions':True,'scope':'Exact one new profile from the actually executed current parameters ELF,16 public parameter tests; all LLVM-exported objects/files/functions retained without denominator exclusions.'}
(p/'binding.json').write_text(json.dumps(bind,indent=2)+'\n')
