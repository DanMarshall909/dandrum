import os,sys,subprocess,time,json,pathlib,hashlib,signal,shutil
root=pathlib.Path('/tmp/dandrum-lanes/runtime'); evidence=pathlib.Path('/tmp/dandrum-evidence/automation-pending-iterator'); phase=sys.argv[1]; cmd=sys.argv[2:]; dest=evidence/phase; dest.mkdir()
cov='llvm-cov' in cmd; ordinary='/tmp/dandrum-lanes/cache-host-snapshot-cov'; coverage='/tmp/dandrum-lanes/cache-host-snapshot-cov'
env=os.environ.copy(); env.update(PATH='/home/dan/.cargo/bin:/home/dan/.local/bin:/usr/bin:/bin',CARGO_TARGET_DIR=coverage if cov else ordinary,CARGO_LLVM_COV_TARGET_DIR=coverage,CARGO_LLVM_COV_BUILD_DIR=coverage,CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',TMPDIR=str(evidence/'tmp'))
paths=[p for d in ['src/trigger-host','src/instrument-session','src/rust-engine'] for p in (root/d).rglob('*') if p.is_file() and ('target' not in p.parts) and p.suffix in ('.rs','.toml','.lock')]
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
for name in ['src/trigger-host/src/parameters.rs','src/trigger-host/tests/parameters.rs']:
 p=root/name
 if p.exists():
  saved=dest/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,saved)
def sample():
 m={s.split(':')[0]:int(s.split()[1])*1024 for s in pathlib.Path('/proc/meminfo').read_text().splitlines()};return dict(disk=shutil.disk_usage('/tmp').free,memory=m['MemAvailable'])
def low(s):return s['disk']<1024**3 or s['memory']<4*1024**3
before_profiles={str(p):(p.stat().st_mtime_ns,p.stat().st_size) for p in pathlib.Path(coverage).rglob('*.profraw')} if cov else {}
start=time.monotonic(); samples=[sample()];assert not low(samples[0]),samples[0]
assert all(not pathlib.Path(env[k]).resolve().is_relative_to('/dev/shm') for k in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','TMPDIR'))
with (dest/'stdout.log').open('w') as out,(dest/'stderr.log').open('w') as err:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=err,start_new_session=True); reason=None
 while p.poll() is None:
  time.sleep(.5);s=sample();samples.append(s)
  if low(s):
   reason='fixed resource floor';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
receipt=dict(command=cmd,cargo_executable='/home/dan/.cargo/bin/cargo',cargo_rustup_dispatch_realpath=str(pathlib.Path('/home/dan/.cargo/bin/cargo').resolve()),cargo_actual_toolchain_path=subprocess.check_output(['/home/dan/.cargo/bin/rustup','which','cargo'],text=True).strip(),cwd=str(root),environment={k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','TMPDIR')},exit=p.returncode,duration_seconds=time.monotonic()-start,pid_and_pgid=p.pid,source_hashes=hashes,resource_min={k:min(s[k] for s in samples) for k in samples[0]},stop_reason=reason,ramfs='UNUSED_OUTPUT_VOLUME')
if cov:
 receipt['modified_existing_profiles']=[str(p) for p in pathlib.Path(coverage).rglob('*.profraw') if str(p) in before_profiles and before_profiles[str(p)] != (p.stat().st_mtime_ns,p.stat().st_size)]
 receipt['new_profiles']=[str(p) for p in pathlib.Path(coverage).rglob('*.profraw') if before_profiles.get(str(p)) != (p.stat().st_mtime_ns,p.stat().st_size)]
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ('exit','duration_seconds','resource_min','stop_reason')}));print((dest/'stderr.log').read_text()[-1800:]);print((dest/'stdout.log').read_text()[-1800:]);sys.exit(p.returncode)
