from pathlib import Path
import json,hashlib,gzip,re,shutil,subprocess,difflib,tarfile,os
base=Path('/tmp/dandrum-evidence/automation-pending-iterator');root=Path('/tmp/dandrum-lanes/runtime');owner='src/trigger-host/src/parameters.rs';tests='src/trigger-host/tests/parameters.rs';cov=base/'10-llvm-parameter-tests'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
freeze={n:sha(root/n) for n in [owner,tests]}
prior=json.loads((base/'prior-coverage-source-comparison.json').read_text());assert prior['identical_count']==124 and not prior['different'] and not prior['missing']
receipts={d.parent.name:json.loads(d.read_text()) for d in base.glob('*/receipt.json')}
for name in ['02-owner-green-compile','03-test-green-compile','04-focused-green','05-fmt-check','06-clippy','07-full-host-tests','08-llvm-owner-compile','09-llvm-tests-compile','10-llvm-parameter-tests']:
 r=receipts[name];assert r['exit']==0 and not r['stop_reason'];assert all(r['source_hashes'][n]==v for n,v in freeze.items())
red=[]
for line in (base/'01-interface-red/stderr.log').read_text().splitlines():
 x=json.loads(line)
 if x.get('code',{}):
  if x['code']['code']=='E0599':red.append(x)
assert len(red)==7 and all('no method named `pending_automation`' in x['message'] for x in red)
report=json.load(gzip.open(cov/'exact-export.json.gz','rt'));fs=[f for d in report['data'] for f in d['functions'] if 'pending_automation' in f['name'] and any(n.endswith('/'+owner) for n in f['filenames'])];assert len(fs)==1 and fs[0]['count']==7
regions=[r for r in fs[0]['regions'] if r[7]==0];assert len(regions)==5 and all(r[4]>0 for r in regions)
assert not (cov/'merge.stderr').read_bytes() and not (cov/'export.stderr').read_bytes()
current_cov=receipts['10-llvm-parameter-tests']['source_hashes'];old=json.loads(Path('/tmp/dandrum-lanes/evidence-editor-encoding/04-full-host-cov/receipt.json').read_text())['source_hashes'];changed=[n for n,v in old.items() if current_cov[n]!=v];assert set(changed)=={owner,tests}
for n in [owner,tests]:
 dest=base/'source-final'/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/n,dest)
 before=(base/'00-baseline-coverage'/n).read_text().splitlines(keepends=True);after=(root/n).read_text().splitlines(keepends=True)
 with (base/'source-change.patch').open('a') as f:f.writelines(difflib.unified_diff(before,after,fromfile='a/'+n,tofile='b/'+n))
production={f['filename']:f['summary'] for d in report['data'] for f in d['files'] if '/src/trigger-host/src/' in f['filename']}
phase_results={n:{k:r[k] for k in ['exit','duration_seconds','resource_min','stop_reason']} for n,r in receipts.items()}
qualification={'criterion':'Read-only borrowed automation stream preserves FIFO event identity/physical values, queued capacity and explicit host-acceptance acknowledgement boundary.','supplied_base':'68668a3ffc1a6a65eebc359a66b577f3ee9c4fdb','changed_path_hashes':freeze,'all_relevant_source_hashes':current_cov,'only_changed_relevant_paths':changed,'baseline':'Prior editor-encoding04-full-host-cov exact receipt: all124 source/manifest/lock hashes identical before source edits; accepted by root. Fresh baseline rerun was a guarded resource/setup stop, not evidence.','red':{'kind':'Expected absent-interface compiler RED; no assertion RED claimed','e0599_diagnostics':7,'warning':'Separate harmless explicit -o/multiple-output adaptation warning; normal strict Cargo Clippy clean.'},'green':{'focused':1,'normal_host_total':154,'normal_host_unit_integration':152,'normal_host_compile_fail_docs':2,'normal_host_cargo_reported_test_elfs':14,'llvm_parameter_tests':16},'coverage':{'changed_method':fs[0],'normal_regions_executed':5,'normal_regions_total':5,'invocations':7,'raw_profile_count':1,'actual_elf_count':1,'production_owner_summaries':production,'gap_label':'Existing unexecuted source is visible and outside these16 parameter tests; no reachability, deletion, exclusion, whole-owner100%, branch orMC/DC claim. Full export retained without denominator exclusions.'},'phases':phase_results,'refactor':{'production':'No extraction/change: iter().copied() is the smallest borrowing adapter over the sole ledger; no new module.','tests':'Existing package/request and independent manual peek-ack helpers retained. One public scenario owns empty/repeated/partial/ordered/allocation/capacity/acknowledgement/append+reserved-End behavior; no broader helper or adjacent-test rewrites warranted.'},'timings':'Focused libtest0.04s; full Cargo154 tests22.12s including compilation; LLVM16 tests0.17s. Stable default libtest gives suite durations, not trustworthy per-test setup/timing; no lane membership changed.','limits':['Mutation explicitly excluded; none run.','No adapterG2, browser/native/GUI/service/heartbeat/mapping-worker integration, release or full-beta completion claimed.','No spec/task/tracker/Git/index edits; root owns review and publication.','Direct compiler output-name adaptation warning is harness-only and separately recorded.','Initial resource stop preserved all caches; later disk headroom recovery was external, no deletion authority inferred.']}
(base/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
proc=[]
for d in Path('/proc').iterdir():
 if not d.name.isdigit():continue
 try:
  c=(d/'comm').read_text().strip()
  if c in ['cargo','rustc','cargo-llvm-cov','clippy-driver','rustdoc','llvm-cov','llvm-profdata']:proc.append({'pid':int(d.name),'comm':c})
 except OSError:pass
assert not proc,proc
mem={l.split(':')[0]:int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines()};terminal={'status':'verified narrow prerequisite ready for root review, not publication/completion','source_hashes':freeze,'build_processes':proc,'all_known_execution_sessions_terminal':True,'cache_loans':'Explicitly returned idle to root: cache-runtime and cache-host-snapshot-cov; no further author tests/builds after handback.','caches_preserved':True,'owned_disposable_cleanup':'Only direct-output/scratch-test removed; exact receipt retained. Final instrumented parameters ELF+owner rlib retained outside portable packet for review.','disk_free_bytes':shutil.disk_usage('/tmp').free,'mem_available_bytes':mem['MemAvailable'],'mutation':'Excluded, not run'}
(base/'terminal-handback.json').write_text(json.dumps(terminal,indent=2)+'\n')
(base/'FINAL_HANDOFF.md').write_text('''Implemented only the accepted narrow pending_automation prerequisite in Runtime. The five-line public method borrows the existing ledger and yields copied AutomationEvent values with impl Iterator<Item=AutomationEvent> + '_; no allocation, owned ledger, removal, acknowledgement or new storage. Only src/trigger-host/src/parameters.rs and src/trigger-host/tests/parameters.rs changed. Supplied base68668a3f; root owns Git/status/review/commit/publication.

TDD: accepted prior exact baseline matched all124 relevant source/manifest/lock hashes. One packaged public-controller scenario was added first; compilerRED has seven E0599 missing-method errors, distinct from the harness-only output-name warning. Minimal method then passed the exact test. The test checks empty and multi-event/multi-parameter order with independently chosen physical1.5/-0.5/+0.5 values; partial/repeated reads; zero iteration allocations; pressure while an End is reserved and when ledger fully populated; explicit one-head acknowledgement/suffix; subsequent admitted Value and reserved End; and the existing independent manual peek/ack drain. Existing adjacent tests were not rewritten.

Normal Cargo fmt and strict all-target Clippy pass; normal Cargo host suite154PASS=152 unit/integration+2 compile-fail doctests. Fourteen actual compiler-artifact test ELFs are hash/build-ID bound in07-full-host-tests/executed-artifact-bindings.json. Full normal signed-audio regressions retained. Direct current LLVM16 parameter tests pass using one fresh profile and exactly the executed current parameter ELF: pending_automation7 invocations,5/5 normal method regions execute. Full raw export and explicit existing owner gaps remain visible; parameters.rs284/924 lines in this focused selection. No exclusions, whole-owner100%, branch/MC-DC or assertion-strength-from-coverage claim.

Refactor checkpoint: production is already the minimal borrowing adapter; no extraction/module. Existing public package/request/manual peek-ack helpers keep the single scenario readable and preserve independent oracles; no further test refactor warranted. Mutation excluded by user. Task3.2/3.3/4.2 and the full beta remain open; no adapter/services/native/release/readiness or publication claim.

Initial baseline LLVM attempt stopped only its owned group at the disk floor before source edits; zero-group audit and raw setup failure preserved. Later resources improved externally; no cache deletion or lower floor/profile was inferred. Final normal gates use the existing coverage target with ordinary flags, serial jobs1. Direct LLVM preserves original debug2/unoptimized flags, redirects only task-owned outputs and omits shared incremental writes. Actual argv/dependency/tool/source/binary hashes and source chronology retained. One explicitly disposable scratch ELF was removed; all reusable caches preserved. Both cache loans returned idle to root; no author tests/builds after terminal handback.

Read qualification.json, source-change.patch, source-final/ and terminal-handback.json first. Full raw logs/profiles/exact export are retained; portable packet excludes ELFs/rlibs/cache copies and duplicate identical final source snapshots. Instrumented final parameters ELF+owner rlib remain at direct-output/ with exact binding hashes for root review. Existing initial HANDOFF.md/terminal-pause.json describe the historical resource pause only; FINAL_HANDOFF.md and terminal-handback.json are current.
''')
# Curate a compact portable record: retain RED and baseline source chronology,
# one final pair, actual receipts/logs/tools/LLVM; no duplicate byte-identical snapshots/ELFs.
selected=[]
for f in base.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(base)
 if rel.parts[0] in ['direct-output','tmp']:continue
 if f.name in ['portable.tar.gz','final-portable.tar.gz','manifest.json','portable-manifest.json']:continue
 if 'src' in rel.parts and rel.parts[0] not in ['00-baseline-coverage','01-interface-red','source-final']:continue
 selected.append(f)
manifest={str(f.relative_to(base)):sha(f) for f in selected};(base/'portable-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');selected.append(base/'portable-manifest.json')
with tarfile.open(base/'final-portable.tar.gz','w:gz') as tf:
 for f in sorted(selected):tf.add(f,arcname='automation-pending-iterator/'+str(f.relative_to(base)))
summary={'source_hashes':freeze,'portable_packet_sha256':sha(base/'final-portable.tar.gz'),'portable_packet_bytes':(base/'final-portable.tar.gz').stat().st_size,'selected_files':len(selected),'coverage_invocations':7,'coverage_normal_regions':'5/5','full_host_passed':154,'build_processes':proc,'disk_free_bytes':terminal['disk_free_bytes']};print(json.dumps(summary,indent=2))
