"""One-run resource-guarded CLAP regression checkpoint for the VST3 proof."""
import hashlib, importlib.util, json, os, shutil, signal, subprocess, time
from pathlib import Path

repo=Path('/home/dan/code/dandrum'); root=Path('/tmp/dandrum-vst3-proof-20261103')
out=root/'evidence/native-clap-extraction';out.mkdir()
spec=importlib.util.spec_from_file_location('cargo_cache',repo/'scripts/cargo-cache.py')
cache_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(cache_module)
cache=repo/'.git/dandrum-cargo-cache'; baseline=36657377280
reserve=8*2**30; output_limit=32*2**30
children=[]; receipts=[]; opened=[]
env=dict(os.environ,DISPLAY=':94',GDK_BACKEND='x11',LIBGL_ALWAYS_SOFTWARE='1',CARGO_BUILD_JOBS='4',XDG_RUNTIME_DIR='/run/user/1000')
env.pop('XAUTHORITY',None)

def available_memory():
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):return int(line.split()[1])*1024
    raise RuntimeError('memory observation unavailable')

def observe():
    retained=cache_module.retained_bytes(cache)
    sample={'utc':time.time(),'memory_available':available_memory(),'disk_free':shutil.disk_usage(repo).free,'managed_retained':retained,'managed_growth':retained-baseline}
    assert sample['memory_available']>=reserve,'8-GiB memory floor'
    assert sample['disk_free']>=reserve,'8-GiB free-disk floor'
    assert sample['managed_growth']<output_limit,'32-GiB task output allowance'
    return sample

def stop(child):
    if child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=8)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)

def run(name,command,timeout):
    before=observe()
    # The existing manager reserves8GiB per producer. Refuse before it can retire
    # any preserved old generation to manufacture admission.
    assert before['managed_retained']+8*2**30<=64*2**30,'64-GiB retained-cache admission; preserve generations'
    started=time.monotonic();samples=[before];log=(out/(name+'.log')).open('w');opened.append(log)
    child=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);children.append(child)
    (out/'current.json').write_text(json.dumps({'phase':name,'pid':child.pid,'command':command,'started':time.time()}))
    error=None
    try:
        while child.poll() is None:
            if time.monotonic()-started>timeout:raise RuntimeError('owned producer deadline')
            time.sleep(2)
            samples.append(observe())
        result=child.wait()
    except BaseException as e:
        error=str(e);stop(child);result=child.returncode
    receipt={'phase':name,'command':command,'pid':child.pid,'exit':result,'error':error,'elapsed_seconds':time.monotonic()-started,'before':before,'after':observe(),'minimum_memory_available':min(s['memory_available'] for s in samples),'minimum_disk_free':min(s['disk_free'] for s in samples),'maximum_managed_retained':max(s['managed_retained'] for s in samples),'samples':len(samples)}
    receipts.append(receipt);(out/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)
    assert result==0 and error is None,f'{name}: {error or result}; inspect retained log'

try:
    initial=observe();(out/'initial.json').write_text(json.dumps(initial,indent=2))
    assert not Path('/tmp/.X11-unix/X94').exists(),'display already owned'
    xlog=(out/'xvfb.log').open('w');opened.append(xlog)
    x=subprocess.Popen(['/tmp/dandrum-task-7-3/xvfb/usr/bin/Xvfb',':94','-screen','0','1600x1200x24','-nolisten','tcp'],stdout=xlog,stderr=xlog,start_new_session=True);children.append(x)
    for _ in range(100):
        if Path('/tmp/.X11-unix/X94').exists():break
        assert x.poll() is None,'Xvfb exited'
        time.sleep(.05)
    else:raise RuntimeError('Xvfb did not start')
    wlog=(out/'wm.log').open('w');opened.append(wlog)
    wm=subprocess.Popen(['xfwm4','--compositor=off'],env=env,stdout=wlog,stderr=wlog,start_new_session=True);children.append(wm)
    run('plain-product-build',['/home/dan/.local/bin/cmake','--build','build/cache-native','--target','dandrum-clap-proof','--parallel','1'],1200)
    run('trigger-product-build',['/home/dan/.local/bin/cmake','--build','build/cache-native','--target','dandrum-trigger-clap-product','--parallel','1'],1200)
    run('native-regressions',['/home/dan/.local/bin/ctest','--test-dir','build/cache-native','--parallel','1','--output-on-failure','-R','^trigger-clap-(dynamic-host|native-.*|installed-native-overlap|install-contract)$'],1800)
finally:
    for c in reversed(children):stop(c)
    for f in opened:f.close()
    (out/'cleanup.json').write_text(json.dumps({'children':[{'pid':c.pid,'exit':c.returncode} for c in children],'all_known_children_terminal':all(c.poll() is not None for c in children)},indent=2)+'\n')
