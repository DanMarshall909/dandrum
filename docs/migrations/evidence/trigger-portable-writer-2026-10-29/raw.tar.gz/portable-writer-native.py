from pathlib import Path
import os, subprocess, json, hashlib, shutil, tarfile, time
root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');out=Path(__file__).parent;env=dict(os.environ);cargo='/home/dan/.cargo/bin/cargo';cache=Path(env['CARGO_TARGET_DIR']);scratch=Path(env['TMPDIR']);phases=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024), b''):h.update(b)
 return h.hexdigest()
def run(name,args,child=None):
 start=time.monotonic();r=subprocess.run(args,cwd=root,env=child or env,capture_output=True,timeout=900)
 for label,data in [('stdout',r.stdout),('stderr',r.stderr)]: (out/('portable-writer-native-'+name+'.'+label)).write_bytes(data)
 phases.append({'name':name,'argv':args,'exit':r.returncode,'seconds':time.monotonic()-start});(out/'portable-writer-native-phases.json').write_text(json.dumps(phases,indent=2)+'\n');print(name,r.returncode,flush=True);assert r.returncode==0,name
 return r.stdout.decode()
# Preserve the verified headless product before the shared target changes feature.
headless=cache/'debug/libdandrum_clap_adapter.so'
assert sha(headless)=='c44d304a81ac6e8fd576f66f4abfccc8119afaad13aee298d38cb8885ec325f2'
headless_archive=out/'portable-writer-dynamic-replay.tar.gz'
with tarfile.open(headless_archive,'x:gz',compresslevel=3) as t:
 for source,name in [(headless,'DandrumTrigger.clap'),(root/'examples/patches/advanced-drum-kit.yaml','DandrumTrigger.resources/instrument/advanced-drum-kit.yaml'),(root/'examples/patches/assets/advanced-drums.wav','DandrumTrigger.resources/instrument/assets/advanced-drums.wav')]:t.add(source,arcname=name,recursive=False)
run('build',[cargo,'build','--manifest-path','src/clap-adapter/Cargo.toml','--features','trigger-editor','--lib','--offline','--locked'])
text=run('compile',[cargo,'test','--manifest-path','src/clap-adapter/Cargo.toml','--features','trigger-editor','--test','trigger_parameters','--no-run','--message-format=json','--offline','--locked'])
records=[json.loads(l) for l in text.splitlines() if l.startswith('{')];tests=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('profile',{}).get('test')];assert len(tests)==1
fixture=scratch/'native';resources=fixture/'DandrumTrigger.resources';(resources/'instrument/assets').mkdir(parents=True)
shutil.copy2(headless,fixture/'DandrumTrigger.clap');shutil.copy2(tests[0]['executable'],fixture/'trigger-parameters-test')
shutil.copy2(root/'examples/patches/advanced-drum-kit.yaml',resources/'instrument/advanced-drum-kit.yaml');shutil.copy2(root/'examples/patches/assets/advanced-drums.wav',resources/'instrument/assets/advanced-drums.wav');shutil.copytree(root/'build/engine-only/clap/DandrumTrigger.resources/editor',resources/'editor')
assert sha(resources/'editor/app.js')=='d157a01be9cc121d3e310b2b4ca099cddb36d355328d45170d02e406d6fa918e'
files={str(p.relative_to(fixture)):sha(p) for p in fixture.rglob('*') if p.is_file()};archive=out/'portable-writer-native-replay.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=3) as t:
 for name in files:t.add(fixture/name,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for n,d in files.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==d
(out/'portable-writer-native-binding.json').write_text(json.dumps({'profile':'debug, debuginfo1, no incremental','files':files,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'headless_archive_sha256':sha(headless_archive),'headless_archive_bytes':headless_archive.stat().st_size,'scope':'Two affected actual native GUI state consumers under private authenticated X11. Existing unchanged production React bundle d157; no installed/release/physical-input/DAW claim.'},indent=2)+'\n')
child=dict(env,DANDRUM_TRIGGER_GUI_PLUGIN_PATH=str(fixture/'DandrumTrigger.clap'),GDK_BACKEND='x11');child.pop('DISPLAY',None);child.pop('WAYLAND_DISPLAY',None)
for i,name in enumerate(['copied_native_host_feedback_updates_rendered_control_without_polling_or_undo_pollution','structural_native::copied_native_mapping_survives_lost_reply_and_view_loss']):run('case-'+str(i),['xvfb-run','-a','-s','-screen 0 1920x1200x24 -nolisten tcp',str(fixture/'trigger-parameters-test'),'--exact',name,'--ignored','--nocapture','--test-threads=1'],child)
