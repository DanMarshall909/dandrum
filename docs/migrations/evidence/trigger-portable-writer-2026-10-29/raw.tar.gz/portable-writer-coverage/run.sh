#!/usr/bin/env bash
set -euo pipefail
python3 /home/dan/code/dandrum/.git/codex/trigger-recovery-20261026/portable-writer-coverage/measure.py
python3 /home/dan/code/dandrum/.git/codex/trigger-recovery-20261026/portable-writer-coverage/extend-dynamic.py
