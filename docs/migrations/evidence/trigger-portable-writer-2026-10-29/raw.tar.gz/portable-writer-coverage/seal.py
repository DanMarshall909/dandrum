from pathlib import Path
import hashlib,json,tarfile,re,subprocess
root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');out=Path(__file__).parent

def digest(stream):
 h=hashlib.sha256()
 for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def sha(p):
 with p.open('rb') as f:return digest(f)
binding=json.loads((out/'binding.json').read_text());members={}
for i,o in enumerate(binding['objects']):
 p=Path(o['path']);assert sha(p)==o['sha256'];members[f'objects/{i}-{p.name}']=p
for name in ['binding.json','source.json','source.tar.gz','merged.profdata','phases.json','environment.json','measure.py','extend-dynamic.py']:
 members[name]=out/name
for p in sorted((out/'profiles').glob('*.profraw')):members['profiles/'+p.name]=p
archive=out/'replay-objects.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=3) as t:
 for name,p in members.items():t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(members)
 for m in t.getmembers():assert digest(t.extractfile(m))==sha(members[m.name])
(out/'replay-archive.json').write_text(json.dumps({'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(members),'readback':'all exact'},indent=2)+'\n')
print((out/'replay-archive.json').read_text(),flush=True)
