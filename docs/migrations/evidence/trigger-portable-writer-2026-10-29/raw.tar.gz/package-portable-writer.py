from pathlib import Path
import hashlib,json,tarfile,subprocess
root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');out=Path(__file__).parent;packet=root/'docs/migrations/evidence/trigger-portable-writer-2026-10-29';packet.mkdir(exist_ok=True)
def digest(f):
 h=hashlib.sha256()
 for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()
def sha(p):
 with p.open('rb') as f:return digest(f)
names=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines();names=[n for n in names if n.startswith('src/') or n=='openspec/changes/add-juce-free-trigger-beta-products/portable-state.md'];assert len(names)==15
sources={n:sha(root/n) for n in names};final=out/'portable-writer-final-source';(final/'blobs').mkdir(parents=True,exist_ok=True)
for n,d in sources.items():(final/'blobs'/d).write_bytes((root/n).read_bytes())
base='11a7f708e01a23d33a656e78989c00175ee8b192';(final/'binding.json').write_text(json.dumps({'base':base,'sources':sources},indent=2)+'\n');paths=[]
for folder in sorted(out.glob('portable-writer-*')):
 if folder.is_dir() and not ('package' in folder.name and folder.name.endswith('-run')):
  for p in sorted(folder.rglob('*')):
   if p.is_file() and not p.is_symlink() and p.name not in {'lock','replay-objects.tar.gz'} and 'scratch' not in p.relative_to(folder).parts:paths.append(p)
for p in sorted(out.glob('portable-writer-*')):
 if p.is_file() and p.suffix in {'.sh','.json','.py','.stdout','.stderr'}:paths.append(p)
paths.append(Path(__file__));paths=list(dict.fromkeys(paths));index={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths};archive=packet/'raw.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3) as t:
 for p in paths:t.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(index)
 for n,r in index.items():assert digest(t.extractfile(n))==r['sha256']
(packet/'raw-index.json').write_text(json.dumps(index,indent=2)+'\n');replay=out/'portable-writer-coverage/replay-objects.tar.gz';native=json.loads((out/'portable-writer-native-binding.json').read_text());binding={'base':base,'source':sources,'archive':{'path':'raw.tar.gz','sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(index)},'external_replay':{'path':str(replay),'sha256':sha(replay),'bytes':replay.stat().st_size},'dynamic_replay':{'path':str(out/'portable-writer-dynamic-replay.tar.gz'),'sha256':native['headless_archive_sha256'],'bytes':native['headless_archive_bytes']},'native_replay':{'path':str(out/'portable-writer-native-replay.tar.gz'),'sha256':native['archive_sha256'],'bytes':native['archive_bytes']},'scope':'All-new-saves self-contained v3 writer, legacy packaged-profile support and current-output test consumers. Full payload qualification/fresh selected CLAP/installed/native-input/DAW/final release remain open.'};(packet/'binding.json').write_text(json.dumps(binding,indent=2)+'\n');print(json.dumps({k:v for k,v in binding.items() if k!='source'},indent=2))
