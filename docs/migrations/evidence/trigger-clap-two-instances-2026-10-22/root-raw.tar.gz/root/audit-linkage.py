from pathlib import Path
import subprocess,json,hashlib
out=Path('/tmp/dandrum-evidence/g3-two-native-fixture');bindings=json.loads((out/'root-actual-cargo-bindings.json').read_text());cases={}
for fixture,b in bindings.items():
 for name,a in b['artifacts'].items():cases[fixture+'-'+name]=(out/'native-build'/fixture/a['copy'],a['copy_sha256'])
p=Path('/tmp/dandrum-evidence/g3-two-native-instances/installed/DandrumTrigger.clap');cases['ordinary-product']=(p,'17251daa8ecbcc4ec3da600e04056e2338426926c0a274ebb84b70e72e810df3');rows=[]
for label,(path,expected) in cases.items():
 assert hashlib.sha256(path.read_bytes()).hexdigest()==expected;results=[]
 for tool in ['readelf','ldd']:
  cmd=['readelf','-d',str(path)] if tool=='readelf' else ['ldd',str(path)];p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=20);assert p.returncode==0 and b'not found' not in p.stdout and b'juce' not in p.stdout.lower();dest=out/f'root-link-{label}-{tool}.log';dest.write_bytes(p.stdout);results.append(dict(command=cmd,exit=p.returncode,log=dest.name,sha256=hashlib.sha256(p.stdout).hexdigest()))
 rows.append(dict(label=label,path=str(path),elf_sha256=expected,results=results))
(out/'root-linkage-audit.json').write_text(json.dumps(dict(artifacts=rows,scope='Current actual Cargo-selected maintained fixture DSOs and both host binaries plus immutable ordinary product DSO: no unresolved/JUCE linkage. No current headless rebuild or installed-beta claim.'),indent=2)+'\n');print('Linkage PASS for',len(rows),'bound artifacts')
