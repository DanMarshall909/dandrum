import gzip,hashlib,io,json,tarfile
from pathlib import Path
root=Path('/tmp/dandrum-evidence/g3-two-native-fixture');author=Path('/tmp/dandrum-evidence/g3-two-native-instances');dest=Path('/tmp/dandrum-lanes/integration/docs/migrations/evidence/trigger-clap-two-instances-2026-10-22');dest.mkdir(parents=True,exist_ok=True)
sha=lambda d:hashlib.sha256(d).hexdigest()
def archive(name,e):
 e['meta/index.json']=(json.dumps({n:{'sha256':sha(d),'bytes':len(d)} for n,d in e.items()},sort_keys=True,indent=2)+'\n').encode();p=dest/name;assert not p.exists()
 with p.open('wb') as f,gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as z,tarfile.open(fileobj=z,mode='w') as t:
  for n,d in sorted(e.items()):
   i=tarfile.TarInfo(n);i.size=len(d);i.mode=0o644;t.addfile(i,io.BytesIO(d))
 with tarfile.open(p,'r:gz') as t:
  assert set(t.getnames())==set(e)
  for i in t:assert t.extractfile(i).read()==e[i.name]
 v={'archive':name,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'members':len(e),'every_member_byte_verified':True};(dest/name.replace('-raw.tar.gz','-archive.json')).write_text(json.dumps(v,indent=2)+'\n');print(v)
def add(e,p,name):
 assert not p.is_symlink();d=p.read_bytes();assert not d.startswith(b'\x7fELF') and len(d)<8*1024**2;d.decode('utf8');e[name]=d
# Compiler captures contain only required Cargo/build variables, never credential variables.
for p in (author/'compiler-captures').glob('*.json'):
 env=json.loads(p.read_text()).get('environment',{});assert not any(any(word in k.upper() for word in ('TOKEN','PASSWORD','SECRET','CREDENTIAL','API_KEY')) for k in env)
e={}
for p in sorted(author.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(author)
 if 'source' in rel.parts or rel.parts[0] in ('installed','tmp'):continue
 if p.suffix in ('.py','.json','.log','.md','.txt','.before'):add(e,p,'author/'+str(rel))
states={};objects={}
for folder in sorted(author.iterdir()):
 if not (folder/'source').is_dir():continue
 rows={}
 for p in sorted((folder/'source').rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink();d=p.read_bytes();assert not d.startswith(b'\x7fELF') and p.suffix not in ('.profraw','.profdata');assert 'target' not in p.relative_to(folder/'source').parts;h=sha(d);objects[h]=d;rows[str(p.relative_to(folder/'source'))]={'sha256':h,'bytes':len(d),'mode':oct(p.stat().st_mode&0o777)}
 states[folder.name]=rows
e['meta/source-states.json']=(json.dumps(states,sort_keys=True,indent=2)+'\n').encode()
for h,d in objects.items():e['source-objects/'+h]=d
archive('author-raw.tar.gz',e)
e={}
for p in sorted(root.iterdir()):
 if p.is_file() and p.suffix in ('.py','.json','.log','.d'):add(e,p,'root/'+p.name)
for n in ('test-before','implementation-before'):add(e,root/n,'root/'+n)
for p in sorted((root/'integration-before').rglob('*')):
 if p.is_file():add(e,p,'integration-before/'+str(p.relative_to(root/'integration-before')))
for fixture in ('trigger-clap-native-fixture','trigger-clap-parameters-fixture'):
 for p in sorted((root/'native-build'/fixture/'evidence').iterdir()):
  if p.is_file():add(e,p,'native-prepare/'+fixture+'/'+p.name)
for n in ('CTestTestfile.cmake','CMakeCache.txt'):add(e,root/'native-build'/n,'native-configuration/'+n)
for n in ('root-clap-build-boundary.json','root-clap-build-boundary.stdout.log','root-clap-build-boundary.stderr.log'):
 add(e,Path('/tmp/dandrum-evidence/g3-native-fixture')/n,'prior-structural-base-build/'+n)
archive('root-raw.tar.gz',e)
for n in ('root-final-coverage-assessment.json','root-native-result.json','root-actual-cargo-bindings.json','root-build-boundary-reuse.json','root-linkage-audit.json','root-two-instance-case-summary.json'):(dest/n).write_bytes((root/n).read_bytes())
(dest/'author-handoff.json').write_bytes((author/'handoff.json').read_bytes())
