from pathlib import Path
import hashlib,json,subprocess,time
out=Path('/tmp/dandrum-evidence/g3-two-native-fixture');author=Path('/tmp/dandrum-evidence/g3-two-native-instances');root=Path('/tmp/dandrum-lanes/integration')
assert (out/'author-release-admitted.json').is_file()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binding=author/'coverage-binding.json';frozen=json.loads((out/'author-file-manifest.json').read_text());assert sha(binding)==frozen['coverage-binding.json'];b=json.loads(binding.read_text())
assert len(b['objects'])==len(b['profiles'])==2
for p,h in b['objects'].items():assert sha(Path(p))==h
for p,h in b['profiles'].items():assert sha(Path(p))==h
for i,t in enumerate(('llvm-profdata','llvm-cov')):assert sha(Path(b['commands'][i][0]))==b['tool_sha256'][t]
merge=list(b['commands'][0]);merge[merge.index('-o')+1]=str(out/'root-final.profdata')
export=list(b['commands'][1]);export[-1]='--instr-profile='+str(out/'root-final.profdata')
start=time.monotonic()
for label,cmd in [('merge',merge),('export',export)]:
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);(out/f'root-final-{label}.stderr.log').write_bytes(p.stderr);assert p.returncode==0 and not p.stderr
 if label=='export':(out/'root-final-raw-export.json').write_bytes(p.stdout)
original=author/'coverage-final/export.json';assert sha(original)==b['export_sha256']
v=json.loads(original.read_text());assert v==json.loads((out/'root-final-raw-export.json').read_text())
suffix='src/clap-adapter/tests/internal/trigger_instances_native.rs';rows=[]
for f in v['data'][0]['functions']:
 if not any(p.endswith('/'+suffix) for p in f['filenames']):continue
 regions=[r for r in f['regions'] if r[7]==0 and f['filenames'][r[5]].endswith('/'+suffix)]
 rows.append({'name':f['name'],'source':suffix,'source_sha256':sha(root/suffix),'function_count':f['count'],'source_regions':len(regions),'positive_source_regions':sum(r[4]>0 for r in regions),'zero_hit_spans':[r[:4] for r in regions if r[4]==0]})
files=[f for f in v['data'][0]['files'] if f['filename'].endswith('/'+suffix)];assert len(files)==1
summary=files[0]['summary'];assert summary==json.loads((author/'handoff.json').read_text())['new_test_coverage']['summary']
x={'binding_sha256':sha(binding),'objects':b['objects'],'profiles':b['profiles'],'raw_profile_count':len(b['profiles']),'original_export_sha256':sha(original),'regenerated_export_sha256':sha(out/'root-final-raw-export.json'),'commands':[merge,export],'exit':[0,0],'seconds':time.monotonic()-start,'source_summary':summary,'functions':rows,'scope':'Fresh independent warning-free merge/export from verified LLVM tools, two actual ELFs and two raw profiles for one exact final success case. Parsed data equal. Production instrumentation is explicitly reused with unchanged source/compiler/extern bindings; exact final test instrumented anew. Malformed-fixture/worker failure/watchdog/mismatch/cleanup and timing-dependent pending branches remain unhit; no full-owner/branch/hardware claim.'}
(out/'root-final-coverage-assessment.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'profiles':len(b['profiles']),'functions':len(rows),'summary':summary,'seconds':x['seconds'],'warnings':0}))
