asserted_handback='DO NOT EXECUTE until explicit final author source/cache handback'
from pathlib import Path
import hashlib,json,subprocess
out=Path('/tmp/dandrum-evidence/g3-two-native-fixture');author=Path('/tmp/dandrum-evidence/g3-two-native-instances');runtime=Path('/tmp/dandrum-lanes/runtime');root=Path('/tmp/dandrum-lanes/integration');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
import sys
assert len(sys.argv)==2 and len(sys.argv[1])==64
assert sha(author/'handoff.json')==sys.argv[1]
manifest=json.loads((out/'author-file-manifest.json').read_text());total=0
for name,expected in manifest.items():
 p=author/name;assert p.is_file() and not p.is_symlink() and '..' not in Path(name).parts;assert sha(p)==expected,name;total+=p.stat().st_size
paths=json.loads((author/'handoff.json').read_text())['final_sources']
for path,expected in paths.items():assert sha(runtime/path)==expected
cache=runtime/'cache-editor-guard';rows=[]
for p in sorted(cache.rglob('*')):
 if p.is_symlink():rows.append(dict(path=str(p.relative_to(cache)),symlink=str(p.readlink())))
 elif p.is_file():rows.append(dict(path=str(p.relative_to(cache)),mode=p.stat().st_mode&0o777,size=p.stat().st_size,sha256=sha(p)))
assert rows==json.loads(Path('/tmp/dandrum-evidence/g3-creation-publication/runtime-preserved-cache-baseline.json').read_text())
git=lambda p,*a:subprocess.check_output(['git',*a],cwd=p).decode().strip()
assert not git(runtime,'diff','--cached','--name-only') and not git(root,'diff','--cached','--name-only')
assert git(runtime,'rev-parse','HEAD')==git(root,'rev-parse','HEAD')=='d205756b6c61a2813a67920d4d9830e8241daa87'
assert set(line[3:] for line in subprocess.check_output(['git','status','--porcelain'],cwd=runtime).decode().splitlines())==set(paths)|{'cache-editor-guard/'}
assert set(line[3:] for line in subprocess.check_output(['git','status','--porcelain'],cwd=root).decode().splitlines())=={'CMakeLists.txt','tests/python/test_engine_only_build.py'}
p=subprocess.run(['ps','-C','cargo,rustc,cmake,ctest','-o','pid,ppid,etime,args'],stdout=subprocess.PIPE);assert p.returncode==1 and p.stdout.decode().strip()=='PID    PPID     ELAPSED COMMAND'
r=dict(evidence_files=len(manifest),evidence_bytes=total,evidence_manifest_sha256=sha(out/'author-file-manifest.json'),handoff_sha256=sha(author/'handoff.json'),source_sha256=paths,cache_files=len(rows),actual_host_builder_inventory=p.stdout.decode(),ownership='Explicit source and both native/LLVM cache handback accepted; root sole writer/builder now.');(out/'author-release-admitted.json').write_text(json.dumps(r,indent=2)+'\n')
(out/'integration-before').mkdir(exist_ok=True)
for path,expected in paths.items():
 backup=out/'integration-before'/path;backup.parent.mkdir(parents=True,exist_ok=True)
 if (root/path).exists():backup.write_bytes((root/path).read_bytes())
 (root/path).write_bytes((runtime/path).read_bytes())
mirrors=[]
for path in ['CMakeLists.txt','tests/python/test_engine_only_build.py']:
 before=sha(runtime/path);(runtime/path).write_bytes((root/path).read_bytes());mirrors.append(dict(path=path,before_sha256=before,after_sha256=sha(runtime/path)))
(out/'source-integration.json').write_text(json.dumps(dict(source=r,registration_mirrors=mirrors),indent=2)+'\n');print(json.dumps(r))
