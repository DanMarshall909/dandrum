from pathlib import Path
import subprocess,sys,json,time,hashlib
out=Path('/tmp/dandrum-evidence/g3-two-native-instances');mode=sys.argv[1];records=[json.loads(s) for s in (out/'final-build.stdout.log').read_text().splitlines() if s.startswith('{')]
name={'native':'trigger_parameters','gui':'trigger_gui','fast':'dandrum_clap_adapter'}[mode]
artifacts=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('executable')];assert len(artifacts)==1
elf=artifacts[0]['executable'];all_names={s[:-6] for s in subprocess.check_output([elf,'--list'],text=True).splitlines() if s.endswith(': test')};ignored={s[:-6] for s in subprocess.check_output([elf,'--list','--ignored'],text=True).splitlines() if s.endswith(': test')}
cases=sorted(all_names-ignored if mode=='fast' else ignored)
if mode=='native':
 assert len(cases)==22
 cases.remove('native_parameter_callback_allocator_audit_child');cases.remove('note_native::continuous_audio_allocator_audit_child')
assert len(cases)=={'native':20,'gui':5,'fast':13}[mode],cases
logs=out/(mode+'-cases');logs.mkdir(exist_ok=True);results=[]
for case in cases:
 command=[elf,case,'--exact','--show-output','--test-threads=1']+([] if mode=='fast' else ['--ignored'])
 start=time.monotonic();r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 (logs/(case+'.stdout.log')).write_bytes(r.stdout);(logs/(case+'.stderr.log')).write_bytes(r.stderr)
 assert b'running 1 test' in r.stdout
 results.append({'case':case,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start})
 (out/(mode+'-cases.json')).write_text(json.dumps({'artifact':artifacts[0],'elf_sha256':hashlib.sha256(Path(elf).read_bytes()).hexdigest(),'cases':results},indent=2))
 print(results[-1],flush=True)
 if r.returncode:sys.exit(r.returncode)
