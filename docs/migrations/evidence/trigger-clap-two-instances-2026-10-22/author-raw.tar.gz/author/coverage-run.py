from pathlib import Path
import json,sys,os,shutil,subprocess,hashlib,time
out=Path('/tmp/dandrum-evidence/g3-two-native-instances');old=Path('/tmp/dandrum-evidence/g3-continuous-native-audio');label=sys.argv[1]
root=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g3-two-native-instances');tests=[p for p in (root/label).glob('trigger_parameters-*') if p.is_file() and not p.suffix];assert len(tests)==1
test=tests[0];normal=out/'ordinary-library.so';dest=out/'installed/DandrumTrigger.clap';shutil.copy2(dest,normal)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
oldrun=json.loads((old/'refactor-coverage-execution-binding.json').read_text());dso=Path(oldrun['instrumented_dso']);assert h(dso)==oldrun['dso_sha256']
# Reuse instrumentation only for unchanged production sources, never old test code.
proofs={}
for name in ('dso-final-instrument.json','editor-final-instrument.json'):
 r=json.loads((old/name).read_text());sources={p:d for p,d in r['source_sha256'].items() if '/tests/' not in p}
 for p,d in sources.items():assert h(p)==d,(p,'production source changed')
 assert h(r['command'][0])==r['compiler_sha256']
 for external,digest in r['extern_sha256'].items():assert h(external.split('=',1)[1])==digest,(external,'extern changed')
 shutil.copy2(old/name,out/('reused-'+name))
 proofs[name]={'record_sha256':h(old/name),'matching_production_sources':sources,'compiler_sha256':r['compiler_sha256'],'extern_sha256':r['extern_sha256'],'retained_record':'reused-'+name}
profiles=root/(label+'-profiles');profiles.mkdir(exist_ok=False)
env=dict(os.environ,LLVM_PROFILE_FILE=str(profiles/'%m-%p.profraw'));assert 'LD_PRELOAD' not in env and 'RUST_MIN_STACK' not in env
name='instances_native::copied_native_two_instances_keep_edits_audio_and_editors_independent'
command=[str(test),name,'--exact','--ignored','--show-output','--test-threads=1']
r={'command':command,'reused_unchanged_production_instrumentation':proofs,'ordinary_sha256':h(normal),'test':str(test),'test_sha256':h(test),'instrumented_dso':str(dso),'dso_sha256':h(dso),'profile_pattern':env['LLVM_PROFILE_FILE']}
try:
 shutil.copy2(dso,dest);r['copy_sha256']=h(dest)
 result=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 sys.stdout.buffer.write(result.stdout);sys.stderr.buffer.write(result.stderr)
 assert b'running 1 test' in result.stdout
 r['exit']=result.returncode
finally:
 shutil.copy2(normal,dest);r['restored_sha256']=h(dest);assert r['restored_sha256']==r['ordinary_sha256'];r['profiles']={str(p):h(p) for p in profiles.glob('*.profraw')};(out/(label+'-coverage-execution-binding.json')).write_text(json.dumps(r,indent=2))
sys.exit(result.returncode)
