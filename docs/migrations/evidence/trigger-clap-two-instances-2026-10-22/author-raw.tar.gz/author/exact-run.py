import pathlib,json,subprocess,sys,hashlib
out=pathlib.Path('/tmp/dandrum-evidence/g3-two-native-instances')
label=sys.argv[1]
records=[json.loads(line) for line in (out/(label+'.stdout.log')).read_text().splitlines() if line.startswith('{')]
artifacts=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='trigger_parameters' and r.get('executable')]
assert len(artifacts)==1
elf=pathlib.Path(artifacts[0]['executable'])
name='instances_native::copied_native_two_instances_keep_edits_audio_and_editors_independent'
assert name+': test' in subprocess.check_output([str(elf),'--list'],text=True).splitlines()
binding={'elf':str(elf),'sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'artifact':artifacts[0], 'source_binding':label+'.json','plugin_sha256':hashlib.sha256((out/'installed/DandrumTrigger.clap').read_bytes()).hexdigest(),'resources':{str(p.relative_to(out/'installed')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (out/'installed/DandrumTrigger.resources').rglob('*') if p.is_file()}}
(out/(label+'-execution-binding.json')).write_text(json.dumps(binding,indent=2))
result=subprocess.run([str(elf),name,'--exact','--ignored','--show-output','--test-threads=1'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
sys.stdout.buffer.write(result.stdout);sys.stderr.buffer.write(result.stderr)
assert b'running 1 test' in result.stdout
assert any(s in result.stdout for s in [b'test result: ok. 1 passed; 0 failed;',b'test result: FAILED. 0 passed; 1 failed;'])
sys.exit(result.returncode)
