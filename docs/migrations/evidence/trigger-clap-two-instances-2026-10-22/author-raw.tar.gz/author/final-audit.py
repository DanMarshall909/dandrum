from pathlib import Path
import json,hashlib,subprocess,shutil,os
out=Path('/tmp/dandrum-evidence/g3-two-native-instances');root=Path('/tmp/dandrum-lanes/runtime');old=Path('/tmp/dandrum-evidence/g3-creation-failure')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
run=lambda args,cwd=root:subprocess.check_output(args,cwd=cwd,text=True).strip()
files=['src/clap-adapter/tests/internal/trigger_instances_native.rs','src/clap-adapter/tests/trigger_parameters.rs'];sources={p:h(root/p) for p in files}
build=json.loads((out/'final-build.json').read_text());assert all(build['source_sha256'][p]==digest for p,digest in sources.items())
baseline=json.loads((out/'characterize-build-execution-binding.json').read_text());normal=out/'installed/DandrumTrigger.clap';assert h(normal)==baseline['plugin_sha256']
resources=json.loads((out/'resources-baseline.json').read_text());installed=out/'installed/DandrumTrigger.resources';assert {str(p.relative_to(installed)):h(p) for p in installed.rglob('*') if p.is_file()}==resources
cache=json.loads((old/'runtime-untracked-cache-baseline.json').read_text());cache_root=root/'cache-editor-guard';current={str(p.relative_to(cache_root)):{'size':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in cache_root.rglob('*') if p.is_file()};assert current==cache
tracked=run(['git','ls-files','src/clap-adapter/src','src/trigger-editor/src','src/clap-adapter/Cargo.toml','src/clap-adapter/Cargo.lock','src/trigger-editor/Cargo.toml']).splitlines();production={}
for name in tracked:
 published=subprocess.check_output(['git','show','HEAD:'+name],cwd=root);assert hashlib.sha256(published).hexdigest()==h(root/name),name;production[name]=h(root/name)
assert run(['git','diff','--name-only'])=='src/clap-adapter/tests/trigger_parameters.rs';subprocess.run(['git','diff','--check'],cwd=root,check=True)
receipts=[];groups=set();minimum_disk=None;minimum_mem=None
for p in out.glob('*.json'):
 try:r=json.loads(p.read_text())
 except json.JSONDecodeError:continue
 if isinstance(r,dict) and 'owned_process_group' in r:
  receipts.append({'receipt':p.name,'recorded_group':r['owned_process_group'],'exit':r.get('exit')});assert 'exit' in r
  # Small IDs came from isolated compile PID namespaces, not host PGIDs.
  if r['owned_process_group']>1000:groups.add(r['owned_process_group'])
  for sample in json.loads((out/(p.stem+'.samples.json')).read_text()):
   minimum_disk=min(minimum_disk or sample['disk_free_bytes'],sample['disk_free_bytes']);minimum_mem=min(minimum_mem or sample['MemAvailable'],sample['MemAvailable'])
owned=[];builders=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  comm=(p/'comm').read_text().strip();pgid=os.getpgid(int(p.name));args=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  if comm in ('cargo','rustc','rust-lld','ld','cc','clang','cc1'):builders.append({'pid':p.name,'comm':comm})
  if pgid in groups:owned.append({'pid':p.name,'pgid':pgid,'comm':comm})
  elif comm.startswith(('trigger_paramet','trigger_gui','WebKit','dandrum_clap')) and '/tmp/dandrum-lanes/cache-editor-guard/' in args:owned.append({'pid':p.name,'pgid':pgid,'comm':comm})
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
assert not owned,owned;assert not builders,builders
main=Path('/home/dan/code/dandrum');main_head=run(['git','rev-parse','HEAD'],main);main_status=run(['git','status','--short'],main);assert main_head=='68dd6553a2f07e71e2fe09ee1d7094d518559937' and not main_status
body={'final_source_sha256':sources,'normal_plugin':{'path':str(normal),'sha256':h(normal)},'restored_resources_sha256':resources,'production_sha256':production,'production_unchanged_from_HEAD':True,'runtime_head':run(['git','rev-parse','HEAD']),'known_runtime_cache_files':len(current),'known_runtime_cache_size_mtime_unchanged':True,'host_native_process_groups':sorted(groups),'owned_processes_remaining':owned,'host_builders_remaining':builders,'all_guarded_sessions_completed':receipts,'pid_namespace_note':'Compile groups were namespaced; completed tool sessions and this host-global idle audit cover those, not numerical matching to unrelated host PGIDs.','minimum_sampled_disk_free_bytes':minimum_disk,'minimum_sampled_MemAvailable_bytes':minimum_mem,'disk_free_bytes':shutil.disk_usage('/tmp').free,'cache_sizes':run(['du','-sb','/tmp/dandrum-lanes/cache-editor-guard','/tmp/dandrum-lanes/cache-host-snapshot-cov']),'git_status':run(['git','status','--short']),'main_head':main_head,'main_status':main_status}
(out/'final-restoration-audit.json').write_text(json.dumps(body,indent=2));print(json.dumps({k:v for k,v in body.items() if k in ('final_source_sha256','known_runtime_cache_files','owned_processes_remaining','host_builders_remaining','minimum_sampled_disk_free_bytes','minimum_sampled_MemAvailable_bytes','disk_free_bytes','git_status','main_head','main_status')}))
