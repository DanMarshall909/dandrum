from pathlib import Path
import os,sys,json,subprocess,hashlib
out=Path('/tmp/dandrum-evidence/g3-two-native-instances');label=sys.argv[1]
capture=json.loads((out/'trigger_parameters-test-rustc.json').read_text())
dest=Path('/tmp/dandrum-lanes/cache-host-snapshot-cov/g3-two-native-instances')/label;dest.mkdir(parents=True,exist_ok=False)
command=list(capture['command']);command[command.index('--out-dir')+1]=str(dest);command+=['-C','instrument-coverage']
env=dict(os.environ,**capture['environment'])
for k in ('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS','RUSTC_WRAPPER','LD_PRELOAD','LLVM_PROFILE_FILE'):env.pop(k,None)
env['RUST_MIN_STACK']='16777216';env['TMPDIR']=str(out/'tmp')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r={'capture':capture,'command':command,'cwd':capture['cwd'],'compiler':subprocess.check_output([command[0],'-Vv'],text=True),'compiler_sha256':h(command[0]),'environment':{k:env[k] for k in capture['environment'] if k in env},'changes':['exclusive LLVM out-dir','instrument-coverage','compiler-only16MiB stack','physical task TMPDIR'],'source_sha256':{str(p):h(p) for p in Path('/tmp/dandrum-lanes/runtime/src/clap-adapter').rglob('*.rs')},'extern_sha256':{a:h(a.split('=',1)[1]) for i,a in enumerate(command) if i and command[i-1]=='--extern'}}
(out/(label+'-instrument-binding.json')).write_text(json.dumps(r,indent=2))
result=subprocess.run(command,cwd=capture['cwd'],env=env);r['exit']=result.returncode;r['artifacts']={str(p):h(p) for p in dest.iterdir() if p.is_file()};(out/(label+'-instrument-binding.json')).write_text(json.dumps(r,indent=2));sys.exit(result.returncode)
