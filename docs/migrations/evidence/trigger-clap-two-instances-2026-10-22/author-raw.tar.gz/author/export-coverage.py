from pathlib import Path
import json,hashlib,subprocess,shutil,sys
out=Path('/tmp/dandrum-evidence/g3-two-native-instances');label=sys.argv[1];binding=json.loads((out/(label+'-coverage-execution-binding.json')).read_text());tools=Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin');dest=out/'coverage-final';dest.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();profiles=[]
for p,digest in binding['profiles'].items():
 assert h(p)==digest;q=dest/Path(p).name;shutil.copy2(p,q);profiles.append(q)
assert profiles
dso=Path(binding['instrumented_dso']);test=Path(binding['test']);assert h(dso)==binding['dso_sha256'] and h(test)==binding['test_sha256'];merged=dest/'coverage.profdata'
commands=[[str(tools/'llvm-profdata'),'merge','-sparse',*[str(p) for p in profiles],'-o',str(merged)],[str(tools/'llvm-cov'),'export',str(dso),'--object='+str(test),'--instr-profile='+str(merged)]]
r={'tool_versions':{n:subprocess.check_output([str(tools/n),'--version'],text=True) for n in ('llvm-profdata','llvm-cov')},'tool_sha256':{n:h(tools/n) for n in ('llvm-profdata','llvm-cov')},'commands':commands,'objects':{str(dso):h(dso),str(test):h(test)},'profiles':{str(p):h(p) for p in profiles},'exits':[]}
for i,c in enumerate(commands):
 with (dest/('merge.stdout.log' if i==0 else 'export.json')).open('w') as stdout,(dest/(str(i)+'.stderr.log')).open('w') as stderr:result=subprocess.run(c,stdout=stdout,stderr=stderr)
 r['exits'].append(result.returncode);assert result.returncode==0
files=['src/clap-adapter/tests/internal/trigger_instances_native.rs','src/clap-adapter/src/trigger.rs','src/clap-adapter/src/trigger/gui.rs','src/trigger-editor/src/native_x11.rs']
show=[str(tools/'llvm-cov'),'show',str(dso),'--object='+str(test),'--instr-profile='+str(merged),'--show-line-counts-or-regions','--show-instantiations',*[str(Path('/tmp/dandrum-lanes/runtime')/p) for p in files]]
with (dest/'focused-show.txt').open('w') as stdout,(dest/'show.stderr.log').open('w') as stderr:result=subprocess.run(show,stdout=stdout,stderr=stderr)
r['show_command']=show;r['show_exit']=result.returncode;assert result.returncode==0
for obj in (dso,test):
 for option,name in [('-n','notes'),('-S','sections')]:
  with (dest/(obj.name+'.'+name+'.txt')).open('w') as f:subprocess.run(['readelf',option,str(obj)],stdout=f,check=True)
data=json.loads((dest/'export.json').read_text());r['focused_functions']=[f for d in data['data'] for f in d['functions'] if any('trigger_instances_native.rs' in p for p in f['filenames'])];r['file_summaries']=[{'filename':f['filename'],'summary':f['summary']} for d in data['data'] for f in d['files'] if any(f['filename'].endswith(p) for p in files)];r['export_sha256']=h(dest/'export.json');r['merged_sha256']=h(merged)
(out/'coverage-binding.json').write_text(json.dumps(r,indent=2));print(json.dumps(r['file_summaries'],indent=2))
