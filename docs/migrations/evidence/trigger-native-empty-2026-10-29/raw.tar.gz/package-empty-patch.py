from pathlib import Path
import hashlib,json,tarfile
out=Path(__file__).parent
root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters')
dest=root/'docs/migrations/evidence/trigger-native-empty-2026-10-29'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={}
def add(p,name=None):
 p=Path(p);assert p.is_file() and not p.is_symlink(),p
 key=name or str(p.relative_to(out));assert key not in files,key;files[key]=p
runs=['empty-patch-native-red-run','empty-patch-frontend-red-run','empty-patch-frontend-correlated-red-run','empty-patch-frontend-focused-green-run','empty-patch-engine-wiring-red-run','empty-patch-frontend-integrated-green-run','empty-patch-native-green-run','empty-patch-static-build-run','empty-patch-unmapping-red-run','empty-patch-final-node-run','empty-patch-final-native-run','empty-patch-regression-final-node-run','empty-patch-official-run','empty-patch-source-free-run','empty-patch-final-spec-run']
for name in runs:
 p=out/name;receipt=json.loads((p/'cleanup.json').read_text());assert receipt['scratch_removed'] and not receipt['remaining_workers'],name
 for f in sorted(p.iterdir()):
  if f.is_file():add(f)
for f in sorted((out.parent/'be1').iterdir()):
 if f.is_file():add(f,'browser-be1/'+f.name)
for name in ['empty-patch-regression-final-v8','empty-patch-official']:
 for p in sorted((out/name).rglob('*')):
  if p.is_file():add(p)
for name in ['empty-patch-phases.json','empty-patch-frontend-red-source.tar.gz','empty-patch-engine-wiring-red-source.tar.gz','empty-patch-unmapping-red-source.tar.gz','empty-patch-final-native-replay.json','empty-patch-native-red-x11.log','empty-patch-native-green-x11.log','empty-patch-final-native-x11.log','empty-patch-official-x11.log','validator-tooling.json','package-empty-patch.py']:
 add(out/name)
paths=['CMakeLists.txt','openspec/changes/add-juce-free-trigger-beta-products/interactive-patches.md','src/clap-adapter/tests/internal/trigger_selection_native.rs','web/trigger/engine/native-document.mjs','web/trigger/engine/native-engine.mjs','web/trigger/tests/native-empty.test.mjs']
for name in paths:add(root/name,'source/'+name)
external=[]
for name in ['empty-patch-native-red-replay.tar.gz','empty-patch-final-native-replay.tar.gz']:
 p=out/name;external.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
dest.mkdir(exist_ok=False)
index=[]
with tarfile.open(dest/'raw.tar.gz','x:gz',compresslevel=1) as tf:
 for name,p in sorted(files.items()):
  index.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)});tf.add(p,arcname=name,recursive=False)
with tarfile.open(dest/'raw.tar.gz') as tf:
 assert len(tf.getmembers())==len(index)
 for row in index:assert hashlib.sha256(tf.extractfile(row['path']).read()).hexdigest()==row['sha256']
archive_sha=sha(dest/'raw.tar.gz')
(dest/'raw-index.json').write_text(json.dumps({'archive_sha256':archive_sha,'members':index},indent=2)+'\n')
binding={'base':'d7f37fcea030ca70cbeb590351959c82a5cfe921','published_base':'05b1048ac8a30b681a3a6f3a9211f7cf21cea995','source':{name:sha(root/name) for name in paths},'raw_archive_sha256':archive_sha,'external_replays':external,'native_replay_binding':'raw.tar.gz:empty-patch-final-native-replay.json','current_product_sha256':'1c770ba4ab9a2cdf5f757794b1b2c407b774eadb29a37d00f6bcd3ac30f52177','scope':'CLAP-only beta tasks5.3/5.5 resource-free Empty with immutable product controls, recreated selected import, native Undo/Redo and independent-instance signed audio; not whole task closure. Descriptor prerequisite has its separate committed LLVM packet.','checks':'257Node tests,14Chromium entrypoint cases,32native CLAP cases,9source-free cases; types/components/fmt/strict host+adapterClippy;192host tests+2doctests and focused3object/3profileLLVM retained from unchanged d7 descriptor prerequisite. Active and52canonical strict specs,631scenarios392mapped239ratchet. Current official validator34success10explicitSKIP0FAIL.','known_failure':'Strict engineClippy remains FAIL129 baseline diagnostics (unchanged engine); not a passing lint gate or waiver.','limits':'Private authenticated X11/WebKitGTK2.50.4 component/acquisition proof, not physical input, continuous selected audio, installed/offline or named-DAW acceptance. Legacyv2 state still refuses selected/Empty; portable codec remains open. Fixed unmapped16voices/oldest; unknown binding/voice changes and final unmapping retaining assets explicitly refuse before admission. Comparison Empty behavior unchanged. Mutation excluded, VST3/standalone deferred.','refactor':'Three validation/reconstruction helpers remain in existing native-document module; one current accepted compiler session, existing native history/parameter owners. Borrowed audio-case slice factors existing test oracles. No new module/dependency/engine language/codec.','finding':'Early independent design audit found last mapping removal could drop retained assets. Two genuine REDs now reject before admission; a positive ordinary removeRule assertion preserves supported removal. No new standing guidance/memory.'}
(dest/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
print(json.dumps({'members':len(index),'bytes':(dest/'raw.tar.gz').stat().st_size,'sha256':archive_sha}))
