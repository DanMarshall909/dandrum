from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
out=Path(__file__).parent
fixture=Path(os.environ['DANDRUM_VERIFICATION_SCRATCH'])/'fixture';fixture.mkdir()
archive=out/'native-import-final-native-replay.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='bf6e600f528bd321fa93ecc318f1339d5a93cdd24103efe273d32ceb97443205'
with tarfile.open(archive) as tar:
    for member in tar:
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        target=fixture/member.name;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(tar.extractfile(member).read());target.chmod(member.mode)
current=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters/build/engine-only/trigger-clap-parameters-fixture').resolve()
binding=json.loads((current/'binding.json').read_text());record=binding['artifacts']['test'];test=current/record['copy']
assert hashlib.sha256(test.read_bytes()).hexdigest()==record['copy_sha256']
shutil.copy2(test,fixture/'trigger-parameters-test')
report={'old_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'current_test':record,'test_source_sha256':hashlib.sha256(Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters/src/clap-adapter/tests/internal/trigger_selection_native.rs').read_bytes()).hexdigest(),'resource_files':json.loads((fixture/'binding.json').read_text())['resources']['files']}
(out/'native-import-disposal-correlated-red-binding.json').write_text(json.dumps(report,indent=2)+'\n')
env=dict(os.environ,DANDRUM_TRIGGER_GUI_PLUGIN_PATH=str(fixture/'DandrumTrigger.clap'),GDK_BACKEND='x11')
raise SystemExit(subprocess.run([str(fixture/'trigger-parameters-test'),'selection_native::copied_react_import_maps_selected_pcm_once_through_native_history','--ignored','--exact','--nocapture','--test-threads=1'],env=env).returncode)
