from pathlib import Path
import hashlib,json,tarfile,re,subprocess
root=Path('/home/dan/code/dandrum-worktrees/juce-free-host-adapters');out=Path(__file__).parent

def digest(stream):
 h=hashlib.sha256()
 for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def sha(p):
 with p.open('rb') as f:return digest(f)
binding=json.loads((out/'binding.json').read_text());members={}
for i,o in enumerate(binding['objects']):
 p=Path(o['path']);assert sha(p)==o['sha256'];members[f'objects/{i}-{p.name}']=p
for name in ['binding.json','source.json','source.tar.gz','merged.profdata','phases.json','environment.json','measure.py','extend-dynamic.py']:
 members[name]=out/name
for p in sorted((out/'profiles').glob('*.profraw')):members['profiles/'+p.name]=p
archive=out/'replay-objects.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=3) as t:
 for name,p in members.items():t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(members)
 for m in t.getmembers():assert digest(t.extractfile(m))==sha(members[m.name])
(out/'replay-archive.json').write_text(json.dumps({'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(members),'readback':'all exact'},indent=2)+'\n')
sections={};current=None
for line in (out/'extended-annotation.stdout').read_text().splitlines():
 if line.startswith(str(root)) and line.endswith(':'):current=line[:-1];sections.setdefault(current,{})
 elif current:
  m=re.match(r'\s*(\d+)\|\s*([^|]*)\|',line)
  if m and m[2].strip():sections[current].setdefault(int(m[1]),m[2].strip())
result={}
for rel in ['src/trigger-host/src/parameters.rs','src/trigger-host/src/state.rs','src/clap-adapter/src/trigger.rs']:
 added=[];n=0
 for line in subprocess.check_output(['git','diff','--unified=0','--',rel],cwd=root,text=True).splitlines():
  m=re.match(r'@@ .* \+(\d+)',line)
  if m:n=int(m[1]);continue
  if line.startswith('+++'):continue
  if line.startswith('+'):added.append(n);n+=1
  elif line.startswith(' '):n+=1
 counts=sections.get(str(root/rel),{});hit={n:counts[n] for n in added if n in counts};zeros=[n for n,v in hit.items() if v=='0'];result[rel]={'added_production_line_counts':hit,'zero_hit_added_production':zeros};assert not zeros,(rel,zeros)
rel='src/trigger-host/src/state.rs';lines=(root/rel).read_text().splitlines();start=next(i+1 for i,l in enumerate(lines) if l.startswith('pub(crate) fn restore_samples('));end=next(i+1 for i,l in enumerate(lines) if i+1>start and l.startswith('fn validate_manifest'));whole={n:c for n,c in sections[str(root/rel)].items() if start<=n<end};assert all(c!='0' for c in whole.values()),whole;result['extracted_complete_payload_reader']={'annotated_counts':whole,'zero_hits':[]}
(out/'changed-lines.json').write_text(json.dumps(result,indent=2)+'\n');print((out/'replay-archive.json').read_text());print({k:len(v.get('added_production_line_counts',v.get('annotated_counts',{}))) for k,v in result.items()},flush=True)
