#!/usr/bin/env bash
set -euo pipefail
python3 /home/dan/code/dandrum/.git/codex/trigger-recovery-20261026/portable-mixed-budget-refactor-coverage/measure.py
python3 /home/dan/code/dandrum/.git/codex/trigger-recovery-20261026/portable-mixed-budget-refactor-coverage/extend-dynamic.py
