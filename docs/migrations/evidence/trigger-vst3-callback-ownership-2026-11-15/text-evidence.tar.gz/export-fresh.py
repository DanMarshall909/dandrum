import hashlib, json, re, subprocess
from pathlib import Path
root=Path('/home/dan/code/dandrum')
out=Path('/tmp/dandrum-vst3-remaining-20261115')
gen=root/'.git/dandrum-cargo-cache/generations/fafc0b7c77a511cff6f8ed44'
llvm=Path('/home/dan/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin')
mode=__import__('sys').argv[1]
owner='trigger-host' if mode.startswith('host') else 'vst3-adapter'
start=int((out/f'{mode}-start-ns').read_text())
end=int((out/'host-slow-start-ns').read_text()) if mode=='host-fast' else 2**64
key=hashlib.sha256(str(root/f'src/{owner}/Cargo.toml').encode()).hexdigest()[:24]
profiles=sorted(p for p in (gen/f'targets/{key}/coverage').glob('*.profraw') if start<=p.stat().st_mtime_ns<end)
assert profiles, (mode,key)
log=out/'logs'/({'host-fast':'host-final-coverage','host-slow':'host-slow-coverage','vst3':'vst3-final-coverage'}[mode]+'.log')
if mode=='vst3':
 objects=[gen/'coverage/debug/deps/libdandrum_vst3_adapter.so']
else:
 objects=[root/p for p in re.findall(r'^\s*Running .*?\(([^)]+)\)',log.read_text(),re.M)]
assert objects and all(p.is_file() for p in objects)
profdata=out/f'{mode}-fresh.profdata'
merge=[str(llvm/'llvm-profdata'),'merge','-sparse',*[str(p) for p in profiles],'-o',str(profdata)]
subprocess.run(merge,check=True)
command=[str(llvm/'llvm-cov'),'export',str(objects[0]),*[v for p in objects[1:] for v in ['-object',str(p)]],f'-instr-profile={profdata}']
with (out/f'{mode}-fresh.json').open('w') as target, (out/f'logs/{mode}-fresh.stderr').open('w') as errors:
 subprocess.run(command,check=True,stdout=target,stderr=errors)
data=json.loads((out/f'{mode}-fresh.json').read_text())['data'][0]
files={f['filename'].removeprefix(str(root)+'/'):f['summary'] for f in data['files'] if f'/src/{owner}/src/' in f['filename']}
functions=[]
for f in data['functions']:
 if any(s in f['name'] for s in ['setComponentState','receive_parameter_reply','parameter_values']):
  functions.append({'symbol':f['name'],'calls':f['count'],'regions':len(f['regions']),'unhitRegions': [r[:4] for r in f['regions'] if r[4]==0]})
receipt={'mode':mode,'profiles':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in profiles], 'objects':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in objects],'mergeCommand':merge,'exportCommand':command,'files':files,'functions':functions}
(out/f'{mode}-fresh-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'mode':mode,'profiles':len(profiles),'objects':len(objects),'relevantFunctions':functions}))
