use vst3::{Interface, Steinberg::{*, Vst::*}};
use std::mem::{size_of,align_of,offset_of};
macro_rules! declare { ($($n:ty),*) => {$(println!("{} {} {}",stringify!($n),size_of::<$n>(),align_of::<$n>());)*}; }
fn main() {
declare!(PFactoryInfo,PClassInfo,PClassInfo2,PClassInfoW,BusInfo,ProcessSetup,ProcessData,AudioBusBuffers,Event,NoteOnEvent,NoteOffEvent,ParameterInfo,ViewRect);
macro_rules! iid { ($($n:ty),*) => {$(print!("{} ",stringify!($n)); for c in <$n>::IID { print!("{c:02x}"); } println!();)*}; }
iid!(IPluginFactory3,IComponent,IAudioProcessor,IEditController,IConnectionPoint,IMessage,Linux::IRunLoop,Linux::ITimerHandler);
println!("ProcessData.numSamples {}",offset_of!(ProcessData,numSamples));
println!("ProcessData.inputs {}",offset_of!(ProcessData,inputs));
println!("ProcessData.inputParameterChanges {}",offset_of!(ProcessData,inputParameterChanges));
println!("Event.noteOn {}",offset_of!(Event,__field0));
println!("kResultOk {kResultOk}\nkNoInterface {kNoInterface}\nkInvalidArgument {kInvalidArgument}");
}
