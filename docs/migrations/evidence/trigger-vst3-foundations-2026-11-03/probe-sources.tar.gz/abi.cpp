#include <cstdio>
#include <cstddef>
#include "pluginterfaces/base/ipluginbase.h"
#include "pluginterfaces/gui/iplugview.h"
#include "pluginterfaces/vst/ivstaudioprocessor.h"
#include "pluginterfaces/vst/ivstevents.h"
#include "pluginterfaces/vst/ivsteditcontroller.h"
#include "pluginterfaces/vst/ivstmessage.h"
#define DECLARE(n) printf(#n " %zu %zu\n", sizeof(n), alignof(n));
int main() { using namespace Steinberg; using namespace Vst;
DECLARE(PFactoryInfo); DECLARE(PClassInfo); DECLARE(PClassInfo2); DECLARE(PClassInfoW); DECLARE(BusInfo); DECLARE(ProcessSetup); DECLARE(ProcessData); DECLARE(AudioBusBuffers); DECLARE(Event); DECLARE(NoteOnEvent); DECLARE(NoteOffEvent); DECLARE(ParameterInfo); DECLARE(ViewRect);
#define IID(n) printf(#n " "); for(auto c: n ## _iid) printf("%02x", (unsigned char)c); printf("\n");
IID(IPluginFactory3); IID(IComponent); IID(IAudioProcessor); IID(IEditController); IID(IConnectionPoint); IID(IMessage); IID(Linux::IRunLoop); IID(Linux::ITimerHandler);
printf("ProcessData.numSamples %zu\n",offsetof(ProcessData,numSamples));
printf("ProcessData.inputs %zu\n",offsetof(ProcessData,inputs));
printf("ProcessData.inputParameterChanges %zu\n",offsetof(ProcessData,inputParameterChanges));
printf("Event.noteOn %zu\n",offsetof(Event,noteOn));
printf("kResultOk %d\nkNoInterface %d\nkInvalidArgument %d\n",kResultOk,kNoInterface,kInvalidArgument);
}
