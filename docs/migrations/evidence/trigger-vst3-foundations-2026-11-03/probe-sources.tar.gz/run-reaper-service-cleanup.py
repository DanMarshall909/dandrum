import os, subprocess, time, signal, json, shutil
from pathlib import Path
root=Path('/tmp/dandrum-vst3-proof-20261103/probe')
bundle=root/'plugins/DandrumServiceProbe.vst3/Contents/x86_64-linux'
bundle.mkdir(parents=True,exist_ok=True)
shutil.copy2(root/'service-probe.so',bundle/'DandrumServiceProbe.so')
run=root/'reaper-service-cleanup-attempt-1'; run.mkdir()
for folder in ['cache','config','tmp']: (run/folder).mkdir()
ini=(Path('/tmp/dandrum-task-7-3/reaper-fixed-config/reaper.ini').read_text())
# The task-owned config only searches the probe, retaining the qualified GTK setting.
ini=ini.replace('[REAPER]\n','[REAPER]\nvstpath='+str(root/'plugins')+'\n')
ini=ini.replace('clappath= /tmp/dandrum-task-7-3/installed/lib/clap','clappath= '+str(run/'no-clap'))
(run/'reaper.ini').write_text(ini)
(run/'setup.lua').write_text('''
local root="'''+str(run)+'''/"
reaper.InsertTrackAtIndex(0,true)
local track=reaper.GetTrack(0,0)
local fx=reaper.TrackFX_AddByName(track,"Dandrum service probe",false,-1)
local f=assert(io.open(root.."setup.txt","w"));f:write("version="..reaper.GetAppVersion().." fx="..fx.."\\n");f:close()
local start=reaper.time_precise()
local function finish()
 if reaper.time_precise()-start<4 then reaper.defer(finish);return end
 if fx>=0 then reaper.TrackFX_Delete(track,fx) end
 -- task-owned disposable project; do not save
 local f=assert(io.open(root.."finished.txt","w"));f:write("editor never opened; processor removed");f:close()
 reaper.Main_OnCommand(40004,0)
end
reaper.defer(finish)
''')
env=dict(os.environ, DISPLAY=':94',XDG_RUNTIME_DIR='/run/user/1000', XDG_CONFIG_HOME=str(run/'config'),XDG_CACHE_HOME=str(run/'cache'),TMPDIR=str(run/'tmp'),DANDRUM_VST3_PROBE_LOG=str(run/'plugin.log'),LIBGL_ALWAYS_SOFTWARE='1')
env.pop('XAUTHORITY',None)
children=[]; results={}; started=time.monotonic()
try:
 assert not Path('/tmp/.X11-unix/X94').exists(), 'display occupied'
 xlog=(run/'xvfb.log').open('w'); x=subprocess.Popen(['/tmp/dandrum-task-7-3/xvfb/usr/bin/Xvfb',':94','-screen','0','1600x1200x24','-nolisten','tcp'],stdout=xlog,stderr=xlog,start_new_session=True);children.append(x)
 for _ in range(50):
  if Path('/tmp/.X11-unix/X94').exists():break
  assert x.poll() is None
  time.sleep(.05)
 wlog=(run/'wm.log').open('w');wm=subprocess.Popen(['xfwm4','--compositor=off'],env=env,stdout=wlog,stderr=wlog,start_new_session=True);children.append(wm)
 log=(run/'reaper.log').open('w'); daw=subprocess.Popen(['pw-jack','/tmp/dandrum-task-7-3/reaper_linux_x86_64/REAPER/reaper','-newinst','-new','-nosplash','-cfgfile',str(run/'reaper.ini'),str(run/'setup.lua')],env=env,cwd=run,stdout=log,stderr=log,start_new_session=True);children.append(daw)
 (run/'runtime.json').write_text(json.dumps({'pids':[c.pid for c in children],'start':time.time()}))
 for n in range(80):
  if daw.poll() is not None:break
  if n in (12,40):
   names=subprocess.run(['xdotool','search','--onlyvisible','--name','.*'],env=env,capture_output=True,text=True)
   windows=[]
   for wid in names.stdout.split():
    name=subprocess.run(['xdotool','getwindowname',wid],env=env,capture_output=True,text=True).stdout.strip();windows.append([wid,name])
    if name == 'REAPER Query':
     subprocess.run(['xdotool','mousemove','790','612','click','1'],env=env,capture_output=True)
    elif name.startswith('About REAPER'):
     subprocess.run(['xdotool','mousemove','799','672','click','1'],env=env,capture_output=True)
   (run/f'windows-{n}.json').write_text(json.dumps(windows))
  if n==40:
   from PIL import ImageGrab
   ImageGrab.grab(xdisplay=':94').save(run/'native-screen.png')
  time.sleep(.5)
 results['reaper_exit']=daw.poll(); results['timed_out']=daw.poll() is None
finally:
 for child in reversed(children):
  if child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
 results['children']=[{'pid':c.pid,'exit':c.returncode} for c in children];results['elapsed_seconds']=time.monotonic()-started
 (run/'receipt.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results))
