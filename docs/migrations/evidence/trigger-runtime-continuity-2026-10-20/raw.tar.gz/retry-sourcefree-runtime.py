"""One-off corrected-test retry in the retained actual source-free fixture."""
from pathlib import Path
import os,shutil,hashlib,json,subprocess,signal,time
out=Path('/tmp/dandrum-lanes/evidence-runtime-continuity');root=Path('/tmp/dandrum-lanes/runtime');copy=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source');fixture=copy/'build/engine-only-regression/fixture-kwjt48yz/source';build=fixture/'build/trigger-editor'
assert not (fixture/'web').exists() and not (fixture/'third_party').exists() and not (fixture/'ui').exists()
old=json.loads((out/'guard-final/source-manifest.json').read_text());changed={}
for name,digest in old.items():
 p=root/name;q=copy/name;f=fixture/name;current=hashlib.sha256(p.read_bytes()).hexdigest()
 if current!=digest:changed[name]=dict(guard_sha256=digest,current_sha256=current)
 assert hashlib.sha256(q.read_bytes()).hexdigest()==digest,name
 # Resource-build test modifies its owned bundle, not these source inputs.
 assert hashlib.sha256(f.read_bytes()).hexdigest()==digest,name
assert set(changed)=={'src/trigger-host/src/runtime.rs'},changed
# Production ordinary-lease change was already compiled by full guard; this
# retry changes only the failed test's API use and rustfmt in cfg(test) module.
for name in changed:shutil.copy2(root/name,copy/name);shutil.copy2(root/name,fixture/name)
cmd=['/home/dan/.local/bin/ctest','--test-dir',str(build),'--output-on-failure','-R','^(clap-dynamic-host|trigger-host-tests|trigger-editor-tests)$']
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_NET_OFFLINE='true')
samples=[];stop=None;start=time.monotonic()
with (out/'sourcefree-retry.log').open('wb') as f:
 p=subprocess.Popen(cmd,cwd=fixture,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  disk=os.statvfs(root);ram=os.statvfs('/dev/shm');mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
  sample=dict(elapsed=time.monotonic()-start,disk=disk.f_bavail*disk.f_frsize,ram=ram.f_bavail*ram.f_frsize,mem=mem);samples.append(sample)
  if sample['disk']<256*1024**2 or sample['ram']<1024**3 or mem<4*1024**3:
   stop='Resource floor; caches preserved';os.killpg(p.pid,signal.SIGINT);break
  time.sleep(.5)
 code=p.wait()
for name in old:assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==hashlib.sha256((root/name).read_bytes()).hexdigest(),name
r=dict(command=cmd,cwd=str(fixture),environment={'PATH':env['PATH'],'CARGO_NET_OFFLINE':'true'},exit_code=code,elapsed_seconds=time.monotonic()-start,stop_reason=stop,qualified_retry_of='guard-final failed only test API compilation; original full build/resource/inventory/dependency checks passed',changed_inputs=changed,all586FinalSourceInputsEqual=True,absentTrees=['web','ui','third_party'],resource_samples=samples,log_sha256=hashlib.sha256((out/'sourcefree-retry.log').read_bytes()).hexdigest())
(out/'sourcefree-retry.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='resource_samples'}));raise SystemExit(code if code>=0 else 128-code)
