"""One-off exact-source final verification receipt for ordinary runtime continuity."""
from pathlib import Path
import subprocess,json,hashlib,os,time,sys
out=Path('/tmp/dandrum-lanes/evidence-runtime-continuity');root=Path('/tmp/dandrum-lanes/runtime')
env=dict(os.environ,PATH='/home/dan/.cargo/bin:/home/dan/.local/bin:/usr/bin:/bin',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR='/tmp/dandrum-lanes/cache-runtime',CARGO_LLVM_COV_TARGET_DIR='/dev/shm/dandrum-beta-20261020/llvm-cov-target',CARGO_LLVM_COV_BUILD_DIR='/dev/shm/dandrum-beta-20261020/llvm-cov-target')
commands=[('final-format',['cargo','fmt','--manifest-path','src/trigger-host/Cargo.toml']),('final-format-check',['cargo','fmt','--manifest-path','src/trigger-host/Cargo.toml','--','--check']),('final-clippy',['cargo','clippy','--manifest-path','src/trigger-host/Cargo.toml','--all-targets','--','-D','warnings']),('final-coverage',['cargo','llvm-cov','--manifest-path','src/trigger-host/Cargo.toml','--lcov','--output-path',str(out/'final-host.lcov')]),('session-regression',['cargo','test','--manifest-path','src/instrument-session/Cargo.toml'])]
for name,cmd in commands:
 disk=os.statvfs(root);ram=os.statvfs('/dev/shm');mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 assert disk.f_bavail*disk.f_frsize>256*1024**2 and ram.f_bavail*ram.f_frsize>1024**3 and mem>4*1024**3, 'resource floor; preserve caches'
 if name!='final-format':
  (out/(name+'-sources.json')).write_text(json.dumps({p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['src/trigger-host/src/runtime.rs','src/trigger-host/tests/runtime.rs','src/instrument-session/src/lib.rs']},indent=2)+'\n')
 t=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec=dict(command=cmd,cwd=str(root),environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR']},elapsed_seconds=time.monotonic()-t,exit_code=r.returncode,log_sha256=hashlib.sha256((out/(name+'.log')).read_bytes()).hexdigest(),disk_free_before=disk.f_bavail*disk.f_frsize,ram_free_before=ram.f_bavail*ram.f_frsize,mem_available_before=mem)
 (out/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
