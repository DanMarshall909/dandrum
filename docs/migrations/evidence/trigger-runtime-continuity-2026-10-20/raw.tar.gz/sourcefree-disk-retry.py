"""One-off source-free retry with compiler outputs on disk and incremental off."""
from pathlib import Path
import os,hashlib,json,subprocess,signal,time
out=Path('/tmp/dandrum-lanes/evidence-runtime-continuity');root=Path('/tmp/dandrum-lanes/runtime');fixture=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source');build=fixture/'build/trigger-editor'
original=json.loads((out/'guard-final/source-manifest.json').read_text());manifest={}
for name in original:
 current=hashlib.sha256((root/name).read_bytes()).hexdigest();assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==current,name;manifest[name]=current
assert len(manifest)==586
assert not any((fixture/name).exists() for name in ['web','ui','third_party'])
target=(build/'rust-target').resolve();assert str(target)=='/tmp/dandrum-lanes/cache-editor-guard',target
(out/'sourcefree-disk-retry-inputs.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
cmd=['/home/dan/.local/bin/ctest','--test-dir',str(build),'--output-on-failure','-R','^(clap-dynamic-host|trigger-host-tests|trigger-editor-tests)$']
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_NET_OFFLINE='true',CARGO_INCREMENTAL='0',TMPDIR='/tmp')
samples=[];stop=None;start=time.monotonic()
with (out/'sourcefree-disk-retry.log').open('wb') as f:
 p=subprocess.Popen(cmd,cwd=fixture,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 owned_pid=p.pid
 while p.poll() is None:
  disk=os.statvfs(target);ram=os.statvfs('/dev/shm');mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
  sample=dict(elapsed=time.monotonic()-start,disk=disk.f_bavail*disk.f_frsize,ram=ram.f_bavail*ram.f_frsize,mem=mem);samples.append(sample)
  if sample['disk']<1024**3 or sample['ram']<256*1024**2 or mem<4*1024**3:
   stop='Disk1GiB/RAMfs256MiB/MemAvailable4GiB floor; caches preserved';os.killpg(p.pid,signal.SIGINT);break
  time.sleep(.5)
 code=p.wait()
for name,digest in manifest.items():assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest and hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
r=dict(command=cmd,cwd=str(fixture),environment={k:env[k] for k in ['PATH','CARGO_NET_OFFLINE','CARGO_INCREMENTAL','TMPDIR']},owned_pid=owned_pid,owned_pgid=owned_pid,exit_code=code,elapsed_seconds=time.monotonic()-start,stop_reason=stop,qualification='Corrected test/API and formatting only since full source-free build/resource/inventory/dependency checks. Actual3CTestretry disables incremental compiler output; not a fresh complete default-profile guard.',compiler_target=str(target),all586FinalSourceInputsEqual=True,ram_floor_basis='256MiB only for this disk-backed nonincremental retry; RAM cache output disabled; MemAvailable4GiB floor retained. Prior1GiBfloor attempt stopped honestly.',resource_samples=samples,log_sha256=hashlib.sha256((out/'sourcefree-disk-retry.log').read_bytes()).hexdigest())
(out/'sourcefree-disk-retry.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='resource_samples'}));raise SystemExit(code if code>=0 else 128-code)
