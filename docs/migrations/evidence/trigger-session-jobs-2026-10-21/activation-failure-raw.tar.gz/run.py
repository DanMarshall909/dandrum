import os,sys,subprocess,time,json,pathlib,hashlib,shutil,signal,re
root=pathlib.Path('/tmp/dandrum-lanes/protocol');base=pathlib.Path('/tmp/dandrum-lanes/evidence-session-jobs-activation-failure');phase=sys.argv[1];command=sys.argv[2:];dest=base/phase;dest.mkdir(exist_ok=False)
env=os.environ.copy()
for key in ['CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']:env.pop(key,None)
env.update(CARGO_TARGET_DIR='/tmp/dandrum-lanes/cache-editor-guard',CARGO_BUILD_JOBS='1',TMPDIR=str(base/'scratch'))
paths=['src/trigger-host/tests/runtime.rs','src/trigger-host/src/runtime.rs','src/trigger-host/src/parameters.rs','src/trigger-host/src/protocol.rs','src/instrument-session/src/lib.rs','src/trigger-host/tests/parameters.rs','src/trigger-host/tests/session_jobs.rs','src/trigger-host/Cargo.toml','src/trigger-host/Cargo.lock'];hashes={}
for rel in paths:
 p=root/rel;data=p.read_bytes();hashes[rel]=hashlib.sha256(data).hexdigest();copy=dest/rel;copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(data)
expected=json.loads(pathlib.Path('/tmp/dandrum-evidence/session-jobs-integration/integration.json').read_text())['source_sha256_after']
for rel,h in expected.items():
 if rel.startswith('src/'):assert hashes[rel]==h,(rel,hashes[rel],h)
def resource():return {'disk_free':shutil.disk_usage('/tmp').free,'ramfs_free':shutil.disk_usage('/dev/shm').free,'memory_available':next(int(l.split()[1])*1024 for l in pathlib.Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))}
def low(r):return r['disk_free']<1024**3 or r['ramfs_free']<256*1024**2 or r['memory_available']<4*1024**3
start=time.monotonic();samples=[resource()];pid=None;code=None;reason=None
if low(samples[0]):reason='resource floor before launch'
else:
 with (dest/'output.log').open('w') as log:
  proc=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);pid=proc.pid
  while proc.poll() is None:
   time.sleep(.25);samples.append(resource())
   if low(samples[-1]):reason='resource floor';os.killpg(pid,signal.SIGTERM);proc.wait();break
  code=proc.returncode
log=(dest/'output.log').read_text() if (dest/'output.log').exists() else '';binaries={}
for name in set(re.findall(r'/tmp/dandrum-lanes/cache-editor-guard/debug/deps/[A-Za-z_]+-[0-9a-f]+(?=[`\s)])',log)):
 p=pathlib.Path(name)
 if p.is_file():binaries[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size}
keys=['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','TMPDIR','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']
r={'command':command,'cwd':str(root),'environment':{k:env.get(k) for k in keys},'source_hashes':hashes,'exit':code,'pid':pid,'seconds':time.monotonic()-start,'stop_reason':reason,'resource_first':samples[0],'resource_last':samples[-1],'resource_min':{k:min(r[k] for r in samples) for k in samples[0]},'executed_binaries':binaries};(dest/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['exit','seconds','stop_reason','resource_min','executed_binaries']}));print(log[-3500:]);sys.exit(code if code is not None else 99)
