# Criterion4 loop closure

04-red observed a forged numeric attachment owner being accepted for another editor's held parameter gesture. Revised existing mutated-command assertion also failed with InvalidValue instead of sealed StaleRequest; its first selector matched zero and is explicitly not RED, exact-name rerun04-red-mutated-command-exact captured the genuine assertion.

The minimal production change routes parameter apply through the same admitted_context as snapshot/admission/status, using the connection's actual native attachment/correlation. 23 parameter/snapshot/job tests and31 focusedLLVM owner tests pass; all-target strict Clippy and formatting pass. Forged native request attachment cannot replace the private controller stamp. Valid original owner retains balanced ordinary behavior.

Covered refactor: remove duplicate InvalidValue guard/unused enum variant after sealed exact-command recovery establishes protocol normalization checks remain valid. Only maintained consumer was the forged-command test, now asserting StaleRequest. Existing real ingress malformed/out-of-range tests retain that boundary. No legacy compatibility data/caller requires a redundant post-seal validation branch. Test helpers already keep the explicit ownership cases concise; no additional extraction is useful.
