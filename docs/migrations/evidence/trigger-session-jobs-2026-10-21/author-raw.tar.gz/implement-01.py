from pathlib import Path
w=Path('/tmp/dandrum-lanes/protocol/src/trigger-host/src')
p=w/'runtime.rs';s=p.read_text();needle='impl RuntimeControl {\n';assert s.count(needle)==1;s=s.replace(needle,needle+'    pub(crate) fn activation_available(&self) -> bool {\n        !self.in_flight\n    }\n\n');s=s.replace('if self.in_flight {','if !self.activation_available() {').replace('if self.in_flight || !self.compatible(&next) {','if !self.activation_available() || !self.compatible(&next) {');p.write_text(s)
p=w/'protocol.rs';s=p.read_text();needle='pub const OUTBOUND_BYTES_LIMIT: usize = 64 * 1024;';s=s.replace(needle,'''pub(crate) struct AdmittedContext {
    pub instance_id: u64,
    pub attachment_id: u64,
    pub attachment: Attachment,
    pub snapshot: SessionSnapshot,
}

'''+needle);s=s.replace('pub(crate) fn admitted_snapshot(', 'pub(crate) fn admitted_context(').replace(') -> Result<(String, SessionSnapshot), ProtocolError> {',') -> Result<AdmittedContext, ProtocolError> {').replace('Ok((self.instance_id.to_string(), snapshot))','''Ok(AdmittedContext {
            instance_id: self.instance_id.get(),
            attachment_id: connection.id,
            attachment: connection.attachment.clone(),
            snapshot,
        })''');p.write_text(s)
p=w/'parameters.rs';s=p.read_text().replace('    Host(String),','    Host(String),\n    Session(dandrum_instrument_session::SessionError),\n    UnknownJob,\n    InvalidJob,')
pos=s.index('pub struct ParameterController {');s=s[:pos]+'''/// A native job can leave the controller for preparation without an editor.
/// Its private identity must return with the completion to the same active slot.
pub struct SessionPreparation {
    authority: std::sync::Arc<()>,
    request_id: dandrum_instrument_session::RequestId,
    job: dandrum_instrument_session::MappingJob,
}
pub struct SessionCompletion {
    authority: std::sync::Arc<()>,
    request_id: dandrum_instrument_session::RequestId,
    job: dandrum_instrument_session::PreparedMappingJob,
}
impl SessionPreparation {
    pub fn prepare(self) -> SessionCompletion {
        SessionCompletion { authority: self.authority, request_id: self.request_id, job: self.job.prepare() }
    }
}
pub struct RejectedSessionCompletion {
    completion: SessionCompletion,
}
impl RejectedSessionCompletion {
    pub fn into_completion(self) -> SessionCompletion { self.completion }
}
impl std::fmt::Debug for RejectedSessionCompletion {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.debug_struct("RejectedSessionCompletion").finish_non_exhaustive()
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SessionJobProgress { Idle, Pending, Completed }
struct ActiveSessionJob {
    authority: std::sync::Arc<()>,
    request_id: dandrum_instrument_session::RequestId,
    work: SessionWork,
}
enum SessionWork {
    Queued(dandrum_instrument_session::MappingJob),
    Preparing,
    Ready(dandrum_instrument_session::PreparedMappingJob),
}

'''+s[pos:];s=s.replace('pub struct ParameterController {\n','pub struct ParameterController {\n    session_job: Option<ActiveSessionJob>,\n').replace('            Self {\n                host,','            Self {\n                session_job: None,\n                host,')
s=s.replace('''        let (instance_id, snapshot) = self
            .protocol
            .admitted_snapshot(self.host.session(), request)
            .map_err(ParameterError::Protocol)?;''','''        let context = self.protocol.admitted_context(self.host.session(), request)
            .map_err(ParameterError::Protocol)?;
        let snapshot = context.snapshot;
        let instance_id = context.instance_id.to_string();''')
pos=s.index('    pub fn apply(')
s=s[:pos]+'''    /// Admit structural work once. Transport correlation is separate from the
    /// native request ID retained by the persistent session.
    pub fn admit_session_command(&mut self, request: &AdmittedRequest) -> Result<String, ParameterError> {
        use dandrum_instrument_session::{MappingAdmission, MappingRequest};
        let context = self.protocol.admitted_context(self.host.session(), request)
            .map_err(ParameterError::Protocol)?;
        let (id, admission) = match &request.command {
            EditorCommand::SetZoneKeyRange { identity, intent } => (identity.request_id,
                self.host.session_mut().admit_mapping(&context.attachment, MappingRequest {
                    instance: context.snapshot.instance, request_id: identity.request_id,
                    expected_revision: identity.expected_revision, intent: intent.clone(),
                })),
            _ => return Err(ParameterError::UnsupportedCommand),
        };
        match admission.map_err(ParameterError::Session)? {
            MappingAdmission::Admitted(job) => {
                self.session_job = Some(ActiveSessionJob { authority: std::sync::Arc::new(()), request_id:id, work:SessionWork::Queued(job) });
            }
            MappingAdmission::Pending | MappingAdmission::Completed(_) => {}
        }
        self.protocol.encode_reply(self.host.session(), &context.attachment_id.to_string(),
            &request.request_id.to_string(), Ok(serde_json::json!({"status":"accepted","job_id":id.0.to_string()})))
            .map_err(ParameterError::Protocol)
    }
    pub fn take_session_preparation(&mut self) -> Option<SessionPreparation> {
        let active = self.session_job.as_mut()?;
        match std::mem::replace(&mut active.work, SessionWork::Preparing) {
            SessionWork::Queued(job) => Some(SessionPreparation { authority: active.authority.clone(), request_id:active.request_id, job }),
            work => { active.work=work; None }
        }
    }
    pub fn submit_session_completion(&mut self, completion: SessionCompletion) -> Result<(), RejectedSessionCompletion> {
        let Some(active) = self.session_job.as_mut().filter(|active| active.request_id == completion.request_id
            && std::sync::Arc::ptr_eq(&active.authority, &completion.authority)
            && matches!(active.work, SessionWork::Preparing)) else {
                return Err(RejectedSessionCompletion { completion });
        };
        active.work = SessionWork::Ready(completion.job);
        Ok(())
    }
    /// A bounded main/control service step. Preparation is performed elsewhere;
    /// returned retired processors are destroyed only here, away from audio.
    pub fn service_session_jobs(&mut self) -> Result<SessionJobProgress, ParameterError> {
        drop(self.runtime.reclaim());
        let Some(active) = self.session_job.as_ref() else { return Ok(SessionJobProgress::Idle); };
        if !matches!(active.work, SessionWork::Ready(_)) { return Ok(SessionJobProgress::Pending); }
        let next_generation = document_generation(self.generation)?;
        let active = self.session_job.take().expect("ready session job exists");
        let SessionWork::Ready(completion) = active.work else { unreachable!("ready session job checked above") };
        let outcome = match self.host.session_mut().complete_mapping(completion, &mut self.runtime) {
            Ok(outcome) => outcome,
            Err(route) => {
                self.session_job = Some(ActiveSessionJob { authority: active.authority, request_id: active.request_id, work:SessionWork::Ready(route.into_completion()) });
                return Err(ParameterError::InvalidJob);
            }
        };
        if outcome.result.is_ok() { self.generation = next_generation; }
        Ok(SessionJobProgress::Completed)
    }
    pub fn session_job_status(&self, request: &AdmittedRequest) -> Result<String, ParameterError> {
        let context = self.protocol.admitted_context(self.host.session(), request)
            .map_err(ParameterError::Protocol)?;
        let EditorCommand::GetInstrumentSessionJobStatus { request_id } = request.command else { return Err(ParameterError::UnsupportedCommand); };
        let result = if self.session_job.as_ref().is_some_and(|active| active.request_id == request_id) {
            serde_json::json!({"request_id":request_id.0.to_string(),"state":"running","revision":context.snapshot.revision.to_string(),"undoCount":context.snapshot.undo_len,"redoCount":context.snapshot.redo_len,"error":""})
        } else {
            let outcome = self.host.session().request_outcome(&context.attachment,request_id)
                .map_err(ParameterError::Session)?.ok_or(ParameterError::UnknownJob)?;
            match &outcome.result {
                Ok(snapshot) => serde_json::json!({"request_id":request_id.0.to_string(),"state":"completed","revision":snapshot.revision.to_string(),"undoCount":snapshot.undo_len,"redoCount":snapshot.redo_len,"error":""}),
                Err(error) => serde_json::json!({"request_id":request_id.0.to_string(),"state":"failed","revision":context.snapshot.revision.to_string(),"undoCount":context.snapshot.undo_len,"redoCount":context.snapshot.redo_len,"error":format!("{error:?}")}),
            }
        };
        self.protocol.encode_reply(self.host.session(), &context.attachment_id.to_string(), &request.request_id.to_string(), Ok(result)).map_err(ParameterError::Protocol)
    }

'''+s[pos:];p.write_text(s)
