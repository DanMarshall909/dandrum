# Criterion5 loop closure

A genuine invalid-zone preparation keeps accepted YAML/history/generation/scalars/signed PCM and a retained failed outcome across detach/reconnect. Unknown status is explicitly UnknownJob. RED05-red showed initial code fabricating historical metadata from the current snapshot for a failure that has no snapshot. The smallest correction emits only native request_id/state/error for failed outcomes, as consumed by production pollJob. Five job tests, strict Clippy/format and focusedLLVM32tests pass.

Production refactor removes misleading failed metadata rather than creating a second history record. Existing session RequestFailure remains the actual error owner. Test helpers already expose the independent failure/preservation oracle clearly. Next ownership/window tests characterize other already present minimal slot protection before any further production refactor; they will not be advertised as invented RED failures.
