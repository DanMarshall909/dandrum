    #[test]
    fn activation_readiness_returns_only_after_control_reclaims_retired_runtime() {
        let (mut control, mut audio) = gain_runtime();
        assert!(control.activation_available());
        let (_, replacement) = gain_runtime();
        assert!(control.offer(replacement.state.current).is_ok());
        assert!(
            !control.activation_available(),
            "pending publication owns the slot"
        );
        audio.process(&mut [0.0; 16], &mut [0.0; 16]).unwrap();
        assert!(
            !control.activation_available(),
            "audio consumption does not reclaim"
        );
        drop(control.reclaim().unwrap());
        assert!(control.activation_available());
    }

