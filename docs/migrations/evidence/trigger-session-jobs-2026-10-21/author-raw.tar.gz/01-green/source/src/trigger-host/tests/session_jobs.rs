use dandrum_trigger_host::parameters::{ParameterController, SessionJobProgress};
use dandrum_trigger_host::protocol::{Admission, AdmittedRequest};
use dandrum_trigger_host::runtime::{ControlEvent, RuntimeAudio, TimedEvent};
use dandrum_trigger_host::{ADVANCED_DRUM_KIT_DOCUMENT, ADVANCED_DRUM_KIT_SAMPLE, TriggerHostConfiguration};
use serde_json::{Value, json};
use std::{num::NonZeroU64, path::PathBuf, sync::mpsc, time::Duration};

fn package() -> (tempfile::TempDir, PathBuf) {
    let temporary = tempfile::tempdir().unwrap();
    let root = temporary.path().join("Trigger.resources");
    std::fs::create_dir_all(root.join("instrument/assets")).unwrap();
    let repository = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..");
    for (source, destination) in [("examples/patches/advanced-drum-kit.yaml", ADVANCED_DRUM_KIT_DOCUMENT),("examples/patches/assets/advanced-drums.wav", ADVANCED_DRUM_KIT_SAMPLE)] {
        std::fs::copy(repository.join(source),root.join(destination)).unwrap();
    }
    (temporary,root)
}
fn open(root: &std::path::Path) -> (ParameterController,RuntimeAudio) {
    ParameterController::open(root, TriggerHostConfiguration{sample_rate_hz:48000,max_block_frames:16},NonZeroU64::new(9007199254740993).unwrap(),4,8).unwrap()
}
fn request(host: &mut ParameterController, attachment: &str, id:u64, method:&str,args:Value)->AdmittedRequest {
    let message=json!({"version":1,"attachmentId":attachment,"requestId":id.to_string(),"method":method,"args":args}).to_string();
    match host.admit(&message).unwrap(){Admission::New(request)=>request,Admission::Duplicate{..}=>panic!("expected new transport request")}
}
fn result(reply: String)->Value { let value:Value=serde_json::from_str(&reply).unwrap();assert_eq!(value["status"],"accepted");value["result"].clone() }
fn status(host:&mut ParameterController,attachment:&str,transport:u64,job:&str)->Value {
    let read=request(host,attachment,transport,"getInstrumentSessionJobStatus",json!([job]));
    result(host.session_job_status(&read).unwrap())
}
fn snapshot(host:&mut ParameterController,attachment:&str,transport:u64)->Value {
    let read=request(host,attachment,transport,"getSamplerSession",json!([]));
    result(host.sampler_session_reply(&read).unwrap())
}
fn mapping(host:&mut ParameterController,attachment:&str,transport:u64,job:&str,revision:&str,note:u8)->AdmittedRequest {
    request(host,attachment,transport,"setInstrumentZoneKeyRange",json!(["9007199254740993",attachment,job,revision,"kit","kick",note,note]))
}
fn render(audio:&mut RuntimeAudio,note:u8)->([f32;16],[f32;16]) {
    audio.reset();
    let (mut left,mut right)=([0.;16],[0.;16]);
    let allocation=allocation_counter::measure(|| { audio.process_events(&mut left,&mut right,&[TimedEvent{frame_offset:0,event:ControlEvent::NoteOn{note,velocity:100}}]).unwrap(); });
    assert_eq!(allocation,allocation_counter::AllocationInfo::default());
    (left,right)
}
#[test]
fn admitted_mapping_survives_editor_loss_and_recovers_one_native_outcome() {
    let (_package,root)=package();let (mut host,mut audio)=open(&root);let editor=host.attach_editor().unwrap();
    let command=mapping(&mut host,&editor.attachment_id,90,"1","0",60);
    assert_eq!(result(host.admit_session_command(&command).unwrap()),json!({"status":"accepted","job_id":"1"}));
    assert_eq!(status(&mut host,&editor.attachment_id,91,"1")["state"],"running");
    assert_eq!(snapshot(&mut host,&editor.attachment_id,92)["connection"]["nextRequestId"],"2");
    let preparation=host.take_session_preparation().unwrap();assert!(host.take_session_preparation().is_none());
    let (ready_tx,ready_rx)=mpsc::channel();let (release_tx,release_rx)=mpsc::channel();
    let worker=std::thread::spawn(move||{ready_tx.send(()).unwrap();release_rx.recv_timeout(Duration::from_secs(5)).unwrap();preparation.prepare()});
    ready_rx.recv_timeout(Duration::from_secs(5)).unwrap();
    host.detach_editor(&editor.attachment_id).unwrap();
    let (left,right)=render(&mut audio,36);assert_eq!((left[0],right[0]),(-0.5,-0.5));assert_eq!(render(&mut audio,60),([0.;16],[0.;16]));
    let fresh=host.attach_editor().unwrap();
    assert_eq!(status(&mut host,&fresh.attachment_id,1,"1")["state"],"running");
    release_tx.send(()).unwrap();host.submit_session_completion(worker.join().unwrap()).unwrap();
    assert_eq!(host.service_session_jobs().unwrap(),SessionJobProgress::Completed);
    let (left,right)=render(&mut audio,60);assert_eq!((left[0],right[0]),(-0.5,-0.5));assert_eq!(render(&mut audio,36),([0.;16],[0.;16]));
    let accepted=snapshot(&mut host,&fresh.attachment_id,2);
    assert_eq!(accepted["connection"]["revision"],"1");assert_eq!(accepted["connection"]["nextRequestId"],"2");assert_eq!(accepted["connection"]["history"],json!({"undoCount":1,"redoCount":0}));assert_eq!(accepted["document"]["generation"],2);
    assert_eq!(host.parameter_state().parameters[2].value,0.25);
    for id in 3..=135 {
        let retained=status(&mut host,&fresh.attachment_id,id,"1");
        assert_eq!(retained["state"],"completed");assert_eq!(retained["revision"],"1");assert_eq!(retained["undoCount"],1);
    }
    assert_eq!(host.service_session_jobs().unwrap(),SessionJobProgress::Idle);assert!(host.take_session_preparation().is_none());
    host.detach_editor(&fresh.attachment_id).unwrap();let reopened=host.attach_editor().unwrap();
    assert_eq!(status(&mut host,&reopened.attachment_id,1,"1")["revision"],"1");
    assert_eq!(snapshot(&mut host,&reopened.attachment_id,2)["connection"]["history"]["undoCount"],1);
    let (left,right)=render(&mut audio,60);assert_eq!((left[0],right[0]),(-0.5,-0.5));
}
