import subprocess,sys,time,json,pathlib,os,signal,hashlib
root=pathlib.Path('/tmp/dandrum-lanes/evidence-session-jobs');label=sys.argv[1];cmd=sys.argv[2:];phase=root/label;phase.mkdir();work=pathlib.Path('/tmp/dandrum-lanes/protocol')
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/dandrum-lanes/cache-editor-guard',CARGO_LLVM_COV_TARGET_DIR='/dev/shm/dandrum-beta-20261020/host-snapshot-cov',CARGO_LLVM_COV_BUILD_DIR='/dev/shm/dandrum-beta-20261020/host-snapshot-cov',CARGO_BUILD_JOBS='2',TMPDIR='/tmp')
paths=['src/trigger-host/src/parameters.rs','src/trigger-host/src/protocol.rs','src/trigger-host/src/runtime.rs','src/instrument-session/src/lib.rs','src/trigger-host/tests/session_jobs.rs','src/trigger-host/tests/parameters.rs','src/trigger-host/Cargo.toml','src/trigger-host/Cargo.lock'];hashes={}
for name in paths:
 p=work/name
 if p.exists():
  b=p.read_bytes();dest=phase/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);hashes[name]=hashlib.sha256(b).hexdigest()
def sample():
 a=os.statvfs('/tmp');b=os.statvfs('/dev/shm');mem={x.split(':',1)[0]:int(x.split()[1])*1024 for x in pathlib.Path('/proc/meminfo').read_text().splitlines()};return {'disk':a.f_bavail*a.f_frsize,'ramfs':b.f_bavail*b.f_frsize,'memory':mem['MemAvailable']}
def safe(s):return s['disk']>=1024**3 and s['ramfs']>=256*1024**2 and s['memory']>=4*1024**3
start=time.monotonic();samples=[sample()];assert safe(samples[0]),samples
with (phase/'output.log').open('w') as f:
 p=subprocess.Popen(cmd,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);stopped=None
 while p.poll() is None:
  s=sample();samples.append(s)
  if not safe(s):
   stopped={'reason':'resource floor','sample':s};os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.25)
 code=p.wait()
result={'command':cmd,'cwd':str(work),'exit':code,'seconds':time.monotonic()-start,'pidAndPgid':p.pid,'environment':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_LLVM_COV_TARGET_DIR','CARGO_LLVM_COV_BUILD_DIR','CARGO_BUILD_JOBS','TMPDIR']},'source_hashes':hashes,'resource_first':samples[0],'resource_min':{k:min(s[k] for s in samples) for k in samples[0]},'stop':stopped};(phase/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'phase':label,'exit':code,'seconds':result['seconds'],'resource_min':result['resource_min'],'stop':stopped}));print((phase/'output.log').read_text()[-1400:]);sys.exit(code)
