# Criterion3 loop closure

Real native undo was UnsupportedCommand in03-red; production adds only dispatch to the existing admit_undo and its pub visibility. Three job tests, strict Clippy, formatting and focusedLLVM11tests pass. Actual signed-.5 audio returns36,60silence, with native revision/history/generation; a later edit truncates redo while status of the known undo request still returns its retained historical revision/counts. Recovery does not redispatch undo. Public exposure is exercised by the real host dependency call and actual behavior test, not a visibility-only mirror.

Refactoring: extracted only the repeated real take/thread/prepare/submit/service sequence into finish_preparation in tests; no production extraction or duplicate history owner is useful. Status remains backed by session outcomes, not copied terminal records. Failed/unknown status and authority/gesture paths are the remaining explicitly planned criteria.
