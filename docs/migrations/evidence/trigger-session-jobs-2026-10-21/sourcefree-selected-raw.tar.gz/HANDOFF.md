# Selected source-free release verification

PASS: parameters14 + runtime18 + session_jobs9 = **41 tests**, actual Cargo default optimized release, offline/locked/jobs1/incremental0. Test driver elapsed152.02s; dependency audit0.25s. Actual compiler flags include opt-level3, LTO, codegen-units1 and strip=debuginfo; verbose commands are retained.

Candidate HEAD24a4afe7e266f5458a7cc1ddac9f9e7c99947929. All589 prior retained fixture inputs verified against archived prior-source-manifest.json before mutation. EXACT7 approved changed/added Rust inputs updated and freshened;583 unchanged prior inputs retained bytes and mtimes. All590 current repository and fixture inputs verified before and after execution. No web/ui/third_party trees. Normal dependency audit contains no Clack/Wry/GTK/WebKit/JUCE.

Only copied fixture inputs changed; repository and Git untouched. Old assigned disk cache used for RELEASE only; no debug build, deletion or relocation. Actual elevated host namespace used for fixture operations, compiler, resource guards and audit. Earlier exploratory sandbox shm figure is excluded from evidence. Guards sampled every.25s with disk1GiB/shm256MiB/evidenceRAM256MiB/Mem4GiB floors; no floor crossed.

Exact source maps/update hashes, binary hashes, commands, environment, timing, logs and resource samples are in receipt.json, fixture-update.json, release-tests.json/log and dependencies.json/log. No owned workers remain; source-free fixture and cache execution ownership returned to root.

Proof is limited to the three selected actual source-free optimized integration binaries. This does not claim the full host suite, fresh complete guard, native CMake restaging, browser/CLAP or beta acceptance. No code refactor applies to this verification-only task.
