from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time,re
root=Path('/tmp/dandrum-lanes/protocol')
out=Path('/run/user/1000/dandrum-beta-20261020/session-jobs-sourcefree')
fixture=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source')
priorpath=Path('/run/user/1000/dandrum-beta-20261020/runtime-notes-r1-sourcefree/source-manifest.json')
target=Path('/tmp/dandrum-lanes/cache-editor-guard')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,obj):(out/name).write_text(json.dumps(obj,indent=2)+'\n')
def resources():
 d={k:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for k,p in [('disk','/tmp'),('shm','/dev/shm'),('evidence_ram','/run/user/1000')]}
 d['memory']=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 return d
floors={'disk':1024**3,'shm':256*1024**2,'evidence_ram':256*1024**2,'memory':4*1024**3}
def safe(s):return all(s[k]>=v for k,v in floors.items())
def inputs():
 result={'CMakeLists.txt':sha(root/'CMakeLists.txt')}
 for part in ('src','tests','examples','schema','scripts','spikes'):
  for parent,dirs,files in os.walk(root/part):
   dirs[:]=[d for d in dirs if d not in ('target','build','__pycache__')]
   for name in files:
    p=Path(parent)/name;assert not p.is_symlink();result[str(p.relative_to(root))]=sha(p)
 return result
assert safe(resources()),resources()
prior=json.loads(priorpath.read_text());assert len(prior)==589
shutil.copy2(priorpath,out/'prior-source-manifest.json')
priorstats={}
for n,d in prior.items():
 p=fixture/n;assert sha(p)==d,n;st=p.stat();priorstats[n]={'mtime_ns':st.st_mtime_ns,'size':st.st_size,'sha256':d}
save('prior-fixture-verified.json',priorstats)
current=inputs();assert len(current)==590;assert set(prior)<=set(current)
changes={n:{'previous_sha256':prior.get(n),'current_sha256':d} for n,d in current.items() if prior.get(n)!=d}
expected={'src/instrument-session/src/lib.rs','src/trigger-host/src/runtime.rs','src/trigger-host/src/parameters.rs','src/trigger-host/src/protocol.rs','src/trigger-host/tests/session_jobs.rs','src/trigger-host/tests/runtime.rs','src/trigger-host/tests/parameters.rs'}
assert set(changes)==expected,changes
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
mtimes=[]
for n in sorted(changes):
 p=fixture/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/n,p);before=p.stat().st_mtime_ns;os.utime(p,None);mtimes.append({'path':n,'copied_mtime_ns':before,'fresh_mtime_ns':p.stat().st_mtime_ns})
def verify():
 assert inputs()==current,'root changed'
 for n,d in current.items():assert sha(fixture/n)==d,n
 for n,st in priorstats.items():
  if n not in changes:assert (fixture/n).stat().st_mtime_ns==st['mtime_ns'],n
 assert not any((fixture/n).exists() for n in ('web','ui','third_party'))
verify();save('source-manifest.json',current);save('fixture-update.json',{'root':str(root),'head':head,'prior_inputs':len(prior),'current_inputs':len(current),'changes':changes,'freshened_only_changed':mtimes,'unchanged_prior_inputs':len(prior)-len(set(changes)&set(prior)),'all_inputs_verified_before_and_after_update':True})
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_TARGET_DIR=str(target),CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',TMPDIR=str(out/'scratch'))
removed={k:env.pop(k) for k in list(env) if k.startswith(('CARGO_PROFILE_','CARGO_LLVM_COV_')) or k in ('RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS')}
commands=[('release-tests',['/home/dan/.cargo/bin/cargo','test','--release','--offline','--locked','--jobs','1','--manifest-path',str(fixture/'src/trigger-host/Cargo.toml'),'--test','session_jobs','--test','runtime','--test','parameters','-vv']),('dependencies',['/home/dan/.cargo/bin/cargo','tree','--offline','--locked','--manifest-path',str(fixture/'src/trigger-host/Cargo.toml'),'--edges','normal','--prefix','none'])]
results=[]
for label,argv in commands:
 assert safe(resources()),resources()
 start=time.monotonic();samples=[];stop=None
 with (out/(label+'.log')).open('wb') as log:
  proc=subprocess.Popen(argv,cwd=fixture,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   s=resources();s['elapsed_seconds']=time.monotonic()-start;samples.append(s)
   if not safe(s):
    stop='Resource floor: stopped only owned process group; retained outputs/cache';os.killpg(proc.pid,signal.SIGINT)
    try:proc.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL)
    break
   time.sleep(.25)
  code=proc.wait()
 r={'argv':argv,'cwd':str(fixture),'environment':{k:env[k] for k in ('PATH','CARGO_TARGET_DIR','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','TMPDIR')},'removed_profile_instrumentation_environment':removed,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'pgid':proc.pid,'stop_reason':stop,'resource_samples':samples,'log_sha256':sha(out/(label+'.log'))}
 save(label+'.json',r);results.append(r);print(label,code,r['elapsed_seconds'],flush=True)
 if code!=0 or stop:verify();save('stopped.json',{'results':results,'all_inputs_still_match':True,'resources':resources()});raise SystemExit(1)
verify()
text=(out/'release-tests.log').read_text();counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',text)];assert counts==[14,18,9],counts
names={line.split()[0].lower() for line in (out/'dependencies.log').read_text().splitlines() if line.strip()};forbidden=[n for n in names if any(x in n for x in ('clack','wry','webkit','gtk','juce'))];assert not forbidden,forbidden
binaries=[]
for line in text.splitlines():
 if 'Running `' in line:
  m=re.search(r"(/tmp/dandrum-lanes/cache-editor-guard/release/deps/(?:parameters|runtime|session_jobs)-[a-f0-9]+)(?:'|`|\s)",line)
  if m:
   p=Path(m.group(1));binaries.append({'path':str(p),'sha256':sha(p),'size':p.stat().st_size})
assert len(binaries)==3,binaries
record={'head':head,'source_inputs':len(current),'all_root_and_fixture_inputs_match_before_after':True,'absent_trees':['web','ui','third_party'],'selected_counts':dict(zip(('parameters','runtime','session_jobs'),counts)),'total_passed':sum(counts),'profile':'Default optimized release; CARGO_INCREMENTAL=0; jobs1; no profile/instrumentation overrides; exact verbose compiler commands retained','scope_limit':'Selected actual source-free optimized Cargo integration binaries only; not full host suite, complete guard, CMake artifact restaging, native/browser/CLAP or beta acceptance','results':[{'gate':label,'exit_code':r['exit_code'],'elapsed_seconds':r['elapsed_seconds'],'pgid':r['pgid']} for (label,_),r in zip(commands,results)],'binaries':binaries,'forbidden_dependency_matches':forbidden,'resource_floors':floors,'final_resources':resources(),'cache_preserved':True,'source_changes':'Only seven approved copied fixture inputs updated; repository untouched','namespace':'All fixture/cache/process/resource operations executed elevated in actual host namespace'}
save('receipt.json',record);print(json.dumps(record),flush=True)
