from pathlib import Path
import os,json,hashlib,subprocess,time,signal,re
out=Path('/run/user/1000/dandrum-beta-20261020/session-jobs-sourcefree-full');(out/'scratch').mkdir()
prior=out.parent/'session-jobs-sourcefree';root=Path('/tmp/dandrum-lanes/protocol');fixture=Path('/dev/shm/dandrum-beta-20261020/editor-guard-source/build/engine-only-regression/fixture-kwjt48yz/source');target=Path('/tmp/dandrum-lanes/cache-editor-guard')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(out/n).write_text(json.dumps(x,indent=2)+'\n')
manifest=json.loads((prior/'source-manifest.json').read_text());assert len(manifest)==590
priorinventory={str(p.relative_to(prior)):sha(p) for p in prior.rglob('*') if p.is_file()};save('selected-evidence-before.json',priorinventory)
initialstats={n:(fixture/n).stat().st_mtime_ns for n in manifest}
def verify():
 for n,d in manifest.items():assert sha(root/n)==sha(fixture/n)==d,n
 assert all((fixture/n).stat().st_mtime_ns==m for n,m in initialstats.items())
 assert not any((fixture/n).exists() for n in ('web','ui','third_party'))
 assert {str(p.relative_to(prior)):sha(p) for p in prior.rglob('*') if p.is_file()}==priorinventory,'Selected evidence changed'
verify();save('source-manifest.json',manifest)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
floors={'disk':1024**3,'shm':256*1024**2,'evidence_ram':256*1024**2,'memory':4*1024**3}
def resources():
 d={k:os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for k,p in [('disk','/tmp'),('shm','/dev/shm'),('evidence_ram','/run/user/1000')]};d['memory']=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024;return d
def safe(s):return all(s[k]>=v for k,v in floors.items())
assert safe(resources()),resources()
env=dict(os.environ,PATH='/home/dan/.local/bin:/home/dan/.cargo/bin:/usr/bin:/bin',CARGO_TARGET_DIR=str(target),CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',TMPDIR=str(out/'scratch'))
removed={k:env.pop(k) for k in list(env) if k.startswith(('CARGO_PROFILE_','CARGO_LLVM_COV_')) or k in ('RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS')}
argv=['/home/dan/.cargo/bin/cargo','test','--release','--offline','--locked','--jobs','1','--manifest-path',str(fixture/'src/trigger-host/Cargo.toml'),'-vv']
start=time.monotonic();samples=[];stop=None
with (out/'full-host.log').open('wb') as log:
 proc=subprocess.Popen(argv,cwd=fixture,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll() is None:
  s=resources();s['elapsed_seconds']=time.monotonic()-start;samples.append(s)
  if not safe(s):
   stop='Resource floor crossed; stopped only owned process group; all cache/evidence retained';os.killpg(proc.pid,signal.SIGINT)
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL)
   break
  time.sleep(.25)
 code=proc.wait()
receipt={'head':head,'argv':argv,'cwd':str(fixture),'environment':{k:env[k] for k in ('PATH','CARGO_TARGET_DIR','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','TMPDIR')},'removed_profile_instrumentation_environment':removed,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'pgid':proc.pid,'stop_reason':stop,'resource_floors':floors,'resource_samples':samples,'log_sha256':sha(out/'full-host.log')}
save('execution.json',receipt);verify();print('full-host',code,receipt['elapsed_seconds'],flush=True)
workers=[]
for l in subprocess.check_output(['ps','-eo','pid=,pgid=,args='],text=True).splitlines():
 f=l.split(None,2)
 if len(f)>1 and int(f[1])==proc.pid:workers.append(l.strip())
assert not workers,workers
save('handback.json',{'remaining_owned_workers':workers,'pgid':proc.pid,'minimum_observed_free_bytes':{k:min(s[k] for s in samples) for k in floors},'final_resources':resources(),'source_inputs_still_match':590,'selected_evidence_preserved':True,'cache_preserved':True})
if code!=0 or stop:raise SystemExit(1)
text=(out/'full-host.log').read_text();counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',text)];doc=text.split('Doc-tests dandrum_trigger_host',1);assert len(doc)==2
normalcounts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',doc[0])];doccounts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',doc[1])];assert sum(normalcounts)==102,normalcounts;assert doccounts==[1],doccounts
binaries=[]
for line in text.splitlines():
 if 'Running `' in line:
  m=re.search(r'(/tmp/dandrum-lanes/cache-editor-guard/release/deps/[a-z_]+-[a-f0-9]+)(?:\s|`|\x27)',line)
  if m:
   p=Path(m.group(1));binaries.append({'path':str(p),'sha256':sha(p),'size':p.stat().st_size})
assert len(binaries)==len(normalcounts),(len(binaries),normalcounts)
result={'head':head,'source_inputs_verified_before_after':590,'selected_evidence_preserved':True,'fixture_bytes_and_mtimes_unchanged':True,'normal_test_binary_counts':normalcounts,'normal_passed':sum(normalcounts),'doc_passed':sum(doccounts),'binaries':binaries,'elapsed_seconds':receipt['elapsed_seconds'],'profile':'Default optimized RELEASE normal/uninstrumented full host Cargo test including doc test; offline/locked/jobs1/incremental0; exact verbose compiler flags retained','scope_limit':'Not default-symbol debug full-host proof; not complete source-free guard/CMake artifact restaging/native/browser/CLAP/beta acceptance','exit_code':code,'cache_preserved':True,'namespace':'Elevated actual host namespace throughout','remaining_owned_workers':workers}
save('receipt.json',result);print(json.dumps(result),flush=True)
