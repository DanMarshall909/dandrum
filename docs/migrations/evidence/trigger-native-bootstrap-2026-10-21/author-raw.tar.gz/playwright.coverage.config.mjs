import original from './playwright.config.mjs';
export default {...original,testDir:'/dev/shm/dnb',testMatch:'coverage.spec.mjs'};
