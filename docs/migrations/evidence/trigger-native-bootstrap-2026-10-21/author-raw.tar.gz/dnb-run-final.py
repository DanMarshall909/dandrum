import os,sys,subprocess,time,json,pathlib,signal,shutil
name=sys.argv[1];cmd=sys.argv[2:];out=pathlib.Path('/dev/shm/dandrum-beta-20261020/native-bootstrap-evidence');start=time.monotonic();env=os.environ.copy();env.update(TMPDIR='/dev/shm/dnb/tmp',npm_config_cache='/dev/shm/dnb/npm-cache',DNB_OUTPUT=str(out/(name+'-browser')))
owned={}
def processes():
 result={}
 for path in pathlib.Path('/proc').glob('[0-9]*/stat'):
  try:
   pid=int(path.parent.name);fields=path.read_text().rsplit(')',1)[1].split();result[pid]={'pid':pid,'ppid':int(fields[1]),'pgid':int(fields[2]),'startTicks':int(fields[19]),'state':fields[0]}
  except (OSError,ValueError):pass
 return result
def observe(root):
 current=processes();parents={root}|{pid for pid,entry in owned.items() if pid in current and current[pid]['startTicks']==entry['startTicks']}
 while True:
  added={pid for pid,entry in current.items() if entry['ppid'] in parents or pid==root}-parents
  if not added:break
  parents|=added
 for pid in parents:
  if pid in current:owned[pid]=current[pid]
 return current
with (out/(name+'.log')).open('w') as log,(out/(name+'-resources.jsonl')).open('w') as samples:
 p=subprocess.Popen(cmd,cwd='/tmp/dandrum-lanes/frontend/web/trigger',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);reason=None
 while p.poll() is None:
  current=observe(p.pid)
  mem=int(next(line.split()[1] for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))*1024
  sample={'elapsed':time.monotonic()-start,'disk':shutil.disk_usage('/tmp').free,'shm':shutil.disk_usage('/dev/shm').free,'memory':mem,'owned':list(owned.values())};samples.write(json.dumps(sample)+'\n');samples.flush()
  if sample['disk']<1024**3 or sample['shm']<256*1024**2 or mem<4*1024**3:
   reason='resource floor'
   for group in {entry['pgid'] for pid,entry in owned.items() if pid in current and current[pid]['startTicks']==entry['startTicks']}:
    try:os.killpg(group,signal.SIGTERM)
    except ProcessLookupError:pass
   break
  time.sleep(.25)
 try:status=p.wait(timeout=10)
 except subprocess.TimeoutExpired:
  current=observe(p.pid)
  for group in {entry['pgid'] for pid,entry in owned.items() if pid in current and current[pid]['startTicks']==entry['startTicks']}:
   try:os.killpg(group,signal.SIGKILL)
   except ProcessLookupError:pass
  status=p.wait()
current=observe(p.pid);remaining=[entry for pid,entry in owned.items() if pid in current and current[pid]['startTicks']==entry['startTicks'] and current[pid]['state']!='Z']
receipt={'name':name,'command':cmd,'cwd':'/tmp/dandrum-lanes/frontend/web/trigger','env':{k:env[k] for k in ['TMPDIR','npm_config_cache','DNB_OUTPUT']},'rootPgid':p.pid,'ownedProcesses':list(owned.values()),'remainingLive':remaining,'exit':status,'duration':time.monotonic()-start,'stop':reason}
(out/(name+'.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps({k:v for k,v in receipt.items() if k!='ownedProcesses'}));print('\n'.join((out/(name+'.log')).read_text().splitlines()[-20:]));sys.exit(status)
