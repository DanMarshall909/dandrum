import original from '/tmp/dandrum-lanes/frontend/web/trigger/vite.native.config.mjs';
export default {...original,root:'/tmp/dandrum-lanes/frontend/web/trigger',cacheDir:'/dev/shm/dnb/cache-native'};
