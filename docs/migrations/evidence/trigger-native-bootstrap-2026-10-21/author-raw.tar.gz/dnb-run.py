import os,sys,subprocess,time,json,pathlib,signal,shutil
name=sys.argv[1];cmd=sys.argv[2:];out=pathlib.Path('/dev/shm/dandrum-beta-20261020/native-bootstrap-evidence');start=time.monotonic();env=os.environ.copy();env.update(TMPDIR='/dev/shm/dnb/tmp',npm_config_cache='/dev/shm/dnb/npm-cache')
env['DNB_OUTPUT']=str(out/(name+'-browser'))
if name.startswith('coverage'):env['NODE_V8_COVERAGE']=str(out/name)
with (out/(name+'.log')).open('w') as log,(out/(name+'-resources.jsonl')).open('w') as samples:
 p=subprocess.Popen(cmd,cwd='/tmp/dandrum-lanes/frontend/web/trigger',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 reason=None
 while p.poll() is None:
  mem=int(next(line.split()[1] for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))*1024
  sample={'elapsed':time.monotonic()-start,'disk':shutil.disk_usage('/tmp').free,'shm':shutil.disk_usage('/dev/shm').free,'memory':mem};samples.write(json.dumps(sample)+'\n');samples.flush()
  if sample['disk']<1024**3 or sample['shm']<256*1024**2 or mem<4*1024**3:
   reason='resource floor';os.killpg(p.pid,signal.SIGTERM);break
  time.sleep(.25)
 try:status=p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);status=p.wait()
receipt={'name':name,'command':cmd,'cwd':'/tmp/dandrum-lanes/frontend/web/trigger','env':{k:env[k] for k in ['TMPDIR','npm_config_cache','NODE_V8_COVERAGE'] if k in env},'pgid':p.pid,'exit':status,'duration':time.monotonic()-start,'stop':reason}
(out/(name+'.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt));print('\n'.join((out/(name+'.log')).read_text().splitlines()[-35:]));sys.exit(status)
