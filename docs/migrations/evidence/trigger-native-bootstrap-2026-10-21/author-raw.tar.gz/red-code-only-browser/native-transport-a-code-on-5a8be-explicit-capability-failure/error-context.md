# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-transport.spec.mjs >> a code-only native protocol rejection displays its explicit capability failure
- Location: tests/browser/native-transport.spec.mjs:191:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  getByRole('alert')
Expected: "Native sampler failed: capabilityUnavailable"
Received: "Native sampler failed: "
Timeout:  5000ms

Call log:
  - Expect "toHaveText" getByRole('alert') with timeout 5000ms
  - waiting for getByRole('alert')
    14 × locator resolved to <div role="alert">Native sampler failed: </div>
       - unexpected value "Native sampler failed: "

```

```yaml
- alert: "Native sampler failed:"
```

# Test source

```ts
  101 |     window.nativeCalls=[];
  102 |     window.__DANDRUM_NATIVE__={protocolVersion:1,instanceId:initial.connection.instanceId,attachmentId:initial.connection.attachmentId,nextRequestId:'41'};
  103 |     window.ipc={postMessage(message){
  104 |       if(this!==window.ipc)throw Error('Wry IPC receiver was lost');
  105 |       const request=JSON.parse(message);window.nativeCalls.push(request);
  106 |       if(window.nativeCalls.length>2)throw Error('Unexpected repeated native request');
  107 |       if(request.method!=='getSamplerSession')throw Error('Unexpected native method '+request.method);
  108 |       window.__DANDRUM__.receiveNativeMessage(JSON.stringify({version:1,instanceId:initial.connection.instanceId,attachmentId:initial.connection.attachmentId,requestId:request.requestId,status:'accepted',result:initial}));
  109 |     }};
  110 |   },session());
  111 |   await page.goto('/');
  112 |   await expect(page.getByRole('banner').locator('[data-backend="native"]')).toBeVisible();
  113 |   await expect(page.locator('[data-knob="drums.level"]')).toBeVisible();
  114 |   await expect(page.getByRole('banner').getByTestId('backend-status')).toHaveText('Connected');
  115 |   expect(await page.evaluate(()=>window.nativeCalls)).toEqual([{version:1,attachmentId:'9007199254740993',requestId:'41',method:'getSamplerSession',args:[]}]);
  116 |   await expect(page.getByRole('alert')).toHaveCount(0);
  117 |   expect(errors).toEqual([]);
  118 | });
  119 | 
  120 | test('page disposal closes a pending native initialization once without rendering a late failure',async({page})=>{
  121 |   const errors=[];page.on('pageerror',error=>errors.push(error.message));
  122 |   await page.addInitScript(()=>{
  123 |     window.nativeCalls=[];
  124 |     window.__DANDRUM_NATIVE__={protocolVersion:1,instanceId:'17',attachmentId:'23'};
  125 |     window.ipc={postMessage(message){window.nativeCalls.push(JSON.parse(message));if(window.nativeCalls.length>1)throw Error('Unexpected native request after disposal');}};
  126 |   });
  127 |   await page.goto('/');await expect(page.getByRole('status')).toHaveText('Connecting to native sampler…');
  128 |   await page.evaluate(async()=>{
  129 |     const descriptor=window.__DANDRUM__;
  130 |     const listener=()=>{throw Error('Native event delivered after page disposal');};
  131 |     descriptor.backend.addEventListener('instrumentSessionChanged',listener);
  132 |     window.dispatchEvent(new Event('pagehide'));window.dispatchEvent(new Event('pagehide'));
  133 |     window.lateDelivery=descriptor.receiveNativeMessage(JSON.stringify({version:1,instanceId:'17',attachmentId:'23',event:'instrumentSessionChanged',sequence:'1',payload:{generation:9}}));
  134 |     window.afterClose=await descriptor.backend.getNativeFunction('getSamplerSession')().catch(error=>error.code);
  135 |   });
  136 |   await expect(page.getByRole('alert')).toHaveCount(0);
  137 |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  138 |   expect(await page.evaluate(()=>({calls:window.nativeCalls,late:window.lateDelivery,closed:window.afterClose}))).toEqual({calls:[{version:1,attachmentId:'23',requestId:'1',method:'getSamplerSession',args:[]}],late:'ignored',closed:'closed'});
  139 |   expect(errors).toEqual([]);
  140 | });
  141 | 
  142 | test('failed bootstrap initialization renders its native error and closes pending browser work',async({page})=>{
  143 |   await page.addInitScript(()=>{
  144 |     window.nativeCalls=[];
  145 |     window.__DANDRUM_NATIVE__={protocolVersion:1,instanceId:'17',attachmentId:'23'};
  146 |     window.ipc={postMessage(message){
  147 |       const request=JSON.parse(message);window.nativeCalls.push(request);
  148 |       if(window.nativeCalls.length>2)throw Error('Unexpected native request after failure');
  149 |       if(request.method==='getSamplerSession'){
  150 |         window.pendingOutcome=window.__DANDRUM__.backend.getNativeFunction('pending')().catch(error=>error.code);
  151 |         window.__DANDRUM__.receiveNativeMessage(JSON.stringify({version:1,instanceId:'17',attachmentId:'23',requestId:request.requestId,status:'rejected',error:{code:'capabilityUnavailable',message:'Session unavailable'}}));
  152 |       }
  153 |     }};
  154 |   });
  155 |   await page.goto('/');await expect(page.getByRole('alert')).toHaveText('Native sampler failed: Session unavailable');
  156 |   expect(await page.evaluate(()=>window.pendingOutcome)).toBe('closed');
  157 |   expect(await page.evaluate(()=>window.nativeCalls.map(call=>call.method))).toEqual(['getSamplerSession','pending']);
  158 |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  159 | });
  160 | 
  161 | test('invalid trusted bootstrap is visible before any native call or preview',async({page})=>{
  162 |   await page.addInitScript(()=>{window.nativeCalls=[];window.__DANDRUM_NATIVE__={protocolVersion:2};window.ipc={postMessage:message=>window.nativeCalls.push(message)};});
  163 |   await page.goto('/');await expect(page.getByRole('alert')).toHaveText('Native sampler failed: invalidNativeBootstrap');
  164 |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  165 |   expect(await page.evaluate(()=>window.nativeCalls)).toEqual([]);
  166 | });
  167 | 
  168 | test('page disposal sends held-note cleanup before closing the local broker',async({page})=>{
  169 |   const errors=[];page.on('pageerror',error=>errors.push(error.message));
  170 |   await page.addInitScript(initial=>{
  171 |     window.nativeCalls=[];
  172 |     window.__DANDRUM_NATIVE__={protocolVersion:1,instanceId:initial.connection.instanceId,attachmentId:initial.connection.attachmentId};
  173 |     window.ipc={postMessage(message){
  174 |       const request=JSON.parse(message);window.nativeCalls.push(request);
  175 |       if(window.nativeCalls.length>4)throw Error('Repeated native cleanup');
  176 |       if(!['getSamplerSession','noteOn','noteOff','noteHeartbeat'].includes(request.method))throw Error('Unexpected '+request.method);
  177 |       window.__DANDRUM__.receiveNativeMessage(JSON.stringify({version:1,instanceId:initial.connection.instanceId,attachmentId:initial.connection.attachmentId,requestId:request.requestId,status:'accepted',result:request.method==='getSamplerSession'?initial:true}));
  178 |     }};
  179 |   },session());
  180 |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  181 |   await page.keyboard.down('a');
  182 |   await expect.poll(()=>page.evaluate(()=>window.nativeCalls.filter(call=>call.method==='noteOn').length)).toBe(1);
  183 |   await page.evaluate(()=>{window.dispatchEvent(new Event('pagehide'));window.dispatchEvent(new Event('pagehide'));});
  184 |   const notes=await page.evaluate(()=>window.nativeCalls.filter(call=>['noteOn','noteOff'].includes(call.method)));
  185 |   expect(notes).toHaveLength(2);expect(notes[0].method).toBe('noteOn');expect(notes[1].method).toBe('noteOff');
  186 |   expect(notes[0].args).toEqual([48,100/127,7]);expect(notes[1].args).toEqual([48,7]);
  187 |   expect(await page.evaluate(()=>window.__DANDRUM__.backend.getNativeFunction('getSamplerSession')().catch(error=>error.code))).toBe('closed');
  188 |   expect(errors).toEqual([]);
  189 | });
  190 | 
  191 | test('a code-only native protocol rejection displays its explicit capability failure',async({page})=>{
  192 |   await page.addInitScript(()=>{
  193 |     window.nativeCalls=[];
  194 |     window.__DANDRUM_NATIVE__={protocolVersion:1,instanceId:'17',attachmentId:'23'};
  195 |     window.ipc={postMessage(message){
  196 |       const request=JSON.parse(message);window.nativeCalls.push(request);
  197 |       if(window.nativeCalls.length>1)throw Error('Unexpected native retry');
  198 |       window.__DANDRUM__.receiveNativeMessage(JSON.stringify({version:1,instanceId:'17',attachmentId:'23',requestId:request.requestId,status:'rejected',error:{code:'capabilityUnavailable'}}));
  199 |     }};
  200 |   });
> 201 |   await page.goto('/');await expect(page.getByRole('alert')).toHaveText('Native sampler failed: capabilityUnavailable');
      |                                                              ^ Error: expect(locator).toHaveText(expected) failed
  202 |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  203 |   expect(await page.evaluate(()=>window.nativeCalls)).toEqual([{version:1,attachmentId:'23',requestId:'1',method:'getSamplerSession',args:[]}]);
  204 |   expect(await page.evaluate(()=>window.__DANDRUM__.backend.getNativeFunction('getSamplerSession')().catch(error=>error.code))).toBe('closed');
  205 | });
  206 | 
```