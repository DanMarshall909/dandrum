import original from '/tmp/dandrum-lanes/frontend/web/trigger/vite.config.mjs';
export default {...original,root:'/tmp/dandrum-lanes/frontend/web/trigger',cacheDir:'/dev/shm/dnb/cache'};
