# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-transport.spec.mjs >> trusted Wry bootstrap connects the production entrypoint through correlated native messages
- Location: tests/browser/native-transport.spec.mjs:98:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('banner').locator('[data-backend="native"]')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('banner').locator('[data-backend="native"]') with timeout 5000ms
  - waiting for getByRole('banner').locator('[data-backend="native"]')

```

```yaml
- banner:
  - text: dandrum Trigger
  - button "Nothing to undo" [disabled]
  - button "Nothing to redo" [disabled]
  - button "Patch Untitled"
  - status: Empty Drop or browse samples
  - text: Silent Voices 0 / 32
  - radiogroup:
    - radio "Min"
    - radio "Default" [checked]
    - radio "Expanded"
  - button "Collapse"
  - button "Log"
  - button "Clip indicator"
- text: Macros
- slider "Macro 1" [disabled]
- slider "Macro 2" [disabled]
- slider "Macro 3" [disabled]
- slider "Macro 4" [disabled]
- slider "Macro 5" [disabled]
- slider "Macro 6" [disabled]
- slider "Macro 7" [disabled]
- slider "Macro 8" [disabled]
- navigation:
  - tablist:
    - tab "Sample" [selected]
    - tab "Slices 8"
    - tab "Mapping"
    - tab "Layers"
    - tab "Voice"
    - tab "Modulation 0"
    - tab "Routing"
    - tab "Effects"
  - button "Browser"
- complementary:
  - text: Instrument
  - button "Add group"
  - option "Untitled 0 groups"
  - text: Sources
  - button "Add source…"
  - text: Modulators
  - button "Add modulator"
  - button "Envelopes 0 · 0"
  - button "LFOs 0 · 0"
  - button "Performance 0 · 0"
  - button "Macros 0 · 0"
  - button "Random 0 · 0"
  - text: Click to preview a source. Drag sources onto pads or zones, modulators onto controls. Right-click a control for Modulation.
- main:
  - text: Drop samples here One file becomes a sound across the keyboard. Several files ask how to map them.
  - button "Browse samples…"
  - button "Load multiple…"
  - text: WAV · AIFF · FLAC · MP3 · OGG
- complementary: Untitled Untitled Instrument Instrument Sounds None Voice limit 32 Output Main 1/2 Nothing is selected yet. Drop or browse a sample; the inspector then shows whatever you select in the workspace or tree.
- contentinfo: Drop files anywhere in the window · Ctrl+O browses 1200 × 800
```

# Test source

```ts
  12  |       if(name==='requestSourceWaveform')return {status:'accepted',job_id:'1',generation:initial.document.generation};
  13  |       if(name==='getWaveformJobStatus')return {state:'ready',generation:initial.document.generation,result:{buckets:[]}};
  14  |       return null;
  15  |     }};
  16  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',backend};
  17  |     window.__JUCE__={backend:{getNativeFunction:()=>{throw new Error('Comparison bridge must remain unused');}}};
  18  |   },session());
  19  |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  20  |   await expect(page.getByRole('banner').locator('[data-backend="native"]')).toBeVisible();
  21  |   expect(await page.evaluate(()=>window.nativeCalls.filter(call=>call[0]==='setTriggerWindowTitle'))).toEqual([['setTriggerWindowTitle','Advanced Drum Kit']]);
  22  |   await expect(page.getByRole('alert')).toHaveCount(0);
  23  | });
  24  | 
  25  | test('an incompatible declared native host displays an error and never opens the silent preview',async({page})=>{
  26  |   await page.addInitScript(()=>{window.__DANDRUM__={protocolVersion:2};});
  27  |   await page.goto('/');
  28  |   await expect(page.getByRole('alert')).toHaveText('Native sampler failed: Unsupported native transport protocol version');
  29  |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  30  | });
  31  | 
  32  | test('a rejected native snapshot displays its capability error without simulating an instrument',async({page})=>{
  33  |   await page.addInitScript(()=>{
  34  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',backend:{addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:()=>async()=>{
  35  |       throw Object.assign(new Error('Session snapshot capability unavailable'),{code:'capabilityUnavailable',method:'getSamplerSession'});
  36  |     }}};
  37  |   });
  38  |   await page.goto('/');await expect(page.getByRole('alert')).toHaveText('Native sampler failed: Session snapshot capability unavailable');
  39  |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  40  | });
  41  | 
  42  | test('an ordinary browser continues to show an explicitly silent preview',async({page})=>{
  43  |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  44  |   await expect(page.getByRole('banner').locator('[data-backend="mock"]')).toContainText(/silent/i);
  45  |   await expect(page.getByRole('alert')).toHaveCount(0);
  46  | });
  47  | 
  48  | 
  49  | test('explicit absent services render accepted controls with unavailable measurements and host-controlled size',async({page},testInfo)=>{
  50  |   const errors=[];page.on('pageerror',error=>errors.push(error.message));
  51  |   await page.addInitScript(initial=>{
  52  |     window.nativeCalls=[];
  53  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend:{addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:name=>async(...args)=>{
  54  |       window.nativeCalls.push([name,...args]);if(name==='getSamplerSession')return initial;
  55  |       throw Object.assign(new Error('Unsupported '+name),{code:'capabilityUnavailable',method:name});
  56  |     }}};
  57  |   },(()=>{const graph=parse(yaml);graph.assets.sample_sources[0].regions[0].loop={mode:'forward',start_frame:0,end_frame:10000,crossfade_ms:0};return session(stringify(graph));})());
  58  |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  59  |   const header=page.getByRole('banner');
  60  |   await expect(header.getByTestId('backend-status')).toHaveText('Connected');
  61  |   await expect(header).toContainText('Voices — / 8');
  62  |   await expect(header.getByText('Meters unavailable',{exact:true})).toBeVisible();
  63  |   await expect(header.getByText('Size controlled by host',{exact:true})).toBeVisible();
  64  |   await expect(header.getByRole('radio')).toHaveCount(0);
  65  |   await expect(header.getByRole('button',{name:'Collapse',exact:true})).toHaveCount(0);
  66  |   await expect(page.getByRole('img',{name:'Waveform unavailable'}).first()).toBeVisible();
  67  |   await expect(page.locator('[data-knob="drums.level"]')).toBeVisible();
  68  |   await expect(page.getByRole('spinbutton',{name:'Loop start',exact:true})).toBeVisible();
  69  |   await expect(page.getByRole('img',{name:'Waveform unavailable'})).toHaveCount(4);
  70  |   await expect(page.getByRole('img',{name:'Waveform unavailable'}).locator('svg')).toHaveCount(0);
  71  |   await page.getByRole('tab',{name:/^Slices/}).click();await expect(page.getByRole('img',{name:'Waveform unavailable'})).toHaveCount(1);
  72  |   await page.getByRole('tab',{name:'Routing',exact:true}).click();await expect(page.getByText('Meters unavailable',{exact:true})).toHaveCount(2);
  73  |   await expect(page.getByRole('alert')).toHaveCount(0);
  74  |   expect(await page.evaluate(()=>window.nativeCalls.map(call=>call[0]))).toEqual(['getSamplerSession']);
  75  |   await page.screenshot({path:testInfo.outputPath('native-optional-unavailable.png'),animations:'disabled'});
  76  |   expect(errors).toEqual([]);
  77  | });
  78  | 
  79  | test('accepted voice-limit refresh updates the rendered header while meters remain unavailable',async({page})=>{
  80  |   await page.addInitScript(initial=>{
  81  |     window.nativeCalls=[];window.nativeSession=initial;window.nativeEvents={};
  82  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend:{
  83  |       addEventListener:(name,listener)=>{window.nativeEvents[name]=listener;return name;},removeEventListener:name=>{delete window.nativeEvents[name];},
  84  |       getNativeFunction:name=>async(...args)=>{window.nativeCalls.push([name,...args]);if(name==='getSamplerSession')return window.nativeSession;throw Error('Unexpected '+name);},
  85  |     }};
  86  |   },session());
  87  |   await page.goto('/');const header=page.getByRole('banner');await expect(header).toContainText('Voices — / 8');
  88  |   await page.evaluate(async next=>{
  89  |     window.nativeSession=next;await window.nativeEvents.parameterStateChanged({generation:next.document.generation,sequence:0,parameters:[]});
  90  |   },session(yaml.replace('max_voices: 8','max_voices: 12'),8));
  91  |   await expect(header).toContainText('Voices — / 12');
  92  |   await expect(header.getByText('Meters unavailable',{exact:true})).toBeVisible();
  93  |   expect(await page.evaluate(()=>window.nativeCalls.map(call=>call[0]))).toEqual(['getSamplerSession','getSamplerSession']);
  94  |   await expect(page.getByRole('alert')).toHaveCount(0);
  95  | });
  96  | 
  97  | 
  98  | test('trusted Wry bootstrap connects the production entrypoint through correlated native messages',async({page})=>{
  99  |   const errors=[];page.on('pageerror',error=>errors.push(error.message));
  100 |   await page.addInitScript(initial=>{
  101 |     window.nativeCalls=[];
  102 |     window.__DANDRUM_NATIVE__={protocolVersion:1,instanceId:initial.connection.instanceId,attachmentId:initial.connection.attachmentId,nextRequestId:'41'};
  103 |     window.ipc={postMessage(message){
  104 |       if(this!==window.ipc)throw Error('Wry IPC receiver was lost');
  105 |       const request=JSON.parse(message);window.nativeCalls.push(request);
  106 |       if(window.nativeCalls.length>2)throw Error('Unexpected repeated native request');
  107 |       if(request.method!=='getSamplerSession')throw Error('Unexpected native method '+request.method);
  108 |       window.__DANDRUM__.receiveNativeMessage(JSON.stringify({version:1,instanceId:initial.connection.instanceId,attachmentId:initial.connection.attachmentId,requestId:request.requestId,status:'accepted',result:initial}));
  109 |     }};
  110 |   },session());
  111 |   await page.goto('/');
> 112 |   await expect(page.getByRole('banner').locator('[data-backend="native"]')).toBeVisible();
      |                                                                             ^ Error: expect(locator).toBeVisible() failed
  113 |   await expect(page.locator('[data-knob="drums.level"]')).toBeVisible();
  114 |   await expect(page.getByRole('banner').getByTestId('backend-status')).toHaveText('Connected');
  115 |   expect(await page.evaluate(()=>window.nativeCalls)).toEqual([{version:1,attachmentId:'9007199254740993',requestId:'41',method:'getSamplerSession',args:[]}]);
  116 |   await expect(page.getByRole('alert')).toHaveCount(0);
  117 |   expect(errors).toEqual([]);
  118 | });
  119 | 
```