# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-transport.spec.mjs >> page disposal closes a pending native initialization once without rendering a late failure
- Location: tests/browser/native-transport.spec.mjs:120:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('alert')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByRole('alert') with timeout 5000ms
  - waiting for getByRole('alert')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- alert [ref=e3]: "Native sampler failed: closed"
```

# Test source

```ts
  36  |     }}};
  37  |   });
  38  |   await page.goto('/');await expect(page.getByRole('alert')).toHaveText('Native sampler failed: Session snapshot capability unavailable');
  39  |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  40  | });
  41  | 
  42  | test('an ordinary browser continues to show an explicitly silent preview',async({page})=>{
  43  |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  44  |   await expect(page.getByRole('banner').locator('[data-backend="mock"]')).toContainText(/silent/i);
  45  |   await expect(page.getByRole('alert')).toHaveCount(0);
  46  | });
  47  | 
  48  | 
  49  | test('explicit absent services render accepted controls with unavailable measurements and host-controlled size',async({page},testInfo)=>{
  50  |   const errors=[];page.on('pageerror',error=>errors.push(error.message));
  51  |   await page.addInitScript(initial=>{
  52  |     window.nativeCalls=[];
  53  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend:{addEventListener:()=>0,removeEventListener:()=>{},getNativeFunction:name=>async(...args)=>{
  54  |       window.nativeCalls.push([name,...args]);if(name==='getSamplerSession')return initial;
  55  |       throw Object.assign(new Error('Unsupported '+name),{code:'capabilityUnavailable',method:name});
  56  |     }}};
  57  |   },(()=>{const graph=parse(yaml);graph.assets.sample_sources[0].regions[0].loop={mode:'forward',start_frame:0,end_frame:10000,crossfade_ms:0};return session(stringify(graph));})());
  58  |   await page.goto('/');await expect(page.getByTestId('trigger-editor')).toBeVisible();
  59  |   const header=page.getByRole('banner');
  60  |   await expect(header.getByTestId('backend-status')).toHaveText('Connected');
  61  |   await expect(header).toContainText('Voices — / 8');
  62  |   await expect(header.getByText('Meters unavailable',{exact:true})).toBeVisible();
  63  |   await expect(header.getByText('Size controlled by host',{exact:true})).toBeVisible();
  64  |   await expect(header.getByRole('radio')).toHaveCount(0);
  65  |   await expect(header.getByRole('button',{name:'Collapse',exact:true})).toHaveCount(0);
  66  |   await expect(page.getByRole('img',{name:'Waveform unavailable'}).first()).toBeVisible();
  67  |   await expect(page.locator('[data-knob="drums.level"]')).toBeVisible();
  68  |   await expect(page.getByRole('spinbutton',{name:'Loop start',exact:true})).toBeVisible();
  69  |   await expect(page.getByRole('img',{name:'Waveform unavailable'})).toHaveCount(4);
  70  |   await expect(page.getByRole('img',{name:'Waveform unavailable'}).locator('svg')).toHaveCount(0);
  71  |   await page.getByRole('tab',{name:/^Slices/}).click();await expect(page.getByRole('img',{name:'Waveform unavailable'})).toHaveCount(1);
  72  |   await page.getByRole('tab',{name:'Routing',exact:true}).click();await expect(page.getByText('Meters unavailable',{exact:true})).toHaveCount(2);
  73  |   await expect(page.getByRole('alert')).toHaveCount(0);
  74  |   expect(await page.evaluate(()=>window.nativeCalls.map(call=>call[0]))).toEqual(['getSamplerSession']);
  75  |   await page.screenshot({path:testInfo.outputPath('native-optional-unavailable.png'),animations:'disabled'});
  76  |   expect(errors).toEqual([]);
  77  | });
  78  | 
  79  | test('accepted voice-limit refresh updates the rendered header while meters remain unavailable',async({page})=>{
  80  |   await page.addInitScript(initial=>{
  81  |     window.nativeCalls=[];window.nativeSession=initial;window.nativeEvents={};
  82  |     window.__DANDRUM__={protocolVersion:1,backendId:'juce-free',capabilities:{metering:false,sourceWaveforms:false,windowTitle:false,editorResize:false},backend:{
  83  |       addEventListener:(name,listener)=>{window.nativeEvents[name]=listener;return name;},removeEventListener:name=>{delete window.nativeEvents[name];},
  84  |       getNativeFunction:name=>async(...args)=>{window.nativeCalls.push([name,...args]);if(name==='getSamplerSession')return window.nativeSession;throw Error('Unexpected '+name);},
  85  |     }};
  86  |   },session());
  87  |   await page.goto('/');const header=page.getByRole('banner');await expect(header).toContainText('Voices — / 8');
  88  |   await page.evaluate(async next=>{
  89  |     window.nativeSession=next;await window.nativeEvents.parameterStateChanged({generation:next.document.generation,sequence:0,parameters:[]});
  90  |   },session(yaml.replace('max_voices: 8','max_voices: 12'),8));
  91  |   await expect(header).toContainText('Voices — / 12');
  92  |   await expect(header.getByText('Meters unavailable',{exact:true})).toBeVisible();
  93  |   expect(await page.evaluate(()=>window.nativeCalls.map(call=>call[0]))).toEqual(['getSamplerSession','getSamplerSession']);
  94  |   await expect(page.getByRole('alert')).toHaveCount(0);
  95  | });
  96  | 
  97  | 
  98  | test('trusted Wry bootstrap connects the production entrypoint through correlated native messages',async({page})=>{
  99  |   const errors=[];page.on('pageerror',error=>errors.push(error.message));
  100 |   await page.addInitScript(initial=>{
  101 |     window.nativeCalls=[];
  102 |     window.__DANDRUM_NATIVE__={protocolVersion:1,instanceId:initial.connection.instanceId,attachmentId:initial.connection.attachmentId,nextRequestId:'41'};
  103 |     window.ipc={postMessage(message){
  104 |       if(this!==window.ipc)throw Error('Wry IPC receiver was lost');
  105 |       const request=JSON.parse(message);window.nativeCalls.push(request);
  106 |       if(window.nativeCalls.length>2)throw Error('Unexpected repeated native request');
  107 |       if(request.method!=='getSamplerSession')throw Error('Unexpected native method '+request.method);
  108 |       window.__DANDRUM__.receiveNativeMessage(JSON.stringify({version:1,instanceId:initial.connection.instanceId,attachmentId:initial.connection.attachmentId,requestId:request.requestId,status:'accepted',result:initial}));
  109 |     }};
  110 |   },session());
  111 |   await page.goto('/');
  112 |   await expect(page.getByRole('banner').locator('[data-backend="native"]')).toBeVisible();
  113 |   await expect(page.locator('[data-knob="drums.level"]')).toBeVisible();
  114 |   await expect(page.getByRole('banner').getByTestId('backend-status')).toHaveText('Connected');
  115 |   expect(await page.evaluate(()=>window.nativeCalls)).toEqual([{version:1,attachmentId:'9007199254740993',requestId:'41',method:'getSamplerSession',args:[]}]);
  116 |   await expect(page.getByRole('alert')).toHaveCount(0);
  117 |   expect(errors).toEqual([]);
  118 | });
  119 | 
  120 | test('page disposal closes a pending native initialization once without rendering a late failure',async({page})=>{
  121 |   const errors=[];page.on('pageerror',error=>errors.push(error.message));
  122 |   await page.addInitScript(()=>{
  123 |     window.nativeCalls=[];
  124 |     window.__DANDRUM_NATIVE__={protocolVersion:1,instanceId:'17',attachmentId:'23'};
  125 |     window.ipc={postMessage(message){window.nativeCalls.push(JSON.parse(message));if(window.nativeCalls.length>1)throw Error('Unexpected native request after disposal');}};
  126 |   });
  127 |   await page.goto('/');await expect(page.getByRole('status')).toHaveText('Connecting to native sampler…');
  128 |   await page.evaluate(async()=>{
  129 |     const descriptor=window.__DANDRUM__;
  130 |     const listener=()=>{throw Error('Native event delivered after page disposal');};
  131 |     descriptor.backend.addEventListener('instrumentSessionChanged',listener);
  132 |     window.dispatchEvent(new Event('pagehide'));window.dispatchEvent(new Event('pagehide'));
  133 |     window.lateDelivery=descriptor.receiveNativeMessage(JSON.stringify({version:1,instanceId:'17',attachmentId:'23',event:'instrumentSessionChanged',sequence:'1',payload:{generation:9}}));
  134 |     window.afterClose=await descriptor.backend.getNativeFunction('getSamplerSession')().catch(error=>error.code);
  135 |   });
> 136 |   await expect(page.getByRole('alert')).toHaveCount(0);
      |                                         ^ Error: expect(locator).toHaveCount(expected) failed
  137 |   await expect(page.getByTestId('trigger-editor')).toHaveCount(0);
  138 |   expect(await page.evaluate(()=>({calls:window.nativeCalls,late:window.lateDelivery,closed:window.afterClose}))).toEqual({calls:[{version:1,attachmentId:'23',requestId:'1',method:'getSamplerSession',args:[]}],late:'ignored',closed:'closed'});
  139 |   expect(errors).toEqual([]);
  140 | });
  141 | 
```