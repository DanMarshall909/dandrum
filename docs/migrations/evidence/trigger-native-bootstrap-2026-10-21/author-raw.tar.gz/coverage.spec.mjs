import {test} from '/tmp/dandrum-lanes/frontend/web/trigger/node_modules/@playwright/test/index.mjs';
import {writeFileSync} from 'node:fs';
import '/tmp/dandrum-lanes/frontend/web/trigger/tests/browser/native-transport.spec.mjs';
test.beforeEach(async ({page})=>{await page.coverage.startJSCoverage({resetOnNavigation:false});});
test.afterEach(async ({page},info)=>{const entries=await page.coverage.stopJSCoverage();writeFileSync(info.outputPath('entry-v8.json'),JSON.stringify(entries.filter(entry=>/\/(main\.jsx|native-webview-bootstrap\.mjs)(\?|$)/.test(entry.url))));});
