import pathlib,json
scratch=pathlib.Path('/dev/shm/dnb');evidence=pathlib.Path('/dev/shm/dandrum-beta-20261020/native-bootstrap-evidence')
assert not scratch.exists() and not evidence.exists()
scratch.mkdir();evidence.mkdir()
(scratch/'owner.json').write_text(json.dumps({'task':'native-bootstrap','source':'/tmp/dandrum-lanes/frontend'}))
for p in ['tmp','cache']:(scratch/p).mkdir()
root='/tmp/dandrum-lanes/frontend/web/trigger'
(scratch/'vite.config.mjs').write_text(f"import original from '{root}/vite.config.mjs';\nexport default {{...original,root:'{root}',cacheDir:'/dev/shm/dnb/cache'}};\n")
(scratch/'playwright.config.mjs').write_text(f"import {{defineConfig}} from '{root}/node_modules/@playwright/test/index.mjs';\nexport default defineConfig({{testDir:'{root}/tests/browser',fullyParallel:false,workers:1,outputDir:'{evidence}/browser-output',reporter:[['list']],use:{{baseURL:'http://127.0.0.1:8426',viewport:{{width:1800,height:1200}},launchOptions:{{executablePath:'/usr/bin/google-chrome'}}}},webServer:{{cwd:'{root}',command:'npm run dev -- --config /dev/shm/dnb/vite.config.mjs --configLoader native --port 8426 --strictPort',url:'http://127.0.0.1:8426',reuseExistingServer:false}}}});\n")
