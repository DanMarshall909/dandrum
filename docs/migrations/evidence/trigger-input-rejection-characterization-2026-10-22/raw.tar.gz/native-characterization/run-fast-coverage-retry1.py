from pathlib import Path
import os,json,subprocess,hashlib,time,signal,shutil
ROOT=Path('/tmp/dandrum-lanes/runtime');BASE=Path('/tmp/dandrum-evidence/final-clap-dcd65e4a');OUT=Path('/tmp/dandrum-evidence/final-native-input-characterization/fast-coverage-retry1');OUT.mkdir(exist_ok=False);PROFILES=OUT/'profiles';PROFILES.mkdir();TMP=Path('/tmp/dnic-fast-cov1');TMP.mkdir(exist_ok=False);(TMP/'owner.json').write_text(json.dumps({'owner':'final-clap-adapter-coverage','source_commit':'dcd65e4a6226f581510c585376c6b1af1689cae5'})+'\n');CACHE=Path('/tmp/dandrum-lanes/cache-editor-guard');CARGO='/home/dan/.cargo/bin/cargo';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();manifest=ROOT/'src/clap-adapter/Cargo.toml'
before={str(p.relative_to(ROOT)):sha(p) for folder in ('src/clap-adapter','src/trigger-host','src/trigger-editor') for p in (ROOT/folder).rglob('*') if p.is_file() and 'target' not in p.parts and p.suffix in ('.rs','.toml','.lock')};(OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ,CARGO_TARGET_DIR=str(CACHE),CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',TMPDIR=str(TMP),DISPLAY=':10.0',GDK_BACKEND='x11',XAUTHORITY='/home/dan/.Xauthority')
for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LD_PRELOAD','LLVM_PROFILE_FILE'):env.pop(k,None)
rows=[]
def run(label,command,extra=None,timeout=600):
 start=time.monotonic();samples=[];reason=None;effective=dict(env,**(extra or {}))
 with (OUT/(label+'.stdout')).open('wb') as a,(OUT/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(command,cwd=ROOT,env=effective,stdout=a,stderr=b,start_new_session=True)
  while p.poll() is None:
   sample={'seconds':time.monotonic()-start,'disk_free_bytes':shutil.disk_usage('/tmp').free,'mem_available_bytes':int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024};samples.append(sample)
   if sample['disk_free_bytes']<1024**3 or sample['mem_available_bytes']<4*1024**3 or sample['seconds']>timeout:
    reason='resource floor or deadline';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.25)
  code=p.wait()
 row={'label':label,'command':command,'cwd':str(ROOT),'exit':code,'seconds':time.monotonic()-start,'owned_pgid':p.pid,'stop_reason':reason,'resource_samples':samples,'environment':{k:effective[k] for k in ('CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','TMPDIR','DISPLAY','GDK_BACKEND','XAUTHORITY','LLVM_PROFILE_FILE','DANDRUM_TRIGGER_CLAP_PLUGIN_PATH') if k in effective},'stdout_sha256':sha(OUT/(label+'.stdout')),'stderr_sha256':sha(OUT/(label+'.stderr'))};rows.append(row);(OUT/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');assert code==0 and reason is None,(label,code,(OUT/(label+'.stderr')).read_text()[-3000:]);print(label,code,round(row['seconds'],3),flush=True);return (OUT/(label+'.stdout')).read_text()
capture=[json.loads(x) for x in Path('/tmp/dandrum-evidence/final-native-input-characterization/fast-capture.jsonl').read_text().splitlines()][-1];command=list(capture['command']);command[command.index('src/lib.rs')]=str(Path(capture['cwd'])/'src/lib.rs');dependencies={}
for i,arg in enumerate(command):
 if arg=='--extern':
  path=Path(command[i+1].split('=',1)[1]);assert path.is_file();dependencies[str(path)]=sha(path)
art=OUT/'artifacts';art.mkdir();command[command.index('--out-dir')+1]=str(art)
i=0
while i<len(command)-1:
 if command[i]=='-C' and command[i+1].startswith('incremental='):del command[i:i+2]
 else:i+=1
command+=['-C','instrument-coverage','-C','strip=none'];run('compile-instrumented-fast-owner',command,dict(capture['environment'],RUST_MIN_STACK='16777216'))
executables=[p for p in art.iterdir() if p.is_file() and p.name.startswith('dandrum_clap_adapter-') and p.suffix==''];assert len(executables)==1;exe=executables[0]
text=run('all-fast-owner-tests',[str(exe),'--nocapture','--test-threads=1'],{'LLVM_PROFILE_FILE':str(PROFILES/'fast-%m-%p.profraw')});assert '13 passed; 0 failed' in text
profiles=sorted(PROFILES.glob('*.profraw'));assert profiles;sysroot=Path(subprocess.check_output(['/home/dan/.cargo/bin/rustc','--print','sysroot'],text=True).strip());binpath=sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/bin';profdata=OUT/'merged.profdata';run('merge',[str(binpath/'llvm-profdata'),'merge','-sparse',*[str(p) for p in profiles],'-o',str(profdata)])
args=[str(exe),'--instr-profile',str(profdata),str(ROOT/'src/clap-adapter/src/trigger/gui.rs'),str(ROOT/'src/clap-adapter/tests/internal/trigger_gui_dispatch.rs')];run('export',[str(binpath/'llvm-cov'),'export',*args]);run('show',[str(binpath/'llvm-cov'),'show',*args,'--show-line-counts-or-regions']);assert before=={p:sha(ROOT/p) for p in before};assert dependencies=={p:sha(p) for p in dependencies}
(OUT/'binding.json').write_text(json.dumps({'source_sha256':before,'ordinary_capture':capture,'instrumented_command':command,'dependencies':dependencies,'elf':str(exe),'elf_sha256':sha(exe),'profiles':{str(p):sha(p) for p in profiles},'merged_profile_sha256':sha(profdata),'scope':'Fresh current fastowner source13tests plus changedstalenote signed/silence characterization. Instrumenttargetonly, no globalflags or sharedincremental writes. Firstfixturefailure retained separately; production unchanged.'},indent=2)+'\n');print('Focused fast owner coverage complete',flush=True)
