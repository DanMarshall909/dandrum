from pathlib import Path
import os,json,subprocess,hashlib,time,signal,shutil
ROOT=Path('/tmp/dandrum-lanes/runtime');BASE=Path('/tmp/dandrum-evidence/final-clap-dcd65e4a');OUT=Path('/tmp/dandrum-evidence/final-native-input-characterization/native-baseline');OUT.mkdir(exist_ok=False);PROFILES=OUT/'profiles';PROFILES.mkdir();TMP=Path('/tmp/dnic-native');TMP.mkdir(exist_ok=False);(TMP/'owner.json').write_text(json.dumps({'owner':'final-clap-adapter-coverage','source_commit':'dcd65e4a6226f581510c585376c6b1af1689cae5'})+'\n');CACHE=Path('/tmp/dandrum-lanes/cache-editor-guard');CARGO='/home/dan/.cargo/bin/cargo';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();manifest=ROOT/'src/clap-adapter/Cargo.toml'
before={str(p.relative_to(ROOT)):sha(p) for folder in ('src/clap-adapter','src/trigger-host','src/trigger-editor') for p in (ROOT/folder).rglob('*') if p.is_file() and 'target' not in p.parts and p.suffix in ('.rs','.toml','.lock')};(OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ,CARGO_TARGET_DIR=str(CACHE),CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',TMPDIR=str(TMP),DISPLAY=':10.0',GDK_BACKEND='x11',XAUTHORITY='/home/dan/.Xauthority')
for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LD_PRELOAD','LLVM_PROFILE_FILE'):env.pop(k,None)
rows=[]
def run(label,command,extra=None,timeout=600):
 start=time.monotonic();samples=[];reason=None;effective=dict(env,**(extra or {}))
 with (OUT/(label+'.stdout')).open('wb') as a,(OUT/(label+'.stderr')).open('wb') as b:
  p=subprocess.Popen(command,cwd=ROOT,env=effective,stdout=a,stderr=b,start_new_session=True)
  while p.poll() is None:
   sample={'seconds':time.monotonic()-start,'disk_free_bytes':shutil.disk_usage('/tmp').free,'mem_available_bytes':int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024};samples.append(sample)
   if sample['disk_free_bytes']<1024**3 or sample['mem_available_bytes']<4*1024**3 or sample['seconds']>timeout:
    reason='resource floor or deadline';os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    break
   time.sleep(.25)
  code=p.wait()
 row={'label':label,'command':command,'cwd':str(ROOT),'exit':code,'seconds':time.monotonic()-start,'owned_pgid':p.pid,'stop_reason':reason,'resource_samples':samples,'environment':{k:effective[k] for k in ('CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','TMPDIR','DISPLAY','GDK_BACKEND','XAUTHORITY','LLVM_PROFILE_FILE','DANDRUM_TRIGGER_CLAP_PLUGIN_PATH') if k in effective},'stdout_sha256':sha(OUT/(label+'.stdout')),'stderr_sha256':sha(OUT/(label+'.stderr'))};rows.append(row);(OUT/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');assert code==0 and reason is None,(label,code,(OUT/(label+'.stderr')).read_text()[-3000:]);print(label,code,round(row['seconds'],3),flush=True);return (OUT/(label+'.stdout')).read_text()
run('fmt-check',[CARGO,'fmt','--manifest-path',str(manifest),'--','--check'])
product=Path('/tmp/dandrum-evidence/maintained-gui-product-root/sourcefree-production/installed/DandrumTrigger.clap');resources=product.with_name('DandrumTrigger.resources');assert sha(product)=='309e9006a4e41c616b46e41e889e9400507349b20eaf1d0e39ecfde0409b905a';fixture=OUT/'fixture'
run('prepare-native',['python3',str(ROOT/'scripts/prepare-trigger-clap-native.py'),'--cargo',CARGO,'--manifest',str(manifest),'--target-dir',str(CACHE),'--resource-dir',str(resources),'--product',str(product),'--output-dir',str(fixture),'--test-target','trigger_parameters'])
fixturebinding=json.loads((fixture/'binding.json').read_text())
for value in fixturebinding['artifacts'].values():assert sha(fixture/value['copy'])==value['copy_sha256']
inventory=json.loads(Path('/tmp/dandrum-evidence/maintained-gui-product-root/root-native-inventory.stdout.log').read_text());selected=[t for t in inventory['tests'] if t['name']=='trigger-clap-native-parameter-state'];assert len(selected)==1;original='/tmp/dandrum-evidence/g3-lost-ack-native-fixture/native-build/trigger-clap-parameters-fixture';command=[arg.replace(original,str(fixture)) for arg in selected[0]['command']];assert command!=selected[0]['command'];text=run('raw-native-characterization',command,timeout=90);assert 'running 1 test' in text and '1 passed; 0 failed' in text and 'running 0 tests' not in text
assert before=={p:sha(ROOT/p) for p in before};(OUT/'binding.json').write_text(json.dumps({'source_sha256':before,'fixture':fixturebinding,'product':str(product),'product_sha256':sha(product),'scope':'Unmodified publishedGUIproduction product with fresh existingnativeDTOtest extendednine hostile rawIPC cases plus authenticatedbarriers/fullsnapshot/saved/scalar/identity/offsetsignedaudio. No artificialRED/privateproductseam/assetfilechange.'},indent=2)+'\n');print('Raw native input characterization complete',flush=True)
