#!/usr/bin/env python3
import sys,os,json
from pathlib import Path
args=sys.argv[1:]
if '--crate-name' in args and args[args.index('--crate-name')+1]=='dandrum_clap_adapter' and '--test' in args:
 keys=('CARGO_MANIFEST_DIR','CARGO_MANIFEST_PATH','CARGO_CRATE_NAME','LD_LIBRARY_PATH','OUT_DIR')
 record={'command':args,'cwd':os.getcwd(),'environment':{k:v for k,v in os.environ.items() if k in keys or k.startswith('CARGO_PKG_')}}
 fd=os.open('/tmp/dandrum-evidence/final-native-input-characterization/fast-capture.jsonl',os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o644);os.write(fd,(json.dumps(record)+'\n').encode());os.close(fd)
os.execv(args[0],args)
