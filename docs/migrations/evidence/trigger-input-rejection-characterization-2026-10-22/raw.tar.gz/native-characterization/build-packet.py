from pathlib import Path
import hashlib,json,tarfile,gzip,io,subprocess
R=Path('/tmp/dandrum-lanes/integration');E=Path('/tmp/dandrum-evidence');B=E/'final-native-input-characterization';P=R/'docs/migrations/evidence/trigger-input-rejection-characterization-2026-10-22'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
for name in ('final-adapter-coverage-assessment-refresh','final-host-coverage-assessment-refresh'):assert (E/name/'report.md').is_file(),name
assert not P.exists();P.mkdir(parents=True)
roots={
 'host-characterization':E/'final-host-characterization',
 'native-characterization':B,
 'host-baseline':E/'final-clap-dcd65e4a/host-owner-coverage',
 'adapter-baseline':E/'final-clap-dcd65e4a/adapter-production-coverage-retry1',
 'adapter-controller-attempt0':E/'final-clap-dcd65e4a/adapter-production-coverage',
 'host-gap-assessment':E/'final-clap-coverage-ledger',
 'adapter-gap-assessment':E/'final-adapter-coverage-assessment',
 'host-refresh':E/'final-host-coverage-assessment-refresh',
 'adapter-refresh':E/'final-adapter-coverage-assessment-refresh',
}
allowed={'.json','.jsonl','.md','.py','.profraw','.profdata','.stdout','.stderr','.log','.rs','.txt','.patch'}
rows=[];external=[]
for label,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  relative=p.relative_to(root);name=label+'/'+relative.as_posix()
  if p.suffix not in allowed:
   if p.suffix in ('.clap','.rlib','.so','.gz') or p.name in ('dynamic-host','dynamic-host','dynamic-host','fast-owner-libtest','instrumented-dynamic-host','trigger-gui-test','trigger-parameters-test'):
    external.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'disposition':'Retained external executable/archive, not committed as reusable binary output'})
   continue
  rows.append({'path':name,'source':str(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777,'sha256':sha(p)})
rows.sort(key=lambda r:r['path']);assert len({x['path']for x in rows})==len(rows)
archive=P/'raw.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for row in rows:
  data=Path(row['source']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];info=tarfile.TarInfo(row['path']);info.size=len(data);info.mode=row['mode'];info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for m,row in zip(members,rows):assert m.name==row['path'] and m.mode==row['mode'] and m.size==row['bytes'] and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==row['sha256']
index={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'included_members':rows,'retained_external_artifacts':external,'scope':'Raw outputs/recipes/profiles/exports/assessments retained byte/mode exact; standalone binary/archive copies remain externally preserved and hash-bound, not committed build caches. Source paths are original evidence locators. No evidence/cache deletion.'};(P/'raw-index.json').write_text(json.dumps(index,indent=2)+'\n')
paths=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines();assert len(paths)==8 and all('/tests/'in p for p in paths)
production=[*R.glob('src/trigger-host/src/*.rs'),*R.glob('src/trigger-editor/src/*.rs'),R/'src/clap-adapter/src/trigger.rs',*R.glob('src/clap-adapter/src/trigger/*.rs')]
combined=read(B/'combined-validation-retry1/commands.json');final=read(B/'final-boundary-checks/commands.json')
binding={'base':'dcd65e4a6226f581510c585376c6b1af1689cae5','scope':'Eight maintained test files only; production unchanged; bounded task5.1 characterization checkpoint, no task/spec/map/overall beta closure','test_sources':{p:sha(R/p)for p in paths},'production_sources':{str(p.relative_to(R)):sha(p)for p in production},'ordinary_validation':[{k:r[k]for k in ('label','command','cwd','exit','seconds','stop_reason')}for r in combined+final if r['label']!='export' and r['label']!='show'],'host_counts':{'unit_and_integration':157,'compile_fail_doctests':2,'affected_characterization_tests':55},'native_counts':{'outer_cases':25,'nested_allocator_children':2},'dynamic_counts':{'ordinary_headless':16,'ordinary_gui':16,'instrumented_gui':16,'nested_allocator_child_each':1},'fast_owner_tests':13,'host_coordinate_union':read(E/'final-host-characterization/root-coverage/combined-production-regions.json'),'adapter_coordinate_union':read(B/'adapter-final-regions.json'),'coverage_limits':'Distinct normal source-coordinate execution union is not LLVM branch/MC/DC or assertion proof; all remaining ranges retain source-bound classifications. Raw runtime/state counts include embedded tests and aliases, separated in host refresh. Three earlier sibling-test snapshot differences are outside those compilation inputs, qualified in adapter refresh.','red_disposition':'Characterizations pass unchanged production. First fast silence assertion included an earlier valid unheard one-shot tap; accepted behavior confirmed, reset before rejection baseline corrected fixture. No invented behavior RED. Unsupported preparer flag, direct rustc relative cwd, and manual CStr lint failures retained separately from product behavior.','refactoring':'Reuse existing tables, copied fixtures, public render/status/metadata paths and existing native selector. No production change or extraction. One fanout fixture is the smallest distinct accepted shape; raw IPC matrix stays in its sole owning native DTO test.','artifacts':{'ordinary_gui':'309e9006a4e41c616b46e41e889e9400507349b20eaf1d0e39ecfde0409b905a','ordinary_headless':'bc2830ffacfe7e6acd373d2af89389cbe8974956611af29631af40a6364dfdc7'},'resources':read(B/'pre-review-preservation.json'),'integration':read(B/'pre-review-integration.json'),'raw_archive_sha256':sha(archive),'raw_index_sha256':sha(P/'raw-index.json'),'mutation':'Excluded by explicit user direction. Normal hooks remain installed; no engine files changed.','overall_remaining':'CLAP final scenario/spec/increment review/publication; fractional sample-rate validator failure unwaived; VST3, standalone/device, selected sample persistence, named DAW, installed/offline and physical native acceptance still required.','orchestration_cost':{'model_token_usage':'unavailable','native_command_wall_times':'Recorded per phase in raw commands.json; controller duration includes sampling intervals and is not per-test duration.'}}
(P/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
(P/'README.md').write_text('''# Trigger rejected-input and accepted-shape characterization

This task5.1 checkpoint extends eight existing test files over published dcd65e4a. Production Rust, product resources, dependency locks, tasks and canonical specs remain unchanged. The full beta is open.

New assertions protect malformed envelope/tuple/decimal admission and invalid detach; native Session attachment capacity without consuming a protocol identity; stale/unknown BeginGesture rejection followed by a balanced valid gesture; regular corrupt WAV preparation and repair; a valid two-output Session rejected by the narrower Trigger runtime; and a maximum public structural request ID whose admitted job still completes and remains recoverable despite snapshot cursor exhaustion.

One accepted control-fanout fixture closes a formerly unproved shape. A single public control targets global and kick gains; its DTO reports instrument scope without a controlGroup. Physical0.5 on each target transforms the known stereo onset from -0.5 to literal -0.125 at offset3, independently distinguishing either missing gain target. Accepted authoring/history remains unchanged.

The existing actual WebView DTO case now sends nine hostile frames through public window.ipc.postMessage: oversized16385-byte input, malformed JSON, another attachment, missing/numeric request IDs, zero, noncanonical decimal, overflowing u64 and overlong decimal. Each is followed by a real authenticated reply, providing an ordering barrier and positive delivery calibration. No fabricated reply appears. Complete accepted session/parameter DTO, saved bytes, original child/attachment, physical value and automation remain unchanged. MIDI36 at offset3 retains literal stereo[-0.5,-358/32768] with leading zeros. The test observes the real production app in memory; no product asset file is modified. A fast real-controller dispatch test separately proves fresh stale-generation note rejection, silence and subsequent valid signed playback. Existing dynamic query tables now reject ID0, invalid UTF8 C bytes, a too-small text buffer and nonexistent audio/note ports.

| Verification | Actual result |
| --- | --- |
| Full format-neutral host | 157 unit/integration plus2 compile-fail doctests,159 passed |
| Affected host ordinary and instrumented targets | 55 passed each |
| Current fast GUI owners | 13 instrumented tests passed |
| Dynamic host against ordinary headless and GUI | 16 passed each, plus allocator child each |
| Current instrumented dynamic host/GUI product | 16 passed, plus allocator child |
| Full ordinary actual native lane | 25 outer cases plus2 nested allocator children passed |
| Changed raw IPC native case | Ordinary and owner/test-instrumented runs passed |
| Formatting and all-target warnings-denied Clippy | Host and editor adapter passed |

Focused host measurement joins the source-identical152-test baseline with55 current affected tests; their overlap is not counted as new tests. All16 identified useful host zero ranges now execute. Production-only remaining guards are individually classified in the host refresh: runtime1114/1117, parameters1345/1382, protocol512/516, lib173/173 and state165/165 distinct normal coordinates. Raw inline-test/duplicate totals differ and remain visible. The adapter union joins the full source-identical product baseline, current13 fast owners, raw native case and16 current dynamic tests: GUI652/700, Trigger628/653 and automation62/62. All12 newly positive adapter coordinates were original zeros; the remaining73 keep explicit invariant, resource-bound or unforced-platform-failure dispositions. No coverage exclusion or branch/MC/DC claim is introduced. Coverage is execution evidence; the named public assertions establish the outcomes.

First characterization runs pass unchanged production; no artificial RED is claimed. One fast fixture initially heard an earlier accepted one-shot tap, an existing documented behavior. An explicit reset before the rejection baseline isolates the new assertion. Its failure/source are retained. Unsupported preparer CLI flags, an initial relative-source rustc working-directory error and a strict CStr style warning are retained as controller/lint failures, not production REDs. Per-criterion refactor decisions reuse existing fixtures/tables and require no production extraction.

The ordinary graphical DSO is the already verified source-free installed product309e9006; plain Trigger is bc2830ff. Current production SHA checks justify that reuse after test-only changes. Three earlier broad snapshots contain later edits to sibling integration tests outside their compilation targets; the refresh identifies them instead of calling every broad snapshot current. The actual selected test sources, owner sources, objects and profiles are bound separately.

raw.tar.gz and raw-index.json retain byte/mode-verified raw commands, outputs, profiles, LLVM exports, recipes and assessments. Large exact instrumented executables and two fully verified compressed host-object archives remain external and are SHA-bound in the index. No reusable cache or evidence was deleted; only redundant one-off host object copies were released after verified archiving. Main remains clean68dd655 and the known1766-file Runtime cache is preserved. RAM cache release was already completed with full disk preservation. Normal review/hooks/publication receipts belong to the sole task tracker.

This checkpoint closes no OpenSpec checkbox or canonical mapping. The official validator fractional1234.5678Hz activation failure remains unwaived, not a total PASS. Final CLAP assessment/spec synchronization/review and all later VST3, standalone, selected sample, named-DAW, offline-installed and physical/native beta gates remain required. Mutation is excluded by user direction.
''')
(P/'sha256.txt').write_text(''.join(sha(p)+'  '+p.name+'\n'for p in sorted(P.iterdir())if p.is_file() and p.name!='sha256.txt'))
print(json.dumps({'packet':str(P),'raw_members':len(rows),'raw_bytes':archive.stat().st_size,'raw_sha256':sha(archive),'packet_files':len(list(P.iterdir()))},indent=2))
