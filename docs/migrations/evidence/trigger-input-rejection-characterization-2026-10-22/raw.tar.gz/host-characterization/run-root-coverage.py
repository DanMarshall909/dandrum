from pathlib import Path
import os,json,hashlib,subprocess,time,shutil,signal
BASE=Path('/tmp/dandrum-evidence/final-clap-dcd65e4a');OUT=Path('/tmp/dandrum-evidence/final-host-characterization/root-coverage');OUT.mkdir(exist_ok=False);ROOT=Path('/tmp/dandrum-lanes/runtime');CRATE=ROOT/'src/trigger-host';ART=OUT/'artifacts';ART.mkdir();TMP=OUT/'tmp';TMP.mkdir();owner=json.loads((BASE/'current-host-owner-recipe.json').read_text());test=json.loads((BASE/'current-host-test-recipe.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={x['path']:x for d in (owner,test) for x in d['input_artifacts']}
inputs={p:b for p,b in inputs.items() if not Path(p).name.startswith('libdandrum_trigger_host-')}
for p,b in inputs.items():assert sha(p)==b['sha256'],p
before={str(p.relative_to(ROOT)):sha(p) for folder in ('src/trigger-host','src/instrument-session','src/rust-engine') for p in (ROOT/folder).rglob('*') if p.is_file() and 'target' not in p.parts and p.suffix in ('.rs','.toml','.lock')};(OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ,CARGO_MANIFEST_DIR=str(CRATE),CARGO_MANIFEST_PATH=str(CRATE/'Cargo.toml'),CARGO_PKG_NAME='dandrum-trigger-host',CARGO_PKG_VERSION='0.1.0',CARGO_PKG_VERSION_MAJOR='0',CARGO_PKG_VERSION_MINOR='1',CARGO_PKG_VERSION_PATCH='0',CARGO_PKG_VERSION_PRE='',TMPDIR=str(TMP),RUST_MIN_STACK='16777216')
for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','LD_PRELOAD','LLVM_PROFILE_FILE'):env.pop(k,None)
receipts=[]
def run(label,command,extra=None):
 start=time.monotonic();samples=[];reason=None;effective=dict(env,**(extra or {}))
 with (OUT/(label+'.stdout')).open('wb') as a,(OUT/(label+'.stderr')).open('wb') as b:
  child=subprocess.Popen(command,cwd=CRATE,env=effective,stdout=a,stderr=b,start_new_session=True)
  while child.poll() is None:
   sample={'seconds':time.monotonic()-start,'disk_free_bytes':shutil.disk_usage('/tmp').free,'mem_available_bytes':int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024};samples.append(sample)
   if sample['disk_free_bytes']<1024**3 or sample['mem_available_bytes']<4*1024**3 or sample['seconds']>300:
    reason='resource floor or deadline';os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    break
   time.sleep(.25)
  code=child.wait()
 row={'label':label,'command':command,'cwd':str(CRATE),'exit':code,'seconds':time.monotonic()-start,'owned_pgid':child.pid,'stop_reason':reason,'resource_samples':samples,'environment':{k:effective[k] for k in ('CARGO_MANIFEST_DIR','CARGO_PKG_VERSION','TMPDIR','RUST_MIN_STACK','LLVM_PROFILE_FILE') if k in effective},'stdout_sha256':sha(OUT/(label+'.stdout')),'stderr_sha256':sha(OUT/(label+'.stderr'))};receipts.append(row);(OUT/'commands.json').write_text(json.dumps(receipts,indent=2)+'\n');assert code==0 and reason is None,(label,code,(OUT/(label+'.stderr')).read_text()[-2500:]);print(label,code,round(row['seconds'],3),flush=True)
import tarfile
old=json.loads((BASE/'host-owner-coverage/binding.json').read_text());archive=json.loads((BASE/'host-owner-coverage/artifact-archive.json').read_text());archive_path=Path(archive['archive']);assert sha(archive_path)==archive['archive_sha256'];member=next(m for m in archive['members'] if m['path'].endswith('.rlib'));rlib=ART/Path(member['path']).name
with tarfile.open(archive_path,'r:gz') as source,rlib.open('wb') as destination:shutil.copyfileobj(source.extractfile(member['path']),destination)
assert sha(rlib)==member['sha256']==old['owner_rlib']['sha256']
for p,h in old['source_sha256'].items():
 if not p.startswith('src/trigger-host/tests/'):assert sha(ROOT/p)==h,p
executables=[]
for name in ('packaged_resources','parameters','protocol','session_jobs','snapshot'):
 cmd=list(test['command']);cmd[cmd.index('--crate-name')+1]=name;cmd[cmd.index('tests/parameters.rs')]='tests/'+name+'.rs';cmd[cmd.index('-o')+1]=str(ART/name)
 for i,a in enumerate(cmd):
  if a=='--extern' and cmd[i+1].startswith('dandrum_trigger_host='):cmd[i+1]='dandrum_trigger_host='+str(rlib)
 run('compile-'+name,cmd,{'CARGO_CRATE_NAME':name});executables.append((name,ART/name))
for name,exe in executables:run('test-'+name,[str(exe),'--test-threads=1'],{'LLVM_PROFILE_FILE':str(OUT/(name+'-%m-%p.profraw'))})
assert before=={p:sha(ROOT/p) for p in before};(OUT/'source-after.json').write_text(json.dumps(before,indent=2)+'\n');profiles=sorted(OUT.glob('*.profraw'));assert len(profiles)==5
sysroot=Path(subprocess.check_output(['/home/dan/.cargo/bin/rustc','--print','sysroot'],text=True).strip());binpath=sysroot/'lib/rustlib/x86_64-unknown-linux-gnu/bin';profdata=OUT/'merged.profdata';run('merge',[str(binpath/'llvm-profdata'),'merge','-sparse',*[str(p) for p in profiles],'-o',str(profdata)])
objects=[str(p) for _,p in executables];sourcefiles=[str(p) for p in sorted((CRATE/'src').glob('*.rs'))];args=[objects[0],*[x for p in objects[1:] for x in ('--object',p)],'--instr-profile',str(profdata),*sourcefiles];run('export',[str(binpath/'llvm-cov'),'export',*args]);run('show',[str(binpath/'llvm-cov'),'show',*args,'--show-line-counts-or-regions'])
binding={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_sha256':before,'compiler':cmd[0],'compiler_sha256':sha(cmd[0]),'dependencies':inputs,'reused_owner_rlib':{'path':str(rlib),'sha256':sha(rlib),'original_binding':str(BASE/'host-owner-coverage/binding.json'),'archive':archive['archive'],'archive_sha256':archive['archive_sha256']},'test_executables':{n:{'path':str(p),'sha256':sha(p)} for n,p in executables},'profiles':{p.name:sha(p) for p in profiles},'merged_profile_sha256':sha(profdata),'scope':'Exact unchanged production instrumented host rlib restored from verified archive; fresh five current test executables run55tests. Separate current152baseline supplies full owner scope, merged only through distinct identical production source-coordinate analysis. No sharedcache mutation/dependency rebuild/global flags/branch claim.'};(OUT/'binding.json').write_text(json.dumps(binding,indent=2)+'\n');print('Focused final host characterization coverage complete',flush=True)
