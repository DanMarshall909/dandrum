import pathlib,json,os,subprocess,sys,time,hashlib,signal
out=pathlib.Path('/tmp/dandrum-evidence/final-host-characterization');label=sys.argv[1];cmd=sys.argv[2:];root=pathlib.Path('/tmp/dandrum-lanes/protocol')
mem=lambda:int(next(l.split()[1] for l in pathlib.Path('/proc/meminfo').read_text().splitlines()if l.startswith('MemAvailable:')))*1024
free=lambda:os.statvfs(out).f_bavail*os.statvfs(out).f_frsize
assert free()>=1024**3 and mem()>=4*1024**3
receipt={'command':cmd,'cwd':str(root),'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()for p in list(root.glob('src/trigger-host/src/*.rs'))+list(root.glob('src/trigger-host/tests/*.rs'))},'disk_before':free(),'mem_before':mem()}
env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/dandrum-lanes/cache-runtime';env['TMPDIR']=str(out/'tmp');pathlib.Path(env['TMPDIR']).mkdir(exist_ok=True)
assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
start=time.monotonic()
with (out/(label+'.stdout')).open('w') as so,(out/(label+'.stderr')).open('w') as se:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=so,stderr=se,start_new_session=True);receipt['owned_pgid']=p.pid
 while p.poll() is None:
  if free()<1024**3 or mem()<4*1024**3:
   os.killpg(p.pid,signal.SIGTERM);receipt['stop_reason']='resource floor';break
  time.sleep(.25)
 try:code=p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
receipt.update(exit=code,seconds=time.monotonic()-start,disk_after=free(),mem_after=mem());(out/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items()if k!='source_sha256'}));print((out/(label+'.stdout')).read_text()[-3000:]);print((out/(label+'.stderr')).read_text()[-2000:]);sys.exit(code)
