from pathlib import Path
import hashlib,json,tarfile,gzip,shutil,time
OUT=Path('/tmp/dandrum-evidence/final-host-characterization/root-coverage');ART=OUT/'artifacts';ARCHIVE=OUT/'host-owner-artifacts.tar.gz';assert ART.is_dir() and not ART.is_symlink() and not ARCHIVE.exists()
def digest(f):
 h=hashlib.sha256()
 while True:
  b=f.read(1024*1024)
  if not b:break
  h.update(b)
 return h.hexdigest()
rows=[];start=time.monotonic();disk_before=shutil.disk_usage('/tmp').free
for p in sorted(ART.iterdir()):
 assert p.is_file() and not p.is_symlink()
 with p.open('rb') as f:sha=digest(f)
 rows.append({'path':'artifacts/'+p.name,'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777,'sha256':sha})
with ARCHIVE.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=1) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for row in rows:tar.add(OUT/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(ARCHIVE,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):assert member.name==row['path'] and member.size==row['bytes'] and member.mode==row['mode'] and digest(tar.extractfile(member))==row['sha256']
with ARCHIVE.open('rb') as f:sha=digest(f)
record={'archive':str(ARCHIVE),'archive_sha256':sha,'archive_bytes':ARCHIVE.stat().st_size,'members':rows,'uncompressed_bytes':sum(x['bytes'] for x in rows),'restore':'tar -xzf host-owner-artifacts.tar.gz -C the host-owner-coverage directory','scope':'All exact temporary instrumented owner/test outputs retained in fully byte/mode-verified archive. Only redundant one-off artifacts directory removed after verification; no shared/reusable Cargo cache or profile/export/input removed.','seconds':time.monotonic()-start,'disk_free_before':disk_before};(OUT/'artifact-archive.json').write_text(json.dumps(record,indent=2)+'\n');shutil.rmtree(ART);record['disk_free_after_releasing_redundant_copies']=shutil.disk_usage('/tmp').free;(OUT/'artifact-archive.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='members'}),flush=True)
