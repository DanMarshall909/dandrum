# Test-only characterization plan

Baseline: dcd65e4a, fresh current full owner152 actual tests, same five production owner hashes. No production behavior/API/schema change; immediate characterization PASS is valid.

1. Followup: extend public protocol malformed envelope/method and lifecycle cases. Exact InvalidArguments, native-capacity failure, accepted state/signed audio and transport/attachment identity preservation. Reuse current fixtures/tables; no new abstraction.
2. Followup: stale/unknown BeginGesture rows in existing invalid-command test, preserving parameter/automation and independent signed output.
3. Followup: readable valid YAML plus regular corrupt WAV fails actual initial Session preparation; restore file and render known signed sample. A second stereo root output prepares as a Session but controller rejects UnsupportedLayout.
4. Followup: public session request ID u64::MAX makes advertised nextRequestId unavailable without preventing real admitted job service/outcome recovery. Preserve accepted state/audio until normal completion.
5. Tracer: accepted root control fans out to both player.level and player.group_1_level, with original global level alias/root removed. Snapshot labels fanout alias instrument/no controlGroup; physical0.5 must produce signed first sample -0.125 (sample -0.5 times each of two0.5 gains), distinguishing one-target wiring. Fixture rejection is setup evidence, not behavior RED or permission to repair production.

Source-only phase: no builds/tests/cache writes until root leases cache-runtime. Later execute ordinary narrow tests, formatting/strictClippy and direct current-owner LLVM; retain exact commands/source/dependency/profile binding. No mutation, Git staging/commit, tracker/spec/map updates. Consider production and test refactoring per criterion after executable evidence.
