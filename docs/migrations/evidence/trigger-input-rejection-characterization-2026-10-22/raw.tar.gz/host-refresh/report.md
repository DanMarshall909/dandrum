# Final current Trigger-host coverage assessment

The joined evidence now supports the current host owner assessment within its stated scope. **All16 previously identified useful missing production ranges execute in the fresh55-test characterization run, with explicit public behavior assertions.** The remaining44 production ranges retain individual invariant, counter or unforced failure qualifications. No additional useful reachable host gap was identified in this bounded followup. This is a coverage/evidence assessment, not an independent completion verdict or task closure.

The source-coordinate totals were independently reconstructed from the actual baseline152 export and fresh55 export. The method resolves LLVM file IDs, normalizes source paths, selects only the five exact production owners, removes inline `cfg(test)` source ranges and takes the maximum count for identical normal coordinates. No percentages or raw-instantiation counts were added together.

| Current production owner | Positive normal source regions | Previous useful gaps closed | Qualified ranges still zero |
|---|---:|---:|---:|
| `parameters.rs` `e124d39b…` |1345/1382|4|37|
| `protocol.rs` `d18bb5e0…` |512/516|11|4|
| `lib.rs` `d16daf16…` |173/173|1|0|
| `runtime.rs` `41cb1468…` |1114/1117|0|3|
| `state.rs` `9355b2c8…` |165/165|0|0|

The published combined JSON's runtime2124/2130 includes1010/1013 inline test regions. Runtime's three other zero coordinates at1508/1636/1853 belong to test alternatives. State's177/177 includes12/12 inline test regions, while its old raw176/177 report retained a duplicate-instantiation miss. The source alias `src/trigger-host/src/../tests/internal/state.rs` normalizes to a test file and is excluded entirely from these production counts. These distinctions prevent either inflating production coverage with tests or misclassifying test branches as missing product behavior.

## Assertion correspondence for the16 newly positive ranges

Coverage proves execution. The following correspondence is based on reading the exact final test assertions; the results do not claim mutation or exhaustive fault detection. All nine owning test functions have positive entries in the fresh export and appear in the successful55-test execution logs.

| Owner ranges | Exact owning public tests | Observable protection |
|---|---|---|
| protocol195|`versioned_snapshot_requests_are_typed_and_invalid_envelopes_preserve_accepted_state`|Noncanonical, zero and overflowing attachment IDs return exact `InvalidArguments`; accepted native snapshot, controls and literal stereo sample remain intact; valid transport ID2 can subsequently be admitted.|
| protocol280/282/292/298/304/334/350/351|`invalid_method_arguments_and_stale_session_intents_cannot_change_controls_or_sound`|Wrong mapping/Undo/status/gesture/noteOff tuple shapes and malformed mapping identity strings return exact typed errors. Every row retains the same accepted snapshot and signed/controls oracle; valid request ID2 at the ingress-size boundary still succeeds, so rejection has not consumed admission.|
| protocol448|`retired_editor_ids_and_foreign_native_sessions_cannot_recover_authority`|Malformed detach text returns `InvalidArguments`, current attachment and duplicate correlation remain usable, known signed output remains, then real detach retires the native authority.|
| protocol91|`native_attachment_capacity_rejection_does_not_consume_a_protocol_identity`|Sixteen directly retained Session attachments exhaust native capacity before protocol has any connections. Failed protocol attach reports `Session(AttachmentLimit)` and preserves accepted state/audio; releasing one slot permits attachment ID1 and a valid first request.|
| parameters1159|`invalid_commands_and_stale_or_foreign_owners_preserve_both_instances`|Stale and unknown Begin requests return exact errors with unchanged values/empty ledger. A subsequent valid Begin/End returns generation1/sequence0 and yields exactly one ordered acknowledged Begin/End pair. The existing independent scalar writes render distinct literal stereo values afterward.|
| parameters708|`a_valid_session_with_two_stereo_outputs_is_rejected_by_the_trigger_runtime`|Authored YAML with a second stereo output genuinely prepares under public Session, then public controller construction returns exact `Runtime(UnsupportedLayout)`. This distinguishes Session acceptance from Trigger runtime rejection.|
| lib198|`a_regular_corrupt_sample_fails_preparation_without_checkout_fallback_and_can_be_repaired`|The real packaged file remains regular/present, but corrupt WAV bytes produce `Session(PreparationFailed(_))`; restoring those bytes permits ordinary opening and literal stereo-0.5 output. This prevents checkout fallback from masquerading as success.|
| parameters930|`exhausted_next_request_projection_does_not_cancel_the_last_admitted_native_job`|One public mapping with session request ID`u64::MAX` is acknowledged. Snapshot cursor projection returns exact `Protocol(Session(RevisionExhausted))`, preserving accepted session, public values, automation and old signed playback. The actual owned completion still publishes once, moves signed playback36→60 and exposes exact recovered terminal status/history despite the persistent snapshot cursor error. No private counter injection or enormous loop.|
| parameters875|`a_public_control_fanning_out_to_global_and_group_gain_has_instrument_scope_and_drives_both`|A genuinely accepted authored root-control list targets global and kick gains. The DTO has instrument scope and omits controlGroup. Physical0.5 yields literal stereo-0.125 at offset3 after default-0.5; one gain alone would yield-0.25. Prefix silence, normalized values and unchanged accepted history are also asserted. This establishes the previously unproved fanout fixture.|

No production source changed. The five current test source hashes match the author handback, fresh root coverage binding, Integration and Runtime copies. The old152 run is reused only for the unchanged production source and exact dependency identities; its old test profiles are not falsely labelled new-test execution.

## Remaining44 ranges

`assessment.json` retains every exact coordinate, source line, prior reachability reason and action. All44 match the carried classifications with no new zero production coordinate and no leftover `useful_missing_behavior`/`useful_missing_shape` entry:

- **37 parameter coordinates:**22 ownership invariants, nine abnormal-worker failure coordinates, four impractical accumulated-counter guards, one literal-zero invariant and one OS thread-launch failure. The one-active-job/channel, sealed nonclone completion, exclusive prepare/commit and sole-producer queue proofs still apply to unchanged source. Worker disconnect can race thread-finished observation; that failure remains explicitly unforced, rather than being labelled impossible. Intentionally panicking a wake violates its public nonpanicking precondition and was not added as a score test.
- **Four protocol coordinates:**private attachment/event identity exhaustion at90/541, private actual-caller live-attachment validation at495, and owned derived-enum serialization at521. No custom fallible serializer/user writer enters that last call. Foreign public Session APIs remain distinct from the controller's private helper input domain.
- **Three runtime coordinates:**same-document/private reconfiguration preparation at299, immutable host-slice parameter preflight at874, and validated/reserved event budget at1066. Existing callback and signed DSP tests remain the behavior evidence; the count alone is not proof of those assertions.

No source exclusion was introduced. Practically unreachable counters and external/abnormal failures remain visible measurement limits; this is not a claim of every-instantiation, branch, concurrency-schedule or production100% coverage.

## Independent artifact and execution checks

- Rehashed all five fresh raw profiles and merged profile: exact matches.
- Rehashed the fresh archive and streamed **every one of its11 members**, independently checking each byte count, mode and SHA-256. All six bound artifacts (13MB owner rlib plus five test executables) match those streamed members; the five dep-info files match too. Uncompressed total997,831,533bytes; compressed archive277,546,187bytes, SHA-256`52ae63ee2533d8b12ce3445d9a91877ce7ede050970d403d00d5fb06f43137b4`. No object was extracted or written. Released redundant artifact paths are preserved evidence, not missing objects.
- Verified all ten relevant dependency identities are identical between baseline and fresh bindings and match current files. Reused owner rlib SHA-256 remains`c0000b35a111d1fb679a24b276b038e893220825d2da62e18677aabdcfe15a5c`.
- Fresh instrumented55 tests: five successful owning executables, no failed/ignored/filtered cases. Baseline152 plus new55 is a coverage-source join, **not207 distinct tests**.
- Independent final ordinary suite log reconstructs157 unit/integration tests plus2 compile-fail doctests =159 passes. Recorded full-suite, fmt and warnings-denied all-target Clippy commands exit0 and their stdout/stderr hashes match. The ordinary suite is separate from LLVM evidence.

The original fractional-rate validator failure remains unwaived, mutation is excluded, and beta/task/publication authority remains with root. This followup started no build, test, LLVM command or worker and changed no source/cache/Git/tracker state. Only this report and `assessment.json` were written in the authorized evidence directory. All inspected Rust source hashes remained unchanged through review; no resources are retained beyond these reports.
