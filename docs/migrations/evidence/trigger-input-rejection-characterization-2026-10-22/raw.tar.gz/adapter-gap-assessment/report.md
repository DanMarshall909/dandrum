# Final adapter production coverage: read-only assessment

Scope: source commit supplied dcd65e4a6226f581510c585376c6b1af1689cae5; only new product owners trigger.rs/gui.rs/automation.rs. `assessment.json` records all85 distinct normal zero ranges, individual classifications/source excerpts/related test limits, independently reconstructed aggregation and162 read-hash checks. No builds/tests/native/LLVM execution, Git/tracker/spec/task/map/source changes or cache mutations occurred. Source and exact objects/profiles/tools were read only; no resources acquired. This is task5.1 preparation, not an increment review or validator disposition.

## Provenance and interpretation

All supplied source digests matched Integration at the check instant. Rehashed product, dynamic host, both copied fixture test/plugin objects, copied/original fast-owner object, all54 merged-input profiles plus27 retained original fast-owner profiles, merged.profdata, export/show bytes and their empty stderr, LLVM binaries and source-before/source-after evidence: no mismatch/read failure. Exact checks and expected/observed SHA256 are retained. This does not recreate compilation or rerun LLVM; the supplied commands retain successful merge/export/show. Runtime-named source paths inside LLVM are mapped to byte-equal Integration source, not read as a changing worktree.

I independently parsed export function regions, selected kind0 normal regions, keyed by filename + four source coordinates and took positive execution across instantiations. The regenerated zero sets exactly equal supplied distinct-source-regions.json:

| Owner | Distinct normal source ranges | Remaining |
|---|---:|---:|
| trigger.rs |624/653|29|
| trigger/gui.rs |644/700|56|
| trigger/automation.rs |62/62|0|

Raw LLVM gui summary is627/700 regions, not644/700; the difference is aggregation across generic instantiations. Raw lines are trigger499/512 and gui422/468. Neither representation is branch coverage or proof every region's output is asserted. Tiny error-propagation and closing-delimiter ranges are retained individually;85 ranges are not85 separate behaviors. Unchanged fixture lib.rs and embedded test misses are outside this new-owner count. They keep their earlier headless fixture proof and explicit source/evidence reuse limits; this run does not newly prove every fixture path.

## Useful remaining characterizations

Two bounded additions are worthwhile before final owner closure. They exercise legal reachable input and reuse existing ownership/tests; no production change is inferred or authorized by this assessment.

**1. Actual raw ingress, in `copied_native_parameter_state_is_an_authenticated_numeric_dto`.** Keep the existing real mount/initial DTO, insert a hostile-frame phase before its current early destroy/drop, and reuse same-file saved_state, invoke, start_audio/render_audio/return_audio. No new test selector or CMake registration is needed. Send through actual `window.ipc.postMessage`, bypassing the browser broker that already validates outgoing requests:

- a valid parameter-write envelope padded to16385 UTF8 bytes;
- malformed JSON `{`;
- a wellformed parameter-write frame carrying another attachmentId;
- missing/nonstring requestId;
- requestId zero, noncanonical01, overflowing u64 or >20digits.

These drive gui295/311/314/317/324. Use baseline full accepted session/parameter DTO and saved bytes, original XID/view/composite attachment and physical value1; after rejected frames, obtain real authenticated snapshot/DTO via the ordinary broker, compare generation/sequence and no extra automation, and assert independently known MIDI36 offset3 stereo[-0.5,-358/32768] plus leading zeros. A later normal Promise establishes continued native usability. Keep failure cleanup reliable before resuming assertions. Uncorrelatable frames intentionally have no fabricated reply; a timeout alone is not a rejection oracle. A correlatable unknown method can calibrate actual rejection delivery, but no native duplicate/conflict matrix is needed to replace existing admission/dispatch proof.

Lower protocol tests already protect malformed/oversized/stale input and signed sound. They do **not** execute receive preflight; its zero ranges are real reachable characterization gaps, not blanket-waived invariants. Retired callback authority (gui302), missing child during transition(gui305) and borrow failure(gui299/328) are different owner/lifetime guards, not the same as a foreign envelope attachment(gui314).

**2. Semantic note error projection, in `current_dispatch_preserves_snapshot_notes_admission_and_capability_errors`.** Add a freshly admitted noteOn36/value1/generation2 while actual generation is1, with a fresh transport ID. It must encode rejected invalidArguments from StaleGeneration without accepted session/control/automation change and without an audible onset. Keep its returned RuntimeAudio and then issue a fresh valid generation1 note; assert accepted reply and literal signed PCM, followed by cleanup. Existing later IDs must stay fresh. This exercises gui371/373/374 and actual public command recovery without fabricating an AdmittedRequest. The unhit Protocol arm at372 is separate: the same owner admits and immediately dispatches sealed input, so stale/foreign/altered admitted context cannot appear between those steps. Existing controller sealed-note tests cover their own public authority law, not this adapter arm.

Optional cheap adjacent defensive queries can extend existing `physical_text_conversion_and_unknown_metadata_indices_are_explicit`: ID0 conversion and missing direction/index metadata. They are safe queries and do not require native setup. They are lower priority than raw ingress/note projection; non-UTF8 or undersized typed-event fabrication is not required for a score.

## Disposition of the other ranges

The JSON gives exact coordinates for every entry; group rationale is source-bound:

- **Private main-owner borrow guards (25):** controller/GUI/automation borrows end before foreign stream/host/browser calls. Current ordinary entrypoint/reentrancy paths cannot retain those borrows. Existing detached-feedback deferral and reentrant-state-stream tests establish related laws. No fabricated retained RefCell borrow is recommended merely to execute another guard. Creation's post-register borrow failure is distinct from already tested reentrant destroy invalidating provisional creation.
- **Matched endpoints/layout/call order (16 plus one timer alternative):** audio and automation endpoints transfer/return together; failed activation restores ownership. Missing output after count1 or missing channels after count2 contradicts the validated typed layout. Timer callers disable before removal, leaving the private Live-removal match unexecuted. Preserve these invariants and existing rollback/return/reset/independent-instance tests; do not call active-only entrypoints through inactive handles or mutate private endpoints.
- **Authority/path/counter invariants:** valid absolute existing plugin file has a parent and cannot contain NUL; one GUI owns one native attachment, immediately sealed note admission cannot turn foreign, and controller.admit currently returns only Protocol errors. Attachment/instance exhaustion is checked, but u64 exhaustion is not meaningfully driven by public factory/reconnect calls. No private counter or attachment mutation is proposed.
- **Lifetime/final cleanup backstops:** weak callbacks and GLib sources are cancelled/disconnected before final Core loss; normal Main destruction detaches before Core fallback. Actual WebView/XID/application-capture expiry and no-late-event assertions remain meaningful independent proof. Unexecuted backstops are not evidence of a leak, and cannot be manufactured by retaining obsolete private callbacks while claiming ordinary lifecycle.
- **Unforced platform/capability failures:** OS worker creation, GTK init, GTK already owned by another thread, dladdr/NOLOAD and HostTimer disappearing at unregister remain unforced. These are explicit gaps, not mathematical impossibilities. Wrong loaded-object identity, missing/refused timer registration and failed unregister retry are independently tested. A fresh process with owned environment can later characterize supported non-X11/display/thread failure if required; no global display mutation/interposition/unsafe foreign entrypoint is justified solely for these ranges.
- **Visibility:** NativeEditor.set_visible checks its GTK thread, then show/hide/display.sync returns Ok. After valid parenting the same GTK/CLAP main-thread law precludes its error arm; off-thread owner transfer would violate that law.
- **Fixed product size/reply bounds:** state-save and receive reply failure propagation are unexecuted for the small immutable current product. Lower codec/encoding owners have explicit bounds/errors; another trusted giant document/package could trigger them. Do not call them universal impossibilities or pretend all native output failure paths were reproduced.
- **Pinned typed-event contract:** UnknownEvent::from_raw requires valid header/content. An advertised byte span shorter than EventHeader would violate that wrapper's safety precondition before translate's defensive size check; do not add unsafe malformed Rust events to force trigger321. Existing count/missing/truncated-supported-payload tests preserve values and signed audio at their actual boundary.

Current positive automation source ranges are62/62, with actual delivery/backpressure/accepted-credit behavior independently asserted by existing fast/native tests. This is not automatic behavioral completeness or an allocation/branch claim for every callback schedule.

## Handback

Retain the85-range JSON, aggregate/raw distinction and all unforced qualifications. Root can author the two small additions at the existing owners, establish honest characterization/RED as observed, and rerun only relevant verification/coverage afterward. No new monolith, production seam, unsafe ABI violation or private-field mutation is recommended. This report does not close task5.1/any task; whole-increment independent review and the official fractional-rate validator FAIL remain open. Read-only assignment released; no processes/resources retained.
