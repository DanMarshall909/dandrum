import pathlib,json,hashlib,collections,subprocess
out=pathlib.Path('/tmp/dandrum-evidence/final-clap-coverage-ledger'); repo=pathlib.Path('/tmp/dandrum-lanes/integration'); ev=pathlib.Path('/tmp/dandrum-evidence')
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
paths=[*repo.glob('src/trigger-host/src/*.rs'),*repo.glob('src/trigger-editor/src/*.rs'),repo/'src/clap-adapter/src/trigger.rs',*repo.glob('src/clap-adapter/src/trigger/*.rs'),*repo.glob('src/instrument-session/src/*.rs')]
before={str(p.relative_to(repo)):sha(p) for p in paths}
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
records=[('g3-note-lease/final-owner-raw-export.json','g3-note-lease/final-owner-coverage-binding.json'),('g3-note-lease/final-native-raw-export.json','g3-note-lease/final-native-coverage-binding.json'),('g3-continuous-native-audio/coverage-final/export.json','g3-continuous-native-audio/refactor-coverage-binding.json'),('g3-creation-failure/coverage/export.json','g3-creation-failure/final-coverage-binding.json'),('g3-held-destruction/held-dso-final-raw-export.json','g3-held-destruction/held-dso-final-coverage-binding.json')]
agg=collections.defaultdict(dict); receipts=[]
for exp,binding in records:
 p=ev/exp;b=read(ev/binding);d=read(p);actual=sha(p);expected=b.get('export_sha256'); r={'export':str(p),'actual_export_sha256':actual,'binding':str(ev/binding),'binding_sha256':sha(ev/binding),'recorded_export_sha256':expected,'export_matches':actual==expected,'objects':[],'profiles':[]}
 objects=b.get('objects',{})
 if 'elf' in b:objects={b['elf']:b['elf_sha256']}
 for key,items in [('objects',objects),('profiles',b.get('profiles',{}))]:
  for path,h in items.items():
   q=pathlib.Path(path);check={'path':path,'expected_sha256':h,'present':q.is_file()}
   if q.is_file():check.update(actual_sha256=sha(q));check['matches']=check['actual_sha256']==h
   r[key].append(check)
 receipts.append(r)
 for f in d['data'][0]['functions']:
  for rr in f['regions']:
   if len(rr)<8 or rr[7]!=0:continue
   try:nm=f['filenames'][rr[5]]
   except IndexError:continue
   if not nm.endswith(('/src/trigger.rs','/src/trigger/gui.rs','/src/trigger/automation.rs','/src/native_x11.rs')):continue
   k=tuple(rr[:4]);agg[nm][k]=max(agg[nm].get(k,0),rr[4])
result={'method':'Read existing exports only; distinct normal code source coordinates, max positive across source-identical runs. Not LLVM summary arithmetic, branch coverage or assertion proof. Existing source bindings inspected separately; no new LLVM/tool/test execution.','inputs':receipts,'owners':{nm:{'distinct_normal_regions':len(rs),'positive_regions':sum(v>0 for v in rs.values()),'zero_ranges':[list(k) for k,v in rs.items() if not v]} for nm,rs in agg.items()}}
(out/'current-source-region-union.json').write_text(json.dumps(result,indent=2)+'\n')
after={str(p.relative_to(repo)):sha(p) for p in paths}
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
(out/'preservation.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'git_status_short':subprocess.check_output(['git','status','--short'],cwd=repo,text=True),'source_before_after_identical':before==after,'executed_builds_tests_llvm_git_mutations':False,'only_writes':str(out),'resources_retained':'Only report files; no worker or builder started.'},indent=2)+'\n')
print(json.dumps({'source_files':len(before),'before_after_identical':before==after,'exports':[{ 'export':r['export'],'export_matches':r['export_matches'],'objects_present_matching':sum(x.get('matches',False) for x in r['objects']),'objects':len(r['objects']),'profiles_present_matching':sum(x.get('matches',False) for x in r['profiles']),'profiles':len(r['profiles'])}for r in receipts],'union':{k:(v['positive_regions'],v['distinct_normal_regions']) for k,v in result['owners'].items()}},indent=2))
