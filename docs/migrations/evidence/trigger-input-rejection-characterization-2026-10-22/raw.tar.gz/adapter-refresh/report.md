# Adapter coverage assessment refresh — delta only

Read-only Followup to `/tmp/dandrum-evidence/final-adapter-coverage-assessment`. Current production trigger.rs/gui.rs/automation.rs is byte-identical to that85-range assessment. Root added tests only: raw native DTO ingress, fast stale-note recovery, public metadata/text queries and five separate host-test changes. No production repair, asset change, extraction or new selector is inferred. No builds/tests/LLVM/native/Git/cache mutation/source/tracker/task/map changes occurred here; only this report/JSON were written.

## Verified evidence delta

Rehashed all4 union exports,3 fresh coverage bindings/commands/source snapshots, new ELF/dependency objects,7 raw profiles and3 merged profiles, current ordinary host/DSO identities and result/chronology evidence. Artifact/profile/object checks match. Independently reparsed normal function regions from all4 exports and unioned unchanged coordinates across instantiations; regenerated zero sets exactly match adapter-final-regions.json.

| Owner | Prior distinct normal execution | Current union | Remaining |
|---|---:|---:|---:|
| trigger/gui.rs |644/700|652/700|48|
| trigger.rs |624/653|628/653|25|
| trigger/automation.rs |62/62|62/62|0|

All12 removed initial-zero coordinates are accounted for; the other73 original entries, classifications, source excerpts and limitations are carried verbatim into `assessment.json`. The new raw body347–408 has155 distinct normal ranges,155 positive/0 zero in its fresh host export. These are execution measures, not branch coverage, behavioral completeness or whole fixture/owner completion.

Three broad source-map differences are preserved explicitly: fast-coverage-retry1 captured earlier trigger_parameters.rs and trigger_dynamic.rs; native-coverage captured earlier trigger_dynamic.rs. Those sibling integration tests are not compiled into the selected fast libtest / native parameter host respectively. Selected changed owners and production match; newest final dynamic/ordinary bindings cover final sibling tests. Do not claim every broad earlier directory snapshot equals the final test tree. No artifact mismatch/read failure was found.

##12 formerly zero coordinates now positive

Coordinates are start-line:column–end-line:column, exact production source coordinates; each is linked to positive input exports in JSON.

| Owner / exact initial ranges | Current assertion owner |
|---|---|
| gui295:13–295:19;311:13–311:19;314:13–314:19;317:13–317:19;324:13–324:19 | `copied_native_parameter_state_is_an_authenticated_numeric_dto`: actual raw ingress drops |
| gui371:40–371:45;373:26–373:57;374:17–374:18 | `current_dispatch_preserves_snapshot_notes_admission_and_capability_errors`: semantic note-error projection |
| trigger208:52–208:53;247:44–247:45 | `physical_text_conversion_and_unknown_metadata_indices_are_explicit`: ID0 and valid CStr containing non-UTF8 bytes reject; public scalar/save remain unchanged |
| trigger286:9–286:10;301:9–301:10 | `real_sampler_ports_and_offset_midi_parameter_values_render_literal_signed_pcm`: nonexistent audio/note direction/index returns no descriptor; independent later signed playback remains |

## Actual useful-gap closure

**Raw IPC:** the existing DTO test retains its real production mount, baseline saved bytes/full session/DTO, child and composite identity. Nine hostile frames use real `window.ipc.postMessage`:16385-byte padded valid write, malformed JSON, foreign attachment, missing request ID, numeric ID, zero, noncanonical01, u64 overflow and21digit ID. These write-shaped inputs would alter level if incorrectly admitted. Each is followed by a genuine authenticated broker parameter request; reply observation asserts exactly that valid reply and its unchanged payload. The ordering barrier plus independently positive native receive-drop coordinates avoids relying on a timeout or a successful fake response. Full session/save/physical1/original child/identity remain unchanged; zero offered automation and offset3 stereo[-0.5,-358/32768] with leading zeros independently protect control/mapping/audio. Assertions occur after ordinary GUI teardown, retaining cleanup on an assertion failure.

This closes the five specific reachable receive preflight gaps identified earlier. It does not claim delayed global framework quiescence or execution of stale callback/busy owner/missing-child branches; those are different remaining coordinates. Unknown method and duplicate/conflict classification retains complementary protocol/shared-dispatch proof; a new native monolith is unnecessary.

**Semantic note:** the existing fast dispatch owner resets the earlier accepted one-shot before its silence baseline. Fresh request8 noteOn36/value1/generation0, against current generation1, returns invalidArguments from the real controller. Session snapshot/parameter DTO/automation remain unchanged and a real block stays silent. Fresh request9 generation1 then accepts and renders literal stereo-0.5. This closes the adapter semantic failure projection and recovery gap; it does not force the still-unhit Protocol error arm after immediate sealed admission.

**Cheap query rows:** tests use public typed metadata/text APIs, including `c"\xff"`, and preserve saved state/control or later literal audio. No unsafe invalid EventHeader or private-field/counter mutation was introduced.

## Chronology and retained validation

The first stale-note silence failure was an oracle calibration error: an earlier accepted one-shot had not been rendered and NoteOff does not cancel that sample's one-shot semantics. Root's explicit reset establishes the intended clean baseline; no product defect or production RED is claimed. Initial direct fast instrumentation failed from a wrong cwd/source path; the manual CStr form failed strict Clippy and was replaced by the C-string literal. Original logs remain distinct from corrected results.

Retained ordinary evidence reports159 host passes (157 unit/integration +2 doctests),16 dynamic tests each against plain/GUI product, formatting and strict Clippy. Fresh fast owner13 and native9-frame characterization pass; final boundary run passes25 ordinary native outer cases with2 nested allocator children. Shared build/setup/driver coverage remains separate existing29-CTest proof. These are retained source-bound outcomes, not executions by this agent.

## Remaining73 are not blanket-waived

The JSON carries every remaining zero classification. Prior source-backed reasoning still applies to private same-owner borrow guards, matched endpoint/validated layout laws, checked identity exhaustion, sealed-context fallback and cleanup backstops. Actual GTK/loader/thread-start/host-capability failures remain explicitly unforced. Current fixed-product state/reply-budget propagation is not generalized to arbitrary giant resources. Visibility error would require violating the established GTK/main-thread law; undersized UnknownEvent fabrication would violate the pinned typed wrapper precondition. These distinctions remain qualifications for root's final owner assessment, not automatically waived coverage or newly tested behavior.

The two originally recommended useful public gaps are now behaviorally characterized and their exact production ranges execute. No further delta gap is established by this refresh. Whole-owner adequacy, independent checkpoint/increment review, task completion and official fractional-rate validator FAIL disposition remain outside this report. Mutation remains excluded. Read-only assignment released; no processes/resources acquired or retained.
