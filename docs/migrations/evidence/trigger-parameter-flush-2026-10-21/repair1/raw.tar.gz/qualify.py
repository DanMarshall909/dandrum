from pathlib import Path
import json,hashlib,collections,subprocess,os,re,time
b=Path('/tmp/dandrum-lanes/evidence-parameter-flush-repair1');root=Path('/tmp/dandrum-lanes/runtime');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((b/'04-full-owner-cov/host.json').read_text())['data'][0];q={'source_phase':'04-full-owner-cov','functions':{}}
for name in ('flush_parameters','apply_parameter'):
 c=collections.defaultdict(int)
 for f in d['functions']:
  if name not in f['name']:continue
  for r in f['regions']:
   if f['filenames'][r[5]].endswith('/trigger-host/src/runtime.rs') and r[7]==0:c[tuple(r[:4])]+=r[4]
 q['functions'][name]={'normal_code_source_regions':len(c),'hit':sum(v>0 for v in c.values()),'unhit':[list(k) for k,v in c.items() if v==0],'counts':{str(k):v for k,v in c.items()}}
assert q['functions']['flush_parameters']['normal_code_source_regions']==58;assert q['functions']['flush_parameters']['hit']==57;assert q['functions']['apply_parameter']['hit']==q['functions']['apply_parameter']['normal_code_source_regions']==21
c=collections.defaultdict(int)
for f in d['functions']:
 for r in f['regions']:
  if f['filenames'][r[5]].endswith('/trigger-host/src/runtime.rs') and r[7]==0 and r[0]<1215:c[tuple(r[:4])]+=r[4]
q['merged_production_normal_regions']={'total':len(c),'hit':sum(v>0 for v in c.values()),'unhit':[list(k) for k,v in c.items() if not v]};q['llvm_reported_runtime_summary']=next(f['summary'] for f in d['files'] if f['filename'].endswith('/trigger-host/src/runtime.rs'));q['limits']=json.loads(Path('/tmp/dandrum-lanes/evidence-parameter-flush/coverage-qualification.json').read_text())['limits'];(b/'coverage-qualification.json').write_text(json.dumps(q,indent=2)+'\n')
f=json.loads((b/'author-freeze.json').read_text())
for n,e in f['owned'].items():
 p=root/n;s=p.stat();assert (h(p),s.st_size,s.st_mode&511,s.st_mtime_ns)==(e['sha256'],e['size'],e['mode'],e['mtime_ns'])
old=subprocess.check_output(['git','show',':src/trigger-host/src/runtime.rs'],cwd=root);new=(root/'src/trigger-host/src/runtime.rs').read_bytes();separator=b'#[cfg(test)]\nmod admission_tests';assert old.split(separator)[0]==new.split(separator)[0];assert len(new.split(separator))==2
counts={}
for phase in ('03-full-host','04-full-owner-cov'):
 counts[phase]=[int(x) for x in re.findall(r'test result: ok\. (\d+) passed;', (b/phase/'output.log').read_text())]
assert sum(counts['03-full-host'][:-1])==146 and counts['03-full-host'][-1]==2 and sum(counts['04-full-owner-cov'])==146
assert 'running 1 test\n' in (b/'00-reset-oracle-corrected/output.log').read_text()
proof=json.loads((b/'05-profile-proof/proof.json').read_text());assert proof['raw_count']==len(proof['actual_executed_binaries'])==13 and proof['merged_byte_identical'] and proof['freeze_sha256']==h(b/'author-freeze.json')
processes=[]
for p in Path('/proc').iterdir():
 if p.name.isdecimal():
  try:comm=(p/'comm').read_text().strip()
  except (FileNotFoundError,PermissionError,ProcessLookupError):continue
  if comm in {'cargo','cargo-llvm-cov','rustc','clippy-driver','llvm-cov','llvm-profdata'}:processes.append((p.name,comm))
assert not processes
r={'finding':'R1','status':'Repaired existing reset regression oracle; fresh independent whole-candidate review pending','freeze':'author-freeze.json','freeze_sha256':h(b/'author-freeze.json'),'production_prefix_byte_identical_to_round1':True,'original_evidence_retained':'../evidence-parameter-flush','reset_oracle':'One stale nonzero sequence10 consumed by reset; discarded1/cancelled0; restored scalar0.25, settlement0/resetcausefalse unchanged; callback allocation/deallocation zero. Separate8-stale-scalar flush case retained using sequences20..27.','TDD':'Existing behavior characterization immediatePASS; no new production behavior, no fresh RED claimed; original feature RED preserved.','setup_correction':'Initial exact filter omitted runtime:: and selected0; retained as setup-only. Corrected unique filter ran1. No zero-selection result used as behavior proof.','counts':counts,'gates':{p.parent.name:json.loads(p.read_text()) for p in b.glob('*/receipt.json')},'profile_proof_sha256':h(b/'05-profile-proof/proof.json'),'coverage':'coverage-qualification.json','refactor':'Production unchanged. Kept two distinct witnessed transitions in existing real restoration fixture; no new production helper/seam.','resources_terminal':{'builders':processes,'disk_free_bytes':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'memory':next(l for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))},'limits':'Same native/release/CLAP/installed and mutation exclusions; no new acceptance claim.'}
assert all(g['exit']==0 for g in r['gates'].values());(b/'completion.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ('gates','counts')}))
