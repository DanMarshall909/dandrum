use dandrum_engine::graph::PortDirection;
use dandrum_engine::kernel::document::load_kernel_patch_str;
use dandrum_engine::patch::RenderSettings;
use dandrum_engine::preparation::{HostBuses, PreparationContext};
use dandrum_instrument_session::InstrumentSession;
use dandrum_trigger_host::TriggerHostConfiguration;
use dandrum_trigger_host::runtime::{
    ControlEvent, ParameterFeedback, PreparedRuntime, ProcessReport, RuntimeAudio, RuntimeControl,
    TimedEvent, runtime_handoff,
};

fn config() -> TriggerHostConfiguration {
    TriggerHostConfiguration {
        sample_rate_hz: 48_000,
        max_block_frames: 16,
    }
}
fn session(note: u8) -> InstrumentSession {
    let yaml = include_str!("../../../examples/patches/advanced-drum-kit.yaml").replacen(
        "key_range: [36, 36]",
        &format!("key_range: [{note}, {note}]"),
        1,
    );
    let patch = load_kernel_patch_str(&yaml).unwrap();
    let buses = patch
        .root()
        .ports()
        .iter()
        .fold(HostBuses::new(), |buses, port| match port.direction() {
            PortDirection::Input => buses.with_input(port.name(), 1),
            PortDirection::Output => buses.with_output(port.name(), 2),
        });
    InstrumentSession::new_for_planar_host(
        &yaml,
        PreparationContext::new(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../examples/patches"),
            48_000,
        ),
        RenderSettings {
            sample_rate_hz: 48_000,
            block_size_frames: 16,
            duration_frames: 16,
        },
        buses,
    )
    .unwrap()
}
fn prepared(note: u8) -> PreparedRuntime {
    PreparedRuntime::new(session(note).prepared(), config()).unwrap()
}
fn runtime(capacity: usize) -> (RuntimeControl, RuntimeAudio) {
    runtime_handoff(prepared(36), capacity).unwrap()
}
fn parameter(value: f64) -> ControlEvent {
    ControlEvent::Parameter { index: 2, value }
}
fn note() -> ControlEvent {
    ControlEvent::NoteOn {
        note: 36,
        velocity: 100,
    }
}
fn render<const N: usize>(
    audio: &mut RuntimeAudio,
    events: &[TimedEvent],
) -> ([f32; N], [f32; N], ProcessReport) {
    let (mut left, mut right) = ([1.0; N], [1.0; N]);
    let mut report = ProcessReport::default();
    let audit = allocation_counter::measure(|| {
        report = audio.process_events(&mut left, &mut right, events).unwrap();
    });
    assert_eq!(audit, allocation_counter::AllocationInfo::default());
    (left, right, report)
}
fn feedback(control: &mut RuntimeControl) -> Vec<ParameterFeedback> {
    std::iter::from_fn(|| control.take_feedback()).collect()
}

#[test]
fn ordinary_process_drains_fifo_scalars_and_note_before_timed_host_value_without_replaying_the_note()
 {
    let (mut control, mut audio) = runtime(4);
    for event in [parameter(0.5), note(), parameter(1.5)] {
        control.try_send(event).unwrap();
    }
    let output = render::<4>(
        &mut audio,
        &[TimedEvent {
            frame_offset: 3,
            event: parameter(1.0),
        }],
    );
    assert_eq!(
        output.0,
        [-0.75, -537.0 / 32768.0, 2331.0 / 32768.0, 4137.0 / 32768.0]
    );
    assert_eq!(output.0, output.1);
    assert_eq!(output.2.parameter_updates, 3);
    assert_eq!(
        feedback(&mut control),
        vec![
            ParameterFeedback {
                index: 2,
                value: 0.5,
                frame_offset: 0
            },
            ParameterFeedback {
                index: 2,
                value: 1.5,
                frame_offset: 0
            },
            ParameterFeedback {
                index: 2,
                value: 1.0,
                frame_offset: 3
            }
        ]
    );
    assert_eq!(control.parameter_value(2), Some(1.0));
    assert_eq!(
        render::<2>(&mut audio, &[]).0,
        [-2136.0 / 32768.0, 1664.0 / 32768.0]
    );
}

#[test]
fn invalid_complete_parameter_batch_preserves_values_feedback_fifo_and_pending_runtime() {
    use dandrum_trigger_host::runtime::{ParameterFlushReport, RuntimeError};
    let (mut control, mut audio) = runtime(4);
    control.try_send(parameter(0.25)).unwrap();
    render::<1>(&mut audio, &[]);
    for event in [parameter(0.5), note(), parameter(1.5)] {
        control.try_send(event).unwrap();
    }
    assert!(control.offer(prepared(36)).is_ok());
    let mut invalid = vec![
        vec![parameter(1.0); 5],
        vec![note()],
        vec![ControlEvent::NoteOff { note: 36 }],
        vec![ControlEvent::Parameter {
            index: usize::MAX,
            value: 1.0,
        }],
    ];
    for value in [
        f64::NAN,
        f64::INFINITY,
        f64::NEG_INFINITY,
        f64::MAX,
        -0.1,
        4.1,
    ] {
        invalid.push(vec![parameter(1.0), parameter(value)]);
    }
    for batch in invalid {
        let mut result = None;
        let audit = allocation_counter::measure(|| {
            result = Some(audio.flush_parameters(&batch));
        });
        assert_eq!(audit, allocation_counter::AllocationInfo::default());
        assert_eq!(result.unwrap(), Err(RuntimeError::InvalidEvent));
        assert_eq!(control.parameter_value(2), Some(0.25));
    }
    assert_eq!(
        feedback(&mut control),
        vec![ParameterFeedback {
            index: 2,
            value: 0.25,
            frame_offset: 0
        }]
    );
    let output = render::<4>(&mut audio, &[]);
    assert!(output.2.swapped);
    assert_eq!(output.2.parameter_updates, 2);
    assert_eq!(
        output.0,
        [-0.75, -537.0 / 32768.0, 2331.0 / 32768.0, 6205.5 / 32768.0]
    );
    assert_eq!(output.0, output.1);
    assert!(control.reclaim().is_some());
    assert_eq!(
        feedback(&mut control),
        vec![
            ParameterFeedback {
                index: 2,
                value: 0.5,
                frame_offset: 0
            },
            ParameterFeedback {
                index: 2,
                value: 1.5,
                frame_offset: 0
            }
        ]
    );
    let (_, mut empty) = runtime(4);
    assert_eq!(
        empty.flush_parameters(&[]),
        Ok(ParameterFlushReport::default())
    );
}
